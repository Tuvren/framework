// Cross-validate the Dependabot parse with the repository-pinned `yaml` package.
import { readFileSync } from "node:fs";
import { parse } from "/home/oscar/GitHub/Tuvren/framework-bo/node_modules/yaml/dist/index.js";

const text = readFileSync(
  "/home/oscar/GitHub/Tuvren/framework-bo/.github/dependabot.yml",
  "utf8",
);
const doc = parse(text) as {
  updates: Array<{
    "package-ecosystem": string;
    directory: string;
    ignore?: Array<{ "dependency-name": string; versions?: string[] }>;
  }>;
};
const bun = doc.updates.find(
  (u) => u["package-ecosystem"] === "bun" && u.directory === "/",
)!;
console.log(`yaml-package bun ignore: ${JSON.stringify(bun.ignore)}`);
const names = (bun.ignore ?? []).map((i) => i["dependency-name"]);
for (const held of ["bun", "bun-types", "@types/bun"]) {
  if (names.includes(held)) {
    console.log(`FAIL: hold present for ${held}`);
    process.exit(1);
  }
}
console.log("yaml-package cross-check PASS: no bun/bun-types/@types/bun holds");
