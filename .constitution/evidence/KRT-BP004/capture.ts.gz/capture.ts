// M6 invariant capture: parsed-JSON canonical forms + evidence digests.
// Usage: bun capture.ts <baseline|after> <outfile>
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { spawnSync } from "node:child_process";

const REPO = "/home/oscar/GitHub/Tuvren/framework-bp";
const mode = process.argv[2];
const out = process.argv[3];
if (mode !== "baseline" && mode !== "after") throw new Error("mode");

function sortedStringify(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(sortedStringify).join(",")}]`;
  const entries = Object.entries(value as Record<string, unknown>).sort((a, b) =>
    a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0
  );
  return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${sortedStringify(v)}`).join(",")}}`;
}

function sha256(data: Buffer | string): string {
  return createHash("sha256").update(data).digest("hex");
}

function gitShow(path: string): Buffer {
  const r = spawnSync("git", ["show", `HEAD:${path}`], { cwd: REPO });
  if (r.status !== 0) throw new Error(`git show ${path}: ${r.stderr.toString()}`);
  return r.stdout;
}

const ls = spawnSync("git", ["ls-files", "-z"], { cwd: REPO });
const paths = ls.stdout.toString().split("\0").filter(Boolean);

const parsedJson: Record<string, string> = {};
const rawHashes: Record<string, string> = {};
for (const p of paths) {
  if (!p.endsWith(".json")) continue;
  const buf = mode === "baseline" ? gitShow(p) : readFileSync(`${REPO}/${p}`);
  try {
    parsedJson[p] = sha256(sortedStringify(JSON.parse(buf.toString("utf8"))));
  } catch {
    rawHashes[p] = sha256(buf);
  }
}

// Evidence digests (raw bytes).
const ev = spawnSync("find", [".constitution/evidence", "-type", "f"], { cwd: REPO });
const evidence: Record<string, string> = {};
for (const p of ev.stdout.toString().split("\n").filter(Boolean)) {
  evidence[p.replace(/^\.\//, "")] = sha256(readFileSync(`${REPO}/${p}`));
}

// Constitution tracked files digest (all, to be safe).
const constitution: Record<string, string> = {};
for (const p of paths) {
  if (!p.startsWith(".constitution/")) continue;
  const buf = mode === "baseline" ? gitShow(p) : readFileSync(`${REPO}/${p}`);
  constitution[p] = sha256(buf);
}

writeFileSync(out, JSON.stringify({ mode, parsedJson, rawHashes, evidence, constitution }, null, 2));
console.log(`wrote ${out}: ${Object.keys(parsedJson).length} parsed json, ${Object.keys(evidence).length} evidence, ${Object.keys(constitution).length} constitution`);
