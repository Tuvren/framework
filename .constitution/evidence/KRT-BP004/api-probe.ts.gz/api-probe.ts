import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdir, readFile, symlink } from "node:fs/promises";
import { isDeepStrictEqual } from "node:util";
import ts from "/home/oscar/GitHub/Tuvren/framework-bp/node_modules/typescript/lib/typescript.js";

const root = "/home/oscar/GitHub/Tuvren/framework-bp";
const probe = "/home/oscar/.cache/pig-subagent/framework/wf-bp/M6/api-writer-probe";
const snapshotPath = `${root}/tools/scripts/__snapshots__/api-surface/api-surface-snapshot.json`;
const source = await readFile(`${root}/tools/scripts/api-freeze-gate.ts`, "utf8");
const original = await readFile(snapshotPath);
const sourceFile = ts.createSourceFile("api-freeze-gate.ts", source, ts.ScriptTarget.Latest, true);
const functions = sourceFile.statements.filter(ts.isFunctionDeclaration).filter((node) => node.name?.text === "readSnapshot" || node.name?.text === "writeSnapshot");
const declaration = sourceFile.statements.filter(ts.isInterfaceDeclaration).find((node) => node.name.text === "SnapshotFile");
if (functions.length !== 2 || !declaration) throw new Error("API writer signature changed");
await mkdir(probe, { recursive: true });
try { await symlink(`${root}/node_modules`, `${probe}/node_modules`); }
catch (error: unknown) {
  if (error === null || typeof error !== "object" || !("code" in error) || error.code !== "EEXIST") throw error;
}
await Bun.write(`${probe}/snapshot.json`, original);
await Bun.write(`${probe}/oxfmt.config.ts`, `import config from ${JSON.stringify(`${root}/oxfmt.config.ts`)};\nexport default { ...config, ignorePatterns: [] };\n`);
await Bun.write(`${probe}/writer.ts`, `
import {spawnSync} from "node:child_process";
import {mkdir, readFile, writeFile} from "node:fs/promises";
import path from "node:path";
import {isDeepStrictEqual} from "node:util";
import type {ApiSurface} from ${JSON.stringify(`${root}/tools/scripts/lib/api-freeze-model.ts`)};
const REPO_ROOT = ${JSON.stringify(probe)};
const SNAPSHOT_PATH = ${JSON.stringify(`${probe}/snapshot.json`)};
${declaration.getText(sourceFile)}
${functions.map((node) => node.getText(sourceFile)).join("\n")}
const before = await readSnapshot();
if (!before) throw new Error("probe baseline missing");
await writeSnapshot(before.entrypoints, "probe-only", ["isolated formatter invocation"]);
const after = await readSnapshot();
if (!after || after.ledger.length !== before.ledger.length + 1 || !isDeepStrictEqual(before.ledger, after.ledger.slice(0, -1)) || !isDeepStrictEqual({...before, ledger: after.ledger}, after)) throw new Error("isolated writer changed baseline ledger or surface");
console.log(JSON.stringify({baselineLedger: before.ledger.length, afterLedger: after.ledger.length, ledgerPreserved: true, rootFieldsPreserved: true, entrypointsPreserved: true, parsedFormatterGuardPassed: true}));
`);
const child = Bun.spawn([process.execPath, `${probe}/writer.ts`], { cwd: probe, stdout: "pipe", stderr: "pipe" });
const [stdout, stderr, exitCode] = await Promise.all([new Response(child.stdout).text(), new Response(child.stderr).text(), child.exited]);
assert.equal(exitCode, 0, stderr || stdout);
assert.ok(isDeepStrictEqual(original, await readFile(snapshotPath)), "repository API snapshot changed");
const report = { command: "Bun executes unchanged readSnapshot/writeSnapshot bodies against isolated snapshot; formatter discovery only is overridden for scratch", sourceSha256: createHash("sha256").update(source).digest("hex"), originalSnapshotSha256: createHash("sha256").update(original).digest("hex"), exitCode, writer: JSON.parse(stdout), repositorySnapshotBytesPreserved: true };
await Bun.write("/home/oscar/.cache/pig-subagent/framework/wf-bp/M6/api-writer-probe.json", JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify(report));
