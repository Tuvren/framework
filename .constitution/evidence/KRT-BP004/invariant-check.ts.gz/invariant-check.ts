import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { readFile } from "node:fs/promises";

const root = "/home/oscar/GitHub/Tuvren/framework-bp";
const baselineCommit = "c33c65725a597991adbe12215919b3804d3a81a8";
const scratch = "/home/oscar/.cache/pig-subagent/framework/wf-bp/M6";
interface Capture {
  mode: string;
  parsedJson: Record<string, string>;
  rawHashes: Record<string, string>;
  evidence: Record<string, string>;
  constitution: Record<string, string>;
}
function record(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function hashes(value: unknown): value is Record<string, string> {
  return record(value) && Object.values(value).every((hash) => typeof hash === "string" && /^[a-f0-9]{64}$/u.test(hash));
}
function capture(value: unknown): value is Capture {
  return record(value) && typeof value.mode === "string" && hashes(value.parsedJson) && hashes(value.rawHashes) && hashes(value.evidence) && hashes(value.constitution);
}
const before: unknown = JSON.parse(await readFile(`${scratch}/baseline.json`, "utf8"));
const after: unknown = JSON.parse(await readFile(`${scratch}/lead-after.json`, "utf8"));
if (!capture(before) || !capture(after)) throw new Error("Invalid invariant capture");
assert.equal(before.mode, "baseline");
assert.equal(after.mode, "after");
const beforeJson = { ...before.parsedJson };
const afterJson = { ...after.parsedJson };
assert.ok(beforeJson["package.json"] && afterJson["package.json"]);
delete beforeJson["package.json"];
delete afterJson["package.json"];
assert.deepStrictEqual(afterJson, beforeJson, "parsed authority changed");
assert.deepStrictEqual(after.rawHashes, before.rawHashes, "non-parsed JSON bytes changed");
assert.deepStrictEqual(after.evidence, before.evidence, "evidence bytes changed");
assert.deepStrictEqual(after.constitution, before.constitution, "constitution bytes changed");

const git = spawnSync("git", ["show", `${baselineCommit}:package.json`], { cwd: root, encoding: "utf8" });
if (git.status !== 0) throw new Error(git.stderr || "git show failed");
const expected: unknown = JSON.parse(git.stdout);
const actual: unknown = JSON.parse(await readFile(`${root}/package.json`, "utf8"));
if (!record(expected) || !record(expected.scripts) || !record(actual) || !record(actual.scripts)) throw new Error("Invalid package manifest");
assert.equal(expected.scripts.format, "bunx --bun @biomejs/biome check --write .");
expected.scripts.format = "bunx --bun oxfmt --write .";
assert.deepStrictEqual(actual, expected, "root package changed beyond the format command");

// Direct parsed comparisons also cover JSONC and numeric distinctions such as
// -0 that a canonical JSON hash alone cannot distinguish.
const changed = spawnSync("git", ["diff", "--name-only", "-z", baselineCommit, "--"], { cwd: root, encoding: "utf8" });
if (changed.status !== 0) throw new Error(changed.stderr || "git diff failed");
let changedDocuments = 1;
for (const path of changed.stdout.split("\0")) {
  if (path === "package.json" || !/\.jsonc?$/u.test(path)) continue;
  const old = spawnSync("git", ["show", `${baselineCommit}:${path}`], { cwd: root, encoding: "utf8", maxBuffer: 32 * 1024 * 1024 });
  if (old.status !== 0) throw new Error(old.stderr || `git show failed: ${path}`);
  const parse = path.endsWith(".jsonc") ? Bun.JSONC.parse : JSON.parse;
  const oldValue: unknown = parse(old.stdout);
  const newValue: unknown = parse(await readFile(`${root}/${path}`, "utf8"));
  assert.deepStrictEqual(newValue, oldValue, `${path} parsed values changed`);
  changedDocuments += 1;
}

assert.throws(() => assert.deepStrictEqual({ ...afterJson, "unexpected.json": "0".repeat(64) }, beforeJson));
assert.throws(() => assert.deepStrictEqual({ ...after.evidence, "unexpected-evidence": "0".repeat(64) }, before.evidence));
assert.throws(() => assert.deepStrictEqual({ ...actual, private: "changed" }, expected));
assert.throws(() => assert.deepStrictEqual(-0, 0));
const report = { baselineCommit, parsedJson: Object.keys(before.parsedJson).length, changedDocuments, evidence: Object.keys(before.evidence).length, constitution: Object.keys(before.constitution).length, allPreserved: true, soleAllowedValueChange: "package.json scripts.format", mutationControls: 4 };
await Bun.write(`${scratch}/lead-invariant.json`, JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify(report));
