import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import ts from "/home/oscar/GitHub/Tuvren/framework-bp/node_modules/typescript/lib/typescript.js";

const root = "/home/oscar/GitHub/Tuvren/framework-bp";
const baseline = process.argv[2] ?? "c33c65725a597991adbe12215919b3804d3a81a8";
const sourcePattern = /\.(?:[cm]?js|[cm]?ts|[jt]sx)$/u;

function git(args: string[]): string {
  const result = spawnSync("git", args, { cwd: root, encoding: "utf8", maxBuffer: 32 * 1024 * 1024 });
  if (result.status !== 0) throw new Error(result.stderr || `git failed: ${result.status}`);
  return result.stdout;
}

interface SyntaxRecord { kind: number; text: string; flags: number; children: SyntaxRecord[]; }
function syntax(node: ts.Node, normalizeImportOrder = false): SyntaxRecord {
  if (ts.isParenthesizedExpression(node)) return syntax(node.expression, normalizeImportOrder);
  const children: SyntaxRecord[] = [];
  ts.forEachChild(node, (child) => { children.push(syntax(child, normalizeImportOrder)); });
  // Sorting named bindings does not reorder module evaluation. Import
  // declarations themselves retain their order, so their movement is flagged.
  if (ts.isNamedImports(node) || ts.isNamedExports(node)) children.sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
  if (ts.isSourceFile(node) && normalizeImportOrder) {
    const imports = children.filter((child) => child.kind === ts.SyntaxKind.ImportDeclaration).sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
    const statements = children.filter((child) => child.kind !== ts.SyntaxKind.ImportDeclaration);
    children.splice(0, children.length, ...imports, ...statements);
  }
  const text = ts.isIdentifier(node) || ts.isPrivateIdentifier(node) || ts.isLiteralExpression(node) || ts.isTemplateLiteralToken(node) ? node.text : "";
  const flags = ts.isVariableDeclarationList(node) ? node.flags & (ts.NodeFlags.Let | ts.NodeFlags.Const | ts.NodeFlags.Using) : node.flags & ts.NodeFlags.OptionalChain;
  return { kind: node.kind, text, flags, children };
}

function parse(source: string, name = "control.ts", normalizeImportOrder = false): string {
  return JSON.stringify(syntax(ts.createSourceFile(name, source, ts.ScriptTarget.Latest, true), normalizeImportOrder));
}

assert.equal(parse('const x = ("value");'), parse("const x='value'"));
assert.equal(parse('import { b, a } from "pkg";'), parse('import { a, b } from "pkg";'));
assert.notEqual(parse("const x=1+2"), parse("const x=1-2"));
assert.notEqual(parse("const x=1"), parse("let x=1"));
assert.notEqual(parse('const x="a"'), parse('const x="b"'));
assert.notEqual(parse('import "a";import "b";'), parse('import "b";import "a";'));
assert.equal(parse('import "a";import "b";', "control.ts", true), parse('import "b";import "a";', "control.ts", true));
assert.notEqual(parse('import "a";', "control.ts", true), parse('import "b";', "control.ts", true));

interface Difference { path: string; before: string; after: string; importOrderOnly: boolean; }
const differences: Difference[] = [];
let compared = 0;
for (const path of git(["diff", "--name-only", "-z", baseline, "--"]).split("\0")) {
  if (!sourcePattern.test(path)) continue;
  const beforeSource = git(["show", `${baseline}:${path}`]);
  const afterSource = await readFile(`${root}/${path}`, "utf8");
  const before = parse(beforeSource, path);
  const after = parse(afterSource, path);
  compared += 1;
  if (before !== after) differences.push({ path, before: createHash("sha256").update(before).digest("hex"), after: createHash("sha256").update(after).digest("hex"), importOrderOnly: parse(beforeSource, path, true) === parse(afterSource, path, true) });
}
const report = { baseline, compilerVersion: ts.version, compared, differences, controls: 8, unexplained: differences.filter((difference) => !difference.importOrderOnly).length };
await Bun.write("/home/oscar/.cache/pig-subagent/framework/wf-bp/M6/syntax-comparison.json", JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify(report));
if (report.unexplained > 0) process.exitCode = 1;
