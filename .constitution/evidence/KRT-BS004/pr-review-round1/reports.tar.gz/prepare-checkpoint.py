from pathlib import Path
repo=Path.cwd()
out=Path('/tmp/tuvren-bs-pr-fix1')
original=(repo/'typescript/kernel/testkit/test/native-admission.test.ts').read_text()
old='''    const waiting = delay(0);
    calls.push("called");
    await waiting;
    calls.push("completed");
    deepStrictEqual(calls, ["called", "completed"]);'''
new='''    const waiting = delay(0);
    calls.push("called");
    const observeCompletion = async (): Promise<void> => {
      await waiting;
      calls.push("completed");
    };
    const completion = observeCompletion();
    // A timer stays pending through this checkpoint, unlike an immediate result.
    const checkpoint = Promise.withResolvers<void>();
    queueMicrotask(checkpoint.resolve);
    await checkpoint.promise;
    deepStrictEqual(calls, ["called"]);
    await completion;
    deepStrictEqual(calls, ["called", "completed"]);'''
assert original.count(old)==1
candidate=original.replace(old,new)
(out/'candidate-native-admission.ts.txt').write_text(candidate)
for name,delay in [('immediate', 'const delay = (): Promise<void> => Promise.resolve();'), ('async-immediate', 'const delay = async (): Promise<void> => { await Promise.resolve(); };'), ('real', f'import {{ delay }} from "{repo}/typescript/kernel/testkit/src/lib/kernel-test-fixtures.ts";')]:
    test=candidate.replace('  delay,\n','').replace('../src/lib/',str(repo)+'/typescript/kernel/testkit/src/lib/')
    test=test.replace('describe("kernel',delay+'\n\ndescribe("kernel')
    (out/(name+'.test.ts')).write_text(test)
