import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,openSync,closeSync} from 'node:fs';
import {spawnSync,execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import path from 'node:path';
const repo=process.cwd(),bundle=import.meta.dir,out=process.argv[2]??path.join(bundle,'final');mkdirSync(out,{recursive:true});
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const snapshot=()=>{
 const files=[...new Set([...execFileSync('git',['ls-files','-z'],{encoding:'utf8'}).split('\0'),...execFileSync('git',['ls-files','--others','--exclude-standard','-z'],{encoding:'utf8'}).split('\0')])].filter(Boolean).sort();
 return {head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),index:sha(execFileSync('git',['ls-files','--stage','-z'])),status:execFileSync('git',['status','--porcelain=v1','-z'],{encoding:'utf8'}),hashes:Object.fromEntries(files.map(file=>[file,sha(readFileSync(file))]))};
};
const before=snapshot();writeFileSync(out+'/tree-before.json',JSON.stringify(before,null,2)+'\n');
const commands=[
 ['01-native-testkit',['bunx','--bun','oxlint','--type-aware','typescript/kernel/testkit']],
 ['02-json-testkit',['bun','tools/scripts/json-check.ts','typescript/kernel/testkit']],
 ['03-typecheck',['bun','run','nx','run','kernel-testkit:typecheck']],
 ['04-test',['bun','run','nx','run','kernel-testkit:test']],
 ['05-conformance',['bun','run','nx','run','kernel-testkit:conformance']],
 ['06-exports-smoke',['bun','run','nx','run','kernel-testkit:exports-smoke']],
 ['07-full-lint',['bun','run','lint']],
 ['08-api-freeze',['bun','run','api-freeze:check']],
 ['09-changeset',['bun','run','changeset:check','--base=master']],
 ['10-kernel-verify',['bun','run','verify:kernel']],
 ['11-format',['bunx','--bun','oxfmt','--check','typescript/kernel/testkit/src/lib/fault-injecting-backend.ts','typescript/kernel/testkit/test/native-admission.test.ts']],
 ['12-diff',['git','diff','--check']],
 ['13-all-five-canonical',['bun','run','nx','run-many','-t','lint','--projects=kernel-grpc-client,kernel-testkit,kernel-typescript-certification,kernel-typescript-sqlite-certification,kernel-typescript-postgres-certification','--skipNxCache','--parallel=1']],
 ['14-all-five-native-json',['bunx','--bun','oxlint','--type-aware','--format=json','typescript/kernel/grpc-client','typescript/kernel/testkit','typescript/kernel/certification','typescript/kernel/certification-sqlite','typescript/kernel/certification-postgres']],
 ['15-admission',['bun',path.join(bundle,'admission-proof.mjs'),path.join(out,'admission')]],
 ['16-program',['bun',path.join(bundle,'program.mjs'),path.join(out,'program.json')]],
 ['17-hash',['bun',path.join(bundle,'hash.mjs'),path.join(out,'hash.json')]],
 ['18-replay',['bun',path.join(bundle,'replay.mjs'),bundle,out]],
 ['19-test-proof',['bun',path.join(bundle,'test-proof.mjs'),path.join(out,'test-proof')]]
];
const results=[];let failure;
const execute=(name,command)=>{
 const fd=openSync(out+'/'+name+'.log','w'),started_at=new Date().toISOString();console.log(started_at,'START',name,command.join(' '));let r;
 try{r=spawnSync(command[0],command.slice(1),{cwd:repo,env:{...process.env,LC_ALL:'C',NX_DAEMON:'false'},stdio:['ignore',fd,fd]});}finally{closeSync(fd);}
 const result={name,command,cwd:repo,exit_code:r.status,started_at,finished_at:new Date().toISOString(),log:name+'.log'};
 results.push(result);writeFileSync(out+'/'+name+'.json',JSON.stringify(result,null,2)+'\n');console.log(result.finished_at,'END',name,r.status);return result;
};
try{
 for(const [name,command] of (process.argv[3]==='remaining'?commands.slice(13):commands)){
  const result=execute(name,command);
  assert.deepEqual(snapshot(),before,'ALL tracked/index/new source frozen after '+name);
  if(['05-conformance','09-changeset','10-kernel-verify'].includes(name)){
   const fetch=execute(name+'-fetch',['git','fetch','origin','master']);if(fetch.exit_code!==0){failure=name+'-fetch';break;}
  }
  if(result.exit_code!==0){failure=name;break;}
  if(name==='14-all-five-native-json'){
   const native=JSON.parse(readFileSync(out+'/'+name+'.log','utf8'));assert(Array.isArray(native.diagnostics));assert.deepEqual(native.diagnostics,[]);assert.equal(native.number_of_files,25);assert.equal(native.number_of_rules,474);
  }
 }
}catch(error){failure??='proof-or-freeze';writeFileSync(out+'/exception.log',String(error.stack));}
finally{
 const cleanup=execute('fetch-cleanup',['git','fetch','origin','master']);const after=snapshot();writeFileSync(out+'/tree-after.json',JSON.stringify(after,null,2)+'\n');
 const frozen=JSON.stringify(after)===JSON.stringify(before);
 writeFileSync(out+'/results.json',JSON.stringify({status:failure||cleanup.exit_code!==0||!frozen?'fail':'pass',failure,tracked_and_new_files:Object.keys(before.hashes).length,all_tracked_index_and_new_source_frozen:frozen,full_verify_repeated:false,full_verify_reason:'Scoped comment/test-only review correction; all production normalized AST/signatures/bodies equal historical d04b M10 snapshot. Prior complete serial verify remains historical.',results},null,2)+'\n');
 assert(frozen,'tracked/index/new source drift');assert(!failure,failure);assert.equal(cleanup.exit_code,0);
}
