from pathlib import Path
import subprocess
root=Path('/tmp/tuvren-bs-pr-fix1')
file=root/'gates.mjs'
source=file.read_text()
source=source.replace("assert.equal(native.number_of_warnings,0);assert.equal(native.number_of_errors,0);assert.deepEqual(native.diagnostics,[]);","assert(Array.isArray(native.diagnostics));assert.deepEqual(native.diagnostics,[]);assert.equal(native.number_of_files,25);assert.equal(native.number_of_rules,474);")
source=source.replace("for(const [name,command] of commands)","for(const [name,command] of (process.argv[3]==='remaining'?commands.slice(13):commands))")
file.write_text(source)
file=root/'admission-proof.mjs'
source=file.read_text().replace("'../final/18-native-all-five.json'","'../14-all-five-native-json.log'")
file.write_text(source)
for name in ['admission-proof.mjs','replay.mjs']:
    result=subprocess.run(['diff','-u',str(root/'baseline'/('m10-original-'+name)),str(root/name)],capture_output=True,text=True)
    assert result.returncode==1
    (root/(name+'.adaptation.patch')).write_text(result.stdout)
