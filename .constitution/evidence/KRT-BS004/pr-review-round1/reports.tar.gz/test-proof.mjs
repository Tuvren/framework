import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
const out = process.argv[2];mkdirSync(out,{recursive:true});
const repo=process.cwd(), file='typescript/kernel/testkit/test/native-admission.test.ts';
const source=readFileSync(file,'utf8');
const rows=[];
const run=(name,test,expected) => {
  const result=spawnSync('bun',['test',test],{cwd:repo,encoding:'utf8'});
  writeFileSync(path.join(out,name+'.log'),result.stdout+result.stderr);
  rows.push({name,command:['bun','test',test],exit_code:result.status,expected_exit_code:expected});
  assert.equal(result.status,expected,name);
  if(expected===1){assert.match(result.stderr,/3 pass/);assert.match(result.stderr,/1 fail/);assert.match(result.stderr,/deepStrictEqual\(calls, \["called"\]\)/);assert.match(result.stderr,/delay waits for its timer before completing/);}
  else assert.match(result.stderr,/4 pass/);
};
const mutants={immediate:'const delay = (): Promise<void> => Promise.resolve();',async_immediate:'const delay = async (): Promise<void> => { await Promise.resolve(); };'};
for(const [name,mutation] of Object.entries(mutants)){
  const mutant=source.replace('  delay,\n','').replaceAll('../src/lib/',repo+'/typescript/kernel/testkit/src/lib/').replace('describe("kernel',mutation+'\n\ndescribe("kernel');
  assert.notEqual(mutant,source);
  const target=path.join(out,name+'.test.ts');writeFileSync(target,mutant);
  run(name,target,1);
}
for(let attempt=1;attempt<=10;attempt++)run('positive-'+attempt,file,0);
const result={status:'pass',source_file:file,mutants_fail_at_pending_assertion:2,positive_runs:10,positive_tests:40,wall_clock_thresholds:false,fake_clock:false,promise_identity_guarantees:false,microtask_count_guarantees:false,rows};
writeFileSync(path.join(out,'summary.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
