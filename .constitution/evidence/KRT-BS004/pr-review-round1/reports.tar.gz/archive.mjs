import assert from 'node:assert/strict';
import {readdirSync,statSync,readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import path from 'node:path';
const root=import.meta.dir,sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const summaryFile=path.join(root,'summary.json');const summary=JSON.parse(readFileSync(summaryFile,'utf8'));
summary.ownership.source_ownership_released=true;
summary.portable_replay={proof:'outer-index.json#portable_replay',archive:'reports.tar.gz',instructions:'REPLAY.md',requires_original_worker_tmp_directory:false};
writeFileSync(summaryFile,JSON.stringify(summary,null,2)+'\n');
const excluded=new Set(['original-m10','reports.tar.gz','reports.tar.gz.sha256','digest-index.json','outer-index.json','portable-replay-proof.json','archive-files.nul','archive.log','admission-adaptation.patch']);
const members=[];
const visit=(relative='')=>{
 for(const name of readdirSync(path.join(root,relative)).sort()){
  if(relative===''&&excluded.has(name))continue;
  const file=path.join(relative,name),absolute=path.join(root,file),stat=statSync(absolute);
  if(stat.isDirectory())visit(file);else if(stat.isFile()){const data=readFileSync(absolute);members.push({path:file,bytes:data.length,sha256:sha(data)});}
 }
};visit();
writeFileSync(path.join(root,'archive-files.nul'),members.map(x=>x.path+'\0').join(''));
execFileSync('tar',['-czf',path.join(root,'reports.tar.gz'),'--null','-T',path.join(root,'archive-files.nul')],{cwd:root});
const archive=readFileSync(path.join(root,'reports.tar.gz'));
const index={schema_version:1,archive:'reports.tar.gz',archive_sha256:sha(archive),archive_bytes:archive.length,members};
writeFileSync(path.join(root,'digest-index.json'),JSON.stringify(index,null,2)+'\n');
writeFileSync(path.join(root,'reports.tar.gz.sha256'),index.archive_sha256+'  reports.tar.gz\n');
console.log(JSON.stringify({sha256:index.archive_sha256,bytes:index.archive_bytes,members:members.length}));
