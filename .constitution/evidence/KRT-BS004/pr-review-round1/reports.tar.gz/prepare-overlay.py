from pathlib import Path
import json, subprocess, hashlib
out=Path('/tmp/tuvren-bs-pr-fix1'); original=out/'original-m10'
base='89fbfdb8d9e4944f332ee22fb597c6b822d32aeb'
m10=subprocess.check_output(['git','rev-parse','d04b04d'],text=True).strip()
fingerprints=json.loads((original/'final-source-hashes.json').read_text())['files']
old={}
for path,digest in fingerprints.items():
    source=subprocess.check_output(['git','show',m10+':'+path])
    assert hashlib.sha256(source).hexdigest()==digest,path
    old[path]=source.decode()
(out/'baseline').mkdir(exist_ok=True)
(out/'baseline/owned-sources.json').write_text(json.dumps({'commit':m10,'files':old},indent=2)+'\n')
(out/'baseline/m10-fingerprints.json').write_bytes((original/'final-source-hashes.json').read_bytes())
(out/'baseline/m10-digest-index.json').write_bytes(Path('.constitution/evidence/KRT-BS004/m10-digest-index.json').read_bytes())
(out/'baseline/m10-manifest.json').write_bytes(Path('.constitution/evidence/KRT-BS004/manifest.yaml').read_bytes())
(out/'baseline/program.json').write_bytes((original/'baseline/program.json').read_bytes())
changed=['typescript/kernel/testkit/src/lib/fault-injecting-backend.ts','typescript/kernel/testkit/test/native-admission.test.ts']
(out/'baseline/approved-delta.json').write_text(json.dumps({'base':base,'m10_commit':m10,'original_m10_archive_sha256':hashlib.sha256(Path('.constitution/evidence/KRT-BS004/m10-reports.tar.gz').read_bytes()).hexdigest(),'files':{p:{'before':fingerprints[p],'after':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in changed}},indent=2)+'\n')
for file in ['program.mjs','hash.mjs']:(out/file).write_bytes((original/file).read_bytes())
text=(original/'admission-proof.mjs').read_text()
# Keep original selected-file, raw-ownership, policy, JSON, command and suppression checks intact.
old_line="for(const root of roots.slice(0,2)){const files=sourceInventories.find(x=>x.root===root).files;for(const file of files)assert.equal(readFileSync(file,'utf8'),run('preserved-'+file.replaceAll('/','_')+'.json',['git','show','HEAD:'+file]),'reviewed M8/M9 region unchanged '+file);}"
new_line="const sourceProof=await verifySources(out+'/source-proof.json'); assert.deepEqual(sourceProof.changed_paths, Object.keys(approved.files).sort());"
assert text.count(old_line)==1
text=text.replace(old_line,new_line).replace("['git','show','HEAD:'+file]", "['git','show',approved.m10_commit+':'+file]")
text="import {verifySources,approved} from './source-proof.mjs';\n"+text
text=text.replace('reviewed_M8_M9_regions_byte_identical:true','reviewed_M8_M9_regions_byte_identical:false,post_admission_review_delta:sourceProof.changed_paths,unchanged_production_ast:true,remaining_M10_fingerprints_identical:true')
text=text.replace("milestone:'M10'","milestone:'PR151-round1-overlay'")
(out/'admission-proof.mjs').write_text(text)
(out/'admission-adaptation.patch').write_text(subprocess.check_output(['diff','-u',str(original/'admission-proof.mjs'),str(out/'admission-proof.mjs')],text=True) if False else '')
replay=(original/'replay.mjs').read_text()
old_loop="const fingerprint=read(path.join(report,'final-source-hashes.json'));for(const [file,expected]of Object.entries(fingerprint.files))assert.equal(sha(readFileSync(file)),expected,'current source fingerprint '+file);"
new_loop="const fingerprint=read(path.join(report,'baseline/m10-fingerprints.json'));const sourceProof=await verifySources(path.join(out,'source-proof.json'));"
assert replay.count(old_loop)==1
replay="import {verifySources} from './source-proof.mjs';\n"+replay.replace(old_loop,new_loop)
replay=replay.replace("measurement_base_head:fingerprint.measurement_base_head,measurement_kind:fingerprint.measurement_kind","measurement_base_head:sourceProof.base,measurement_kind:'post-admission-review-overlay',historical_m10:sourceProof.m10_commit,approved_delta:sourceProof.changed_paths")
(out/'replay.mjs').write_text(replay)
