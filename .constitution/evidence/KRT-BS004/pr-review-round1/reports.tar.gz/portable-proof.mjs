import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdtempSync,mkdirSync,openSync,closeSync} from 'node:fs';
import {execFileSync,spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import path from 'node:path';
import os from 'node:os';
const root=import.meta.dir,sha=bytes=>createHash('sha256').update(bytes).digest('hex'),read=file=>JSON.parse(readFileSync(file,'utf8'));
const index=read(path.join(root,'digest-index.json'));
assert.equal(sha(readFileSync(path.join(root,'reports.tar.gz'))),index.archive_sha256);
const extracted=mkdtempSync(path.join(os.tmpdir(),'tuvren-bs-pr151-extracted-')),out=path.join(extracted,'portable-results');mkdirSync(out);
execFileSync('tar',['-xzf',path.join(root,'reports.tar.gz'),'-C',extracted]);
for(const member of index.members){const data=readFileSync(path.join(extracted,member.path));assert.equal(data.length,member.bytes);assert.equal(sha(data),member.sha256);}
const before=read(path.join(root,'final/tree-before.json'));
const freeze=()=>{
 const actual=execFileSync('git',['ls-files','--cached','--others','--exclude-standard','-z'],{encoding:'utf8'}).split('\0').filter(Boolean).sort();
 assert.deepEqual(actual,Object.keys(before.hashes).sort());
 assert.equal(sha(execFileSync('git',['ls-files','--stage','-z'])),before.index);
 assert.equal(execFileSync('git',['status','--porcelain=v1','-z'],{encoding:'utf8'}),before.status);
 for(const file of actual)assert.equal(sha(readFileSync(file)),before.hashes[file],file);
};freeze();
const commands=[
 ['source-proof',['bun',path.join(extracted,'source-proof.mjs'),path.join(out,'source-proof.json')]],
 ['admission',['bun',path.join(extracted,'admission-proof.mjs'),path.join(out,'admission')]],
 ['program',['bun',path.join(extracted,'program.mjs'),path.join(out,'program.json')]],
 ['hash',['bun',path.join(extracted,'hash.mjs'),path.join(out,'hash.json')]],
 ['replay',['bun',path.join(extracted,'replay.mjs'),extracted,out]],
 ['test-proof',['bun',path.join(extracted,'test-proof.mjs'),path.join(out,'test-proof')]]
];
const results=[];
for(const [name,command]of commands){const fd=openSync(path.join(out,name+'.log'),'w');let result;try{result=spawnSync(command[0],command.slice(1),{cwd:process.cwd(),env:{...process.env,NX_DAEMON:'false'},stdio:['ignore',fd,fd]});}finally{closeSync(fd);}results.push({name,command,exit_code:result.status});assert.equal(result.status,0,name);freeze();}
const proof={status:'pass',archive_sha256:index.archive_sha256,indexed_members_verified:index.members.length,extracted_directory:extracted,replay_out:out,uses_only_final_archive_extracted_scripts_and_baselines:true,original_worker_tmp_not_a_replay_input:true,all2318_tracked_index_new_files_frozen:true,results};
writeFileSync(path.join(root,'portable-replay-proof.json'),JSON.stringify(proof,null,2)+'\n');
const external=['summary.json','REPLAY.md','reports.tar.gz','digest-index.json','portable-replay-proof.json','current-source-fingerprints.json'];
const outer={schema_version:1,exact_review_base:before.head,archive_sha256:index.archive_sha256,files:external.map(file=>{const data=readFileSync(path.join(root,file));return {path:file,bytes:data.length,sha256:sha(data)};}),portable_replay:proof};
writeFileSync(path.join(root,'outer-index.json'),JSON.stringify(outer,null,2)+'\n');console.log(JSON.stringify(proof));
