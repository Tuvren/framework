from pathlib import Path
import json,hashlib,tarfile
root=Path('/tmp/tuvren-bs-pr-fix1')
index=json.loads((root/'baseline/m10-digest-index.json').read_text())
archive=Path('.constitution/evidence/KRT-BS004/m10-reports.tar.gz')
assert archive.stat().st_size==index['archive_bytes']
assert hashlib.sha256(archive.read_bytes()).hexdigest()==index['archive_sha256']
with tarfile.open(archive,'r:gz') as tar:
    files={member.name:member for member in tar.getmembers() if member.isfile()}
    assert sorted(files)==sorted(member['path'] for member in index['members'])
    for member in index['members']:
        data=tar.extractfile(files[member['path']]).read()
        assert len(data)==member['bytes'],member['path']
        assert hashlib.sha256(data).hexdigest()==member['sha256'],member['path']
for name in ['admission-proof.mjs','replay.mjs']:
    (root/'baseline'/('m10-original-'+name)).write_bytes((root/'original-m10'/name).read_bytes())
(root/'original-archive-proof.json').write_text(json.dumps({'status':'pass','archive_sha256':index['archive_sha256'],'archive_bytes':index['archive_bytes'],'indexed_members_checked':len(index['members']),'every_original_member_unchanged':True},indent=2)+'\n')
