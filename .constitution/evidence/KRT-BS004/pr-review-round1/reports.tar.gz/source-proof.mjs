import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';
const bundle = import.meta.dir;
export const approved = JSON.parse(readFileSync(path.join(bundle, 'baseline/approved-delta.json'), 'utf8'));
const sha = value => createHash('sha256').update(value).digest('hex');
export const verifySources = async output => {
  const ts = (await import(Bun.resolveSync('typescript', process.cwd()))).default;
  const baseline = JSON.parse(readFileSync(path.join(bundle, 'baseline/owned-sources.json'), 'utf8'));
  const fingerprints = JSON.parse(readFileSync(path.join(bundle, 'baseline/m10-fingerprints.json'), 'utf8')).files;
  assert.equal(baseline.commit, approved.m10_commit);
  const roots = ['typescript/kernel/grpc-client', 'typescript/kernel/testkit', 'typescript/kernel/certification', 'typescript/kernel/certification-sqlite', 'typescript/kernel/certification-postgres'];
  const inventory = execFileSync('git', ['ls-files', '--cached', '--others', '--exclude-standard', '-z', '--', ...roots], {encoding:'utf8'}).split('\0').filter(Boolean).sort();
  assert.deepEqual([...inventory, 'tools/biome-coverage/bs.json'].sort(), Object.keys(fingerprints).sort());
  const printer = ts.createPrinter({removeComments:true});
  const normalized = (file, source) => {
    const ast = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
    const callables = [];
    const visit = node => {
      if (ts.isFunctionLike(node) && node.body) {
        const callable = printer.printNode(ts.EmitHint.Unspecified, node, ast);
        const body = printer.printNode(ts.EmitHint.Unspecified, node.body, ast);
        callables.push({kind:ts.SyntaxKind[node.kind], normalized_callable:sha(callable), normalized_body:sha(body)});
      }
      ts.forEachChild(node, visit);
    };
    visit(ast);
    return {file:printer.printFile(ast), callables};
  };
  const changed = [], production = [], current = {};
  for (const [file, expected] of Object.entries(fingerprints)) {
    const historical = baseline.files[file];
    assert.equal(sha(historical), expected, 'archived historical M10 source '+file);
    assert.equal(sha(execFileSync('git', ['show', approved.m10_commit+':'+file])), expected, 'actual historical M10 commit '+file);
    assert.equal(sha(execFileSync('git', ['show', approved.base+':'+file])), expected, 'exact review base matches historical M10 '+file);
    const source = readFileSync(file, 'utf8');
    current[file] = sha(source);
    if (current[file] !== expected) {
      assert(approved.files[file], 'unsanctioned M10 fingerprint delta '+file);
      assert.equal(current[file], approved.files[file].after, 'exact approved review change '+file);
      assert.equal(expected, approved.files[file].before);
      changed.push(file);
    }
    if (file.includes('/src/') && file.endsWith('.ts')) {
      const oldAst=normalized(file,historical), newAst=normalized(file,source);
      assert.deepEqual(newAst,oldAst,'complete production AST/callable/signature/body equality '+file);
      production.push({file, normalized_ast_sha256:sha(newAst.file), callable_count:newAst.callables.length, callables:newAst.callables});
    }
  }
  assert.deepEqual(changed.sort(),Object.keys(approved.files).sort());
  const result = {status:'pass',base:approved.base,m10_commit:approved.m10_commit,historical_snapshot_files:Object.keys(fingerprints).length,owned_root_files:inventory.length,unchanged_files:Object.keys(fingerprints).length-changed.length,changed_paths:changed,production_files:production.length,production_callables:production.reduce((n,x)=>n+x.callable_count,0),all_production_normalized_ast_signatures_and_bodies_unchanged:true,current_fingerprints:current,production};
  writeFileSync(output,JSON.stringify(result,null,2)+'\n');
  return result;
};
if (process.argv[1] === import.meta.path) console.log(JSON.stringify(await verifySources(process.argv[2])));
