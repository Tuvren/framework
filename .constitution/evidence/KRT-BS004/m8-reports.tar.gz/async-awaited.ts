export const rejectUnsupported = async (): Promise<never> =>
  await Promise.reject(new Error("unsupported"));
