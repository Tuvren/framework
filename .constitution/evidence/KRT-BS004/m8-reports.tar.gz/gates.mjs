import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const out = process.argv[2];
const digest=x=>createHash('sha256').update(x).digest('hex');
const git=(...args)=>{const r=spawnSync('git',args,{encoding:'utf8'});assert.equal(r.status,0,r.stderr);return r.stdout;};
const state=()=>({head:git('rev-parse','HEAD'),status:git('status','--porcelain=v1'),index:digest(git('ls-files','--stage','-z')),files:Object.fromEntries(git('ls-files','-z').split('\0').filter(Boolean).map(f=>[f,digest(readFileSync(f))]))});
const before=state();
const commands=[
 ['native',['bunx','--bun','oxlint','--type-aware','typescript/kernel/grpc-client']],
 ['json',['bun','tools/scripts/json-check.ts','typescript/kernel/grpc-client']],
 ['selection',['bunx','--bun','oxlint','--debug=files','typescript/kernel/grpc-client']],
 ['typecheck',['bun','run','nx','run','kernel-grpc-client:typecheck']],
 ['test',['bun','run','nx','run','kernel-grpc-client:test']],
 ['lint',['bun','run','lint']],
 ['api-freeze',['bun','run','api-freeze:check']],
 ['changeset',['bun','run','changeset:check','--base=master']],
 ['preset-controls',['bun','test','tools/scripts/oxc-preparation.test.ts']],
 ['partition-controls',['bun','test','tools/scripts/lib/biome-lint-partition.test.ts','tools/scripts/lib/biome-oxc-discovery.test.ts','tools/scripts/oxc-project-discovery.test.ts','tools/scripts/lib/json-source-integrity.test.ts','tools/scripts/biome-lint.test.ts']],
 ['format',['bunx','--bun','oxfmt','--check','typescript/kernel/grpc-client','tools/biome-coverage/bs.json']],
 ['diff',['git','diff','--check']],
];
const reports=[];
for(const [name,command] of commands){
 const started=Date.now();
 const r=spawnSync(command[0],command.slice(1),{cwd:process.cwd(),encoding:'utf8',env:{...process.env,NO_COLOR:'1',LC_ALL:'C',NX_TUI:'false'},maxBuffer:64*1024*1024});
 const report={name,command,cwd:process.cwd(),exit_code:r.status,elapsed_ms:Date.now()-started,stdout:r.stdout,stderr:r.stderr,stdout_sha256:digest(r.stdout),stderr_sha256:digest(r.stderr)};
 writeFileSync(`${out}/${name}.json`,JSON.stringify(report,null,2)+'\n');reports.push({...report,stdout:undefined,stderr:undefined});
 console.log(name,r.status,report.elapsed_ms);
 assert.deepEqual(state(),before,`${name}: all tracked/index state unchanged`);
 if(r.status!==0){writeFileSync(`${out}/gate-summary.json`,JSON.stringify({reports,status:'fail',failed:name},null,2)+'\n');process.exit(1);}
}
writeFileSync(`${out}/gate-summary.json`,JSON.stringify({reports,status:'pass',tracked_count:Object.keys(before.files).length,tracked_and_index_unchanged:true},null,2)+'\n');
