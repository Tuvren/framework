import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync,openSync,closeSync,unlinkSync} from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const repo=process.cwd(),out=process.argv[2];mkdirSync(out,{recursive:true});
const save=(name,value)=>writeFileSync(path.join(out,name),JSON.stringify(value,null,2)+'\n');
const run=(name,command)=>{const stdoutPath=path.join(out,'.stdout'),stderrPath=path.join(out,'.stderr');const stdoutFd=openSync(stdoutPath,'w'),stderrFd=openSync(stderrPath,'w');let r;try{r=spawnSync(command[0],command.slice(1),{cwd:repo,stdio:['ignore',stdoutFd,stderrFd],env:{...process.env,NO_COLOR:'1',LC_ALL:'C'}});}finally{closeSync(stdoutFd);closeSync(stderrFd);}const stdout=readFileSync(stdoutPath,'utf8'),stderr=readFileSync(stderrPath,'utf8');unlinkSync(stdoutPath);unlinkSync(stderrPath);save(name,{command,cwd:repo,exit_code:r.status,stdout,stderr});assert.equal(r.status,0,stderr);return stdout;};
const local=rel=>import(path.join(repo,rel));
const {loadNxProjectFiles}=await local('tools/scripts/lib/nx-projects.ts');
const {discoverNativeLintProjects}=await local('tools/scripts/lib/native-lint-routing.ts');
const {discoverJsonInventory,JSON_SOURCE_INTEGRITY_EXCLUSIONS}=await local('tools/scripts/lib/json-source-integrity.ts');
const {default:format}=await local('oxfmt.config.ts');
const projects=discoverNativeLintProjects(loadNxProjectFiles(repo));save('active-projects.json',projects);
const all=[...projects.oxcProjects,...projects.jsonOnlyProjects];
for(let i=0;i<all.length;i++)for(let j=i+1;j<all.length;j++)assert(!(all[i].root===all[j].root||all[i].root.startsWith(all[j].root+'/')||all[j].root.startsWith(all[i].root+'/')),`overlap ${all[i].name}/${all[j].name}`);
const codeOwners=[],jsonOwners=[],inventories=[];
const deps={repoRoot:repo,sourceIgnorePatterns:JSON_SOURCE_INTEGRITY_EXCLUSIONS,formatIgnorePatterns:format.ignorePatterns,runCommand:async(command,options)=>{const r=spawnSync(command[0],command.slice(1),{cwd:options?.cwd,encoding:'utf8',maxBuffer:64*1024*1024});return {code:r.status,stdout:r.stdout,stderr:r.stderr};}};
for(const project of all){
 if('jsonCompanion' in project){const selected=run(`${project.name}-selection.json`,['bunx','--bun','oxlint','--debug=files',project.root]).split(/\r?\n/u).map(x=>x.trim()).filter(Boolean);assert(selected.length>0);for(const file of selected)codeOwners.push({file,owner:project.name,root:project.root});}
 if(!('jsonCompanion' in project)||project.jsonCompanion){
  const inventory=await discoverJsonInventory({...deps,scopes:[project.root]});assert(inventory.jsonFiles.length>0);inventories.push({project,...inventory});for(const file of inventory.jsonFiles)jsonOwners.push({file,owner:project.name,root:project.root});
  const ignoredFormat=await discoverJsonInventory({...deps,scopes:[project.root],formatIgnorePatterns:['**/*']});assert.deepEqual(ignoredFormat.jsonFiles,inventory.jsonFiles);assert.equal(ignoredFormat.formatFiles.length,0);
  if(!('jsonCompanion' in project))assert.equal(inventory.codeFiles.length,0,`fresh uncached JSON-only code absence ${project.name}`);
 }
}
for(const owners of [codeOwners,jsonOwners]){const counts=new Map();for(const {file,owner}of owners){const list=counts.get(file)??[];list.push(owner);counts.set(file,list);}for(const [file,list]of counts)assert.equal(list.length,1,`${file}: raw owners ${list}`);}
save('raw-code-owners.json',codeOwners);save('raw-json-owners.json',jsonOwners);save('json-inventories.json',inventories);
const grpc=all.find(x=>x.name==='kernel-grpc-client');assert(grpc?.jsonCompanion);
const target=JSON.parse(readFileSync('typescript/kernel/grpc-client/project.json','utf8')).targets.lint;
assert.equal(target.executor,'nx:run-commands');assert.deepEqual(target.options,{cwd:'.',commands:['bunx --bun oxlint --type-aware typescript/kernel/grpc-client','bun tools/scripts/json-check.ts typescript/kernel/grpc-client'],parallel:false});assert(!target.defaultConfiguration&&!target.configurations);
const defaults=JSON.parse(readFileSync('nx.json','utf8')).targetDefaults.lint.inputs;assert.deepEqual(target.inputs.filter(x=>typeof x==='string'&&x!=='^production'&&x!=='{workspaceRoot}/tsconfig.json'&&x!=='{workspaceRoot}/tsconfig.base.json'),defaults);assert(target.inputs.includes('^production'));assert(target.inputs.includes('{workspaceRoot}/tsconfig.json'));assert(target.inputs.includes('{workspaceRoot}/tsconfig.base.json'));assert.deepEqual(target.inputs.filter(x=>typeof x!=='string'),[{dependentTasksOutputFiles:'**/*.ts',transitive:false}]);
const preset=(await import(Bun.resolveSync('ultracite/oxlint/core',repo))).default;
const shipped=path.join(out,'shipped-preset.json');writeFileSync(shipped,JSON.stringify(preset));
const ours=JSON.parse(run('effective-type-aware.json',['bunx','--bun','oxlint','--type-aware','--print-config']));
const reference=JSON.parse(run('shipped-effective-type-aware.json',['bunx','--bun','oxlint','--type-aware','-c',shipped,'--print-config']));
for(const key of new Set([...Object.keys(ours),...Object.keys(reference)])){if(key!=='ignorePatterns')assert.deepEqual(ours[key],reference[key],`complete policy ${key}`);}
assert.deepEqual(ours.ignorePatterns,[...reference.ignorePatterns,'.constitution/**']);
const registry=JSON.parse(run('rule-registry.json',['bunx','--bun','oxlint','--rules','--format=json']));
const enabled=Object.entries(ours.rules).filter(([,value])=>{const severity=Array.isArray(value)?value[0]:value;return severity!=='allow'&&severity!=='off'&&severity!==0;});
const enabledRules=enabled.map(([key,value])=>{const [scope,...rest]=key.split('/');const name=rest.join('/');const rule=registry.find(x=>x.scope===(rest.length?scope:'eslint')&&x.value===(rest.length?name:scope));assert(rule,`installed registry missing ${key}`);return {key,value,type_aware:rule.type_aware};});
save('enabled-rules.json',enabledRules);
const baseline=JSON.parse(readFileSync(new URL('./baseline/suppressions.json',import.meta.url),'utf8'));
const remaining=JSON.parse(readFileSync('tools/biome-coverage/bs.json','utf8'));assert(!remaining.includes(grpc.root));assert.equal(remaining.length,4);
const disposition=baseline.entries.map(entry=>{const admitted=entry.path.startsWith(grpc.root+'/');const source=readFileSync(entry.path,'utf8');assert.equal(source.includes(entry.directive),!admitted);return {...entry,baseline_retained_checker_disposition:entry.retained_checker_disposition,retained_checker_disposition:admitted?'retired-at-atomic-native-admission':entry.retained_checker_disposition,currently_retained:!admitted,native_admission_disposition:admitted?'removed-at-atomic-native-admission-no-native-counterpart':entry.native_admission_disposition,admission_proof:admitted?{native_report:'../final/native.json',original_reason:entry.original_reason,equivalent_firing_diagnostics:[],native_suppressions_added:[]}:null};});
save('suppression-disposition.json',{measurement_base_head:run('head.json',['git','rev-parse','HEAD']).trim(),measurement_kind:'uncommitted-working-tree-candidate',candidate_hashes:Object.fromEntries(['typescript/kernel/grpc-client/project.json','typescript/kernel/grpc-client/src/index.ts','typescript/kernel/grpc-client/src/lib/grpc-kernel-client.ts','typescript/kernel/grpc-client/src/lib/grpc-kernel-client-codec.ts','tools/biome-coverage/bs.json'].map(file=>[file,createHash('sha256').update(readFileSync(file)).digest('hex')])),entries:disposition});
const summary={status:'pass',native_projects:all.length,code_projects:projects.oxcProjects.length,json_only_projects:projects.jsonOnlyProjects.length,raw_code_owner_entries:codeOwners.length,raw_json_owner_entries:jsonOwners.length,grpc_code_files:codeOwners.filter(x=>x.owner===grpc.name).map(x=>x.file),grpc_json_files:jsonOwners.filter(x=>x.owner===grpc.name).map(x=>x.file),exactly_one_raw_native_owner:true,no_overlapping_native_roots:true,json_source_independent_of_formatter_ignores:true,fresh_json_only_absence_outside_cache:{applicable_projects:projects.jsonOnlyProjects.length,checked_fresh:true},complete_effective_policy_equal:true,enabled_rules:enabledRules.length,enabled_type_aware:enabledRules.filter(x=>x.type_aware).length,enabled_non_type_aware:enabledRules.filter(x=>!x.type_aware).length,target_inherited_inputs_preserved:true,original_reasons_preserved:true,retained_biome_roots:remaining};save('summary.json',summary);console.log(JSON.stringify(summary));
