import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const results=[];
for(const flavor of ['direct','awaited']){const command=['bunx','--bun','oxlint','-c',process.cwd()+'/oxlint.config.ts','--format=json',new URL(`./async-${flavor}.ts`,import.meta.url).pathname];const r=spawnSync(command[0],command.slice(1),{encoding:'utf8'});const report=JSON.parse(r.stdout);results.push({flavor,command,exit_code:r.status,stdout:r.stdout,stderr:r.stderr});if(flavor==='direct')assert(report.diagnostics.some(d=>d.code==='eslint(require-await)'));else assert.equal(r.status,0);}
writeFileSync(new URL('./async-rule-proof.json',import.meta.url),JSON.stringify(results,null,2)+'\n');
