export const rejectUnsupported = async (): Promise<never> => {
  throw new Error("unsupported");
};
