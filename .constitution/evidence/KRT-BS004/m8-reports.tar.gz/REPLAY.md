# M8 gRPC admission evidence

The candidate is an uncommitted working-tree patch based on `47061b11fd24aabc4c55eec358d3014c4bc80354`. `summary.json` names the candidate file hashes and patch digest. The base HEAD is not the commit that contains the candidate bytes.

All commands ran from the BS worktree with the main checkout's direnv environment. Compiler, type-aware, test-helper, API, and broad gates used the shared runtime verification lock. All tracked files and index state stayed unchanged throughout the frozen final gate batch. No services were started or stopped.

Extract this archive to an external directory. Set `TUVREN_BS_EVIDENCE` to that directory. From the candidate repository root, with its environment loaded, replay:

```sh
mkdir -p "$TUVREN_BS_EVIDENCE/replay-gates" "$TUVREN_BS_EVIDENCE/replay-admission" "$TUVREN_BS_EVIDENCE/replay-cache"
bun "$TUVREN_BS_EVIDENCE/gates.mjs" "$TUVREN_BS_EVIDENCE/replay-gates"
bun "$TUVREN_BS_EVIDENCE/program.mjs" "$TUVREN_BS_EVIDENCE/program.json"
bun "$TUVREN_BS_EVIDENCE/signatures.mjs" 47061b11fd24aabc4c55eec358d3014c4bc80354 "$TUVREN_BS_EVIDENCE/replay-signatures.json"
bun "$TUVREN_BS_EVIDENCE/admission-proof.mjs" "$TUVREN_BS_EVIDENCE/replay-admission"
bun "$TUVREN_BS_EVIDENCE/cache-proof.mjs" "$TUVREN_BS_EVIDENCE/replay-cache"
bun "$TUVREN_BS_EVIDENCE/async-rule-proof.mjs"
```

Acquire the repository's shared runtime verification lock around compiler and gate commands. `cache-proof.mjs` temporarily removes and changes only the owned, ignored generated bindings and restores every original byte in `finally` blocks. It uses the installed Nx task graph and task hasher. The generated-output mutation changes only the dependency-output hash node. Ordinary source inputs exclude generated files.

`baseline/` is the fresh pre-admission M3 probe replay at the base HEAD, captured before product changes. Replay that historical baseline only from a checkout of that HEAD. Its two needed original Biome directives, reasons, and native reports remain historical evidence. `admission/suppression-disposition.json` records the candidate's atomic gRPC retirement and retained testkit directive.

The eight required M8 commands and their complete reports are under `final/`. `gate-summary.json` also names additional preset, partition, JSON, format, and diff controls. M10's broad release verification remains pending.
