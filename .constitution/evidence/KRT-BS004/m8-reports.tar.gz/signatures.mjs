import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
const ts=(await import(Bun.resolveSync('typescript',process.cwd()))).default;
const sourceFiles=['typescript/kernel/grpc-client/src/index.ts','typescript/kernel/grpc-client/src/lib/grpc-kernel-client.ts','typescript/kernel/grpc-client/src/lib/grpc-kernel-client-codec.ts'];
const baseline=process.argv[2],out=process.argv[3];
const config=ts.readConfigFile('typescript/kernel/grpc-client/tsconfig.typecheck.json',ts.sys.readFile);assert(!config.error);
const parsed=ts.parseJsonConfigFileContent(config.config,ts.sys,path.resolve('typescript/kernel/grpc-client'));
const old=new Map(sourceFiles.map(f=>{const r=spawnSync('git',['show',`${baseline}:${f}`],{encoding:'utf8'});assert.equal(r.status,0);return [path.resolve(f),r.stdout];}));
function capture(useBaseline){const host=ts.createCompilerHost(parsed.options);const original=host.getSourceFile.bind(host);host.getSourceFile=(file,version,onError,shouldCreate)=>useBaseline&&old.has(path.resolve(file))?ts.createSourceFile(file,old.get(path.resolve(file)),version,true):original(file,version,onError,shouldCreate);const program=ts.createProgram(parsed.fileNames,parsed.options,host);const checker=program.getTypeChecker();const signatures={};for(const f of sourceFiles){const source=program.getSourceFile(path.resolve(f));assert(source);for(const statement of source.statements){if(ts.isVariableStatement(statement)){for(const decl of statement.declarationList.declarations)if(ts.isIdentifier(decl.name)){signatures[`${f}::${decl.name.text}`]=checker.typeToString(checker.getTypeAtLocation(decl.name),decl,ts.TypeFormatFlags.NoTruncation);}}else if(ts.isInterfaceDeclaration(statement))signatures[`${f}::${statement.name.text}`]=statement.members.map(m=>m.getText(source)).join('\n');}}return signatures;}
const before=capture(true),after=capture(false);assert.deepEqual(after,before,'all top-level callable and interface binding signatures remain equal');writeFileSync(out,JSON.stringify({status:'pass',baseline_commit:baseline,measurement_kind:'uncommitted-working-tree-candidate',signatures:after,bindings:Object.keys(after).length},null,2)+'\n');console.log(Object.keys(after).length,'binding signatures match');
