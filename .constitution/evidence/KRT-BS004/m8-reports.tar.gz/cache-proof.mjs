import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync,cpSync,readdirSync,rmSync} from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const repo=process.cwd(),out=process.argv[2];mkdirSync(out,{recursive:true});
const digest=x=>createHash('sha256').update(x).digest('hex');
const save=(n,v)=>writeFileSync(path.join(out,n),JSON.stringify(v,null,2)+'\n');
const run=(n,c)=>{const r=spawnSync(c[0],c.slice(1),{cwd:repo,encoding:'utf8',maxBuffer:64*1024*1024,env:{...process.env,NX_DAEMON:'false',NX_TUI:'false',NO_COLOR:'1',LC_ALL:'C'}});save(n,{command:c,cwd:repo,exit_code:r.status,stdout:r.stdout,stderr:r.stderr});assert.equal(r.status,0,`${n}: ${r.stderr}`);return r.stdout;};
const root='typescript/kernel/grpc-client/src/lib/generated/kernel-interop';
const files=(dir,prefix='')=>readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name),path.join(prefix,e.name)):[path.join(prefix,e.name)]).sort();
const snapshot=()=>Object.fromEntries(files(root).map(f=>[f,digest(readFileSync(path.join(root,f)))]));
const original=snapshot();assert(Object.keys(original).length>0);
const backup=path.join(out,'generated-original');cpSync(root,backup,{recursive:true});rmSync(root,{recursive:true});
try {run('clean-output-restore.json',['bun','run','nx','run','kernel-grpc-client:lint']);assert.deepEqual(snapshot(),original,'codegen restores exact clean generated output');}
finally {rmSync(root,{recursive:true,force:true});cpSync(backup,root,{recursive:true});rmSync(backup,{recursive:true});}
const repeated=run('repeat-lint.json',['bun','run','nx','run','kernel-grpc-client:lint']);assert.match(repeated,/kernel-grpc-client:lint.*cache|read the output from the cache/u);
const hashCommand=name=>run(name+'.log.json',['bun',new URL('./hash.mjs',import.meta.url).pathname,path.join(out,name+'.json')]);
hashCommand('hash-before');const before=JSON.parse(readFileSync(path.join(out,'hash-before.json'),'utf8'));
assert.deepEqual(before.taskGraph.dependencies['kernel-grpc-client:lint'],['kernel-interop-grpc:codegen']);
const generated=path.join(root,Object.keys(original)[0]);const bytes=readFileSync(generated);
try{writeFileSync(generated,Buffer.concat([bytes,Buffer.from('\n// Generated-output cache invalidation probe.\n')]));hashCommand('hash-mutated');const mutated=JSON.parse(readFileSync(path.join(out,'hash-mutated.json'),'utf8'));assert.notEqual(mutated.hash.value,before.hash.value,'actual Nx task hasher must include generated dependency bytes');save('generated-mutation.json',{file:generated,original_sha256:digest(bytes),mutated_sha256:digest(readFileSync(generated)),syntactically_valid_comment:true});}
finally{writeFileSync(generated,bytes);}
hashCommand('hash-restored');const restored=JSON.parse(readFileSync(path.join(out,'hash-restored.json'),'utf8'));assert.equal(restored.hash.value,before.hash.value);assert.deepEqual(snapshot(),original);
const program=JSON.parse(readFileSync(new URL('./program.json',import.meta.url),'utf8'));const dependencies=program.files.filter(f=>!f.startsWith('typescript/kernel/grpc-client/'));
for(const [i,file]of dependencies.entries())run(`dependency-input-${i}.json`,['bun','run','nx','show','target','inputs','kernel-grpc-client:lint','--check',file]);
for(const file of ['tsconfig.json','tsconfig.base.json'])run(path.basename(file)+'.input.json',['bun','run','nx','show','target','inputs','kernel-grpc-client:lint','--check',file]);
save('summary.json',{status:'pass',generated_files:original,clean_output_restore_equal:true,repeated_lint_cache_hit:true,actual_task_graph_dependency:before.taskGraph.dependencies['kernel-grpc-client:lint'],original_hash:before.hash.value,mutated_hash:JSON.parse(readFileSync(path.join(out,'hash-mutated.json'),'utf8')).hash.value,restored_hash:restored.hash.value,generated_output_invalidates_hash:true,ignored_generated_bytes_restored_exactly:true,dependency_sources_checked:dependencies,all_program_dependency_sources_are_inputs:true,root_typecheck_configs_are_inputs:true,ordinary_typecheck_unchanged:true});console.log('Cache/dependency proof PASS');
