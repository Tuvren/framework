import { mock } from "bun:test";

export const health = mock<() => Promise<{ ok: true }>>().mockResolvedValue({ ok: true });
export const noOp = mock<() => Promise<void>>().mockResolvedValue();
export const emptyList = mock<() => Promise<never[]>>().mockResolvedValue([]);
