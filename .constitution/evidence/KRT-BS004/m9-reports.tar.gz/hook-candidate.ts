export const hookCandidate = async (inject: boolean, error: Error): Promise<void> => {
  if (!inject) {
    return;
  }
  await Promise.reject(error);
};
