/**
 * Copyright 2026 Oscar Yáñez Cisterna (@SkrOYC)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { registerBackendInvariantArchiveCases } from "./backend-invariant-suite-archive.js";
import { registerBackendInvariantRunStateCases } from "./backend-invariant-suite-run-state.js";
import { registerBackendInvariantTurnCases } from "./backend-invariant-suite-turns.js";
import type { BackendConformanceSuiteOptions } from "./backend-test-suite-types.js";

/**
 * Registers the shared backend-invariant test suite — run-state, turn, and
 * archive-branch invariant cases — against `options.testApi`, using a fresh
 * `options.createBackend()` instance per case. Any `RuntimeBackend`
 * implementation that passes this suite enforces the same referential and
 * lineage invariants as the reference (memory) backend.
 */
export const registerBackendInvariantSuite = (
  options: BackendConformanceSuiteOptions
): void => {
  const suiteName = options.suiteName ?? "Backend Invariants";

  options.testApi.describe(suiteName, () => {
    registerBackendInvariantRunStateCases(options);
    registerBackendInvariantTurnCases(options);
    registerBackendInvariantArchiveCases(options);
  });
};
