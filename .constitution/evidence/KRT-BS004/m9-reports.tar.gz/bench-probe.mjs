import assert from 'node:assert/strict';
const root=process.cwd(),phase=process.argv[2],kit=phase==='current'?root:'/tmp/tuvren-bs-m9/runtime-baseline';
const {readSampleCountFromEnv,summarizePhases,percentile}=await import(kit+'/typescript/kernel/testkit/src/lib/bench-phase-stats.ts');
const cases=[undefined,'42x','1e2','0x20','+3','1.9',' 5 ','',' ','-3','9007199254740992','+0','-0','\uFEFF2tail','00034x','-1x','1_000'];const out=[];
const prior=process.env.BENCH_SAMPLE_COUNT;
try {for(const raw of cases){if(raw===undefined)delete process.env.BENCH_SAMPLE_COUNT;else process.env.BENCH_SAMPLE_COUNT=raw;try{out.push({raw:raw??null,value:readSampleCountFromEnv(17)})}catch(e){out.push({raw,error:{name:e.name,message:e.message}})}}}finally{if(prior===undefined)delete process.env.BENCH_SAMPLE_COUNT;else process.env.BENCH_SAMPLE_COUNT=prior;}
const samples=[{phase:'health',durationNs:3},{phase:'health',durationNs:1},{phase:'health',durationNs:2}];const old=structuredClone(samples);assert.deepEqual(summarizePhases([]),[]);const summary=summarizePhases(samples);assert.deepEqual(samples,old);assert.equal(summary[0].medianNs,2);let empty;try{percentile([],0.5)}catch(e){empty=e.message}assert.equal(empty,'expected benchmark samples');console.log(JSON.stringify({cases:out,summary,empty}));
