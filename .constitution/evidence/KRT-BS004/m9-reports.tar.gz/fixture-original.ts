export const fixtures = {
  get<T>(state: Map<string, T>, key: string): Promise<T | null> {
    return Promise.resolve(state.get(key) ?? null);
  },
  health(): Promise<{ ok: true }> {
    return Promise.resolve({ ok: true });
  },
  put<T>(state: Map<string, T>, key: string, value: T): Promise<void> {
    state.set(key, value);
    return Promise.resolve();
  },
  set(): Promise<void> { return Promise.resolve(); },
};
