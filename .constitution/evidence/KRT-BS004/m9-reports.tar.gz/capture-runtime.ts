import {readFileSync} from 'node:fs';
import {deepStrictEqual,strictEqual} from 'node:assert/strict';
const root=process.cwd();
const phase=process.argv[3]; const kitRoot=phase==='current'?root:`/tmp/tuvren-bs-m9/runtime-${phase}`; const files=JSON.parse(readFileSync('/tmp/tuvren-bs-m9/production.json','utf8'));
const first=process.argv[2]??'entry';
await import(`${kitRoot}/${first==='entry'?'typescript/kernel/testkit/src/index.ts':files[Number(first)]}`);
const kit=await import(`${kitRoot}/typescript/kernel/testkit/src/index.ts`);
const fixtures=await import(`${kitRoot}/typescript/kernel/testkit/src/lib/kernel-conformance-fixtures.ts`);
const {createMemoryBackend}=await import(`${root}/typescript/kernel/backends/memory/src/index.ts`);
const helpers=await import(`/tmp/tuvren-bs-m9/test-helpers-${phase}.ts`);
const registrations=[];const tests=[];
const testApi={describe(name,register){registrations.push(['describe',name]);register();},test(name,run){registrations.push(['test',name]);tests.push({name,run});}};
for(const register of [kit.registerBackendConformanceSuite,kit.registerBackendInvariantSuite,kit.registerBackendRecoverySuite]) register({createBackend:createMemoryBackend,testApi});
const outcomes=[];for(const {name,run} of tests){await run();outcomes.push([name,'pass']);}
const errorRecord=e=>({name:e.name,message:e.message,code:e.code,details:e.details});
const matrix=[];Date.now=()=>1000;
for(const point of ['before-commit','mid-commit','after-commit-before-ack'])for(const concurrent of [false,true])for(const policy of ['once','always']){
 const backend=helpers.createTestBackend();const seed=await helpers.seedFaultInjectionBranch(backend,'branch_matrix');const trace=[];
 const control=backend[Object.getOwnPropertySymbols(backend)[0]];const set=control.setFaultHooks.bind(control);
 control.setFaultHooks=hooks=>{trace.push(hooks===null?'hooks:clear':'hooks:install');if(hooks===null){set(null);return;}set(Object.fromEntries(Object.entries(hooks).map(([name,fn])=>[name,async(...args)=>{trace.push(name+':enter');try{const value=await fn(...args);trace.push(name+':return');return value;}catch(e){trace.push(name+':error:'+e.code);throw e;}}])));};
 const wrapped=kit.createFaultInjectingBackend(backend,{point,policy,match:{branchId:seed.branch.branchId,operation:'checkpoint'},...(concurrent?{concurrentWriter:{branchId:seed.branch.branchId}}:{})});
 const errors=[];for(let attempt=0;attempt<2;attempt++){try{await wrapped.transact(async tx=>{trace.push('work:start');await tx.turnNodes.put(seed.childNode);trace.push('work:put');await tx.branches.set({...seed.branch,headTurnNodeHash:seed.childNode.hash,updatedAtMs:16});trace.push('work:set');});errors.push(null);}catch(e){errors.push(errorRecord(e));}}
 const branch=await helpers.readBranch(backend,seed.branch.branchId);const node=await helpers.readTurnNode(backend,branch.headTurnNodeHash);
 strictEqual(errors[0].code,'kernel_persistence_fault_injected');
 if(!concurrent&&policy==='once')strictEqual(errors[1],null);
 matrix.push({point,concurrent,policy,trace,errors,branch,node,child:await helpers.readTurnNode(backend,seed.childNode.hash)});
}
const forwarding=[];const inner=helpers.createTestBackend();for(const key of ['reclaim','purgeScope','close','destroy','fsck'])inner[key]=function(...args){strictEqual(this,inner);forwarding.push([key,args]);return Promise.resolve(key==='fsck'?{ok:true}:undefined);};
const decorated=kit.createFaultInjectingBackend(inner,{point:'before-commit',policy:'once'});
for(const key of ['reclaim','purgeScope','close','destroy','fsck'])await decorated[key]({probe:key});
const absent=kit.createFaultInjectingBackend(helpers.createTestBackend(),{point:'before-commit',policy:'once'});const optionalAbsent=['reclaim','purgeScope','close','destroy','fsck'].map(k=>[k,k in absent]);deepStrictEqual(optionalAbsent.map(x=>x[1]),[false,false,false,false,false]);
const exports={};for(const file of files){const mod=await import(`${kitRoot}/${file}`);exports[file]=Object.entries(mod).map(([k,v])=>[k,typeof v,null]).sort();}
console.log(JSON.stringify({exports,fixtures:{schema:fixtures.canonicalKernelTestSchemaFixture,deterministic:fixtures.kernelProtocolDeterministicFixtures,logical:fixtures.kernelProtocolLogicalFixtures},registrations,outcomes,matrix,forwarding,optionalAbsent},(_,v)=>v instanceof Uint8Array?[...v]:v));
