import{readFileSync,writeFileSync}from'node:fs';const f='typescript/kernel/testkit/test/kernel-testkit.test.ts';let s=readFileSync(f,'utf8');
s=s.replace('/** Focused single-branch unit fixture; real backend conformance lives in shared plans. */\nconst createTestBackend = (): RuntimeBackend => {','interface FocusedTestBackend extends RuntimeBackend {\n  inspect: () => {\n    branches: Map<string, StoredBranch>;\n    objects: Map<string, StoredObject>;\n    turnNodes: Map<string, StoredTurnNode>;\n  };\n}\n\n/** Focused single-branch unit fixture; real backend conformance lives in shared plans. */\nconst createTestBackend = (): FocusedTestBackend => {');
s=s.replace('  const backend = {\n    [faultControl]:', '  const readCommittedHead = (branch: StoredBranch | null): StoredTurnNode | null =>\n    branch === null ? null : state.turnNodes.get(branch.headTurnNodeHash) ?? null;\n  const backend = {\n    [faultControl]:');s=s.replace('    health: mock<RuntimeBackend["health"]>().mockResolvedValue({ ok: true }),','    health: mock<RuntimeBackend["health"]>().mockResolvedValue({ ok: true }),\n    inspect: () => structuredClone(state),');s=s.replace(/      const head =\n        branch === null\n          \? null\n          : \(state.turnNodes.get\(branch.headTurnNodeHash\) \?\? null\);/,'      const head = readCommittedHead(branch);');
const a=s.indexOf('      const result = await work(tx);'),b=s.indexOf('      const draft = {',a);let validate=s.slice(a,b).replace('      const result = await work(tx);\n','');validate=validate.replace('for (const [branchId] of tx.branches.get.mock.calls) {','for (const args of tx.branches.get.mock.calls) {\n        strictEqual(args.length, 1, "focused branch read has one argument");\n        const [branchId] = args;').replace('for (const [hash] of tx.turnNodes.get.mock.calls) {','for (const args of tx.turnNodes.get.mock.calls) {\n        strictEqual(args.length, 1, "focused head read has one argument");\n        const [hash] = args;');s=s.slice(0,a)+'      let result: T;\n      try {\n        result = await work(tx);\n      } finally {\n'+validate+'      }\n'+s.slice(b);
for(const [repo,method]of [['objects','put'],['turnNodes','put'],['branches','set']])s=s.replace(`      for (const [record] of tx.${repo}.${method}.mock.calls) {`,`      for (const args of tx.${repo}.${method}.mock.calls) {\n        strictEqual(args.length, 1, "focused fixture writes have one record");\n        const [record] = args;`);
const insert=`
  test("focused fixture rejects unsupported reads even when work fails", async () => {
    const backend = createTestBackend();
    const seeded = await seedFaultInjectionBranch(backend, "branch_focused");
    const before = backend.inspect();
    await rejects(backend.transact(async (tx) => await tx.branches.get("unsupported")), { message: /focused fixture only reads the committed branch/u });
    await rejects(backend.transact(async (tx) => { await tx.objects.get("unsupported"); throw new Error("work failed"); }), { message: /unsupported focused fixture repository call/u });
    await rejects(backend.transact(async (tx) => { await tx.turnNodes.put(seeded.childNode); return await tx.turnNodes.get(seeded.childNode.hash); }), { message: /focused fixture only reads the committed head/u });
    deepStrictEqual(backend.inspect(), before);
  });

  test("focused fixture discards recorded writes when work rejects", async () => {
    const backend = createTestBackend();
    const seeded = await seedFaultInjectionBranch(backend, "branch_work_reject");
    const before = backend.inspect();
    const failure = new Error("callback failed");
    await rejects(backend.transact(async (tx) => { await tx.turnNodes.put(seeded.childNode); throw failure; }), (error: unknown) => { strictEqual(error, failure); return true; });
    deepStrictEqual(backend.inspect(), before);
  });
`;
s=s.slice(0,s.lastIndexOf('\n});'))+insert+s.slice(s.lastIndexOf('\n});'));writeFileSync(f,s);
