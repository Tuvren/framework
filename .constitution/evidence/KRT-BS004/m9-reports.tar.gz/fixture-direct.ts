export const fixtures = {
  async get<T>(state: Map<string, T>, key: string): Promise<T | null> {
    return state.get(key) ?? null;
  },
  async health(): Promise<{ ok: true }> {
    return { ok: true };
  },
  async put<T>(state: Map<string, T>, key: string, value: T): Promise<void> {
    state.set(key, value);
  },
  async set(): Promise<void> {},
};
