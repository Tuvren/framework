import{readFileSync,writeFileSync}from'node:fs';
const f='typescript/kernel/testkit/test/kernel-testkit.test.ts';let s=readFileSync(f,'utf8').replace('import { describe, expect, test }','import { describe, expect, mock, test }');const a=s.indexOf('const createTestTransaction ='),b=s.indexOf('\ndescribe(',a);
const repos={branches:{get:'branch',listByThread:'[]',set:'void'},objects:{get:'null',has:'false',put:'void'},observeAnnotations:{listByRun:'[]',set:'void'},orderedPathChunks:{get:'null',put:'void'},runs:{get:'null',listByBranch:'[]',listExpired:'[]',set:'void'},schemas:{get:'null',put:'void'},stagedResults:{clearRun:'void',get:'null',listByRun:'[]',set:'void'},threads:{get:'null',list:'{ threads: [] }',put:'void'},turnNodes:{get:'head',put:'void'},turnTreePaths:{get:'null',listByTurnTree:'[]',putMany:'void'},turnTrees:{get:'null',put:'void'},turns:{get:'null',listByThread:'[]',set:'void'}};
const methods=Object.entries(repos).map(([r,ms])=>`        ${r}: {\n${Object.entries(ms).map(([m,v])=>`          ${m}: mock<RuntimeBackendTx["${r}"]["${m}"]>().mockResolvedValue(${v==='void'?'':v==='branch'||v==='head'?`structuredClone(${v})`:v}),`).join('\n')}\n        },`).join('\n');
const unused=Object.entries(repos).flatMap(([r,ms])=>Object.keys(ms).filter(m=>!['branches.get','branches.set','objects.put','turnNodes.get','turnNodes.put'].includes(r+'.'+m)).map(m=>`tx.${r}.${m}.mock.calls`));
const fixture=`/** Focused single-branch unit fixture; real backend conformance lives in shared plans. */
const createTestBackend = (): RuntimeBackend => {
  const faultControl = Symbol("fault-control");
  const state = {
    branches: new Map<string, StoredBranch>(),
    objects: new Map<string, StoredObject>(),
    turnNodes: new Map<string, StoredTurnNode>(),
  };
  let hooks: {
    afterCommitBeforeAck?: () => Promise<void>;
    beforeCommit?: () => Promise<void>;
    midCommit?: (commit: () => void) => Promise<void>;
  } | null = null;
  return {
    ...{ [faultControl]: {
      setFaultHooks(nextHooks: typeof hooks) { hooks = nextHooks; },
      supportsFaultPoint() { return true; },
    } },
    capabilities() { return { "thread.enumeration": false }; },
    health: mock<RuntimeBackend["health"]>().mockResolvedValue({ ok: true }),
    async transact<T>(work: (tx: RuntimeBackendTx) => Promise<T>): Promise<T> {
      const branch = state.branches.values().next().value ?? null;
      const head = branch === null ? null : state.turnNodes.get(branch.headTurnNodeHash) ?? null;
      const tx = {
${methods}
      };
      const result = await work(tx);
      for (const [branchId] of tx.branches.get.mock.calls) {
        strictEqual(branchId, branch?.branchId, "focused fixture only reads the committed branch");
      }
      for (const [hash] of tx.turnNodes.get.mock.calls) {
        strictEqual(hash, branch?.headTurnNodeHash, "focused fixture only reads the committed head");
      }
      for (const calls of [${unused.join(',')}]) {
        strictEqual(calls.length, 0, "unsupported focused fixture repository call");
      }
      const draft = {
        branches: new Map(state.branches),
        objects: new Map(state.objects),
        turnNodes: new Map(state.turnNodes),
      };
      for (const [record] of tx.objects.put.mock.calls) { draft.objects.set(record.hash, structuredClone(record)); }
      for (const [record] of tx.turnNodes.put.mock.calls) { draft.turnNodes.set(record.hash, structuredClone(record)); }
      for (const [record] of tx.branches.set.mock.calls) {
        const existing = draft.branches.get(record.branchId);
        if (existing !== undefined && classifyTurnNodeRelationship(draft.turnNodes, existing.headTurnNodeHash, record.headTurnNodeHash) === "lateral") {
          throw createBranchHeadLateralMoveError(existing.headTurnNodeHash, record.headTurnNodeHash);
        }
        draft.branches.set(record.branchId, structuredClone(record));
      }
      strictEqual(draft.branches.size <= 1, true, "focused fixture supports one branch");
      await hooks?.beforeCommit?.();
      let committed = false;
      const commit = (): void => {
        if (committed) { throw new Error("test backend commit hook attempted double commit"); }
        state.branches = draft.branches;
        state.objects = draft.objects;
        state.turnNodes = draft.turnNodes;
        committed = true;
      };
      if (hooks?.midCommit === undefined) { commit(); }
      else {
        await hooks.midCommit(commit);
        if (!committed) { throw new Error("test backend mid-commit hook must commit once"); }
      }
      await hooks?.afterCommitBeforeAck?.();
      return result;
    },
  };
};
`;
s=s.slice(0,a)+fixture+s.slice(b);
for(const n of ['StoredObserveAnnotation','StoredOrderedPathChunk','StoredRun','StoredStagedResult','StoredThread','StoredTurn','StoredTurnTree','StoredTurnTreePath'])s=s.replace('  '+n+',\n','');
const start=s.indexOf('  test("preserves optional maintenance'),end=s.indexOf('  test("clears installed hooks',start);
s=s.slice(0,start)+`  test("preserves optional maintenance receivers, results, errors and absence", async () => {
    const success = { extra: "preserved", ok: true } as const;
    const failure = { ok: false, reason: "damaged index" } as const;
    const domainError = new Error("fsck backend failure");
    await Promise.all([success, failure, domainError].map(async (expected) => {
      const close = mock<() => Promise<void>>().mockResolvedValue();
      const destroy = mock<(options?: { dropSchema?: boolean }) => Promise<void>>().mockResolvedValue();
      const fsck = mock<() => Promise<typeof success | typeof failure>>();
      if (expected instanceof Error) { fsck.mockRejectedValue(expected); }
      else { fsck.mockResolvedValue(expected); }
      const backend = Object.assign(createTestBackend(), { close, destroy, fsck });
      const wrapped = createFaultInjectingBackend(backend, { point: "before-commit", policy: "once" });
      const invoke = async (key: string): Promise<unknown> => {
        const method: unknown = Reflect.get(wrapped, key);
        if (typeof method !== "function") { throw new TypeError("expected forwarded maintenance method"); }
        return await method.apply(wrapped, key === "destroy" ? [{ dropSchema: true }] : []);
      };
      strictEqual(await invoke("close"), undefined);
      strictEqual(await invoke("destroy"), undefined);
      if (expected instanceof Error) {
        await rejects(invoke("fsck"), (error: unknown) => { strictEqual(error, expected); return true; });
      } else { strictEqual(await invoke("fsck"), expected); }
      deepStrictEqual(close.mock.calls, [[]]);
      deepStrictEqual(destroy.mock.calls, [[{ dropSchema: true }]]);
      deepStrictEqual(fsck.mock.calls, [[]]);
      strictEqual(close.mock.contexts[0], backend);
      strictEqual(destroy.mock.contexts[0], backend);
      strictEqual(fsck.mock.contexts[0], backend);
    }));
    const absent = createFaultInjectingBackend(createTestBackend(), { point: "before-commit", policy: "once" });
    for (const key of ["close", "destroy", "fsck", "reclaim", "purgeScope"]) { strictEqual(key in absent, false); }
  });
  test("validates unknown fsck results without changing valid result objects", async () => {
    const backend = Object.assign(createTestBackend(), { fsck: mock<() => Promise<unknown>>().mockResolvedValue({ ok: false }) });
    const wrapped = createFaultInjectingBackend(backend, { point: "before-commit", policy: "once" });
    const method: unknown = Reflect.get(wrapped, "fsck");
    if (typeof method !== "function") { throw new TypeError("expected forwarded fsck method"); }
    await rejects(async () => { await method.call(wrapped); }, { message: "backend fsck must return an ok result or a failure reason", name: "TypeError" });
  });

`+s.slice(end);writeFileSync(f,s);
