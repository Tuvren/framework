import {mock} from "bun:test";
import { deepStrictEqual, rejects, strictEqual } from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import type {
  RuntimeBackend,
  RuntimeBackendTx,
  StoredBranch,
  StoredObject,
  StoredTurnNode,
} from "/home/oscar/GitHub/Tuvren/framework-worktrees/EPIC-BS/typescript/kernel/protocol/src/index.ts";
import { encodeDeterministicKernelRecord } from "/home/oscar/GitHub/Tuvren/framework-worktrees/EPIC-BS/typescript/kernel/protocol/src/index.ts";
import {
  createCanonicalKernelTestSchema,
  createCanonicalTurnTreePaths,
  createFaultInjectingBackend,
  createHashFromIndex,
  createStoredObjectRecord,
  createStoredSchemaRecord,
  createStoredTurnNodeRecord,
  createStoredTurnTreeRecord,
  registerBackendConformanceSuite,
  registerBackendInvariantSuite,
  registerBackendRecoverySuite,
} from "/home/oscar/GitHub/Tuvren/framework-worktrees/EPIC-BS/typescript/kernel/testkit/src/index.ts";
const seedFaultInjectionBranch = async (
  backend: RuntimeBackend,
  branchId: string
): Promise<{
  branch: StoredBranch;
  childNode: StoredTurnNode;
  rootNode: StoredTurnNode;
}> => {
  const rootNode = await createStoredTurnNodeRecord({
    consumedStagedResults: [],
    createdAtMs: 12,
    eventHash: null,
    previousTurnNodeHash: null,
    schemaId: "schema_fault_injection",
    turnTreeHash: createHashFromIndex(99),
  });
  const childNode = await createStoredTurnNodeRecord({
    consumedStagedResults: [],
    createdAtMs: 13,
    eventHash: null,
    previousTurnNodeHash: rootNode.hash,
    schemaId: rootNode.schemaId,
    turnTreeHash: rootNode.turnTreeHash,
  });
  const branch: StoredBranch = {
    branchId,
    createdAtMs: 15,
    headTurnNodeHash: rootNode.hash,
    threadId: `${branchId}_thread`,
    updatedAtMs: 15,
  };

  await backend.transact(async (tx) => {
    await tx.turnNodes.put(rootNode);
    await tx.branches.set(branch);
  });

  return {
    branch,
    childNode,
    rootNode,
  };
};
const readBranch = async (
  backend: RuntimeBackend,
  branchId: string
): Promise<StoredBranch | null> =>
  await backend.transact(async (tx) => await tx.branches.get(branchId));
const readBranchHeadHash = async (
  backend: RuntimeBackend,
  branchId: string
): Promise<string | null> => {
  const branch = await readBranch(backend, branchId);
  return branch?.headTurnNodeHash ?? null;
};
const readTurnNode = async (
  backend: RuntimeBackend,
  turnNodeHash: string
): Promise<StoredTurnNode | null> =>
  await backend.transact(async (tx) => await tx.turnNodes.get(turnNodeHash));
const hasAncestor = (
  turnNodes: Map<string, StoredTurnNode>,
  startHash: string,
  ancestorHash: string
): boolean => {
  let current = turnNodes.get(startHash);

  while (current !== undefined && current.previousTurnNodeHash !== null) {
    if (current.previousTurnNodeHash === ancestorHash) {
      return true;
    }

    current = turnNodes.get(current.previousTurnNodeHash);
  }

  return false;
};
const classifyTurnNodeRelationship = (
  turnNodes: Map<string, StoredTurnNode>,
  sourceHash: string,
  targetHash: string
): "ancestor" | "descendant" | "lateral" | "same" => {
  if (sourceHash === targetHash) {
    return "same";
  }

  if (hasAncestor(turnNodes, targetHash, sourceHash)) {
    return "descendant";
  }

  if (hasAncestor(turnNodes, sourceHash, targetHash)) {
    return "ancestor";
  }

  return "lateral";
};
const createBranchHeadLateralMoveError = (
  previousHeadTurnNodeHash: string,
  nextHeadTurnNodeHash: string
): Error & { code: string } =>
  Object.assign(
    new Error(
      "record.headTurnNodeHash must remain on the same thread lineage as the current branch head"
    ),
    {
      code: "test_backend_branch_head_lateral_move",
      details: {
        nextHeadTurnNodeHash,
        previousHeadTurnNodeHash,
      },
    }
  );
const createTestBackend = (): FocusedTestBackend => {
  const faultControl = Symbol("fault-control");
  const state = {
    branches: new Map<string, StoredBranch>(),
    objects: new Map<string, StoredObject>(),
    turnNodes: new Map<string, StoredTurnNode>(),
  };
  let hooks: {
    afterCommitBeforeAck?: () => Promise<void>;
    beforeCommit?: () => Promise<void>;
    midCommit?: (commit: () => void) => Promise<void>;
  } | null = null;
  const readCommittedHead = (
    branch: StoredBranch | null
  ): StoredTurnNode | null =>
    branch === null
      ? null
      : (state.turnNodes.get(branch.headTurnNodeHash) ?? null);
  const backend = {
    [faultControl]: {
      setFaultHooks(nextHooks: typeof hooks) {
        hooks = nextHooks;
      },
      supportsFaultPoint() {
        return true;
      },
    },
    capabilities() {
      return { "thread.enumeration": false };
    },
    health: mock<RuntimeBackend["health"]>().mockResolvedValue({ ok: true }),
    inspect: () => structuredClone(state),
    async transact<T>(work: (tx: RuntimeBackendTx) => Promise<T>): Promise<T> {
      const branch = state.branches.values().next().value ?? null;
      const head = readCommittedHead(branch);
      const tx = {
        branches: {
          get: mock<RuntimeBackendTx["branches"]["get"]>().mockResolvedValue(
            structuredClone(branch)
          ),
          listByThread: mock<
            RuntimeBackendTx["branches"]["listByThread"]
          >().mockResolvedValue([]),
          set: mock<RuntimeBackendTx["branches"]["set"]>().mockResolvedValue(),
        },
        objects: {
          get: mock<RuntimeBackendTx["objects"]["get"]>().mockResolvedValue(
            null
          ),
          has: mock<RuntimeBackendTx["objects"]["has"]>().mockResolvedValue(
            false
          ),
          put: mock<RuntimeBackendTx["objects"]["put"]>().mockResolvedValue(),
        },
        observeAnnotations: {
          listByRun: mock<
            RuntimeBackendTx["observeAnnotations"]["listByRun"]
          >().mockResolvedValue([]),
          set: mock<
            RuntimeBackendTx["observeAnnotations"]["set"]
          >().mockResolvedValue(),
        },
        orderedPathChunks: {
          get: mock<
            RuntimeBackendTx["orderedPathChunks"]["get"]
          >().mockResolvedValue(null),
          put: mock<
            RuntimeBackendTx["orderedPathChunks"]["put"]
          >().mockResolvedValue(),
        },
        runs: {
          get: mock<RuntimeBackendTx["runs"]["get"]>().mockResolvedValue(null),
          listByBranch: mock<
            RuntimeBackendTx["runs"]["listByBranch"]
          >().mockResolvedValue([]),
          listExpired: mock<
            RuntimeBackendTx["runs"]["listExpired"]
          >().mockResolvedValue([]),
          set: mock<RuntimeBackendTx["runs"]["set"]>().mockResolvedValue(),
        },
        schemas: {
          get: mock<RuntimeBackendTx["schemas"]["get"]>().mockResolvedValue(
            null
          ),
          put: mock<RuntimeBackendTx["schemas"]["put"]>().mockResolvedValue(),
        },
        stagedResults: {
          clearRun:
            mock<
              RuntimeBackendTx["stagedResults"]["clearRun"]
            >().mockResolvedValue(),
          get: mock<
            RuntimeBackendTx["stagedResults"]["get"]
          >().mockResolvedValue(null),
          listByRun: mock<
            RuntimeBackendTx["stagedResults"]["listByRun"]
          >().mockResolvedValue([]),
          set: mock<
            RuntimeBackendTx["stagedResults"]["set"]
          >().mockResolvedValue(),
        },
        threads: {
          get: mock<RuntimeBackendTx["threads"]["get"]>().mockResolvedValue(
            null
          ),
          put: mock<RuntimeBackendTx["threads"]["put"]>().mockResolvedValue(),
        },
        turnNodes: {
          get: mock<RuntimeBackendTx["turnNodes"]["get"]>().mockResolvedValue(
            structuredClone(head)
          ),
          put: mock<RuntimeBackendTx["turnNodes"]["put"]>().mockResolvedValue(),
        },
        turnTreePaths: {
          get: mock<
            RuntimeBackendTx["turnTreePaths"]["get"]
          >().mockResolvedValue(null),
          listByTurnTree: mock<
            RuntimeBackendTx["turnTreePaths"]["listByTurnTree"]
          >().mockResolvedValue([]),
          putMany:
            mock<
              RuntimeBackendTx["turnTreePaths"]["putMany"]
            >().mockResolvedValue(),
        },
        turnTrees: {
          get: mock<RuntimeBackendTx["turnTrees"]["get"]>().mockResolvedValue(
            null
          ),
          put: mock<RuntimeBackendTx["turnTrees"]["put"]>().mockResolvedValue(),
        },
        turns: {
          get: mock<RuntimeBackendTx["turns"]["get"]>().mockResolvedValue(null),
          listByThread: mock<
            RuntimeBackendTx["turns"]["listByThread"]
          >().mockResolvedValue([]),
          set: mock<RuntimeBackendTx["turns"]["set"]>().mockResolvedValue(),
        },
      };
      let result: T;
      try {
        result = await work(tx);
      } finally {
        for (const args of tx.branches.get.mock.calls) {
          strictEqual(args.length, 1, "focused branch read has one argument");
          const [branchId] = args;
          strictEqual(
            branchId,
            branch?.branchId,
            "focused fixture only reads the committed branch"
          );
        }
        for (const args of tx.turnNodes.get.mock.calls) {
          strictEqual(args.length, 1, "focused head read has one argument");
          const [hash] = args;
          strictEqual(
            hash,
            branch?.headTurnNodeHash,
            "focused fixture only reads the committed head"
          );
        }
        for (const calls of [
          tx.branches.listByThread.mock.calls,
          tx.objects.get.mock.calls,
          tx.objects.has.mock.calls,
          tx.observeAnnotations.listByRun.mock.calls,
          tx.observeAnnotations.set.mock.calls,
          tx.orderedPathChunks.get.mock.calls,
          tx.orderedPathChunks.put.mock.calls,
          tx.runs.get.mock.calls,
          tx.runs.listByBranch.mock.calls,
          tx.runs.listExpired.mock.calls,
          tx.runs.set.mock.calls,
          tx.schemas.get.mock.calls,
          tx.schemas.put.mock.calls,
          tx.stagedResults.clearRun.mock.calls,
          tx.stagedResults.get.mock.calls,
          tx.stagedResults.listByRun.mock.calls,
          tx.stagedResults.set.mock.calls,
          tx.threads.get.mock.calls,
          tx.threads.put.mock.calls,
          tx.turnTreePaths.get.mock.calls,
          tx.turnTreePaths.listByTurnTree.mock.calls,
          tx.turnTreePaths.putMany.mock.calls,
          tx.turnTrees.get.mock.calls,
          tx.turnTrees.put.mock.calls,
          tx.turns.get.mock.calls,
          tx.turns.listByThread.mock.calls,
          tx.turns.set.mock.calls,
        ]) {
          strictEqual(
            calls.length,
            0,
            "unsupported focused fixture repository call"
          );
        }
      }
      const draft = {
        branches: new Map(state.branches),
        objects: new Map(state.objects),
        turnNodes: new Map(state.turnNodes),
      };
      for (const args of tx.objects.put.mock.calls) {
        strictEqual(args.length, 1, "focused fixture writes have one record");
        const [record] = args;
        draft.objects.set(record.hash, structuredClone(record));
      }
      for (const args of tx.turnNodes.put.mock.calls) {
        strictEqual(args.length, 1, "focused fixture writes have one record");
        const [record] = args;
        draft.turnNodes.set(record.hash, structuredClone(record));
      }
      for (const args of tx.branches.set.mock.calls) {
        strictEqual(args.length, 1, "focused fixture writes have one record");
        const [record] = args;
        const existing = draft.branches.get(record.branchId);
        if (
          existing !== undefined &&
          classifyTurnNodeRelationship(
            draft.turnNodes,
            existing.headTurnNodeHash,
            record.headTurnNodeHash
          ) === "lateral"
        ) {
          throw createBranchHeadLateralMoveError(
            existing.headTurnNodeHash,
            record.headTurnNodeHash
          );
        }
        draft.branches.set(record.branchId, structuredClone(record));
      }
      strictEqual(
        draft.branches.size <= 1,
        true,
        "focused fixture supports one branch"
      );
      await hooks?.beforeCommit?.();
      let committed = false;
      const commit = (): void => {
        strictEqual(
          committed,
          false,
          "test backend commit hook attempted double commit"
        );
        state.branches = draft.branches;
        state.objects = draft.objects;
        state.turnNodes = draft.turnNodes;
        committed = true;
      };
      if (hooks?.midCommit === undefined) {
        commit();
      } else {
        await hooks.midCommit(commit);
        if (!committed) {
          throw new Error("test backend mid-commit hook must commit once");
        }
      }
      await hooks?.afterCommitBeforeAck?.();
      return result;
    },
  };
  return backend;
};
export{createTestBackend,seedFaultInjectionBranch,readBranch,readTurnNode};
