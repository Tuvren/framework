export const fixtures = {
  async get<T>(state: Map<string, T>, key: string): Promise<T | null> {
    return Promise.resolve(state.get(key) ?? null);
  },
  async health(): Promise<{ ok: true }> {
    return Promise.resolve({ ok: true });
  },
  async put<T>(state: Map<string, T>, key: string, value: T): Promise<void> {
    state.set(key, value);
    return Promise.resolve();
  },
  async set(): Promise<void> { return Promise.resolve(); },
};
