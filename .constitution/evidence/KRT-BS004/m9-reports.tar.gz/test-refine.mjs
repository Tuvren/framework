import{readFileSync,writeFileSync}from'node:fs';let f='typescript/kernel/testkit/src/lib/fault-injecting-backend.ts',s=readFileSync(f,'utf8');s=s.replace('return async () => {\n    const result: unknown = await method.call(value);','return async (...args: unknown[]) => {\n    const result: unknown = await method.apply(value, args);');writeFileSync(f,s);
f='typescript/kernel/testkit/test/kernel-testkit.test.ts';s=readFileSync(f,'utf8').replace('    for (const expected of [success, failure, domainError]) {','    await Promise.all([success, failure, domainError].map(async (expected) => {').replace('          await Promise.resolve();\n        },\n        async destroy','          await backend.health();\n        },\n        async destroy').replace('          calls.push("destroy");\n          await Promise.resolve();','          calls.push("destroy");\n          await backend.health();').replace('      for (const key of ["close", "destroy", "fsck"]) {','      const invoke = async (key: string): Promise<void> => {').replace('      deepStrictEqual(calls, ["close", "destroy", "fsck"]);\n    }','      };\n      await invoke("close");\n      await invoke("destroy");\n      await invoke("fsck");\n      deepStrictEqual(calls, ["close", "destroy", "fsck"]);\n    }));');
// Remove the old for-body closing brace replaced by invoke's delimiter.
s=s.replace('        }\n      }\n      };\n      await invoke','        }\n      };\n      await invoke');
const start=s.indexOf('  test("clears installed hooks before propagating transaction errors"');s=s.slice(0,start)+`  test("clears installed hooks before propagating transaction errors", async () => {
    const actualError = new Error("backend transaction failed");
    const calls: string[] = [];
    const control = {
      setFaultHooks(hooks: object | null) { calls.push(hooks === null ? "clear" : "install"); },
      supportsFaultPoint() { return true; },
    };
    const backend: RuntimeBackend = {
      capabilities() { return { "thread.enumeration": false }; },
      health: createTestBackend().health,
      async transact<T>(_work: (tx: RuntimeBackendTx) => Promise<T>): Promise<T> {
        calls.push("transaction");
        return await Promise.reject<T>(actualError);
      },
    };
    Object.defineProperty(backend, Symbol("fault-control"), { value: control });
    const wrapped = createFaultInjectingBackend(backend, { point: "before-commit", policy: "once" });
    await rejects(wrapped.transact(async (tx) => await tx.branches.get("missing")), (error: unknown) => {
      deepStrictEqual(calls, ["install", "transaction", "clear"]);
      strictEqual(error, actualError);
      return true;
    });
  });
});\n`;writeFileSync(f,s);
