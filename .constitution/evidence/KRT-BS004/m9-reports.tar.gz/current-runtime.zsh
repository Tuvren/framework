set -e
bun /tmp/tuvren-bs-m9/make-helpers.ts current
bun /tmp/tuvren-bs-m9/capture-runtime.ts entry current > /tmp/tuvren-bs-m9/runtime-current.json
bun /tmp/tuvren-bs-m9/bench-probe.mjs current > /tmp/tuvren-bs-m9/bench-current.json
cmp /tmp/tuvren-bs-m9/runtime-baseline.json /tmp/tuvren-bs-m9/runtime-current.json
cmp /tmp/tuvren-bs-m9/bench-baseline.json /tmp/tuvren-bs-m9/bench-current.json
