import pathlib,subprocess,json
root=pathlib.Path.cwd(); out=pathlib.Path('/tmp/tuvren-bs-m9')
files=list((root/'typescript/kernel/testkit').rglob('*.ts'));files=[f for f in files if not any(p in f.parts for p in ['node_modules','dist'])]
for f in files:
 rel=f.relative_to(root); d=out/'baseline'/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(f.read_text())
for f in (root/'typescript/kernel/testkit/src').rglob('*.ts'):
 rel=f.relative_to(root); d=out/'runtime-baseline'/rel; d.parent.mkdir(parents=True,exist_ok=True)
 s=f.read_text()
 for p,dest in [('@tuvren/core','typescript/core/src/index.ts'),('@tuvren/kernel-protocol','typescript/kernel/protocol/src/index.ts'),('@tuvren/backend-shared','typescript/kernel/backends/shared/src/index.ts')]:s=s.replace('"'+p+'"',json.dumps(str(root/dest)))
 d.write_text(s)
for fn in ['capture-runtime.ts','make-helpers.ts']:
 s=(pathlib.Path('/tmp/tuvren-bs-m7b')/fn).read_text().replace('/tmp/tuvren-bs-m7b','/tmp/tuvren-bs-m9')
 if fn=='capture-runtime.ts':
  s=s.replace("typeof v==='function'?v.length:null","null")
 (out/fn).write_text(s)
prod=list((root/'typescript/kernel/testkit/src/lib').glob('*.ts'));(out/'production.json').write_text(json.dumps([str(f.relative_to(root)) for f in prod]))
