import{readFileSync,writeFileSync}from'node:fs';let f='typescript/kernel/testkit/src/lib/kernel-test-fixtures.ts',s=readFileSync(f,'utf8');s=s.replace('import { setTimeout } from "node:timers/promises";\n','').replace('import type { KernelRecord }','import { setTimeout } from "node:timers/promises";\n\nimport type { KernelRecord }');writeFileSync(f,s);
f='typescript/kernel/testkit/test/native-admission.test.ts';writeFileSync(f,readFileSync(f,'utf8').replaceAll('"read"','"load"'));
f='typescript/kernel/testkit/test/kernel-testkit.test.ts';s=readFileSync(f,'utf8');const insert=`
  test("preserves optional maintenance receivers, results, errors and absence", async () => {
    const success = { extra: "preserved", ok: true };
    const failure = { ok: false, reason: "damaged index" };
    const domainError = new Error("fsck backend failure");
    for (const expected of [success, failure, domainError]) {
      const calls: string[] = [];
      const backend = Object.assign(createTestBackend(), {
        async close() {
          strictEqual(this, backend);
          calls.push("close");
          await Promise.resolve();
        },
        async destroy(options?: { dropSchema?: boolean }) {
          strictEqual(this, backend);
          deepStrictEqual(options, { dropSchema: true });
          calls.push("destroy");
          await Promise.resolve();
        },
        async fsck() {
          strictEqual(this, backend);
          calls.push("fsck");
          if (expected instanceof Error) {
            return await Promise.reject(expected);
          }
          return await Promise.resolve(expected);
        },
      });
      const wrapped = createFaultInjectingBackend(backend, { point: "before-commit", policy: "once" });
      for (const key of ["close", "destroy", "fsck"]) {
        const method: unknown = Reflect.get(wrapped, key);
        if (typeof method !== "function") {
          throw new TypeError("expected forwarded maintenance method");
        }
        if (key === "fsck" && expected instanceof Error) {
          await rejects(async () => { await method.call(wrapped); }, (error: unknown) => {
            strictEqual(error, expected);
            return true;
          });
        } else {
          const result: unknown = await method.call(wrapped, { dropSchema: true });
          strictEqual(result, key === "fsck" ? expected : undefined);
        }
      }
      deepStrictEqual(calls, ["close", "destroy", "fsck"]);
    }
    const absent = createFaultInjectingBackend(createTestBackend(), { point: "before-commit", policy: "once" });
    for (const key of ["close", "destroy", "fsck", "reclaim", "purgeScope"]) {
      strictEqual(key in absent, false);
    }
  });

  test("validates unknown fsck results without changing valid result objects", async () => {
    const backend = Object.assign(createTestBackend(), {
      async fsck() { return await Promise.resolve({ ok: false }); },
    });
    const wrapped = createFaultInjectingBackend(backend, { point: "before-commit", policy: "once" });
    const method: unknown = Reflect.get(wrapped, "fsck");
    if (typeof method !== "function") { throw new TypeError("expected forwarded fsck method"); }
    await rejects(async () => { await method.call(wrapped); }, { message: "backend fsck must return an ok result or a failure reason", name: "TypeError" });
  });

  test("clears installed hooks before propagating transaction errors", async () => {
    const actualError = new Error("backend transaction failed");
    for (const rejection of [actualError, "invalid backend rejection"]) {
      const calls: string[] = [];
      const control = {
        setFaultHooks(hooks: object | null) { calls.push(hooks === null ? "clear" : "install"); },
        supportsFaultPoint() { return true; },
      };
      const backend = Object.assign({
        capabilities() { return { "thread.enumeration": false }; },
        async health() { return await Promise.resolve({ ok: true }); },
        async transact<T>(_work: (tx: RuntimeBackendTx) => Promise<T>): Promise<T> {
          calls.push("transaction");
          return await Promise.reject<T>(rejection);
        },
      }, { [Symbol("fault-control")]: control });
      const wrapped = createFaultInjectingBackend(backend, { point: "before-commit", policy: "once" });
      await rejects(wrapped.transact(async () => { await Promise.resolve(); }), (error: unknown) => {
        deepStrictEqual(calls, ["install", "transaction", "clear"]);
        if (rejection instanceof Error) {
          strictEqual(error, rejection);
        } else {
          if (!(error instanceof Error)) { throw new TypeError("expected normalized error"); }
          strictEqual(error.message, "backend transaction rejected with a non-Error value");
          strictEqual(error.cause, rejection);
        }
        return true;
      });
    }
  });
`;
s=s.slice(0,s.lastIndexOf('\n});'))+insert+s.slice(s.lastIndexOf('\n});'));writeFileSync(f,s);
