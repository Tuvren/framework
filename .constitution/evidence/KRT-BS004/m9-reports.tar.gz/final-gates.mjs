import assert from'node:assert/strict';import{readFileSync,writeFileSync,mkdirSync}from'node:fs';import{spawnSync,execFileSync}from'node:child_process';import{createHash}from'node:crypto';import path from'node:path';
const repo=process.cwd(),out='/tmp/tuvren-bs-m9/final';mkdirSync(out,{recursive:true});const sha=b=>createHash('sha256').update(b).digest('hex');
const snapshot=()=>{const files=[...new Set([...execFileSync('git',['ls-files','-z'],{encoding:'utf8'}).split('\0'),...execFileSync('git',['ls-files','--others','--exclude-standard','-z'],{encoding:'utf8'}).split('\0')])].filter(Boolean).sort();return{head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),index:sha(execFileSync('git',['ls-files','--stage','-z'])),status:execFileSync('git',['status','--porcelain=v1','-z'],{encoding:'utf8'}),hashes:Object.fromEntries(files.map(f=>[f,sha(readFileSync(f))]))}};
const before=snapshot();writeFileSync(out+'/tree-before.json',JSON.stringify(before,null,2));const commands=[
['01-native',['bunx','--bun','oxlint','--type-aware','typescript/kernel/testkit']],
['02-json',['bun','tools/scripts/json-check.ts','typescript/kernel/testkit']],
['03-selection',['bunx','--bun','oxlint','--debug=files','typescript/kernel/testkit']],
['04-typecheck',['bun','run','nx','run','kernel-testkit:typecheck']],
['05-test',['bun','run','nx','run','kernel-testkit:test']],
['06-exports-smoke',['bun','run','nx','run','kernel-testkit:exports-smoke']],
['07-full-lint',['bun','run','lint']],
['08-package-conformance',['bun','run','nx','run','kernel-testkit:conformance']],
['09-workspace-typecheck',['bun','run','typecheck']],
['10-api-freeze',['bun','run','api-freeze:check']],
['11-changeset',['bun','run','changeset:check','--base=master']],
['12-preset-controls',['bun','test','tools/scripts/oxc-preparation.test.ts']],
['13-partition-controls',['bun','test','tools/scripts/lib/biome-lint-partition.test.ts','tools/scripts/lib/biome-oxc-discovery.test.ts','tools/scripts/oxc-project-discovery.test.ts','tools/scripts/lib/json-source-integrity.test.ts','tools/scripts/biome-lint.test.ts']],
['14-format',['bunx','--bun','oxfmt','--check','typescript/kernel/testkit','tools/biome-coverage/bs.json']],
['15-diff',['git','diff','--check']],
['16-admission',['bun','/tmp/tuvren-bs-m9/admission-proof.mjs','/tmp/tuvren-bs-m9/admission-final']],
['17-program',['bun','/tmp/tuvren-bs-m9/program.mjs','/tmp/tuvren-bs-m9/program-final.json']],
['18-signatures',['bun','/tmp/tuvren-bs-m9/signatures.mjs']],
['19-fixtures',['bun','/tmp/tuvren-bs-m9/fixture-proof.mjs']],
['20-json-order',['bun','/tmp/tuvren-bs-m9/json-order-proof.mjs']],
['21-error-boundaries',['bun','/tmp/tuvren-bs-m9/error-boundaries.mjs']],
['22-cache-fresh',['bun','run','nx','run','kernel-testkit:lint','--skipNxCache']],
['23-cache-populate',['bun','run','nx','run','kernel-testkit:lint']],
['24-cache-repeat',['bun','run','nx','run','kernel-testkit:lint']],
];const results=[];let failure;
try{for(const [name,command]of commands){const r=spawnSync(command[0],command.slice(1),{cwd:repo,encoding:'utf8',maxBuffer:64e6,env:{...process.env,LC_ALL:'C'}});const result={name,command,exit_code:r.status,stdout:r.stdout,stderr:r.stderr};writeFileSync(out+'/'+name+'.json',JSON.stringify(result,null,2));results.push({name,command,exit_code:r.status});console.log(name,r.status);assert.deepEqual(snapshot(),before,'tracked/index/new source state frozen after '+name);if(r.status!==0){failure=name;break;}}}finally{const command=['git','fetch','origin','master'];const r=spawnSync(command[0],command.slice(1),{cwd:repo,encoding:'utf8',maxBuffer:16e6});writeFileSync(out+'/fetch-cleanup.json',JSON.stringify({command,exit_code:r.status,stdout:r.stdout,stderr:r.stderr},null,2));results.push({name:'fetch-cleanup',command,exit_code:r.status});console.log('fetch-cleanup',r.status);const after=snapshot();writeFileSync(out+'/tree-after.json',JSON.stringify(after,null,2));assert.deepEqual(after,before);writeFileSync(out+'/results.json',JSON.stringify({status:failure||r.status!==0?'fail':'pass',failure,tracked_and_new_files:Object.keys(before.hashes).length,all_tracked_index_and_new_source_frozen:true,results},null,2));assert(!failure,failure);assert.equal(r.status,0);}
