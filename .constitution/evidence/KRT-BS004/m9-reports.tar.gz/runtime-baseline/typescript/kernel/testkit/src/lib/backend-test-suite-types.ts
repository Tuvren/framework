/**
 * Copyright 2026 Oscar Yáñez Cisterna (@SkrOYC)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { RuntimeBackend as KrakenBackend } from "/home/oscar/GitHub/Tuvren/framework-worktrees/EPIC-BS/typescript/kernel/protocol/src/index.ts";

/**
 * Minimal test-runner surface the shared backend suites register against —
 * a thin shim over whichever test framework (Vitest, Bun test, etc.) the
 * calling package uses, so this package stays framework-agnostic.
 */
export interface BackendTestSuiteApi {
  describe(name: string, register: () => void): void;
  test(name: string, run: () => Promise<void> | void): void;
}

/** Builds a fresh `RuntimeBackend` instance for one test case. */
export type BackendFactory = () => KrakenBackend;

/**
 * Options shared by every `register*Suite` entry point in this package:
 * how to construct the backend under test, which test framework to
 * register against, and an optional override for the top-level suite name.
 */
export interface BackendConformanceSuiteOptions {
  createBackend: BackendFactory;
  suiteName?: string;
  testApi: BackendTestSuiteApi;
}
