import assert from 'node:assert/strict';
import { spawnSync, execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, readdirSync, mkdirSync, mkdtempSync, lstatSync, symlinkSync } from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { createHash } from 'node:crypto';
const repo = process.cwd(), evidence = import.meta.dirname;
const metadata = JSON.parse(readFileSync(path.join(evidence, 'summary.json'), 'utf8'));
const scratch = mkdtempSync(path.join(os.tmpdir(), 'tuvren-bs-m9-replay-'));
const sha = value => createHash('sha256').update(value).digest('hex');
const copy = (source, destination) => { mkdirSync(destination, { recursive: true }); for (const entry of readdirSync(source)) { const from = path.join(source, entry), to = path.join(destination, entry), stat = lstatSync(from); if (stat.isSymbolicLink()) continue; if (stat.isDirectory()) copy(from, to); else { let bytes = readFileSync(from); if (/\.(?:ts|mjs|zsh)$/u.test(entry)) bytes = Buffer.from(bytes.toString().replaceAll('/tmp/tuvren-bs-m9', scratch).replaceAll(metadata.measurement_environment_root, repo)); writeFileSync(to, bytes); } } };
for (const directory of ['baseline', 'runtime-baseline']) copy(path.join(evidence, directory), path.join(scratch, directory));
const probes = ['admission-proof.mjs', 'signatures.mjs', 'program.mjs', 'fixture-proof.mjs', 'json-order-proof.mjs', 'error-boundaries.mjs', 'retained-proof.mjs', 'bench-probe.mjs', 'cache-inputs.mjs'];
for (const file of probes) writeFileSync(path.join(scratch, file), readFileSync(path.join(evidence, file), 'utf8').replaceAll('/tmp/tuvren-bs-m9', scratch).replaceAll(metadata.measurement_environment_root, repo));
symlinkSync(path.join(repo, 'node_modules'), path.join(scratch, 'node_modules'));
symlinkSync(path.join(repo, 'spec'), path.join(scratch, 'spec'));
symlinkSync(path.join(repo, 'spec'), path.join(scratch, 'runtime-baseline/spec'));
const frozen = () => { const files = [...new Set([...execFileSync('git', ['ls-files', '-z'], { encoding: 'utf8' }).split('\0'), ...execFileSync('git', ['ls-files', '--others', '--exclude-standard', '-z'], { encoding: 'utf8' }).split('\0')])].filter(Boolean).sort(); return { index: sha(execFileSync('git', ['ls-files', '--stage', '-z'])), files: Object.fromEntries(files.map(file => [file, sha(readFileSync(file))])) }; };
const before = frozen();
for (const [file, digest] of Object.entries(metadata.product_sha256)) assert.equal(sha(readFileSync(file)), digest, `candidate source ${file}`);
const commands = [
 ['bunx', '--bun', 'oxlint', '--type-aware', 'typescript/kernel/testkit'],
 ['bun', 'tools/scripts/json-check.ts', 'typescript/kernel/testkit'],
 ['bun', path.join(scratch, 'admission-proof.mjs'), path.join(scratch, 'admission')],
 ['bun', path.join(scratch, 'program.mjs'), path.join(scratch, 'program.json')],
 ['bun', path.join(scratch, 'cache-inputs.mjs')],
 ['bun', path.join(scratch, 'signatures.mjs')],
 ['bun', path.join(scratch, 'fixture-proof.mjs')],
 ['bun', path.join(scratch, 'json-order-proof.mjs')],
 ['bun', path.join(scratch, 'error-boundaries.mjs')],
 ['bun', path.join(scratch, 'retained-proof.mjs'), path.join(scratch, 'retained-proof')],
 ['bun', path.join(scratch, 'bench-probe.mjs'), 'baseline'],
 ['bun', path.join(scratch, 'bench-probe.mjs'), 'current'],
];
const results = [];
for (const [number, command] of commands.entries()) { const result = spawnSync(command[0], command.slice(1), { cwd: repo, encoding: 'utf8', maxBuffer: 64e6, env: { ...process.env, LC_ALL: 'C' } }); results.push({ command, exit_code: result.status, stdout: result.stdout, stderr: result.stderr }); writeFileSync(path.join(scratch, `replay-${number}.json`), JSON.stringify(results.at(-1), null, 2)); assert.equal(result.status, 0, result.stderr + result.stdout); assert.deepEqual(frozen(), before, 'read-only replay'); }
assert.equal(results.at(-1).stdout, results.at(-2).stdout, 'decimal-prefix behavior');
console.log(JSON.stringify({ status: 'pass', scratch, commands: results.length, source_frozen: true }));
