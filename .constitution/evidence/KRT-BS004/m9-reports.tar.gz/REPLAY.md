# M9 evidence replay

Run from the M9 candidate or its exact committed source, with this evidence directory extracted. The replay checks the twelve product SHA-256 fingerprints before invoking native tools. Load the repository environment and hold the shared runtime lock outside the script; it takes no nested lock:

```zsh
cd "$WORKTREE"
direnv exec "$ENV_ROOT" flock "$RUNTIME_LOCK" bun "$EVIDENCE_DIR/replay.mjs"
```

`ENV_ROOT` is the repository that provides direnv; `RUNTIME_LOCK` is the shared runtime-verification lock. The replay derives the worktree from its current directory and creates independent temporary files. It never changes repository source. The existing baseline commit must remain accessible.

`final/results.json` contains the seven exact M9 gates and eighteen additional successful checks, including full conformance against actual backends. `final/tree-before.json` and `final/tree-after.json` bind all tracked bytes, index state, and new source bytes. Required package/scenario verification is already archived; replay focuses on admission, policy, ownership, actual dependencies, signatures, behavior, and directive disposition.

Files classified as `historical-attempt-or-baseline` in the digest index are historical measurements, including held candidates containing prohibited resolved-Promise awaits. Their native-zero results are not final acceptance. Only the final source fingerprints and final gate/proof records establish M9 readiness. The focused fixture proves its five named unit scenarios; real backend recovery and concurrency authority remains the shared kernel restart/recovery plan.
