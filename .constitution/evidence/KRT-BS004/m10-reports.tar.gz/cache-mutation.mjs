import assert from 'node:assert/strict';import{readFileSync,writeFileSync}from'node:fs';import{spawnSync}from'node:child_process';import{createHash}from'node:crypto';
const out='/tmp/tuvren-bs-m10',file='typescript/kernel/certification/test/kernel-typescript-conformance.test.ts',original=readFileSync(file);
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const capture=name=>{const command=['bun',out+'/hash.mjs',out+'/'+name+'.json'];const r=spawnSync(command[0],command.slice(1),{encoding:'utf8',env:{...process.env,NX_DAEMON:'false'},maxBuffer:64e6});writeFileSync(out+'/'+name+'.log',r.stdout+r.stderr);assert.equal(r.status,0,r.stderr);return JSON.parse(readFileSync(out+'/'+name+'.json','utf8')).hash.value;};
const before=capture('hash-before');let mutated;
try{writeFileSync(file,Buffer.concat([original,Buffer.from('\n// Native lint cache source probe.\n')]));mutated=capture('hash-mutated');assert.notEqual(mutated,before);}finally{writeFileSync(file,original);}
const restored=capture('hash-restored');assert.equal(restored,before);assert.deepEqual(readFileSync(file),original);
writeFileSync(out+'/cache-mutation.json',JSON.stringify({status:'pass',file,original_sha256:sha(original),before_hash:before,mutated_hash:mutated,restored_hash:restored,actual_Nx_hasher_source_invalidation_proven:true,all_original_bytes_restored:true,mutation_before_broad_source_freeze:true,mutation_only_owned_source:true},null,2));console.log('PASS actual source mutation changes Nx lint hash and exact restoration recovers original hash');
