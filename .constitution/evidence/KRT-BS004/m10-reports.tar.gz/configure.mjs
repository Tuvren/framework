import {readFileSync,writeFileSync} from 'node:fs';
const root='typescript/kernel/certification';
const file=root+'/project.json',project=JSON.parse(readFileSync(file,'utf8'));
const defaults=JSON.parse(readFileSync('nx.json','utf8')).targetDefaults.lint.inputs;
project.targets.lint={executor:'nx:run-commands',inputs:[...defaults,'^production','{workspaceRoot}/tsconfig.json','{workspaceRoot}/tsconfig.base.json'],options:{cwd:'.',commands:[`bunx --bun oxlint --type-aware ${root}`,`bun tools/scripts/json-check.ts ${root}`],parallel:false}};
writeFileSync(file,JSON.stringify(project,null,2)+'\n');
for(const root of ['typescript/kernel/certification-sqlite','typescript/kernel/certification-postgres']){
 const file=root+'/project.json',project=JSON.parse(readFileSync(file,'utf8'));
 project.targets.lint={executor:'nx:run-commands',options:{cwd:'.',command:`bun tools/scripts/json-check.ts --json-only ${root}`}};
 writeFileSync(file,JSON.stringify(project,null,2)+'\n');
}
writeFileSync('tools/biome-coverage/bs.json','[]\n');
writeFileSync('/tmp/tuvren-bs-m10/hash.mjs',readFileSync('/tmp/tuvren-bs-m8/hash.mjs','utf8').replaceAll('kernel-grpc-client','kernel-typescript-certification'));
