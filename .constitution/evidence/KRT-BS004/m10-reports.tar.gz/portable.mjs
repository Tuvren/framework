import{readFileSync,writeFileSync}from'node:fs';import{execFileSync}from'node:child_process';
const rel='typescript/kernel/certification/test/kernel-typescript-conformance.test.ts';
writeFileSync('/tmp/tuvren-bs-m10/baseline/certification.test.ts',execFileSync('git',['show','cd1f44d94e48b963eb48de159484d6de548c96e3:'+rel]));
let code=readFileSync('/tmp/tuvren-bs-m10/behavior-proof.mjs','utf8');
code=code.replace("const repo=process.cwd(),out='/tmp/tuvren-bs-m10',rel=", "const repo=process.cwd(),out=process.argv[3],baselineRoot=process.argv[2],rel=");
code=code.replace("const oldSource=execFileSync('git',['show','HEAD:'+rel],{encoding:'utf8'}),newSource=readFileSync(rel,'utf8');", "mkdirSync(out,{recursive:true});const oldSource=readFileSync(baselineRoot+'/baseline/certification.test.ts','utf8'),newSource=readFileSync(rel,'utf8');");
writeFileSync('/tmp/tuvren-bs-m10/behavior-replay.mjs',code);
