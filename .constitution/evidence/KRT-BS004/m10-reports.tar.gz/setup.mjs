import {readFileSync,writeFileSync} from 'node:fs';
writeFileSync('/tmp/tuvren-bs-m10/program.mjs',readFileSync('/tmp/tuvren-bs-m9/program.mjs','utf8').replaceAll('typescript/kernel/testkit','typescript/kernel/certification'));
