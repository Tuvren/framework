import assert from 'node:assert/strict';import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';import {execFileSync} from 'node:child_process';import {pathToFileURL} from 'node:url';
const repo=process.cwd(),out=process.argv[3],baselineRoot=process.argv[2],rel='typescript/kernel/certification/test/kernel-typescript-conformance.test.ts';
const ts=(await import(Bun.resolveSync('typescript',repo))).default;
mkdirSync(out,{recursive:true});const oldSource=readFileSync(baselineRoot+'/baseline/certification.test.ts','utf8'),newSource=readFileSync(rel,'utf8');
assert.equal(newSource.slice(newSource.indexOf('describe("kernel TypeScript certification"')),oldSource.slice(oldSource.indexOf('describe("kernel TypeScript certification"')),'all existing positive certification assertions unchanged');
const names=['isRecord','readJsonObject','readSuiteManifest','readJsonSchema','fixturePathById'];
const sourceModule=source=>{
 const ast=ts.createSourceFile(rel,source,ts.ScriptTarget.Latest,true);const selected=ast.statements.filter(statement=>ts.isVariableStatement(statement)&&statement.declarationList.declarations.some(d=>ts.isIdentifier(d.name)&&names.includes(d.name.text))).map(statement=>statement.getText(ast));assert.equal(selected.length,names.length);
 const code='import {readFileSync} from "node:fs";import {fileURLToPath} from "node:url";\n'+selected.join('\n')+'\nexport {'+names.join(',')+'};';
 return 'data:text/javascript;base64,'+Buffer.from(new Bun.Transpiler({loader:'ts'}).transformSync(code)).toString('base64');
};
const valid={boundary:'kernel',fixtureSchemaPath:'schema.json',fixtures:[{id:'x',path:'x.json'}],suiteId:'test',suiteVersion:'1'};
const cases=[null,[],1,'invalid',{}, {...valid,boundary:0,fixtures:0},{...valid,fixtureSchemaPath:0},{...valid,fixtures:0},{...valid,suiteId:0},{...valid,suiteVersion:0},{...valid,fixtures:[null]},{...valid,fixtures:[{id:0,path:0}]},{...valid,fixtures:[{id:'x',path:0}]},valid];
const fixture=out+'/manifest-probe.json';const captures={};
for(const [phase,source]of [['baseline',oldSource],['current',newSource]]){
 const m=await import(sourceModule(source));const results=[];
 for(const [i,value]of cases.entries()){writeFileSync(fixture,JSON.stringify(value));try{results.push({case:i,result:m.readSuiteManifest(pathToFileURL(fixture))});}catch(error){results.push({case:i,error:{name:error.name,message:error.message}});}}
 for(const [i,value]of [true,false,{},[],null,1].entries()){writeFileSync(fixture,JSON.stringify(value));try{results.push({case:'schema-'+i,result:m.readJsonSchema(fixture)});}catch(error){results.push({case:'schema-'+i,error:{name:error.name,message:error.message}});}}
 try{m.fixturePathById([], 'missing')}catch(error){results.push({case:'missing-fixture',error:{name:error.name,message:error.message}})}
 captures[phase]=results;
}
const withoutNames=rows=>rows.map(row=>row.error?{case:row.case,message:row.error.message}:row);assert.deepEqual(withoutNames(captures.current),withoutNames(captures.baseline));
const normalizations=captures.current.filter((row,i)=>row.error?.name!==captures.baseline[i].error?.name);assert.equal(normalizations.length,6);for(const row of normalizations){assert.equal(row.error.name,'TypeError');assert.match(row.error.message,/must be a valid suite manifest$/);}
writeFileSync(out+'/behavior-proof.json',JSON.stringify({status:'pass',first_failure_messages_order_and_valid_values_preserved:true,existing_certification_assertions_byte_identical:true,internal_type_guard_constructor_normalization:'A11; Error→TypeError for invalid suite-manifest fields only',cases:captures.current.length,normalizations,...captures},null,2));console.log('PASS21 original/current cases;6 measured TypeError normalizations; all existing positive assertions unchanged');
