import {readFileSync,writeFileSync} from 'node:fs';
const hash=JSON.parse(readFileSync('/tmp/tuvren-bs-m10/hash-candidate.json','utf8'));
const program=JSON.parse(readFileSync('/tmp/tuvren-bs-m10/baseline/program.json','utf8'));
const missing=program.files.filter(file=>!hash.hash.inputs.files.includes(file));
console.log(JSON.stringify({missing,program_files:program.files.length,hash_files:hash.hash.inputs.files.length,dependencies:hash.taskGraph.dependencies},null,2));
writeFileSync('/tmp/tuvren-bs-m10/cache-initial.json',JSON.stringify({missing,program_files:program.files.length,hash_files:hash.hash.inputs.files.length},null,2));
