import assert from 'node:assert/strict';import{readFileSync,writeFileSync,mkdirSync,openSync,closeSync}from'node:fs';import{spawnSync,execFileSync}from'node:child_process';import{createHash}from'node:crypto';
const repo=process.cwd(),out='/tmp/tuvren-bs-m10/final';mkdirSync(out,{recursive:true});const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const snapshot=()=>{const files=[...new Set([...execFileSync('git',['ls-files','-z'],{encoding:'utf8'}).split('\0'),...execFileSync('git',['ls-files','--others','--exclude-standard','-z'],{encoding:'utf8'}).split('\0')])].filter(Boolean).sort();return{head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),index:sha(execFileSync('git',['ls-files','--stage','-z'])),status:execFileSync('git',['status','--porcelain=v1','-z'],{encoding:'utf8'}),hashes:Object.fromEntries(files.map(file=>[file,sha(readFileSync(file))]))}};
const before=snapshot();writeFileSync(out+'/tree-before.json',JSON.stringify(before,null,2)+'\n');
const commands=[
['01-native',['bunx','--bun','oxlint','--type-aware','typescript/kernel/certification']],
['02-json',['bun','tools/scripts/json-check.ts','typescript/kernel/certification']],
['03-sqlite-json',['bun','tools/scripts/json-check.ts','--json-only','typescript/kernel/certification-sqlite']],
['04-postgres-json',['bun','tools/scripts/json-check.ts','--json-only','typescript/kernel/certification-postgres']],
['14-certification-typecheck',['bun','run','nx','run','kernel-typescript-certification:typecheck']],
['15-certification-tests',['bun','run','nx','run','kernel-typescript-certification:test']],
['16-api-freeze',['bun','run','api-freeze:check']],
['17-format',['bunx','--bun','oxfmt','--check','typescript/kernel/certification','typescript/kernel/certification-sqlite/project.json','typescript/kernel/certification-postgres/project.json','tools/biome-coverage/bs.json']],
['18-native-all-five',['bunx','--bun','oxlint','--type-aware','typescript/kernel/grpc-client','typescript/kernel/testkit','typescript/kernel/certification','typescript/kernel/certification-sqlite','typescript/kernel/certification-postgres']],
['19-admission',['bun','/tmp/tuvren-bs-m10/admission-proof.mjs','/tmp/tuvren-bs-m10/admission-final']],
['20-behavior',['bun','/tmp/tuvren-bs-m10/behavior-proof.mjs']],
['21-cache-fresh',['bun','run','nx','run-many','-t','lint','--projects=kernel-typescript-certification,kernel-typescript-sqlite-certification,kernel-typescript-postgres-certification','--skipNxCache','--parallel=1']],
['22-cache-populate',['bun','run','nx','run-many','-t','lint','--projects=kernel-typescript-certification,kernel-typescript-sqlite-certification,kernel-typescript-postgres-certification','--parallel=1']],
['23-cache-repeat',['bun','run','nx','run-many','-t','lint','--projects=kernel-typescript-certification,kernel-typescript-sqlite-certification,kernel-typescript-postgres-certification','--parallel=1']],
['24-diff',['git','diff','--check']],
['05-certification-conformance',['bun','run','nx','run','kernel-typescript-certification:conformance']],
['06-sqlite-conformance',['bun','run','nx','run','kernel-typescript-sqlite-certification:conformance']],
['07-postgres-conformance',['bun','run','nx','run','kernel-typescript-postgres-certification:conformance']],
['08-workspace-typecheck',['bun','run','typecheck']],
['09-full-lint',['bun','run','lint']],
['10-check',['bun','run','check']],
['11-kernel-verify',['bun','run','verify:kernel']],
['12-full-verify',['bun','run','verify']],
['13-changeset',['bun','run','changeset:check','--base=master']]
];
const results=[];let failure;
const execute=(name,command,extraEnv={})=>{const log=out+'/'+name+'.log',fd=openSync(log,'w'),started_at=new Date().toISOString();console.log(started_at,'START',name,command.join(' '));let r;try{r=spawnSync(command[0],command.slice(1),{cwd:repo,env:{...process.env,LC_ALL:'C',...extraEnv},stdio:['ignore',fd,fd]});}finally{closeSync(fd);}
const result={name,command,cwd:repo,env:extraEnv,exit_code:r.status,started_at,finished_at:new Date().toISOString(),log:name+'.log'};writeFileSync(out+'/'+name+'.json',JSON.stringify(result,null,2)+'\n');results.push(result);console.log(result.finished_at,'END',name,r.status);return result;};
try{for(const [name,command]of commands){const result=execute(name,command,name==='12-full-verify'?{VERIFY_SERIAL:'1'}:{});assert.deepEqual(snapshot(),before,'ALL tracked/index/new source frozen after '+name);if(['10-check','11-kernel-verify','12-full-verify'].includes(name)){const fetch=execute(name+'-fetch',['git','fetch','origin','master']);if(fetch.exit_code!==0){failure=name+'-fetch';break;}}if(result.exit_code!==0){failure=name;break;}}}catch(error){failure??='source-freeze';writeFileSync(out+'/exception.log',String(error.stack));}finally{const cleanup=execute('fetch-cleanup',['git','fetch','origin','master']);const after=snapshot();writeFileSync(out+'/tree-after.json',JSON.stringify(after,null,2)+'\n');const frozen=JSON.stringify(after)===JSON.stringify(before);writeFileSync(out+'/results.json',JSON.stringify({status:failure||cleanup.exit_code!==0||!frozen?'fail':'pass',failure,tracked_and_new_files:Object.keys(before.hashes).length,all_tracked_index_and_new_source_frozen:frozen,results},null,2)+'\n');assert(frozen,'tracked/index/new source drift');assert(!failure,failure);assert.equal(cleanup.exit_code,0);}
