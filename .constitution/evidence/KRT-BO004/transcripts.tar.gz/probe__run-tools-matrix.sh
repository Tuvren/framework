#!/usr/bin/env bash
# KRT-BO004: run each tracked tools/** test file (which no Nx project owns, so
# no Nx `test` target discovers them) in ordinary and `--isolate` mode.
#
# The one file with a real CI lane today (tools/scripts/changeset-check.test.ts,
# invoked by .github/workflows/ci.yml) is run from the repo root exactly as CI
# does it; the remaining files are probed the same way so the comparison is
# apples-to-apples.
set -uo pipefail

ROOT=/home/oscar/GitHub/Tuvren/framework-bo
W=/home/oscar/.cache/pi-subagent/framework/wf-bo-m4/lead-replay
OUT_DIR="$W/raw/matrix/tools"
RESULTS="$W/raw/matrix/results-tools.tsv"
mkdir -p "$OUT_DIR"
printf 'file\tmode\texit\tpass\tfail\tskip\tduration_s\tlog\n' >"$RESULTS"
export LC_ALL=C

cd "$ROOT" || exit 1
mapfile -t FILES < <(grep '^tools/' "$W/raw/tracked-tests.txt")

for file in "${FILES[@]}"; do
  for mode in ordinary isolate; do
    label="$(echo "$file" | tr '/' '_')"
    log="$OUT_DIR/${label}.${mode}.log"
    start=$(date +%s)
    if [[ "$mode" == "isolate" ]]; then
      timeout 600 bun test "$file" --isolate >"$log" 2>&1
    else
      # No trailing empty argument: `bun test <file> ""` is interpreted as an
      # empty filter and silently expands discovery to the whole repository,
      # which produced a bogus 1701-pass/117-fail whole-inventory run in the
      # first attempt at this probe.
      timeout 600 bun test "$file" >"$log" 2>&1
    fi
    code=$?
    end=$(date +%s)
    pass=$(grep -oE '^ *[0-9]+ pass$' "$log" | tail -1 | grep -oE '[0-9]+' || echo "")
    fail=$(grep -oE '^ *[0-9]+ fail$' "$log" | tail -1 | grep -oE '[0-9]+' || echo "")
    skip=$(grep -oE '^ *[0-9]+ skip$' "$log" | tail -1 | grep -oE '[0-9]+' || echo "")
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$file" "$mode" "$code" "$pass" "$fail" "$skip" "$((end - start))" "$log" >>"$RESULTS"
    printf '%-62s %-8s exit=%-3s pass=%-5s fail=%-5s %ss\n' "$file" "$mode" "$code" "$pass" "$fail" "$((end - start))"
  done
done
