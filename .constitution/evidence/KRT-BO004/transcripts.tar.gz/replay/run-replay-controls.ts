#!/usr/bin/env bun
/**
 * Positive and negative controls for the KRT-BO004 per-file JUnit replay.
 *
 * Each control copies the byte-verified replay corpus, applies exactly one
 * documented mutation, then runs either the corrected replay grader or the
 * archived historical probe. The archived probe runs from a relocated copy that
 * differs from the retained member only in its scratch-root constant, which is
 * the relocation its own README prescribes. The harness fails when any
 * expectation is unmet, so a drifted control cannot be reported as a pass.
 *
 * Usage:
 *   bun run-replay-controls.ts --work <replay-dir> --source <extraction-root>
 *
 * Produced under --work:
 *   historical-relocated/compare-matrix-junit.ts   retained probe, one line relocated
 *   scaffold/raw/...                               retained layout the probe expects
 *   scaffold-swap/raw/...                          same layout after the swap
 *   controls/<name>/                               one mutated corpus per control
 *   controls/one-file-report-<name>/                 one real report as a whole corpus
 *   receipts/<name>.log                            raw command, exit and output
 *   receipts/control-matrix.json                   machine-readable summary
 *
 * Two of the controls mutate only the closing structure of a report while
 * every counter and testcase stays valid. Per-file grading cannot see those
 * mutations; the native XML processor can, which is why they exist.
 *
 * Round two added controls for the raw-tag-counting defect: a retained testcase
 * moved into an XML comment, a whole valid JUnit document hidden in a comment
 * under an empty root, fake `<testcase>` literals inside a CDATA section, and
 * unexpected root/suite nesting. Each one keeps every counter and every tag
 * literal that a text scanner would read, so only element-tree grading rejects
 * them. A positive control pins the converse: fake tag literals in comments and
 * escaped text beside a real testcase must not add counts or fail the run.
 *
 * Round three added controls for the incomplete-hierarchy defect: the full
 * 29-project corpus with one retained testcase wrapped in another testcase
 * (the reviewer reproducer), a hidden nested suite, a hidden root element, and
 * a testcase hidden under a `<failure>` metadata wrapper. All four keep every
 * counter as reported, so only a traversal that visits every testcase subtree
 * rejects them. A positive control built from the pinned reporter's own output
 * pins the converse: legitimate testcase metadata must stay accepted.
 */
import {
  cpSync,
  existsSync,
  mkdirSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { join } from "node:path";
import {
  NATIVE_METADATA_PROJECT,
  ONE_FILE_PROJECT,
  PROJECTS_TSV,
  SWAP_FILE_FROM,
  SWAP_FILE_TO,
  SWAP_PROJECT,
} from "./replay-constants";
import { ControlError } from "./replay-errors";
import {
  applyEqualAndOppositeSwap,
  buildOneFileFixture,
  commentOutFirstTestcase,
  hideNestedRootInsideTestcase,
  hideNestedSuiteInsideTestcase,
  hideTestcaseUnderMetadataWrapper,
  hideWholeDocumentInComment,
  insertCdataFakeTestcase,
  insertFakeTagLiterals,
  insertRootComment,
  mutateRootAttribute,
  mutateSuiteAttribute,
  removeClosingStructure,
  renameOuterClosingTag,
  reportPath,
  wrapFirstTestcaseInTestcase,
  wrapRootInUnexpectedElement,
  wrapSuiteInUnexpectedElement,
} from "./replay-mutations";
import {
  buildRawScaffold,
  buildScaffold,
  relocateHistorical,
} from "./replay-scaffold";
import { rootCaseCount } from "./replay-xml";

interface ControlResult {
  readonly name: string;
  readonly command: string;
  readonly exit: number;
  readonly expectedExit: number;
  readonly ok: boolean;
  readonly note: string;
}

const run = (
  args: readonly string[],
  cwd = process.cwd()
): { exit: number; stdout: string; stderr: string } => {
  const result = Bun.spawnSync({
    cmd: [process.execPath, ...args],
    cwd,
    stdout: "pipe",
    stderr: "pipe",
  });
  return {
    exit: result.exitCode ?? -1,
    stdout: result.stdout.toString(),
    stderr: result.stderr.toString(),
  };
};

const readFlag = (name: string): string => {
  const index = process.argv.indexOf(name);
  const value = index < 0 ? undefined : process.argv[index + 1];
  if (value === undefined) throw new ControlError(`${name} is required`);
  return value;
};

const work = readFlag("--work");
const source = readFlag("--source");
const corpus = join(work, "corpus");
const receipts = join(work, "receipts");
const controls = join(work, "controls");
if (!existsSync(join(corpus, PROJECTS_TSV))) {
  throw new ControlError(
    `no replay corpus at ${corpus}; run build-replay-corpus.ts first`
  );
}
for (const directory of [receipts, controls])
  mkdirSync(directory, { recursive: true });

const grader = join(work, "compare-matrix-junit-replay.ts");
const relative = (path: string): string =>
  path.startsWith(`${work}/`) ? `replay/${path.slice(work.length + 1)}` : path;

const graderCommand = (
  corpusDir: string,
  extra: readonly string[] = []
): string =>
  [
    "bun",
    relative(grader),
    "--ordinary",
    relative(join(corpusDir, "ordinary")),
    "--isolate",
    relative(join(corpusDir, "isolate")),
    "--projects",
    relative(join(corpusDir, PROJECTS_TSV)),
    ...extra,
  ].join(" ");

const graderArgs = (
  corpusDir: string,
  extra: readonly string[] = []
): string[] => [
  grader,
  "--ordinary",
  join(corpusDir, "ordinary"),
  "--isolate",
  join(corpusDir, "isolate"),
  "--projects",
  join(corpusDir, PROJECTS_TSV),
  ...extra,
];

const results: ControlResult[] = [];

const record = (
  name: string,
  command: string,
  invocation: { exit: number; stdout: string; stderr: string },
  expectedExit: number,
  note = ""
): void => {
  const body = [`$ ${command}`, `# exit=${invocation.exit}`];
  const stdout = invocation.stdout.trimEnd();
  const stderr = invocation.stderr.trimEnd();
  if (stdout !== "") body.push(stdout);
  if (stderr !== "") body.push("# stderr", stderr);
  writeFileSync(join(receipts, `${name}.log`), `${body.join("\n")}\n`);
  results.push({
    name,
    command,
    exit: invocation.exit,
    expectedExit,
    ok: invocation.exit === expectedExit,
    note,
  });
};

const corpusCopy = (name: string): string => {
  const destination = join(controls, name);
  rmSync(destination, { recursive: true, force: true });
  cpSync(corpus, destination, { recursive: true });
  return destination;
};

const runGraderControl = (
  name: string,
  corpusDir: string,
  expectedExit: number,
  note = "",
  extra: readonly string[] = []
): { exit: number; stdout: string; stderr: string } => {
  const invocation = run(graderArgs(corpusDir, extra));
  record(name, graderCommand(corpusDir, extra), invocation, expectedExit, note);
  return invocation;
};


// --- controls -----------------------------------------------------------------

// 1. Pristine, byte-verified corpus: both modes must grade identical.
const pristine = runGraderControl(
  "new-pristine",
  corpus,
  0,
  "29 projects / 179 files / 1596 cases in both modes"
);
if (!pristine.stdout.includes("distinct test files (ordinary): 179")) {
  throw new ControlError("pristine run does not report 179 ordinary files");
}
if (
  !pristine.stdout.includes("test cases (ordinary): 1596") ||
  !pristine.stdout.includes("test cases (isolate):  1596")
) {
  throw new ControlError(
    "pristine run does not report 1596 cases in both modes"
  );
}

// 2. Equal-and-opposite per-file swap. The archived probe exits 0 on it; the
//    corrected grader must not.
const swapCorpus = corpusCopy("swap");
const swapNote = applyEqualAndOppositeSwap(swapCorpus);
const swapInvocation = runGraderControl("new-swap", swapCorpus, 1, swapNote);
if (!swapInvocation.stdout.includes("outcome-mismatch")) {
  throw new ControlError(
    "swap control did not report a per-file outcome mismatch"
  );
}

// 3. Remaining single-mutation controls on the corrected grader.
const failureCorpus = corpusCopy("failure-mismatch");
mutateSuiteAttribute(
  failureCorpus,
  "ordinary",
  SWAP_FILE_FROM,
  "failures",
  "1"
);
mutateRootAttribute(failureCorpus, "ordinary", "failures", "1");
runGraderControl("new-failure-mismatch", failureCorpus, 1);

const skippedCorpus = corpusCopy("skipped-mismatch");
mutateSuiteAttribute(skippedCorpus, "ordinary", SWAP_FILE_FROM, "skipped", "1");
mutateRootAttribute(skippedCorpus, "ordinary", "skipped", "1");
runGraderControl("new-skipped-mismatch", skippedCorpus, 1);

const renamedCorpus = corpusCopy("file-renamed-in-isolate");
{
  const path = reportPath(renamedCorpus, "isolate");
  const xml = readFileSync(path, "utf8");
  if (!xml.includes(`file="${SWAP_FILE_TO}"`))
    throw new ControlError(`${path}: no ${SWAP_FILE_TO}`);
  writeFileSync(
    path,
    xml.replaceAll(
      `file="${SWAP_FILE_TO}"`,
      'file="test/provider-conformance-renamed.test.ts"'
    )
  );
}
runGraderControl("new-file-renamed-in-isolate", renamedCorpus, 1);

const malformedCorpus = corpusCopy("malformed-xml");
{
  const path = reportPath(malformedCorpus, "ordinary");
  const xml = readFileSync(path, "utf8");
  writeFileSync(path, xml.slice(0, Math.floor(xml.length * 0.6)));
}
runGraderControl("new-malformed-xml", malformedCorpus, 1);

const invalidCountCorpus = corpusCopy("invalid-count");
mutateSuiteAttribute(
  invalidCountCorpus,
  "ordinary",
  SWAP_FILE_FROM,
  "tests",
  "abc"
);
runGraderControl("new-invalid-count", invalidCountCorpus, 1);

const unreconciledCorpus = corpusCopy("unreconciled-root");
mutateRootAttribute(unreconciledCorpus, "ordinary", "tests", "8");
runGraderControl("new-unreconciled-root", unreconciledCorpus, 1);

const emptyCorpus = corpusCopy("empty-coverage");
writeFileSync(
  reportPath(emptyCorpus, "ordinary"),
  '<testsuites name="bun test" tests="0" failures="0" skipped="0" time="0"></testsuites>\n'
);
runGraderControl("new-empty-coverage", emptyCorpus, 1);

const missingCorpus = corpusCopy("missing-file");
rmSync(reportPath(missingCorpus, "ordinary"));
runGraderControl("new-missing-file", missingCorpus, 1);

// 3b. Structural well-formedness controls. Both mutations keep every counter
//     and every testcase valid and are invisible to per-file grading; only the
//     pinned runtime's XML processor sees them.
const structuralTruncated = corpusCopy("structural-truncated");
const structuralTruncatedNote = removeClosingStructure(
  structuralTruncated,
  "ordinary",
  SWAP_PROJECT
);
const structuralTruncatedInvocation = runGraderControl(
  "new-structural-truncated",
  structuralTruncated,
  1,
  structuralTruncatedNote
);
if (!structuralTruncatedInvocation.stdout.includes("is not well-formed XML")) {
  throw new ControlError(
    "structural truncation was not reported as malformed XML"
  );
}
if (
  !structuralTruncatedInvocation.stdout.includes(
    "projects with a per-file difference: 0"
  )
) {
  throw new ControlError(
    "structural truncation changed a per-file outcome, so the control does not " +
      "isolate the structural check"
  );
}

const mismatchedClosing = corpusCopy("mismatched-closing-tag");
const mismatchedClosingNote = renameOuterClosingTag(
  mismatchedClosing,
  "ordinary",
  SWAP_PROJECT
);
const mismatchedClosingInvocation = runGraderControl(
  "new-mismatched-closing-tag",
  mismatchedClosing,
  1,
  mismatchedClosingNote
);
if (
  !mismatchedClosingInvocation.stdout.includes(
    "Expected closing tag </testsuite> but found </testsuit>"
  )
) {
  throw new ControlError(
    "the mismatched closing tag was not reported by the native parser"
  );
}
if (
  !mismatchedClosingInvocation.stdout.includes(
    "projects with a per-file difference: 0"
  )
) {
  throw new ControlError(
    "the mismatched closing tag changed a per-file outcome, so the control does " +
      "not isolate the structural check"
  );
}

// 3c. The same structural damage on a one-project corpus: one real report per
//     mode, so a single malformed report is the whole input. A comment control
//     proves the native parser adds no false positive on real report bytes.
const oneFileCases = rootCaseCount(
  readFileSync(join(corpus, "ordinary", `${ONE_FILE_PROJECT}.junit.xml`), "utf8")
);
const oneFileExpectations = [
  "--expect-projects",
  "1",
  "--expect-files",
  "1",
  "--expect-cases",
  String(oneFileCases),
];

const oneFilePristine = buildOneFileFixture("one-file-report-pristine", corpus, controls);
const oneFilePristineInvocation = runGraderControl(
  "new-one-file-report-pristine",
  oneFilePristine,
  0,
  `${ONE_FILE_PROJECT}: one real retained report per mode, ` +
    `${oneFileCases} case(s), no structural change`,
  oneFileExpectations
);
if (
  !oneFilePristineInvocation.stdout.includes(
    `test cases (ordinary): ${oneFileCases}`
  )
) {
  throw new ControlError("the one-file fixture did not grade its case count");
}

const oneFileTruncated = buildOneFileFixture("one-file-report-truncated", corpus, controls);
const oneFileTruncatedNote = removeClosingStructure(
  oneFileTruncated,
  "isolate",
  ONE_FILE_PROJECT
);
const oneFileTruncatedInvocation = runGraderControl(
  "new-one-file-report-truncated",
  oneFileTruncated,
  1,
  oneFileTruncatedNote,
  oneFileExpectations
);
if (
  !oneFileTruncatedInvocation.stdout.includes(
    "Missing closing tag for element 'testsuite'"
  )
) {
  throw new ControlError(
    "the one-file truncation was not reported by the native parser"
  );
}

const oneFileComment = buildOneFileFixture("one-file-report-comment", corpus, controls);
const oneFileCommentNote = insertRootComment(
  oneFileComment,
  "ordinary",
  ONE_FILE_PROJECT
);
runGraderControl(
  "new-one-file-report-comment",
  oneFileComment,
  0,
  oneFileCommentNote,
  oneFileExpectations
);

// 3d. Element-tree controls for the round-two raw-tag-counting defect. Each
//     mutation leaves every counter and every tag literal a text scanner reads
//     untouched, so a raw scanner still grades it as intact; only the parsed
//     element tree sees the missing or misplaced testcase.
const commentedCorpus = corpusCopy("commented-testcase-corpus");
const commentedNote = commentOutFirstTestcase(
  commentedCorpus,
  "isolate",
  ONE_FILE_PROJECT
);
const commentedInvocation = runGraderControl(
  "new-commented-testcase-corpus",
  commentedCorpus,
  1,
  commentedNote
);
if (
  !commentedInvocation.stdout.includes("declares tests=") ||
  !commentedInvocation.stdout.includes("0 testcase elements")
) {
  throw new ControlError(
    "the commented-out testcase was not rejected as a declared/actual count mismatch"
  );
}

const hiddenDocument = buildOneFileFixture("comment-whole-junit-under-empty-root", corpus, controls);
const hiddenDocumentNote = hideWholeDocumentInComment(
  hiddenDocument,
  "isolate",
  ONE_FILE_PROJECT
);
const hiddenDocumentInvocation = runGraderControl(
  "new-comment-whole-junit-under-empty-root",
  hiddenDocument,
  1,
  hiddenDocumentNote,
  oneFileExpectations
);
if (
  !hiddenDocumentInvocation.stdout.includes(
    "root element is <empty>, expected <testsuites>"
  )
) {
  throw new ControlError(
    "the empty root hiding a whole JUnit document was not rejected by element name"
  );
}

const cdataCorpus = buildOneFileFixture("cdata-fake-testcase", corpus, controls);
const cdataNoteOrdinary = insertCdataFakeTestcase(
  cdataCorpus,
  "ordinary",
  ONE_FILE_PROJECT
);
insertCdataFakeTestcase(cdataCorpus, "isolate", ONE_FILE_PROJECT);
// The raw-tag view now counts one extra testcase in both modes, so this control
// uses the raw-consistent case expectation. A text scanner grades it PASS;
// element grading still rejects the declared/actual mismatch.
const cdataExpectations = [
  "--expect-projects",
  "1",
  "--expect-files",
  "1",
  "--expect-cases",
  String(oneFileCases + 1),
];
const cdataInvocation = runGraderControl(
  "new-cdata-fake-testcase",
  cdataCorpus,
  1,
  `${cdataNoteOrdinary}; isolate mutated identically`,
  cdataExpectations
);
if (
  !cdataInvocation.stdout.includes("declares tests=") ||
  !cdataInvocation.stdout.includes(`${oneFileCases} testcase elements`)
) {
  throw new ControlError(
    "the CDATA fake testcase was not rejected as a declared/actual count mismatch"
  );
}

const nestedRoot = buildOneFileFixture("nested-unexpected-root", corpus, controls);
const nestedRootNote = wrapRootInUnexpectedElement(
  nestedRoot,
  "ordinary",
  ONE_FILE_PROJECT
);
const nestedRootInvocation = runGraderControl(
  "new-nested-unexpected-root",
  nestedRoot,
  1,
  nestedRootNote,
  oneFileExpectations
);
if (
  !nestedRootInvocation.stdout.includes(
    "root element is <document>, expected <testsuites>"
  )
) {
  throw new ControlError(
    "a nested <testsuites> under an unexpected root was not rejected by root element name"
  );
}

const nestedSuite = buildOneFileFixture("nested-unexpected-suite", corpus, controls);
const nestedSuiteNote = wrapSuiteInUnexpectedElement(
  nestedSuite,
  "ordinary",
  ONE_FILE_PROJECT
);
const nestedSuiteInvocation = runGraderControl(
  "new-nested-unexpected-suite",
  nestedSuite,
  1,
  nestedSuiteNote,
  oneFileExpectations
);
if (
  !nestedSuiteInvocation.stdout.includes("unexpected <wrapper> under <testsuites>")
) {
  throw new ControlError(
    "an unexpected element around the file suite was not rejected by hierarchy"
  );
}

// 3e. The converse: fake tag literals in comments and escaped text beside a real
//     testcase must neither add counts nor fail the run. Raw counting would read
//     the extra literals and reject the report, so a PASS here is discriminating.
const fakeLiterals = buildOneFileFixture("fake-tag-literals-beside-testcase", corpus, controls);
const fakeLiteralsNote = insertFakeTagLiterals(
  fakeLiterals,
  "ordinary",
  ONE_FILE_PROJECT
);
const fakeLiteralsInvocation = runGraderControl(
  "new-fake-tag-literals-beside-testcase",
  fakeLiterals,
  0,
  fakeLiteralsNote,
  oneFileExpectations
);
if (
  !fakeLiteralsInvocation.stdout.includes(
    `test cases (ordinary): ${oneFileCases}`
  ) ||
  !fakeLiteralsInvocation.stdout.includes("per-file grading: PASS")
) {
  throw new ControlError(
    "fake tag literals in a comment or escaped text changed the graded element count"
  );
}

// 3f. Complete hierarchy validation. Counting a testcase without looking
//     inside it let an execution element sit in an unsupported position while
//     every counter and every supported-position count stayed as reported.
//     `new-nested-testcase-corpus` is the round-three reviewer reproducer
//     exactly: the full 29-project corpus with the retained
//     `isolate/telemetry-semconv.junit.xml` testcase wrapped in
//     `<testcase name="outer-wrapper">`. The other negatives hide a nested
//     suite, a root element, and a testcase under a metadata wrapper. The
//     positive is the converse: the pinned reporter's own testcase metadata
//     must stay accepted.
const nestedTestcaseCorpus = corpusCopy("nested-testcase-corpus");
const nestedTestcaseNote = wrapFirstTestcaseInTestcase(
  nestedTestcaseCorpus,
  "isolate",
  ONE_FILE_PROJECT
);
const nestedTestcaseInvocation = runGraderControl(
  "new-nested-testcase-corpus",
  nestedTestcaseCorpus,
  1,
  nestedTestcaseNote
);
if (
  !nestedTestcaseInvocation.stdout.includes(
    "unexpected <testcase> inside a <testcase> subtree"
  )
) {
  throw new ControlError(
    "the full-corpus nested testcase was not rejected by element hierarchy"
  );
}
if (
  !nestedTestcaseInvocation.stdout.includes(
    "xml well-formedness (Bun.XML.parse): 58 report(s) checked, 0 failure(s)"
  )
) {
  throw new ControlError(
    "the nested testcase control did not stay a well-formed-XML control, so it " +
      "does not isolate the hierarchy check"
  );
}

const nestedSuiteCorpus = corpusCopy("nested-suite-under-testcase");
const hiddenSuiteNote = [
  hideNestedSuiteInsideTestcase(nestedSuiteCorpus, "ordinary", ONE_FILE_PROJECT),
  hideNestedSuiteInsideTestcase(nestedSuiteCorpus, "isolate", ONE_FILE_PROJECT),
].join("; ");
const hiddenSuiteInvocation = runGraderControl(
  "new-nested-suite-under-testcase",
  nestedSuiteCorpus,
  1,
  hiddenSuiteNote
);
if (
  !hiddenSuiteInvocation.stdout.includes(
    "unexpected <testsuite> inside a <testcase> subtree"
  )
) {
  throw new ControlError(
    "a nested suite inside a testcase was not rejected by element hierarchy"
  );
}

const nestedRootCorpus = corpusCopy("nested-root-under-testcase");
const hiddenRootNote = [
  hideNestedRootInsideTestcase(nestedRootCorpus, "ordinary", ONE_FILE_PROJECT),
  hideNestedRootInsideTestcase(nestedRootCorpus, "isolate", ONE_FILE_PROJECT),
].join("; ");
const hiddenRootInvocation = runGraderControl(
  "new-nested-root-under-testcase",
  nestedRootCorpus,
  1,
  hiddenRootNote
);
if (
  !hiddenRootInvocation.stdout.includes(
    "unexpected <testsuites> inside a <testcase> subtree"
  )
) {
  throw new ControlError(
    "a root element inside a testcase was not rejected by element hierarchy"
  );
}

const metadataWrapperCorpus = corpusCopy("execution-under-metadata-wrapper");
const metadataWrapperNote = [
  hideTestcaseUnderMetadataWrapper(
    metadataWrapperCorpus,
    "ordinary",
    ONE_FILE_PROJECT
  ),
  hideTestcaseUnderMetadataWrapper(
    metadataWrapperCorpus,
    "isolate",
    ONE_FILE_PROJECT
  ),
].join("; ");
const metadataWrapperInvocation = runGraderControl(
  "new-execution-under-metadata-wrapper",
  metadataWrapperCorpus,
  1,
  metadataWrapperNote
);
if (
  !metadataWrapperInvocation.stdout.includes(
    "unexpected <testcase> inside a <testcase> subtree"
  )
) {
  throw new ControlError(
    "a testcase under a metadata wrapper was not rejected by element hierarchy"
  );
}

// The positive: the pinned reporter's own JUnit output, whose testcases carry
// the measured `<skipped/>` and `<failure>` metadata children, must still be
// accepted. The fixture is generated here, not copied from the retained corpus,
// because the retained reports hold no non-self-closing testcase.
const metadataFixture = join(controls, "native-testcase-metadata-positive");
rmSync(metadataFixture, { recursive: true, force: true });
mkdirSync(join(metadataFixture, "source"), { recursive: true });
writeFileSync(
  join(metadataFixture, "source", "native-metadata.test.ts"),
  [
    'import { expect, test } from "bun:test";',
    "",
    'test("passes", () => {',
    "  expect(1).toBe(1);",
    "});",
    "",
    'test.skip("skipped one", () => {});',
    "",
    'test("fails", () => {',
    "  expect(1).toBe(2);",
    "});",
    "",
  ].join("\n")
);
const nativeReportName = `${NATIVE_METADATA_PROJECT}.junit.xml`;
const nativeReportPath = join(metadataFixture, nativeReportName);
const reporterRun = run(
  [
    "test",
    "source/native-metadata.test.ts",
    "--reporter=junit",
    `--reporter-outfile=${nativeReportPath}`,
  ],
  metadataFixture
);
if (!existsSync(nativeReportPath)) {
  throw new ControlError(
    `the pinned reporter wrote no ${nativeReportPath} (exit ${reporterRun.exit}): ` +
      reporterRun.stderr.trim()
  );
}
const nativeReportBytes = readFileSync(nativeReportPath);
const nativeCaseCount = rootCaseCount(nativeReportBytes.toString("utf8"));
if (nativeCaseCount !== 3) {
  throw new ControlError(
    `the pinned reporter produced ${nativeCaseCount} testcase element(s) for a ` +
      "three-test fixture; the metadata positive no longer pins the measured shape"
  );
}
for (const mode of ["ordinary", "isolate"]) {
  mkdirSync(join(metadataFixture, mode), { recursive: true });
  writeFileSync(join(metadataFixture, mode, nativeReportName), nativeReportBytes);
}
writeFileSync(
  join(metadataFixture, PROJECTS_TSV),
  `${NATIVE_METADATA_PROJECT}\t${relative(join(metadataFixture, "source"))}\n`
);
const metadataExpectations = [
  "--expect-projects",
  "1",
  "--expect-files",
  "1",
  "--expect-cases",
  String(nativeCaseCount),
];
const metadataInvocation = runGraderControl(
  "new-native-testcase-metadata-positive",
  metadataFixture,
  0,
  `${NATIVE_METADATA_PROJECT}: report produced by the pinned reporter, ` +
    `${nativeCaseCount} case(s) whose <skipped/> and <failure> metadata children must stay accepted`,
  metadataExpectations
);
const metadataGradingLine =
  "native element grading (Bun.XML.parse {compact:false}): 2 outer file suite(s), " +
  `${nativeCaseCount * 2} testcase element(s)`;
if (
  !metadataInvocation.stdout.includes(
    `test cases (ordinary): ${nativeCaseCount}`
  ) ||
  !metadataInvocation.stdout.includes(metadataGradingLine) ||
  !metadataInvocation.stdout.includes("per-file grading: PASS")
) {
  throw new ControlError(
    "legitimate native reporter testcase metadata was not accepted"
  );
}

// 4. Unusable inputs and a CLI usage error.
{
  const absentCorpus = join(controls, "missing-input-root");
  rmSync(absentCorpus, { recursive: true, force: true });
  cpSync(corpus, absentCorpus, { recursive: true });
  rmSync(join(absentCorpus, "ordinary"), { recursive: true, force: true });
  const invocation = run(graderArgs(absentCorpus));
  record("new-missing-input-root", graderCommand(absentCorpus), invocation, 1);

  const usage = run([grader, "--bogus"]);
  record("new-usage-error", `bun ${relative(grader)} --bogus`, usage, 2);
}

// 5. The archived probe, relocated by one line, on the pristine and the swapped
//    layout. It self-reports one differing project on the swap and still exits 0.
const scaffold = join(work, "scaffold");
buildScaffold(corpus, scaffold);
const { path: historicalPath, relocation } = relocateHistorical(scaffold, source, work);
const historicalCommand = `bun ${relative(historicalPath)}`;
const historicalPristine = run([historicalPath]);
record(
  "historical-pristine",
  historicalCommand,
  historicalPristine,
  0,
  relocation
);
if (
  !historicalPristine.stdout.includes(
    "projects with any per-file difference: 0"
  )
) {
  throw new ControlError(
    "archived probe did not report zero differences on the pristine corpus"
  );
}

// Rebuild the same scaffold path from the swapped corpus so the single
// relocated copy is reused unchanged; only the corpus differs.
buildScaffold(swapCorpus, scaffold);
const historicalSwap = run([historicalPath]);
record(
  "historical-swap",
  historicalCommand,
  historicalSwap,
  0,
  "historical defect: prints DIFFERS for the swapped project and still exits 0"
);
if (!historicalSwap.stdout.includes(`${SWAP_PROJECT}: DIFFERS`)) {
  throw new ControlError(
    "archived probe did not print DIFFERS for the swapped project"
  );
}
if (
  !historicalSwap.stdout.includes("projects with any per-file difference: 1")
) {
  throw new ControlError("archived probe did not count one differing project");
}

// 6. The companion aggregate probe cannot see the swap at all: it reads only
//    project-level rows, which the equal-and-opposite change leaves untouched.
{
  const observations = join(source, "assert-observations.mjs");
  const rawPristine = join(work, "raw-scaffold");
  buildRawScaffold(corpus, rawPristine, source);
  const pristineObservations = run([observations, rawPristine]);
  record(
    "historical-assert-observations-pristine",
    `bun ${relative(observations)} ${relative(rawPristine)}`,
    pristineObservations,
    0
  );

  const rawSwapped = join(work, "raw-scaffold-swap");
  buildRawScaffold(swapCorpus, rawSwapped, source);
  const swappedObservations = run([observations, rawSwapped]);
  record(
    "historical-assert-observations-swap",
    `bun ${relative(observations)} ${relative(rawSwapped)}`,
    swappedObservations,
    0,
    "aggregate blind spot: project rows are unchanged, so the swap passes"
  );
  if (swappedObservations.exit !== 0) {
    throw new ControlError(
      "aggregate probe unexpectedly failed the swap control"
    );
  }
}
const failed = results
  .filter((result) => !result.ok)
  .map((result) => result.name);
const summary = {
  ok: failed.length === 0,
  swap: swapNote,
  historicalRelocation: relocation,
  controls: results,
  failed,
};
console.log(JSON.stringify(summary, null, 2));
writeFileSync(
  join(receipts, "control-matrix.json"),
  `${JSON.stringify(summary, null, 2)}\n`
);
process.exitCode = failed.length === 0 ? 0 : 1;
