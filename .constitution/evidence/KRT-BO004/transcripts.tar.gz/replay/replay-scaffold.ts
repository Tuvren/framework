/**
 * Scaffold builders for the archived-probe controls.
 *
 * These rebuild the exact `raw/` layouts the retained probes read and relocate
 * the archived probe's single hardcoded scratch root. Callers pass the
 * extraction root and work directory explicitly.
 */
import {
  copyFileSync,
  cpSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { dirname, join } from "node:path";
import { PROJECTS_TSV } from "./replay-constants";
import { ControlError } from "./replay-errors";

/** Copy the corpus into the `raw/` layout the archived probe reads from `W`. */
export const buildScaffold = (sourceCorpus: string, destination: string): void => {
  rmSync(destination, { recursive: true, force: true });
  mkdirSync(join(destination, "raw", "matrix"), { recursive: true });
  for (const mode of ["ordinary", "isolate"]) {
    cpSync(join(sourceCorpus, mode), join(destination, "raw", "matrix", mode), {
      recursive: true,
    });
  }
  copyFileSync(
    join(sourceCorpus, PROJECTS_TSV),
    join(destination, "raw", PROJECTS_TSV)
  );
};

/**
 * Rebuild the full retained `raw/` tree that `assert-observations.mjs` reads,
 * with the corpus JUnit files overlaid so a mutated corpus is visible to the
 * probe. The archived member prefix `lead-raw__` maps to the recorded `raw/`
 * directory and `__` maps to `/`.
 */
export const buildRawScaffold = (
  sourceCorpus: string,
  destination: string,
  sourceRoot: string
): void => {
  rmSync(destination, { recursive: true, force: true });
  for (const entry of readdirSync(sourceRoot)) {
    if (!entry.startsWith("lead-raw__")) continue;
    const target = join(
      destination,
      entry.slice("lead-raw__".length).replaceAll("__", "/")
    );
    mkdirSync(dirname(target), { recursive: true });
    copyFileSync(join(sourceRoot, entry), target);
  }
  for (const mode of ["ordinary", "isolate"]) {
    const modeDirectory = join(destination, "matrix", mode);
    mkdirSync(modeDirectory, { recursive: true });
    for (const file of readdirSync(join(sourceCorpus, mode))) {
      copyFileSync(join(sourceCorpus, mode, file), join(modeDirectory, file));
    }
  }
};

/**
 * Relocate the archived probe's single hardcoded scratch root. Every other byte,
 * including the line count, must match the retained member.
 */
export const relocateHistorical = (
  scaffold: string,
  sourceRoot: string,
  workDir: string
): { path: string; relocation: string } => {
  const archived = join(sourceRoot, "probe__compare-matrix-junit.ts");
  const original = readFileSync(archived, "utf8");
  const pattern = /const W = "[^"]*";/u;
  const before = original.match(pattern)?.[0];
  if (before === undefined)
    throw new ControlError("archived probe has no relocateable W constant");
  const after = `const W = "${scaffold}";`;
  const relocated = original.replace(pattern, after);
  const originalLines = original.split("\n");
  const relocatedLines = relocated.split("\n");
  if (originalLines.length !== relocatedLines.length)
    throw new ControlError("relocation changed the line count");
  const changed = originalLines.filter(
    (line, index) => line !== relocatedLines[index]
  ).length;
  if (changed !== 1)
    throw new ControlError(`relocation changed ${changed} lines`);
  const path = join(workDir, "historical-relocated", "compare-matrix-junit.ts");
  mkdirSync(join(workDir, "historical-relocated"), { recursive: true });
  writeFileSync(path, relocated);
  return { path, relocation: `${before} -> ${after}` };
};

