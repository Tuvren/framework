#!/usr/bin/env bun
/**
 * Positive and negative controls for the KRT-BO004 per-file JUnit replay.
 *
 * Each control copies the byte-verified replay corpus, applies exactly one
 * documented mutation, then runs either the corrected replay grader or the
 * archived historical probe. The archived probe runs from a relocated copy that
 * differs from the retained member only in its scratch-root constant, which is
 * the relocation its own README prescribes. The harness fails when any
 * expectation is unmet, so a drifted control cannot be reported as a pass.
 *
 * Usage:
 *   bun run-replay-controls.ts --work <replay-dir> --source <extraction-root>
 *
 * Produced under --work:
 *   historical-relocated/compare-matrix-junit.ts   retained probe, one line relocated
 *   scaffold/raw/...                               retained layout the probe expects
 *   scaffold-swap/raw/...                          same layout after the swap
 *   controls/<name>/                               one mutated corpus per control
 *   controls/one-file-report-<name>/                 one real report as a whole corpus
 *   receipts/<name>.log                            raw command, exit and output
 *   receipts/control-matrix.json                   machine-readable summary
 *
 * Two of the controls mutate only the closing structure of a report while
 * every counter and testcase stays valid. Per-file grading cannot see those
 * mutations; the native XML processor can, which is why they exist.
 *
 * Round two added controls for the raw-tag-counting defect: a retained testcase
 * moved into an XML comment, a whole valid JUnit document hidden in a comment
 * under an empty root, fake `<testcase>` literals inside a CDATA section, and
 * unexpected root/suite nesting. Each one keeps every counter and every tag
 * literal that a text scanner would read, so only element-tree grading rejects
 * them. A positive control pins the converse: fake tag literals in comments and
 * escaped text beside a real testcase must not add counts or fail the run.
 */
import {
  copyFileSync,
  cpSync,
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { dirname, join } from "node:path";

const ATTRIBUTE = /([A-Za-z_:][\w:.-]*)="([^"]*)"/g;
const PROJECTS_TSV = "bun-test-projects.tsv";

/** Project and file pair used for the equal-and-opposite swap: 2 and 1 cases. */
const SWAP_PROJECT = "providers-testkit";
const SWAP_FILE_FROM = "test/provider-testkit.test.ts";
const SWAP_FILE_TO = "test/provider-conformance.test.ts";

/**
 * Real project whose retained report holds a single file, used as a whole
 * one-file corpus so a structural mutation can be isolated to one report.
 */
const ONE_FILE_PROJECT = "telemetry-semconv";

class ControlError extends Error {}

interface TagAt {
  readonly start: number;
  readonly end: number;
  readonly text: string;
}

interface Edit {
  readonly start: number;
  readonly end: number;
  readonly text: string;
}

interface ControlResult {
  readonly name: string;
  readonly command: string;
  readonly exit: number;
  readonly expectedExit: number;
  readonly ok: boolean;
  readonly note: string;
}

const attributeMap = (tag: string): Map<string, string> => {
  const attributes = new Map<string, string>();
  for (const match of tag.matchAll(ATTRIBUTE)) {
    const name = match[1];
    const value = match[2];
    if (name !== undefined && value !== undefined) attributes.set(name, value);
  }
  return attributes;
};

const openTagAt = (xml: string, needle: string, from: number): TagAt | null => {
  const start = xml.indexOf(needle, from);
  if (start < 0) return null;
  let inQuotes = false;
  for (let index = start; index < xml.length; index += 1) {
    const character = xml[index];
    if (character === '"') inQuotes = !inQuotes;
    else if (character === ">" && !inQuotes) {
      return { start, end: index, text: xml.slice(start + 1, index) };
    }
  }
  throw new ControlError(`unterminated tag ${needle.trim()}`);
};

/** Outer file suites only: a `file` attribute without a nested-describe `line`. */
const outerSuiteTags = (xml: string): TagAt[] => {
  const tags: TagAt[] = [];
  let cursor = 0;
  for (;;) {
    const tag = openTagAt(xml, "<testsuite ", cursor);
    if (tag === null) return tags;
    if (!attributeMap(tag.text).has("line")) tags.push(tag);
    cursor = tag.end + 1;
  }
};

const outerSuiteFor = (xml: string, file: string): TagAt => {
  for (const tag of outerSuiteTags(xml)) {
    if (attributeMap(tag.text).get("file") === file) return tag;
  }
  throw new ControlError(`no outer suite for ${file}`);
};

const countOccurrences = (haystack: string, needle: string): number => {
  let count = 0;
  let cursor = 0;
  for (;;) {
    const found = haystack.indexOf(needle, cursor);
    if (found < 0) return count;
    count += 1;
    cursor = found + needle.length;
  }
};

const countTestcases = (xml: string): number =>
  countOccurrences(xml, "<testcase ");

const segmentEnd = (xml: string, tag: TagAt): number => {
  const tags = outerSuiteTags(xml);
  const position = tags.findIndex((candidate) => candidate.start === tag.start);
  const next = tags[position + 1];
  return next === undefined ? xml.length : next.start;
};

const suiteTests = (xml: string, file: string): number =>
  Number(attributeMap(outerSuiteFor(xml, file).text).get("tests"));

const withAttribute = (tag: TagAt, name: string, value: string): TagAt => {
  const replaced = tag.text.replace(
    new RegExp(`(\\s${name}=")[^"]*(")`),
    `$1${value}$2`
  );
  if (replaced === tag.text)
    throw new ControlError(`attribute ${name} not found in ${tag.text}`);
  return { start: tag.start, end: tag.end, text: replaced };
};

const applyEdits = (xml: string, edits: readonly Edit[]): string => {
  let result = xml;
  for (const edit of [...edits].sort(
    (left, right) => right.start - left.start
  )) {
    if (edit.start < 0 || edit.end > result.length || edit.start > edit.end) {
      throw new ControlError(`invalid edit range ${edit.start}..${edit.end}`);
    }
    result = result.slice(0, edit.start) + edit.text + result.slice(edit.end);
  }
  return result;
};

const run = (
  args: readonly string[]
): { exit: number; stdout: string; stderr: string } => {
  const result = Bun.spawnSync({
    cmd: [process.execPath, ...args],
    cwd: process.cwd(),
    stdout: "pipe",
    stderr: "pipe",
  });
  return {
    exit: result.exitCode ?? -1,
    stdout: result.stdout.toString(),
    stderr: result.stderr.toString(),
  };
};

const readFlag = (name: string): string => {
  const index = process.argv.indexOf(name);
  const value = index < 0 ? undefined : process.argv[index + 1];
  if (value === undefined) throw new ControlError(`${name} is required`);
  return value;
};

const work = readFlag("--work");
const source = readFlag("--source");
const corpus = join(work, "corpus");
const receipts = join(work, "receipts");
const controls = join(work, "controls");
if (!existsSync(join(corpus, PROJECTS_TSV))) {
  throw new ControlError(
    `no replay corpus at ${corpus}; run build-replay-corpus.ts first`
  );
}
for (const directory of [receipts, controls])
  mkdirSync(directory, { recursive: true });

const grader = join(work, "compare-matrix-junit-replay.ts");
const relative = (path: string): string =>
  path.startsWith(`${work}/`) ? `replay/${path.slice(work.length + 1)}` : path;

const graderCommand = (
  corpusDir: string,
  extra: readonly string[] = []
): string =>
  [
    "bun",
    relative(grader),
    "--ordinary",
    relative(join(corpusDir, "ordinary")),
    "--isolate",
    relative(join(corpusDir, "isolate")),
    "--projects",
    relative(join(corpusDir, PROJECTS_TSV)),
    ...extra,
  ].join(" ");

const graderArgs = (
  corpusDir: string,
  extra: readonly string[] = []
): string[] => [
  grader,
  "--ordinary",
  join(corpusDir, "ordinary"),
  "--isolate",
  join(corpusDir, "isolate"),
  "--projects",
  join(corpusDir, PROJECTS_TSV),
  ...extra,
];

const results: ControlResult[] = [];

const record = (
  name: string,
  command: string,
  invocation: { exit: number; stdout: string; stderr: string },
  expectedExit: number,
  note = ""
): void => {
  const body = [`$ ${command}`, `# exit=${invocation.exit}`];
  const stdout = invocation.stdout.trimEnd();
  const stderr = invocation.stderr.trimEnd();
  if (stdout !== "") body.push(stdout);
  if (stderr !== "") body.push("# stderr", stderr);
  writeFileSync(join(receipts, `${name}.log`), `${body.join("\n")}\n`);
  results.push({
    name,
    command,
    exit: invocation.exit,
    expectedExit,
    ok: invocation.exit === expectedExit,
    note,
  });
};

const corpusCopy = (name: string): string => {
  const destination = join(controls, name);
  rmSync(destination, { recursive: true, force: true });
  cpSync(corpus, destination, { recursive: true });
  return destination;
};

const reportPath = (
  corpusDir: string,
  mode: string,
  project = SWAP_PROJECT
): string => join(corpusDir, mode, `${project}.junit.xml`);

const mutateSuiteAttribute = (
  corpusDir: string,
  mode: string,
  file: string,
  name: string,
  value: string
): void => {
  const path = reportPath(corpusDir, mode);
  const xml = readFileSync(path, "utf8");
  const tag = outerSuiteFor(xml, file);
  const replaced = withAttribute(tag, name, value);
  writeFileSync(
    path,
    xml.slice(0, tag.start) + `<${replaced.text}>` + xml.slice(tag.end + 1)
  );
};

const mutateRootAttribute = (
  corpusDir: string,
  mode: string,
  name: string,
  value: string
): void => {
  const path = reportPath(corpusDir, mode);
  const xml = readFileSync(path, "utf8");
  const root = openTagAt(xml, "<testsuites ", 0);
  if (root === null) throw new ControlError(`${path}: no root element`);
  const replaced = withAttribute(root, name, value);
  writeFileSync(
    path,
    xml.slice(0, root.start) + `<${replaced.text}>` + xml.slice(root.end + 1)
  );
};

/**
 * Move one test case from `SWAP_FILE_FROM` to `SWAP_FILE_TO` inside one
 * project's ordinary report. File names, file count, case total and both mode
 * totals stay unchanged, so only a per-file comparison can detect it.
 */
const applyEqualAndOppositeSwap = (corpusDir: string): string => {
  const path = reportPath(corpusDir, "ordinary");
  const xml = readFileSync(path, "utf8");
  const from = outerSuiteFor(xml, SWAP_FILE_FROM);
  const to = outerSuiteFor(xml, SWAP_FILE_TO);
  const fromTests = suiteTests(xml, SWAP_FILE_FROM);
  const toTests = suiteTests(xml, SWAP_FILE_TO);
  const fromSegment = xml.slice(from.end + 1, segmentEnd(xml, from));
  const testcases = [...fromSegment.matchAll(/<testcase [^>]*\/>/g)];
  const last = testcases[testcases.length - 1];
  if (last === undefined || last.index === undefined) {
    throw new ControlError(`no self-closing testcase inside ${SWAP_FILE_FROM}`);
  }
  const moved = last[0];
  const movedStart = from.end + 1 + last.index;
  const closeIndex = xml
    .slice(to.end + 1, segmentEnd(xml, to))
    .lastIndexOf("</testsuite>");
  if (closeIndex < 0)
    throw new ControlError(`no closing tag for ${SWAP_FILE_TO}`);
  const insertAt = to.end + 1 + closeIndex;
  const swapped = applyEdits(xml, [
    {
      start: from.start,
      end: from.end + 1,
      text: `<${withAttribute(from, "tests", String(fromTests - 1)).text}>`,
    },
    {
      start: to.start,
      end: to.end + 1,
      text: `<${withAttribute(to, "tests", String(toTests + 1)).text}>`,
    },
    { start: movedStart, end: movedStart + moved.length, text: "" },
    { start: insertAt, end: insertAt, text: `${moved}\n    ` },
  ]);
  const afterFrom = suiteTests(swapped, SWAP_FILE_FROM);
  const afterTo = suiteTests(swapped, SWAP_FILE_TO);
  if (fromTests + toTests !== afterFrom + afterTo || afterFrom === fromTests) {
    throw new ControlError(
      "swap did not produce an equal-and-opposite per-file change"
    );
  }
  if (outerSuiteTags(swapped).length !== outerSuiteTags(xml).length) {
    throw new ControlError("swap changed the file set");
  }
  writeFileSync(path, swapped);
  return (
    `${SWAP_PROJECT}: ${SWAP_FILE_FROM} tests ${fromTests}->${afterFrom}, ` +
    `${SWAP_FILE_TO} tests ${toTests}->${afterTo}, project aggregate ${fromTests + toTests} unchanged`
  );
};

/** Copy the corpus into the `raw/` layout the archived probe reads from `W`. */
const buildScaffold = (sourceCorpus: string, destination: string): void => {
  rmSync(destination, { recursive: true, force: true });
  mkdirSync(join(destination, "raw", "matrix"), { recursive: true });
  for (const mode of ["ordinary", "isolate"]) {
    cpSync(join(sourceCorpus, mode), join(destination, "raw", "matrix", mode), {
      recursive: true,
    });
  }
  copyFileSync(
    join(sourceCorpus, PROJECTS_TSV),
    join(destination, "raw", PROJECTS_TSV)
  );
};

/**
 * Rebuild the full retained `raw/` tree that `assert-observations.mjs` reads,
 * with the corpus JUnit files overlaid so a mutated corpus is visible to the
 * probe. The archived member prefix `lead-raw__` maps to the recorded `raw/`
 * directory and `__` maps to `/`.
 */
const buildRawScaffold = (sourceCorpus: string, destination: string): void => {
  rmSync(destination, { recursive: true, force: true });
  for (const entry of readdirSync(source)) {
    if (!entry.startsWith("lead-raw__")) continue;
    const target = join(
      destination,
      entry.slice("lead-raw__".length).replaceAll("__", "/")
    );
    mkdirSync(dirname(target), { recursive: true });
    copyFileSync(join(source, entry), target);
  }
  for (const mode of ["ordinary", "isolate"]) {
    const modeDirectory = join(destination, "matrix", mode);
    mkdirSync(modeDirectory, { recursive: true });
    for (const file of readdirSync(join(sourceCorpus, mode))) {
      copyFileSync(join(sourceCorpus, mode, file), join(modeDirectory, file));
    }
  }
};

/**
 * Relocate the archived probe's single hardcoded scratch root. Every other byte,
 * including the line count, must match the retained member.
 */
const relocateHistorical = (
  scaffold: string
): { path: string; relocation: string } => {
  const archived = join(source, "probe__compare-matrix-junit.ts");
  const original = readFileSync(archived, "utf8");
  const pattern = /const W = "[^"]*";/u;
  const before = original.match(pattern)?.[0];
  if (before === undefined)
    throw new ControlError("archived probe has no relocateable W constant");
  const after = `const W = "${scaffold}";`;
  const relocated = original.replace(pattern, after);
  const originalLines = original.split("\n");
  const relocatedLines = relocated.split("\n");
  if (originalLines.length !== relocatedLines.length)
    throw new ControlError("relocation changed the line count");
  const changed = originalLines.filter(
    (line, index) => line !== relocatedLines[index]
  ).length;
  if (changed !== 1)
    throw new ControlError(`relocation changed ${changed} lines`);
  const path = join(work, "historical-relocated", "compare-matrix-junit.ts");
  mkdirSync(join(work, "historical-relocated"), { recursive: true });
  writeFileSync(path, relocated);
  return { path, relocation: `${before} -> ${after}` };
};

const runGraderControl = (
  name: string,
  corpusDir: string,
  expectedExit: number,
  note = "",
  extra: readonly string[] = []
): { exit: number; stdout: string; stderr: string } => {
  const invocation = run(graderArgs(corpusDir, extra));
  record(name, graderCommand(corpusDir, extra), invocation, expectedExit, note);
  return invocation;
};

/**
 * Drop the outer file-suite closing tag and the root closing tag, keeping every
 * attribute, counter and testcase exactly as reported. This is the structural
 * damage the historical counter-based grading could not see.
 */
const removeClosingStructure = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const outerClose = xml.lastIndexOf("</testsuite>");
  const rootClose = xml.lastIndexOf("</testsuites>");
  if (outerClose < 0 || rootClose < 0 || outerClose > rootClose) {
    throw new ControlError(`${path}: no outer suite and root closing tags`);
  }
  const truncated =
    xml.slice(0, outerClose) +
    xml.slice(outerClose + "</testsuite>".length, rootClose) +
    xml.slice(rootClose + "</testsuites>".length);
  const droppedTags =
    countOccurrences(xml, "</testsuite>") -
    countOccurrences(truncated, "</testsuite>");
  if (droppedTags !== 1 || countOccurrences(truncated, "</testsuites>") !== 0) {
    throw new ControlError(
      `${path}: truncation dropped ${droppedTags} </testsuite> tag(s) and left ` +
        `${countOccurrences(truncated, "</testsuites>")} root closing tag(s)`
    );
  }
  const testcases = countTestcases(xml);
  if (
    testcases === 0 ||
    countTestcases(truncated) !== testcases ||
    countOccurrences(truncated, "<testsuite ") !==
      countOccurrences(xml, "<testsuite ")
  ) {
    throw new ControlError(
      `${path}: truncation changed the content, not only the closing structure`
    );
  }
  writeFileSync(path, truncated);
  return (
    `${project}/${mode}: removed the outer </testsuite> and the root </testsuites> ` +
    `after ${testcases} valid testcases, ${xml.length - truncated.length} bytes ` +
    `dropped, every counter unchanged`
  );
};

/**
 * Rename the outer file-suite closing tag. The tag no longer matches the
 * element it closes, which is a well-formedness error and nothing else.
 */
const renameOuterClosingTag = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const outerClose = xml.lastIndexOf("</testsuite>");
  if (outerClose < 0) {
    throw new ControlError(`${path}: no outer suite closing tag`);
  }
  const mismatched =
    xml.slice(0, outerClose) +
    "</testsuit>" +
    xml.slice(outerClose + "</testsuite>".length);
  if (
    countTestcases(mismatched) !== countTestcases(xml) ||
    countOccurrences(mismatched, "<testsuite ") !==
      countOccurrences(xml, "<testsuite ")
  ) {
    throw new ControlError(`${path}: renaming the closing tag changed the content`);
  }
  writeFileSync(path, mismatched);
  return (
    `${project}/${mode}: outer closing tag </testsuite> renamed to </testsuit>, ` +
    `every counter and testcase unchanged`
  );
};

/**
 * A one-project corpus made of one real retained report per mode, so the grader
 * can be pointed at a minimal corpus with `--expect-projects 1`.
 */
const buildOneFileFixture = (name: string): string => {
  const destination = join(controls, name);
  rmSync(destination, { recursive: true, force: true });
  for (const mode of ["ordinary", "isolate"]) {
    mkdirSync(join(destination, mode), { recursive: true });
    copyFileSync(
      join(corpus, mode, `${ONE_FILE_PROJECT}.junit.xml`),
      join(destination, mode, `${ONE_FILE_PROJECT}.junit.xml`)
    );
  }
  const row = readFileSync(join(corpus, PROJECTS_TSV), "utf8")
    .split("\n")
    .find((line) => line.startsWith(`${ONE_FILE_PROJECT}\t`));
  if (row === undefined) {
    throw new ControlError(`no ${PROJECTS_TSV} row for ${ONE_FILE_PROJECT}`);
  }
  writeFileSync(join(destination, PROJECTS_TSV), `${row}\n`);
  return destination;
};

/** Insert one XML comment directly inside the root element. */
const insertRootComment = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const root = openTagAt(xml, "<testsuites ", 0);
  if (root === null) throw new ControlError(`${path}: no <testsuites> root element`);
  const comment = "<!-- a comment is not a well-formedness failure -->\n  ";
  const commented = xml.slice(0, root.end + 1) + comment + xml.slice(root.end + 1);
  if (
    countTestcases(commented) !== countTestcases(xml) ||
    countOccurrences(commented, "<testsuite ") !==
      countOccurrences(xml, "<testsuite ")
  ) {
    throw new ControlError(`${path}: inserting a comment changed the report content`);
  }
  writeFileSync(path, commented);
  return `${project}/${mode}: inserted one XML comment inside the root`;
};

/** Case count of a report's root element, for the minimal fixture inventory. */
const rootCaseCount = (xml: string): number => {
  const root = openTagAt(xml, "<testsuites ", 0);
  if (root === null) throw new ControlError("fixture report has no <testsuites> root");
  const raw = attributeMap(root.text).get("tests");
  const value = raw === undefined ? Number.NaN : Number(raw);
  if (!Number.isSafeInteger(value)) {
    throw new ControlError(`fixture report has no usable root tests attribute: ${raw}`);
  }
  return value;
};

const firstOuterSuite = (xml: string, path: string): TagAt => {
  const tag = outerSuiteTags(xml)[0];
  if (tag === undefined) throw new ControlError(`${path}: no outer file suite`);
  return tag;
};

/**
 * Replicate the round-two reviewer reproducer exactly: wrap the first
 * self-closing `<testcase ... />` of one report in an XML comment. Every
 * counter and every raw tag literal stays byte for byte as reported, so a text
 * scanner still sees the testcase while the element tree no longer holds it.
 */
const commentOutFirstTestcase = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const before = countOccurrences(xml, "<testcase ");
  const match = /(<testcase\s[^>]*?\s\/>)/u.exec(xml);
  if (match === null || match.index === undefined) {
    throw new ControlError(`${path}: no self-closing testcase to comment out`);
  }
  const literal = match[0];
  const mutated =
    xml.slice(0, match.index) +
    `<!--${literal}-->` +
    xml.slice(match.index + literal.length);
  if (countOccurrences(mutated, "<testcase ") !== before) {
    throw new ControlError(`${path}: commenting out a testcase changed the raw tag count`);
  }
  if (
    countOccurrences(mutated, "<testsuite ") !==
    countOccurrences(xml, "<testsuite ")
  ) {
    throw new ControlError(`${path}: commenting out a testcase changed the suite tags`);
  }
  writeFileSync(path, mutated);
  return (
    `${project}/${mode}: first self-closing <testcase ... /> wrapped in an XML comment; ` +
    `${before} raw <testcase literals and every counter unchanged`
  );
};

/** Replace one report with an empty root that hides a whole JUnit document in a comment. */
const hideWholeDocumentInComment = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  writeFileSync(path, `<empty><!--${xml}--></empty>\n`);
  return (
    `${project}/${mode}: whole valid JUnit report hidden inside an XML comment ` +
    `under an <empty> root`
  );
};

/**
 * Add a CDATA section holding a fake `<testcase .../>` literal and raise the
 * declared counts to match the raw literal count. A text scanner therefore
 * stays self-consistent, while the element tree has no extra testcase.
 */
const insertCdataFakeTestcase = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const suite = firstOuterSuite(xml, path);
  const file = attributeMap(suite.text).get("file");
  const root = openTagAt(xml, "<testsuites ", 0);
  if (file === undefined || root === null) {
    throw new ControlError(`${path}: outer suite or root element is unusable`);
  }
  const suiteTestsBefore = suiteTests(xml, file);
  const rootTestsBefore = rootCaseCount(xml);
  const fake = '<![CDATA[<testcase name="fake" classname="fake"/>]]>';
  const mutated = applyEdits(xml, [
    {
      start: root.start,
      end: root.end + 1,
      text: `<${withAttribute(root, "tests", String(rootTestsBefore + 1)).text}>`,
    },
    {
      start: suite.start,
      end: suite.end + 1,
      text: `<${withAttribute(suite, "tests", String(suiteTestsBefore + 1)).text}>`,
    },
    { start: suite.end + 1, end: suite.end + 1, text: fake },
  ]);
  if (
    countOccurrences(mutated, "<testcase ") !==
      countOccurrences(xml, "<testcase ") + 1 ||
    suiteTests(mutated, file) !== suiteTestsBefore + 1 ||
    rootCaseCount(mutated) !== rootTestsBefore + 1
  ) {
    throw new ControlError(`${path}: the CDATA fixture did not stay raw-tag consistent`);
  }
  writeFileSync(path, mutated);
  return (
    `${project}/${mode}: one CDATA section holding a fake <testcase .../> literal; ` +
    `declared tests ${suiteTestsBefore}->${suiteTestsBefore + 1} and root tests ` +
    `${rootTestsBefore}->${rootTestsBefore + 1} so raw tag counting stays consistent, ` +
    `while the element tree still has ${suiteTestsBefore} testcase(s)`
  );
};

/** Wrap the real root element in an unexpected element. */
const wrapRootInUnexpectedElement = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const root = openTagAt(xml, "<testsuites ", 0);
  const close = xml.lastIndexOf("</testsuites>");
  if (root === null || close < 0) {
    throw new ControlError(`${path}: no <testsuites> root element`);
  }
  const wrapped =
    xml.slice(0, root.start) +
    "<document>" +
    xml.slice(root.start, close + "</testsuites>".length) +
    "</document>" +
    xml.slice(close + "</testsuites>".length);
  if (countOccurrences(wrapped, "<testsuites ") !== countOccurrences(xml, "<testsuites ")) {
    throw new ControlError(`${path}: wrapping the root changed the root tag count`);
  }
  writeFileSync(path, wrapped);
  return (
    `${project}/${mode}: the <testsuites> element wrapped in <document>, so the ` +
    `actual root element is <document>`
  );
};

/** Wrap the outer file suite in an unexpected element under the root. */
const wrapSuiteInUnexpectedElement = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const suite = firstOuterSuite(xml, path);
  const close = xml.lastIndexOf("</testsuite>");
  if (close < 0) throw new ControlError(`${path}: no outer suite closing tag`);
  const wrapped =
    xml.slice(0, suite.start) +
    "<wrapper>" +
    xml.slice(suite.start, close + "</testsuite>".length) +
    "</wrapper>" +
    xml.slice(close + "</testsuite>".length);
  if (countOccurrences(wrapped, "<testsuite ") !== countOccurrences(xml, "<testsuite ")) {
    throw new ControlError(`${path}: wrapping the suite changed the suite tag count`);
  }
  writeFileSync(path, wrapped);
  return (
    `${project}/${mode}: the outer file <testsuite> wrapped in <wrapper>, so the ` +
    `root's element child is no longer a file suite`
  );
};

/**
 * Add fake `<testcase>`/`<testsuite>` literals as a root comment and as escaped
 * text inside the outer suite, beside the real testcase. Element grading must
 * ignore them: same element counts, same PASS verdict.
 */
const insertFakeTagLiterals = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const root = openTagAt(xml, "<testsuites ", 0);
  const suite = firstOuterSuite(xml, path);
  if (root === null) throw new ControlError(`${path}: no <testsuites> root element`);
  const comment =
    '<!-- <testsuite file="fake.test.ts" tests="9" failures="0" skipped="0">' +
    '<testcase name="commented" classname="fake"/></testsuite> -->\n  ';
  const escaped = '&lt;testcase name="escaped" classname="fake"/&gt;\n    ';
  const mutated = applyEdits(xml, [
    { start: root.end + 1, end: root.end + 1, text: comment },
    { start: suite.end + 1, end: suite.end + 1, text: escaped },
  ]);
  const rawBefore = countOccurrences(xml, "<testcase ");
  if (countOccurrences(mutated, "<testcase ") <= rawBefore) {
    throw new ControlError(`${path}: fake tag literals were not added to the raw text`);
  }
  writeFileSync(path, mutated);
  return (
    `${project}/${mode}: fake <testcase>/<testsuite> literals added as a root comment and ` +
    `as escaped text beside the real testcase; raw <testcase literals ` +
    `${rawBefore}->${countOccurrences(mutated, "<testcase ")}, element count unchanged`
  );
};

// --- controls -----------------------------------------------------------------

// 1. Pristine, byte-verified corpus: both modes must grade identical.
const pristine = runGraderControl(
  "new-pristine",
  corpus,
  0,
  "29 projects / 179 files / 1596 cases in both modes"
);
if (!pristine.stdout.includes("distinct test files (ordinary): 179")) {
  throw new ControlError("pristine run does not report 179 ordinary files");
}
if (
  !pristine.stdout.includes("test cases (ordinary): 1596") ||
  !pristine.stdout.includes("test cases (isolate):  1596")
) {
  throw new ControlError(
    "pristine run does not report 1596 cases in both modes"
  );
}

// 2. Equal-and-opposite per-file swap. The archived probe exits 0 on it; the
//    corrected grader must not.
const swapCorpus = corpusCopy("swap");
const swapNote = applyEqualAndOppositeSwap(swapCorpus);
const swapInvocation = runGraderControl("new-swap", swapCorpus, 1, swapNote);
if (!swapInvocation.stdout.includes("outcome-mismatch")) {
  throw new ControlError(
    "swap control did not report a per-file outcome mismatch"
  );
}

// 3. Remaining single-mutation controls on the corrected grader.
const failureCorpus = corpusCopy("failure-mismatch");
mutateSuiteAttribute(
  failureCorpus,
  "ordinary",
  SWAP_FILE_FROM,
  "failures",
  "1"
);
mutateRootAttribute(failureCorpus, "ordinary", "failures", "1");
runGraderControl("new-failure-mismatch", failureCorpus, 1);

const skippedCorpus = corpusCopy("skipped-mismatch");
mutateSuiteAttribute(skippedCorpus, "ordinary", SWAP_FILE_FROM, "skipped", "1");
mutateRootAttribute(skippedCorpus, "ordinary", "skipped", "1");
runGraderControl("new-skipped-mismatch", skippedCorpus, 1);

const renamedCorpus = corpusCopy("file-renamed-in-isolate");
{
  const path = reportPath(renamedCorpus, "isolate");
  const xml = readFileSync(path, "utf8");
  if (!xml.includes(`file="${SWAP_FILE_TO}"`))
    throw new ControlError(`${path}: no ${SWAP_FILE_TO}`);
  writeFileSync(
    path,
    xml.replaceAll(
      `file="${SWAP_FILE_TO}"`,
      'file="test/provider-conformance-renamed.test.ts"'
    )
  );
}
runGraderControl("new-file-renamed-in-isolate", renamedCorpus, 1);

const malformedCorpus = corpusCopy("malformed-xml");
{
  const path = reportPath(malformedCorpus, "ordinary");
  const xml = readFileSync(path, "utf8");
  writeFileSync(path, xml.slice(0, Math.floor(xml.length * 0.6)));
}
runGraderControl("new-malformed-xml", malformedCorpus, 1);

const invalidCountCorpus = corpusCopy("invalid-count");
mutateSuiteAttribute(
  invalidCountCorpus,
  "ordinary",
  SWAP_FILE_FROM,
  "tests",
  "abc"
);
runGraderControl("new-invalid-count", invalidCountCorpus, 1);

const unreconciledCorpus = corpusCopy("unreconciled-root");
mutateRootAttribute(unreconciledCorpus, "ordinary", "tests", "8");
runGraderControl("new-unreconciled-root", unreconciledCorpus, 1);

const emptyCorpus = corpusCopy("empty-coverage");
writeFileSync(
  reportPath(emptyCorpus, "ordinary"),
  '<testsuites name="bun test" tests="0" failures="0" skipped="0" time="0"></testsuites>\n'
);
runGraderControl("new-empty-coverage", emptyCorpus, 1);

const missingCorpus = corpusCopy("missing-file");
rmSync(reportPath(missingCorpus, "ordinary"));
runGraderControl("new-missing-file", missingCorpus, 1);

// 3b. Structural well-formedness controls. Both mutations keep every counter
//     and every testcase valid and are invisible to per-file grading; only the
//     pinned runtime's XML processor sees them.
const structuralTruncated = corpusCopy("structural-truncated");
const structuralTruncatedNote = removeClosingStructure(
  structuralTruncated,
  "ordinary",
  SWAP_PROJECT
);
const structuralTruncatedInvocation = runGraderControl(
  "new-structural-truncated",
  structuralTruncated,
  1,
  structuralTruncatedNote
);
if (!structuralTruncatedInvocation.stdout.includes("is not well-formed XML")) {
  throw new ControlError(
    "structural truncation was not reported as malformed XML"
  );
}
if (
  !structuralTruncatedInvocation.stdout.includes(
    "projects with a per-file difference: 0"
  )
) {
  throw new ControlError(
    "structural truncation changed a per-file outcome, so the control does not " +
      "isolate the structural check"
  );
}

const mismatchedClosing = corpusCopy("mismatched-closing-tag");
const mismatchedClosingNote = renameOuterClosingTag(
  mismatchedClosing,
  "ordinary",
  SWAP_PROJECT
);
const mismatchedClosingInvocation = runGraderControl(
  "new-mismatched-closing-tag",
  mismatchedClosing,
  1,
  mismatchedClosingNote
);
if (
  !mismatchedClosingInvocation.stdout.includes(
    "Expected closing tag </testsuite> but found </testsuit>"
  )
) {
  throw new ControlError(
    "the mismatched closing tag was not reported by the native parser"
  );
}
if (
  !mismatchedClosingInvocation.stdout.includes(
    "projects with a per-file difference: 0"
  )
) {
  throw new ControlError(
    "the mismatched closing tag changed a per-file outcome, so the control does " +
      "not isolate the structural check"
  );
}

// 3c. The same structural damage on a one-project corpus: one real report per
//     mode, so a single malformed report is the whole input. A comment control
//     proves the native parser adds no false positive on real report bytes.
const oneFileCases = rootCaseCount(
  readFileSync(join(corpus, "ordinary", `${ONE_FILE_PROJECT}.junit.xml`), "utf8")
);
const oneFileExpectations = [
  "--expect-projects",
  "1",
  "--expect-files",
  "1",
  "--expect-cases",
  String(oneFileCases),
];

const oneFilePristine = buildOneFileFixture("one-file-report-pristine");
const oneFilePristineInvocation = runGraderControl(
  "new-one-file-report-pristine",
  oneFilePristine,
  0,
  `${ONE_FILE_PROJECT}: one real retained report per mode, ` +
    `${oneFileCases} case(s), no structural change`,
  oneFileExpectations
);
if (
  !oneFilePristineInvocation.stdout.includes(
    `test cases (ordinary): ${oneFileCases}`
  )
) {
  throw new ControlError("the one-file fixture did not grade its case count");
}

const oneFileTruncated = buildOneFileFixture("one-file-report-truncated");
const oneFileTruncatedNote = removeClosingStructure(
  oneFileTruncated,
  "isolate",
  ONE_FILE_PROJECT
);
const oneFileTruncatedInvocation = runGraderControl(
  "new-one-file-report-truncated",
  oneFileTruncated,
  1,
  oneFileTruncatedNote,
  oneFileExpectations
);
if (
  !oneFileTruncatedInvocation.stdout.includes(
    "Missing closing tag for element 'testsuite'"
  )
) {
  throw new ControlError(
    "the one-file truncation was not reported by the native parser"
  );
}

const oneFileComment = buildOneFileFixture("one-file-report-comment");
const oneFileCommentNote = insertRootComment(
  oneFileComment,
  "ordinary",
  ONE_FILE_PROJECT
);
runGraderControl(
  "new-one-file-report-comment",
  oneFileComment,
  0,
  oneFileCommentNote,
  oneFileExpectations
);

// 3d. Element-tree controls for the round-two raw-tag-counting defect. Each
//     mutation leaves every counter and every tag literal a text scanner reads
//     untouched, so a raw scanner still grades it as intact; only the parsed
//     element tree sees the missing or misplaced testcase.
const commentedCorpus = corpusCopy("commented-testcase-corpus");
const commentedNote = commentOutFirstTestcase(
  commentedCorpus,
  "isolate",
  ONE_FILE_PROJECT
);
const commentedInvocation = runGraderControl(
  "new-commented-testcase-corpus",
  commentedCorpus,
  1,
  commentedNote
);
if (
  !commentedInvocation.stdout.includes("declares tests=") ||
  !commentedInvocation.stdout.includes("0 testcase elements")
) {
  throw new ControlError(
    "the commented-out testcase was not rejected as a declared/actual count mismatch"
  );
}

const hiddenDocument = buildOneFileFixture("comment-whole-junit-under-empty-root");
const hiddenDocumentNote = hideWholeDocumentInComment(
  hiddenDocument,
  "isolate",
  ONE_FILE_PROJECT
);
const hiddenDocumentInvocation = runGraderControl(
  "new-comment-whole-junit-under-empty-root",
  hiddenDocument,
  1,
  hiddenDocumentNote,
  oneFileExpectations
);
if (
  !hiddenDocumentInvocation.stdout.includes(
    "root element is <empty>, expected <testsuites>"
  )
) {
  throw new ControlError(
    "the empty root hiding a whole JUnit document was not rejected by element name"
  );
}

const cdataCorpus = buildOneFileFixture("cdata-fake-testcase");
const cdataNoteOrdinary = insertCdataFakeTestcase(
  cdataCorpus,
  "ordinary",
  ONE_FILE_PROJECT
);
insertCdataFakeTestcase(cdataCorpus, "isolate", ONE_FILE_PROJECT);
// The raw-tag view now counts one extra testcase in both modes, so this control
// uses the raw-consistent case expectation. A text scanner grades it PASS;
// element grading still rejects the declared/actual mismatch.
const cdataExpectations = [
  "--expect-projects",
  "1",
  "--expect-files",
  "1",
  "--expect-cases",
  String(oneFileCases + 1),
];
const cdataInvocation = runGraderControl(
  "new-cdata-fake-testcase",
  cdataCorpus,
  1,
  `${cdataNoteOrdinary}; isolate mutated identically`,
  cdataExpectations
);
if (
  !cdataInvocation.stdout.includes("declares tests=") ||
  !cdataInvocation.stdout.includes(`${oneFileCases} testcase elements`)
) {
  throw new ControlError(
    "the CDATA fake testcase was not rejected as a declared/actual count mismatch"
  );
}

const nestedRoot = buildOneFileFixture("nested-unexpected-root");
const nestedRootNote = wrapRootInUnexpectedElement(
  nestedRoot,
  "ordinary",
  ONE_FILE_PROJECT
);
const nestedRootInvocation = runGraderControl(
  "new-nested-unexpected-root",
  nestedRoot,
  1,
  nestedRootNote,
  oneFileExpectations
);
if (
  !nestedRootInvocation.stdout.includes(
    "root element is <document>, expected <testsuites>"
  )
) {
  throw new ControlError(
    "a nested <testsuites> under an unexpected root was not rejected by root element name"
  );
}

const nestedSuite = buildOneFileFixture("nested-unexpected-suite");
const nestedSuiteNote = wrapSuiteInUnexpectedElement(
  nestedSuite,
  "ordinary",
  ONE_FILE_PROJECT
);
const nestedSuiteInvocation = runGraderControl(
  "new-nested-unexpected-suite",
  nestedSuite,
  1,
  nestedSuiteNote,
  oneFileExpectations
);
if (
  !nestedSuiteInvocation.stdout.includes("unexpected <wrapper> under <testsuites>")
) {
  throw new ControlError(
    "an unexpected element around the file suite was not rejected by hierarchy"
  );
}

// 3e. The converse: fake tag literals in comments and escaped text beside a real
//     testcase must neither add counts nor fail the run. Raw counting would read
//     the extra literals and reject the report, so a PASS here is discriminating.
const fakeLiterals = buildOneFileFixture("fake-tag-literals-beside-testcase");
const fakeLiteralsNote = insertFakeTagLiterals(
  fakeLiterals,
  "ordinary",
  ONE_FILE_PROJECT
);
const fakeLiteralsInvocation = runGraderControl(
  "new-fake-tag-literals-beside-testcase",
  fakeLiterals,
  0,
  fakeLiteralsNote,
  oneFileExpectations
);
if (
  !fakeLiteralsInvocation.stdout.includes(
    `test cases (ordinary): ${oneFileCases}`
  ) ||
  !fakeLiteralsInvocation.stdout.includes("per-file grading: PASS")
) {
  throw new ControlError(
    "fake tag literals in a comment or escaped text changed the graded element count"
  );
}

// 4. Unusable inputs and a CLI usage error.
{
  const absentCorpus = join(controls, "missing-input-root");
  rmSync(absentCorpus, { recursive: true, force: true });
  cpSync(corpus, absentCorpus, { recursive: true });
  rmSync(join(absentCorpus, "ordinary"), { recursive: true, force: true });
  const invocation = run(graderArgs(absentCorpus));
  record("new-missing-input-root", graderCommand(absentCorpus), invocation, 1);

  const usage = run([grader, "--bogus"]);
  record("new-usage-error", `bun ${relative(grader)} --bogus`, usage, 2);
}

// 5. The archived probe, relocated by one line, on the pristine and the swapped
//    layout. It self-reports one differing project on the swap and still exits 0.
const scaffold = join(work, "scaffold");
buildScaffold(corpus, scaffold);
const { path: historicalPath, relocation } = relocateHistorical(scaffold);
const historicalCommand = `bun ${relative(historicalPath)}`;
const historicalPristine = run([historicalPath]);
record(
  "historical-pristine",
  historicalCommand,
  historicalPristine,
  0,
  relocation
);
if (
  !historicalPristine.stdout.includes(
    "projects with any per-file difference: 0"
  )
) {
  throw new ControlError(
    "archived probe did not report zero differences on the pristine corpus"
  );
}

// Rebuild the same scaffold path from the swapped corpus so the single
// relocated copy is reused unchanged; only the corpus differs.
buildScaffold(swapCorpus, scaffold);
const historicalSwap = run([historicalPath]);
record(
  "historical-swap",
  historicalCommand,
  historicalSwap,
  0,
  "historical defect: prints DIFFERS for the swapped project and still exits 0"
);
if (!historicalSwap.stdout.includes(`${SWAP_PROJECT}: DIFFERS`)) {
  throw new ControlError(
    "archived probe did not print DIFFERS for the swapped project"
  );
}
if (
  !historicalSwap.stdout.includes("projects with any per-file difference: 1")
) {
  throw new ControlError("archived probe did not count one differing project");
}

// 6. The companion aggregate probe cannot see the swap at all: it reads only
//    project-level rows, which the equal-and-opposite change leaves untouched.
{
  const observations = join(source, "assert-observations.mjs");
  const rawPristine = join(work, "raw-scaffold");
  buildRawScaffold(corpus, rawPristine);
  const pristineObservations = run([observations, rawPristine]);
  record(
    "historical-assert-observations-pristine",
    `bun ${relative(observations)} ${relative(rawPristine)}`,
    pristineObservations,
    0
  );

  const rawSwapped = join(work, "raw-scaffold-swap");
  buildRawScaffold(swapCorpus, rawSwapped);
  const swappedObservations = run([observations, rawSwapped]);
  record(
    "historical-assert-observations-swap",
    `bun ${relative(observations)} ${relative(rawSwapped)}`,
    swappedObservations,
    0,
    "aggregate blind spot: project rows are unchanged, so the swap passes"
  );
  if (swappedObservations.exit !== 0) {
    throw new ControlError(
      "aggregate probe unexpectedly failed the swap control"
    );
  }
}
const failed = results
  .filter((result) => !result.ok)
  .map((result) => result.name);
const summary = {
  ok: failed.length === 0,
  swap: swapNote,
  historicalRelocation: relocation,
  controls: results,
  failed,
};
console.log(JSON.stringify(summary, null, 2));
writeFileSync(
  join(receipts, "control-matrix.json"),
  `${JSON.stringify(summary, null, 2)}\n`
);
process.exitCode = failed.length === 0 ? 0 : 1;
