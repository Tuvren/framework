/**
 * Fixture-mutation helpers for the replay control harness.
 *
 * Each helper copies or rewrites exactly one part of a replay corpus so a
 * control can isolate one grader behavior. Callers pass the corpus and controls
 * roots explicitly, so the helpers hold no process-wide state.
 */
import {
  copyFileSync,
  mkdirSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { join } from "node:path";
import {
  ONE_FILE_PROJECT,
  PROJECTS_TSV,
  SWAP_FILE_FROM,
  SWAP_FILE_TO,
  SWAP_PROJECT,
} from "./replay-constants";
import { ControlError } from "./replay-errors";
import {
  applyEdits,
  attributeMap,
  countOccurrences,
  countTestcases,
  firstOuterSuite,
  openTagAt,
  outerSuiteFor,
  outerSuiteTags,
  rootCaseCount,
  segmentEnd,
  suiteTests,
  withAttribute,
} from "./replay-xml";

export const reportPath = (
  corpusDir: string,
  mode: string,
  project = SWAP_PROJECT
): string => join(corpusDir, mode, `${project}.junit.xml`);

export const mutateSuiteAttribute = (
  corpusDir: string,
  mode: string,
  file: string,
  name: string,
  value: string
): void => {
  const path = reportPath(corpusDir, mode);
  const xml = readFileSync(path, "utf8");
  const tag = outerSuiteFor(xml, file);
  const replaced = withAttribute(tag, name, value);
  writeFileSync(
    path,
    xml.slice(0, tag.start) + `<${replaced.text}>` + xml.slice(tag.end + 1)
  );
};

export const mutateRootAttribute = (
  corpusDir: string,
  mode: string,
  name: string,
  value: string
): void => {
  const path = reportPath(corpusDir, mode);
  const xml = readFileSync(path, "utf8");
  const root = openTagAt(xml, "<testsuites ", 0);
  if (root === null) throw new ControlError(`${path}: no root element`);
  const replaced = withAttribute(root, name, value);
  writeFileSync(
    path,
    xml.slice(0, root.start) + `<${replaced.text}>` + xml.slice(root.end + 1)
  );
};

/**
 * Move one test case from `SWAP_FILE_FROM` to `SWAP_FILE_TO` inside one
 * project's ordinary report. File names, file count, case total and both mode
 * totals stay unchanged, so only a per-file comparison can detect it.
 */
export const applyEqualAndOppositeSwap = (corpusDir: string): string => {
  const path = reportPath(corpusDir, "ordinary");
  const xml = readFileSync(path, "utf8");
  const from = outerSuiteFor(xml, SWAP_FILE_FROM);
  const to = outerSuiteFor(xml, SWAP_FILE_TO);
  const fromTests = suiteTests(xml, SWAP_FILE_FROM);
  const toTests = suiteTests(xml, SWAP_FILE_TO);
  const fromSegment = xml.slice(from.end + 1, segmentEnd(xml, from));
  const testcases = [...fromSegment.matchAll(/<testcase [^>]*\/>/g)];
  const last = testcases[testcases.length - 1];
  if (last === undefined || last.index === undefined) {
    throw new ControlError(`no self-closing testcase inside ${SWAP_FILE_FROM}`);
  }
  const moved = last[0];
  const movedStart = from.end + 1 + last.index;
  const closeIndex = xml
    .slice(to.end + 1, segmentEnd(xml, to))
    .lastIndexOf("</testsuite>");
  if (closeIndex < 0)
    throw new ControlError(`no closing tag for ${SWAP_FILE_TO}`);
  const insertAt = to.end + 1 + closeIndex;
  const swapped = applyEdits(xml, [
    {
      start: from.start,
      end: from.end + 1,
      text: `<${withAttribute(from, "tests", String(fromTests - 1)).text}>`,
    },
    {
      start: to.start,
      end: to.end + 1,
      text: `<${withAttribute(to, "tests", String(toTests + 1)).text}>`,
    },
    { start: movedStart, end: movedStart + moved.length, text: "" },
    { start: insertAt, end: insertAt, text: `${moved}\n    ` },
  ]);
  const afterFrom = suiteTests(swapped, SWAP_FILE_FROM);
  const afterTo = suiteTests(swapped, SWAP_FILE_TO);
  if (fromTests + toTests !== afterFrom + afterTo || afterFrom === fromTests) {
    throw new ControlError(
      "swap did not produce an equal-and-opposite per-file change"
    );
  }
  if (outerSuiteTags(swapped).length !== outerSuiteTags(xml).length) {
    throw new ControlError("swap changed the file set");
  }
  writeFileSync(path, swapped);
  return (
    `${SWAP_PROJECT}: ${SWAP_FILE_FROM} tests ${fromTests}->${afterFrom}, ` +
    `${SWAP_FILE_TO} tests ${toTests}->${afterTo}, project aggregate ${fromTests + toTests} unchanged`
  );
};


/**
 * Drop the outer file-suite closing tag and the root closing tag, keeping every
 * attribute, counter and testcase exactly as reported. This is the structural
 * damage the historical counter-based grading could not see.
 */
export const removeClosingStructure = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const outerClose = xml.lastIndexOf("</testsuite>");
  const rootClose = xml.lastIndexOf("</testsuites>");
  if (outerClose < 0 || rootClose < 0 || outerClose > rootClose) {
    throw new ControlError(`${path}: no outer suite and root closing tags`);
  }
  const truncated =
    xml.slice(0, outerClose) +
    xml.slice(outerClose + "</testsuite>".length, rootClose) +
    xml.slice(rootClose + "</testsuites>".length);
  const droppedTags =
    countOccurrences(xml, "</testsuite>") -
    countOccurrences(truncated, "</testsuite>");
  if (droppedTags !== 1 || countOccurrences(truncated, "</testsuites>") !== 0) {
    throw new ControlError(
      `${path}: truncation dropped ${droppedTags} </testsuite> tag(s) and left ` +
        `${countOccurrences(truncated, "</testsuites>")} root closing tag(s)`
    );
  }
  const testcases = countTestcases(xml);
  if (
    testcases === 0 ||
    countTestcases(truncated) !== testcases ||
    countOccurrences(truncated, "<testsuite ") !==
      countOccurrences(xml, "<testsuite ")
  ) {
    throw new ControlError(
      `${path}: truncation changed the content, not only the closing structure`
    );
  }
  writeFileSync(path, truncated);
  return (
    `${project}/${mode}: removed the outer </testsuite> and the root </testsuites> ` +
    `after ${testcases} valid testcases, ${xml.length - truncated.length} bytes ` +
    `dropped, every counter unchanged`
  );
};

/**
 * Rename the outer file-suite closing tag. The tag no longer matches the
 * element it closes, which is a well-formedness error and nothing else.
 */
export const renameOuterClosingTag = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const outerClose = xml.lastIndexOf("</testsuite>");
  if (outerClose < 0) {
    throw new ControlError(`${path}: no outer suite closing tag`);
  }
  const mismatched =
    xml.slice(0, outerClose) +
    "</testsuit>" +
    xml.slice(outerClose + "</testsuite>".length);
  if (
    countTestcases(mismatched) !== countTestcases(xml) ||
    countOccurrences(mismatched, "<testsuite ") !==
      countOccurrences(xml, "<testsuite ")
  ) {
    throw new ControlError(`${path}: renaming the closing tag changed the content`);
  }
  writeFileSync(path, mismatched);
  return (
    `${project}/${mode}: outer closing tag </testsuite> renamed to </testsuit>, ` +
    `every counter and testcase unchanged`
  );
};

/**
 * A one-project corpus made of one real retained report per mode, so the grader
 * can be pointed at a minimal corpus with `--expect-projects 1`.
 */
export const buildOneFileFixture = (
  name: string,
  corpusDir: string,
  controlsDir: string
): string => {
  const destination = join(controlsDir, name);
  rmSync(destination, { recursive: true, force: true });
  for (const mode of ["ordinary", "isolate"]) {
    mkdirSync(join(destination, mode), { recursive: true });
    copyFileSync(
      join(corpusDir, mode, `${ONE_FILE_PROJECT}.junit.xml`),
      join(destination, mode, `${ONE_FILE_PROJECT}.junit.xml`)
    );
  }
  const row = readFileSync(join(corpusDir, PROJECTS_TSV), "utf8")
    .split("\n")
    .find((line) => line.startsWith(`${ONE_FILE_PROJECT}\t`));
  if (row === undefined) {
    throw new ControlError(`no ${PROJECTS_TSV} row for ${ONE_FILE_PROJECT}`);
  }
  writeFileSync(join(destination, PROJECTS_TSV), `${row}\n`);
  return destination;
};

/** Insert one XML comment directly inside the root element. */
export const insertRootComment = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const root = openTagAt(xml, "<testsuites ", 0);
  if (root === null) throw new ControlError(`${path}: no <testsuites> root element`);
  const comment = "<!-- a comment is not a well-formedness failure -->\n  ";
  const commented = xml.slice(0, root.end + 1) + comment + xml.slice(root.end + 1);
  if (
    countTestcases(commented) !== countTestcases(xml) ||
    countOccurrences(commented, "<testsuite ") !==
      countOccurrences(xml, "<testsuite ")
  ) {
    throw new ControlError(`${path}: inserting a comment changed the report content`);
  }
  writeFileSync(path, commented);
  return `${project}/${mode}: inserted one XML comment inside the root`;
};


/**
 * Replicate the round-two reviewer reproducer exactly: wrap the first
 * self-closing `<testcase ... />` of one report in an XML comment. Every
 * counter and every raw tag literal stays byte for byte as reported, so a text
 * scanner still sees the testcase while the element tree no longer holds it.
 */
export const commentOutFirstTestcase = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const before = countOccurrences(xml, "<testcase ");
  const match = /(<testcase\s[^>]*?\s\/>)/u.exec(xml);
  if (match === null || match.index === undefined) {
    throw new ControlError(`${path}: no self-closing testcase to comment out`);
  }
  const literal = match[0];
  const mutated =
    xml.slice(0, match.index) +
    `<!--${literal}-->` +
    xml.slice(match.index + literal.length);
  if (countOccurrences(mutated, "<testcase ") !== before) {
    throw new ControlError(`${path}: commenting out a testcase changed the raw tag count`);
  }
  if (
    countOccurrences(mutated, "<testsuite ") !==
    countOccurrences(xml, "<testsuite ")
  ) {
    throw new ControlError(`${path}: commenting out a testcase changed the suite tags`);
  }
  writeFileSync(path, mutated);
  return (
    `${project}/${mode}: first self-closing <testcase ... /> wrapped in an XML comment; ` +
    `${before} raw <testcase literals and every counter unchanged`
  );
};

/** Replace one report with an empty root that hides a whole JUnit document in a comment. */
export const hideWholeDocumentInComment = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  writeFileSync(path, `<empty><!--${xml}--></empty>\n`);
  return (
    `${project}/${mode}: whole valid JUnit report hidden inside an XML comment ` +
    `under an <empty> root`
  );
};

/**
 * Add a CDATA section holding a fake `<testcase .../>` literal and raise the
 * declared counts to match the raw literal count. A text scanner therefore
 * stays self-consistent, while the element tree has no extra testcase.
 */
export const insertCdataFakeTestcase = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const suite = firstOuterSuite(xml, path);
  const file = attributeMap(suite.text).get("file");
  const root = openTagAt(xml, "<testsuites ", 0);
  if (file === undefined || root === null) {
    throw new ControlError(`${path}: outer suite or root element is unusable`);
  }
  const suiteTestsBefore = suiteTests(xml, file);
  const rootTestsBefore = rootCaseCount(xml);
  const fake = '<![CDATA[<testcase name="fake" classname="fake"/>]]>';
  const mutated = applyEdits(xml, [
    {
      start: root.start,
      end: root.end + 1,
      text: `<${withAttribute(root, "tests", String(rootTestsBefore + 1)).text}>`,
    },
    {
      start: suite.start,
      end: suite.end + 1,
      text: `<${withAttribute(suite, "tests", String(suiteTestsBefore + 1)).text}>`,
    },
    { start: suite.end + 1, end: suite.end + 1, text: fake },
  ]);
  if (
    countOccurrences(mutated, "<testcase ") !==
      countOccurrences(xml, "<testcase ") + 1 ||
    suiteTests(mutated, file) !== suiteTestsBefore + 1 ||
    rootCaseCount(mutated) !== rootTestsBefore + 1
  ) {
    throw new ControlError(`${path}: the CDATA fixture did not stay raw-tag consistent`);
  }
  writeFileSync(path, mutated);
  return (
    `${project}/${mode}: one CDATA section holding a fake <testcase .../> literal; ` +
    `declared tests ${suiteTestsBefore}->${suiteTestsBefore + 1} and root tests ` +
    `${rootTestsBefore}->${rootTestsBefore + 1} so raw tag counting stays consistent, ` +
    `while the element tree still has ${suiteTestsBefore} testcase(s)`
  );
};

/** Wrap the real root element in an unexpected element. */
export const wrapRootInUnexpectedElement = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const root = openTagAt(xml, "<testsuites ", 0);
  const close = xml.lastIndexOf("</testsuites>");
  if (root === null || close < 0) {
    throw new ControlError(`${path}: no <testsuites> root element`);
  }
  const wrapped =
    xml.slice(0, root.start) +
    "<document>" +
    xml.slice(root.start, close + "</testsuites>".length) +
    "</document>" +
    xml.slice(close + "</testsuites>".length);
  if (countOccurrences(wrapped, "<testsuites ") !== countOccurrences(xml, "<testsuites ")) {
    throw new ControlError(`${path}: wrapping the root changed the root tag count`);
  }
  writeFileSync(path, wrapped);
  return (
    `${project}/${mode}: the <testsuites> element wrapped in <document>, so the ` +
    `actual root element is <document>`
  );
};

/** Wrap the outer file suite in an unexpected element under the root. */
export const wrapSuiteInUnexpectedElement = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const suite = firstOuterSuite(xml, path);
  const close = xml.lastIndexOf("</testsuite>");
  if (close < 0) throw new ControlError(`${path}: no outer suite closing tag`);
  const wrapped =
    xml.slice(0, suite.start) +
    "<wrapper>" +
    xml.slice(suite.start, close + "</testsuite>".length) +
    "</wrapper>" +
    xml.slice(close + "</testsuite>".length);
  if (countOccurrences(wrapped, "<testsuite ") !== countOccurrences(xml, "<testsuite ")) {
    throw new ControlError(`${path}: wrapping the suite changed the suite tag count`);
  }
  writeFileSync(path, wrapped);
  return (
    `${project}/${mode}: the outer file <testsuite> wrapped in <wrapper>, so the ` +
    `root's element child is no longer a file suite`
  );
};

/**
 * Add fake `<testcase>`/`<testsuite>` literals as a root comment and as escaped
 * text inside the outer suite, beside the real testcase. Element grading must
 * ignore them: same element counts, same PASS verdict.
 */
export const insertFakeTagLiterals = (
  corpusDir: string,
  mode: string,
  project: string
): string => {
  const path = reportPath(corpusDir, mode, project);
  const xml = readFileSync(path, "utf8");
  const root = openTagAt(xml, "<testsuites ", 0);
  const suite = firstOuterSuite(xml, path);
  if (root === null) throw new ControlError(`${path}: no <testsuites> root element`);
  const comment =
    '<!-- <testsuite file="fake.test.ts" tests="9" failures="0" skipped="0">' +
    '<testcase name="commented" classname="fake"/></testsuite> -->\n  ';
  const escaped = '&lt;testcase name="escaped" classname="fake"/&gt;\n    ';
  const mutated = applyEdits(xml, [
    { start: root.end + 1, end: root.end + 1, text: comment },
    { start: suite.end + 1, end: suite.end + 1, text: escaped },
  ]);
  const rawBefore = countOccurrences(xml, "<testcase ");
  if (countOccurrences(mutated, "<testcase ") <= rawBefore) {
    throw new ControlError(`${path}: fake tag literals were not added to the raw text`);
  }
  writeFileSync(path, mutated);
  return (
    `${project}/${mode}: fake <testcase>/<testsuite> literals added as a root comment and ` +
    `as escaped text beside the real testcase; raw <testcase literals ` +
    `${rawBefore}->${countOccurrences(mutated, "<testcase ")}, element count unchanged`
  );
};

