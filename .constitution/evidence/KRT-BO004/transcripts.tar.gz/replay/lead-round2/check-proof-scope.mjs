import {strict as assert} from "node:assert";
import {readdir,readFile} from "node:fs/promises";
const dir="/home/oscar/.cache/pi-subagent/framework/wf-bo-pr-r2-fix/lead/replay";
const results=[];
for(const name of await readdir(dir)){
 if(!name.endsWith(".ts"))continue;
 const text=await readFile(dir+"/"+name,"utf8"),lines=text.split("\n").length;
 assert.ok(lines<1000,name+" exceeds 1000 line ceiling");
 assert.ok(!/\brequire\s*\(/.test(text),name+" uses CommonJS");
 assert.ok(!/:\s*any\b|@ts-ignore|@ts-expect-error/.test(text),name+" uses unsafe bypass");
 results.push({file:name,lines});
}
const controls=await Bun.file(dir+"/receipts/control-matrix.json").json();
assert.equal(controls.ok,true);assert.equal(controls.controls.length,27);assert.deepEqual(controls.failed,[]);
const receipt=await Bun.file(dir+"/receipts/positive.json").json();assert.equal(receipt.ok,true);assert.equal(receipt.observed.ordinaryCases,1596);assert.equal(receipt.nativeElementGrading.testcaseElements,3192);
console.log(JSON.stringify({modules:results,controls:27,positive:receipt.observed},null,2));

