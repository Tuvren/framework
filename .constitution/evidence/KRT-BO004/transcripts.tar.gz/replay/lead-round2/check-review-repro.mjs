import {strict as assert} from "node:assert";
const b="/home/oscar/.cache/pi-subagent/framework", j="/home/oscar/.cache/pi-subagent/framework/wf-bo-pr-r2-fix/lead";
const dir=b+"/pr-review-round2-sol61/comment-corpus";
const cmd=[process.execPath,j+"/replay/compare-matrix-junit-replay.ts","--ordinary",dir+"/ordinary","--isolate",dir+"/isolate","--projects",dir+"/bun-test-projects.tsv","--json",j+"/reviewer-repro.json"];
const child=Bun.spawn(cmd,{stdout:"pipe",stderr:"pipe"});
const [stdout,stderr,code]=await Promise.all([new Response(child.stdout).text(),new Response(child.stderr).text(),child.exited]);
console.log(JSON.stringify({command:cmd,exit:code,stdout,stderr}));
assert.equal(code,1,"commented testcase must be rejected");
const result=await Bun.file(j+"/reviewer-repro.json").json();assert.equal(result.ok,false);assert.ok(result.problems.some(p=>p.includes("contains 0 testcase elements")));console.log("PASS: exact reviewer corpus rejected");

