import {strict as assert} from "node:assert";
const b="/home/oscar/.cache/pi-subagent/framework",j="/home/oscar/.cache/pi-subagent/framework/wf-bo-pr-r3-fix/lead";
for(const [name,dir] of [["nested-testcase",b+"/pr-review-round3-sol61/nested-testcase-corpus"],["commented-testcase",b+"/pr-review-round2-sol61/comment-corpus"]]){
 const command=[process.execPath,j+"/replay/compare-matrix-junit-replay.ts","--ordinary",dir+"/ordinary","--isolate",dir+"/isolate","--projects",dir+"/bun-test-projects.tsv","--json",j+"/repro-"+name+".json"];
 const child=Bun.spawn(command,{stdout:"pipe",stderr:"pipe"});
 const [stdout,stderr,exit]=await Promise.all([new Response(child.stdout).text(),new Response(child.stderr).text(),child.exited]);
 console.log(JSON.stringify({name,command,exit,stdout,stderr}));
 assert.equal(exit,1,name+" must be rejected");
 const receipt=await Bun.file(j+"/repro-"+name+".json").json();assert.equal(receipt.ok,false);
}
console.log("PASS: exact round-two and round-three full-corpus negative controls reject");

