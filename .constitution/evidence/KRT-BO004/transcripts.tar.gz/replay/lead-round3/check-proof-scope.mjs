import {strict as assert} from "node:assert";
import {readdir,readFile} from "node:fs/promises";
const dir="/home/oscar/.cache/pi-subagent/framework/wf-bo-pr-r3-fix/lead/replay",prior="/home/oscar/.cache/pi-subagent/framework/wf-bo-pr-r2-fix/lead/replay/receipts/control-matrix.json";
const modules=[];
for(const name of await readdir(dir)){
 if(!name.endsWith(".ts"))continue;
 const source=await readFile(dir+"/"+name,"utf8"),lines=source.split("\n").length;
 assert.ok(lines<1000,name+" exceeds 1000 line ceiling");
 assert.ok(!/\brequire\s*\(/.test(source),name+" uses CommonJS");
 assert.ok(!/:\s*any\b|@ts-ignore|@ts-expect-error/.test(source),name+" uses unsafe bypass");
 modules.push({file:name,lines});
}
const controls=await Bun.file(dir+"/receipts/control-matrix.json").json(),old=await Bun.file(prior).json();
assert.equal(controls.ok,true);assert.ok(controls.controls.length>=30);assert.deepEqual(controls.failed,[]);
assert.equal(old.controls.length,27);
for(const previous of old.controls){const current=controls.controls.find(c=>c.name===previous.name);assert.ok(current,"missing prior control "+previous.name);assert.equal(current.expectedExit,previous.expectedExit);assert.equal(current.exit,current.expectedExit);}
const receipt=await Bun.file(dir+"/receipts/positive.json").json();assert.equal(receipt.ok,true);assert.equal(receipt.observed.ordinaryCases,1596);assert.equal(receipt.nativeElementGrading.testcaseElements,3192);
console.log(JSON.stringify({modules,controls:controls.controls.length,allPrior27ExpectationsPreserved:true,positive:receipt.observed},null,2));

