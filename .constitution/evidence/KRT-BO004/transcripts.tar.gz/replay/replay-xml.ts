/**
 * Well-formed-enough XML scanning helpers for the replay control harness.
 *
 * These read raw report text to locate tags and attributes for fixture
 * mutation. They never derive a grade; grading runs on the parsed element tree
 * in `compare-matrix-junit-replay.ts`.
 */
import { ControlError } from "./replay-errors";

const ATTRIBUTE = /([A-Za-z_:][\w:.-]*)="([^"]*)"/g;

export interface TagAt {
  readonly start: number;
  readonly end: number;
  readonly text: string;
}

export interface Edit {
  readonly start: number;
  readonly end: number;
  readonly text: string;
}

export const attributeMap = (tag: string): Map<string, string> => {
  const attributes = new Map<string, string>();
  for (const match of tag.matchAll(ATTRIBUTE)) {
    const name = match[1];
    const value = match[2];
    if (name !== undefined && value !== undefined) attributes.set(name, value);
  }
  return attributes;
};

export const openTagAt = (xml: string, needle: string, from: number): TagAt | null => {
  const start = xml.indexOf(needle, from);
  if (start < 0) return null;
  let inQuotes = false;
  for (let index = start; index < xml.length; index += 1) {
    const character = xml[index];
    if (character === '"') inQuotes = !inQuotes;
    else if (character === ">" && !inQuotes) {
      return { start, end: index, text: xml.slice(start + 1, index) };
    }
  }
  throw new ControlError(`unterminated tag ${needle.trim()}`);
};

/** Outer file suites only: a `file` attribute without a nested-describe `line`. */
export const outerSuiteTags = (xml: string): TagAt[] => {
  const tags: TagAt[] = [];
  let cursor = 0;
  for (;;) {
    const tag = openTagAt(xml, "<testsuite ", cursor);
    if (tag === null) return tags;
    if (!attributeMap(tag.text).has("line")) tags.push(tag);
    cursor = tag.end + 1;
  }
};

export const outerSuiteFor = (xml: string, file: string): TagAt => {
  for (const tag of outerSuiteTags(xml)) {
    if (attributeMap(tag.text).get("file") === file) return tag;
  }
  throw new ControlError(`no outer suite for ${file}`);
};

export const countOccurrences = (haystack: string, needle: string): number => {
  let count = 0;
  let cursor = 0;
  for (;;) {
    const found = haystack.indexOf(needle, cursor);
    if (found < 0) return count;
    count += 1;
    cursor = found + needle.length;
  }
};

export const countTestcases = (xml: string): number =>
  countOccurrences(xml, "<testcase ");

export const segmentEnd = (xml: string, tag: TagAt): number => {
  const tags = outerSuiteTags(xml);
  const position = tags.findIndex((candidate) => candidate.start === tag.start);
  const next = tags[position + 1];
  return next === undefined ? xml.length : next.start;
};

export const suiteTests = (xml: string, file: string): number =>
  Number(attributeMap(outerSuiteFor(xml, file).text).get("tests"));

export const withAttribute = (tag: TagAt, name: string, value: string): TagAt => {
  const replaced = tag.text.replace(
    new RegExp(`(\\s${name}=")[^"]*(")`),
    `$1${value}$2`
  );
  if (replaced === tag.text)
    throw new ControlError(`attribute ${name} not found in ${tag.text}`);
  return { start: tag.start, end: tag.end, text: replaced };
};

export const applyEdits = (xml: string, edits: readonly Edit[]): string => {
  let result = xml;
  for (const edit of [...edits].sort(
    (left, right) => right.start - left.start
  )) {
    if (edit.start < 0 || edit.end > result.length || edit.start > edit.end) {
      throw new ControlError(`invalid edit range ${edit.start}..${edit.end}`);
    }
    result = result.slice(0, edit.start) + edit.text + result.slice(edit.end);
  }
  return result;
};

/** Case count of a report's root element, for the minimal fixture inventory. */
export const rootCaseCount = (xml: string): number => {
  const root = openTagAt(xml, "<testsuites ", 0);
  if (root === null) throw new ControlError("fixture report has no <testsuites> root");
  const raw = attributeMap(root.text).get("tests");
  const value = raw === undefined ? Number.NaN : Number(raw);
  if (!Number.isSafeInteger(value)) {
    throw new ControlError(`fixture report has no usable root tests attribute: ${raw}`);
  }
  return value;
};

export const firstOuterSuite = (xml: string, path: string): TagAt => {
  const tag = outerSuiteTags(xml)[0];
  if (tag === undefined) throw new ControlError(`${path}: no outer file suite`);
  return tag;
};

