#!/usr/bin/env bun
/**
 * KRT-BO004 replay grader for the retained ordinary / `--isolate` JUnit corpus.
 *
 * Why this file exists
 * --------------------
 * The historical probe retained unchanged as `probe__compare-matrix-junit.ts`
 * computed per-file differences and printed `DIFFERS`, but it never set a
 * failing exit status, and its companion `assert-observations.mjs` graded only
 * project-level totals. An equal-and-opposite per-file change (two files that
 * swap test counts inside one project) therefore left both tools at exit 0.
 * This replay grader exits nonzero for any missing project or file, any
 * malformed report, any invalid count and any per-file mismatch of tests,
 * failures or skipped, even when the project totals still agree. It reads its
 * corpus from the command line instead of a recorded scratch constant.
 *
 * Grading runs on the parsed element tree
 * ---------------------------------------
 * Scanning raw `<testcase` literals is not grading. A report that keeps every
 * counter but moves its only test case into an XML comment, or that hides a
 * whole JUnit document inside a comment, still looked intact to a text scanner
 * because the tag text was still there. Grading data now comes from the pinned
 * runtime's own XML processor, `Bun.XML.parse(<report>, { compact: false })`,
 * which returns the root element as an object tree — `{ name, attributes,
 * children }`, with comments and processing instructions as objects that carry
 * no `name`. Every count is taken from real element nodes: the root must be an
 * actual `<testsuites>` element, its element children must be actual outer
 * `<testsuite file="..">` elements, and a file suite's declared `tests` must
 * equal the number of actual `<testcase>` element descendants, including those
 * inside nested `<testsuite line="..">` describe suites. Text, CDATA sections,
 * comments and processing instructions hold no elements, so tag literals in
 * commented-out or CDATA content cannot inflate a grade.
 *
 * Every testcase subtree is validated too
 * ---------------------------------------
 * Counting `<testcase>` children without looking inside them left the rest of
 * the hierarchy premise open. Wrapping an existing testcase in another
 * `<testcase name="outer-wrapper">` kept every declared counter and every
 * supported-position count intact, so the run still graded PASS even though a
 * testcase had become the parent of a testcase; hiding a `<testsuite>` or a
 * `<testsuites>` element inside a testcase, or hiding a testcase under a
 * metadata wrapper such as `<failure>`, did the same. An execution element
 * (`<testsuites>`, `<testsuite>` or `<testcase>`) may therefore appear only in
 * a supported position: under `<testsuites>` as a file suite, or under a test
 * suite as a testcase or a nested `<testsuite line="..">`. A testcase's
 * descendants may carry reporter metadata — the measured Bun 1.4.2 shapes are
 * `<skipped/>` and `<failure type=".." message="..">text</failure>` — but no
 * execution element may sit anywhere in a testcase subtree, however deeply a
 * metadata wrapper nests it.
 *
 * Bun 1.4.2 JUnit report shape
 * ----------------------------
 * Established by inspecting the pinned reporter output and all 58 retained
 * reports, not assumed:
 *   - `<testsuites tests=".." failures=".." skipped="..">` is the single root
 *     element and carries no `file` attribute.
 *   - Each test file produces exactly one outer
 *     `<testsuite file=".." tests=".." failures=".." skipped="..">` element
 *     with no `line` attribute (358 outer suites in the retained corpus).
 *   - Nested `describe()` blocks produce further `<testsuite file=".." line="N">`
 *     elements that repeat the same `file` and count a subset of the outer
 *     suite (630 in the retained corpus), so they grade as part of their outer
 *     file suite rather than as extra file outcomes.
 *   - Summing the outer suites reproduces the root totals exactly, and each
 *     outer suite's `tests` equals the number of `<testcase>` element
 *     descendants it contains (true for 358/358 retained outer suites).
 *
 * Native helper
 * -------------
 * The repository pins `@types/bun` 1.3.14, which predates `Bun.XML`, so
 * `Bun.XML.parse` cannot be called from typechecked code (`TS2339`). The one
 * inline ESM program below runs under `process.execPath` — the same pinned
 * binary — parses every report with `{ compact: false }`, enforces the element
 * shape, and returns canonical grading data as JSON on stdout: root totals and
 * one record per outer file suite (`file`, `tests`, `failures`, `skipped` and
 * the actual `cases` element count). The parent narrows that JSON as `unknown`
 * before use; it never counts raw XML text. When the child cannot run, exits
 * nonzero, or returns a record the parent cannot narrow, the run fails closed.
 *
 * Usage
 * -----
 *   bun compare-matrix-junit-replay.ts \
 *     --ordinary <dir>            # <dir>/<project>.junit.xml, ordinary mode
 *     --isolate  <dir>            # same naming, isolated mode
 *     --projects <path>           # TSV: project<TAB>cwd, one per expected project
 *     [--ordinary-pattern '{project}.junit.xml']
 *     [--isolate-pattern  '{project}.junit.xml']
 *     [--expect-projects 29] [--expect-files 179] [--expect-cases 1596]
 *     [--json <path>]             # write a machine-readable receipt
 *
 * `--expect-*` default to the KRT-BO004 retained inventory (29 projects,
 * 179 files, 1596 cases per mode). They guard against a truncated corpus
 * passing silently; override them for a different corpus.
 *
 * Exit codes: 0 all graded; 1 any data failure; 2 CLI usage error.
 */
import { existsSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { join } from "node:path";

/** Per-file outcome triple as emitted on an outer file suite. */
interface FileOutcome {
  readonly tests: number;
  readonly failures: number;
  readonly skipped: number;
}

/** One parsed JUnit report, reduced to outer file outcomes. */
interface ParsedReport {
  readonly files: Map<string, FileOutcome>;
  readonly caseCount: number;
}

/** Grading data the native helper extracts from one report's element tree. */
interface NativeFileGrading {
  readonly file: string;
  readonly tests: number;
  readonly failures: number;
  readonly skipped: number;
  readonly cases: number;
}

/** Root totals and outer file suites of one report's element tree. */
interface NativeReportGrading {
  readonly root: FileOutcome;
  readonly files: readonly NativeFileGrading[];
}

/** One report the native helper refused, with the failure kind it recorded. */
interface NativeRejection {
  readonly kind: string;
  readonly message: string;
}

/** Native grading data for every report a run will read. */
interface NativeGrading {
  readonly outcomes: ReadonlyMap<string, NativeReportGrading>;
  readonly rejections: ReadonlyMap<string, NativeRejection>;
  readonly checked: number;
  readonly outerSuites: number;
  readonly testcaseElements: number;
}

/** Raised for any unusable input; every instance fails the run. */
class ReplayInputError extends Error {}

/** Raised for a command-line mistake; exits 2 instead of 1. */
class UsageError extends Error {}

const INTEGER = /^[0-9]+$/;

const DEFAULT_EXPECT_PROJECTS = 29;
const DEFAULT_EXPECT_FILES = 179;
const DEFAULT_EXPECT_CASES = 1596;

/**
 * Inline ESM program that parses every report with the pinned runtime's own XML
 * processor and prints canonical grading data as JSON. It is handed to `bun -e`
 * of `process.execPath` — the binary this grader is running on — because the
 * repository's pinned `@types/bun` (1.3.14) predates `Bun.XML`, so the call
 * cannot live in typechecked TypeScript.
 *
 * Each record is one of:
 *   `{ path, ok: true,  report: { root: {tests,failures,skipped}, files: [...] } }`
 *   `{ path, ok: false, kind: "read" | "parse" | "shape", error }`
 * followed by `{ count, reports }`. Exit 3 means the parser is unavailable,
 * which the grader reports as an unusable input rather than as a pass.
 */
const NATIVE_GRADING_PROGRAM = `
import { readFileSync } from "node:fs";

const parser = Bun.XML;
if (parser === undefined || typeof parser.parse !== "function") {
  console.error("Bun.XML.parse is unavailable in this runtime");
  process.exit(3);
}

const UNSIGNED_INTEGER = /^[0-9]+$/;
const describeError = (error) =>
  error instanceof Error ? error.message : String(error);

const elementChildren = (node) =>
  node.children.filter(
    (child) =>
      typeof child === "object" &&
      child !== null &&
      typeof child.name === "string"
  );

const readCount = (attributes, name, where) => {
  const raw = attributes[name];
  if (typeof raw !== "string")
    throw new Error(where + ": missing " + name + " attribute");
  if (!UNSIGNED_INTEGER.test(raw))
    throw new Error(where + ": " + name + '="' + raw + '" is not a non-negative integer');
  const value = Number(raw);
  if (!Number.isSafeInteger(value))
    throw new Error(where + ": " + name + '="' + raw + '" is not a safe integer');
  return value;
};

const EXECUTION_ELEMENTS = ["testsuites", "testsuite", "testcase"];

// A testcase may hold reporter metadata as element children, but an execution
// element anywhere in its subtree is an unsupported position: the wrapper does
// not become a file suite or a case, and the hidden element must neither be
// counted nor ignored. The walk goes to any depth so a metadata wrapper
// (<failure>, <skipped>, ...) cannot hide one.
const assertTestcaseSubtree = (testcase, where) => {
  for (const child of elementChildren(testcase)) {
    if (EXECUTION_ELEMENTS.includes(child.name))
      throw new Error(
        where + ": unexpected <" + child.name + "> inside a <testcase> subtree"
      );
    assertTestcaseSubtree(child, where);
  }
};

const countTestcases = (suite, where) => {
  let cases = 0;
  for (const child of elementChildren(suite)) {
    if (child.name === "testcase") {
      assertTestcaseSubtree(child, where);
      cases += 1;
    } else if (child.name === "testsuite") {
      if (typeof child.attributes.line !== "string")
        throw new Error(where + ": nested <testsuite> without a line attribute");
      cases += countTestcases(child, where);
    } else {
      throw new Error(
        where + ": unexpected <" + child.name + "> inside a test suite"
      );
    }
  }
  return cases;
};

const extract = (root) => {
  if (root.name !== "testsuites")
    throw new Error("root element is <" + root.name + ">, expected <testsuites>");
  const files = [];
  for (const child of elementChildren(root)) {
    if (child.name !== "testsuite")
      throw new Error("unexpected <" + child.name + "> under <testsuites>");
    if (typeof child.attributes.line === "string")
      throw new Error("nested <testsuite> directly under <testsuites>");
    const file = child.attributes.file;
    if (typeof file !== "string" || file.trim() === "")
      throw new Error("outer suite without a usable file attribute");
    files.push({
      file,
      tests: readCount(child.attributes, "tests", file),
      failures: readCount(child.attributes, "failures", file),
      skipped: readCount(child.attributes, "skipped", file),
      cases: countTestcases(child, file),
    });
  }
  return {
    root: {
      tests: readCount(root.attributes, "tests", "root"),
      failures: readCount(root.attributes, "failures", "root"),
      skipped: readCount(root.attributes, "skipped", "root"),
    },
    files,
  };
};

const gradeReport = (path) => {
  let text;
  try {
    text = readFileSync(path, "utf8");
  } catch (error) {
    return { path, ok: false, kind: "read", error: describeError(error) };
  }
  let root;
  try {
    root = parser.parse(text, { compact: false });
  } catch (error) {
    return { path, ok: false, kind: "parse", error: describeError(error) };
  }
  try {
    return { path, ok: true, report: extract(root) };
  } catch (error) {
    return { path, ok: false, kind: "shape", error: describeError(error) };
  }
};

const reports = process.argv.slice(1).map(gradeReport);
process.stdout.write(JSON.stringify({ count: reports.length, reports }));
`;

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

/** Narrow one non-negative count out of a native grading record. */
const nativeCount = (value: unknown, where: string, name: string): number => {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0) {
    throw new ReplayInputError(
      `${where}: native grading record has an unusable ${name}`
    );
  }
  return value;
};

/** Narrow one non-empty string out of a native grading record. */
const nativeString = (value: unknown, where: string, name: string): string => {
  if (typeof value !== "string" || value === "") {
    throw new ReplayInputError(
      `${where}: native grading record has an unusable ${name}`
    );
  }
  return value;
};

const narrowFile = (value: unknown, where: string): NativeFileGrading => {
  if (!isRecord(value)) {
    throw new ReplayInputError(
      `${where}: native grading record has an unusable file entry`
    );
  }
  return {
    file: nativeString(value.file, where, "file"),
    tests: nativeCount(value.tests, where, "tests"),
    failures: nativeCount(value.failures, where, "failures"),
    skipped: nativeCount(value.skipped, where, "skipped"),
    cases: nativeCount(value.cases, where, "cases"),
  };
};

const narrowReport = (value: unknown, where: string): NativeReportGrading => {
  if (!isRecord(value)) {
    throw new ReplayInputError(
      `${where}: native grading record has an unusable report`
    );
  }
  const root = value.root;
  if (!isRecord(root)) {
    throw new ReplayInputError(
      `${where}: native grading record has no root totals`
    );
  }
  const rawFiles = value.files;
  if (!Array.isArray(rawFiles)) {
    throw new ReplayInputError(
      `${where}: native grading record has no file list`
    );
  }
  const files: NativeFileGrading[] = [];
  for (const rawFile of rawFiles) files.push(narrowFile(rawFile, where));
  return {
    root: {
      tests: nativeCount(root.tests, where, "root tests"),
      failures: nativeCount(root.failures, where, "root failures"),
      skipped: nativeCount(root.skipped, where, "root skipped"),
    },
    files,
  };
};

const narrowRejection = (value: unknown, where: string): NativeRejection => {
  if (!isRecord(value)) {
    throw new ReplayInputError(
      `${where}: native grading record has an unusable rejection`
    );
  }
  return {
    kind: nativeString(value.kind, where, "kind"),
    message: nativeString(value.error, where, "error"),
  };
};

/** Narrow the helper's stdout into per-report grading data, or fail closed. */
const parseNativeOutput = (stdout: string): NativeGrading => {
  let parsed: unknown;
  try {
    parsed = JSON.parse(stdout);
  } catch {
    throw new ReplayInputError(
      `native XML grading did not return JSON: ${stdout.trim().slice(0, 200)}`
    );
  }
  if (!isRecord(parsed)) {
    throw new ReplayInputError("native XML grading returned a non-object");
  }
  const count = nativeCount(parsed.count, "native grading", "count");
  const rawReports = parsed.reports;
  if (!Array.isArray(rawReports)) {
    throw new ReplayInputError("native XML grading returned no report list");
  }
  if (rawReports.length !== count) {
    throw new ReplayInputError(
      `native XML grading sent ${rawReports.length} records but counted ${count}`
    );
  }
  const outcomes = new Map<string, NativeReportGrading>();
  const rejections = new Map<string, NativeRejection>();
  let outerSuites = 0;
  let testcaseElements = 0;
  for (const [index, rawReport] of rawReports.entries()) {
    const where = `native grading record ${index}`;
    if (!isRecord(rawReport)) {
      throw new ReplayInputError(`${where}: not an object`);
    }
    const path = nativeString(rawReport.path, where, "path");
    if (outcomes.has(path) || rejections.has(path)) {
      throw new ReplayInputError(`${where}: duplicate record for ${path}`);
    }
    if (rawReport.ok === true) {
      const report = narrowReport(rawReport.report, where);
      outcomes.set(path, report);
      outerSuites += report.files.length;
      for (const file of report.files) testcaseElements += file.cases;
    } else if (rawReport.ok === false) {
      rejections.set(path, narrowRejection(rawReport, where));
    } else {
      throw new ReplayInputError(`${where}: no ok flag`);
    }
  }
  return {
    outcomes,
    rejections,
    checked: rawReports.length,
    outerSuites,
    testcaseElements,
  };
};

/**
 * Parse every readable report once, in a single child process.
 *
 * The child is the pinned runtime itself (`process.execPath`), so both the
 * grading data and the well-formedness verdict come from the same XML processor
 * that produced the retained reports. A child that does not run, or that stops
 * before its completion record, is an unusable input: the grader fails closed.
 */
const runNativeGrading = (paths: readonly string[]): NativeGrading => {
  if (paths.length === 0) {
    return {
      outcomes: new Map(),
      rejections: new Map(),
      checked: 0,
      outerSuites: 0,
      testcaseElements: 0,
    };
  }
  const child = Bun.spawnSync({
    cmd: [process.execPath, "-e", NATIVE_GRADING_PROGRAM, ...paths],
    stdout: "pipe",
    stderr: "pipe",
  });
  const stdout = child.stdout.toString();
  const stderr = child.stderr.toString().trim();
  const exit = child.exitCode ?? -1;
  if (exit !== 0) {
    throw new ReplayInputError(
      `native XML grading failed (exit ${exit}): ${
        stderr === "" ? stdout.trim() : stderr
      }`
    );
  }
  return parseNativeOutput(stdout);
};

/**
 * Reduce one report's native grading record to outer file outcomes.
 *
 * Only outer file suites are file outcomes: the file-level `<testsuite>` has a
 * `file` attribute and no `line`, while nested `describe()` suites carry a
 * `line` attribute and are already counted inside their outer suite's `cases`.
 */
const gradedReport = (
  project: string,
  mode: string,
  path: string,
  grading: NativeGrading
): ParsedReport => {
  const where = `${project}/${mode}`;
  const rejection = grading.rejections.get(path);
  if (rejection !== undefined) {
    if (rejection.kind === "parse") {
      throw new ReplayInputError(
        `${where}: ${path} is not well-formed XML (Bun.XML.parse): ${rejection.message}`
      );
    }
    if (rejection.kind === "read") {
      throw new ReplayInputError(
        `${where}: ${path} could not be read: ${rejection.message}`
      );
    }
    throw new ReplayInputError(
      `${where}: ${path} is not an actual <testsuites> element tree: ${rejection.message}`
    );
  }
  const report = grading.outcomes.get(path);
  if (report === undefined) {
    throw new ReplayInputError(
      `${where}: native XML grading produced no record for ${path}`
    );
  }
  const files = new Map<string, FileOutcome>();
  let caseCount = 0;
  let sumTests = 0;
  let sumFailures = 0;
  let sumSkipped = 0;
  for (const file of report.files) {
    if (files.has(file.file)) {
      throw new ReplayInputError(
        `${where}: duplicate outer suite for file ${file.file}`
      );
    }
    if (file.cases !== file.tests) {
      throw new ReplayInputError(
        `${where}: ${file.file} declares tests="${file.tests}" but contains ` +
          `${file.cases} testcase elements`
      );
    }
    if (file.failures > file.tests || file.skipped > file.tests) {
      throw new ReplayInputError(
        `${where} ${file.file}: failures=${file.failures} skipped=${file.skipped} exceed tests=${file.tests}`
      );
    }
    files.set(file.file, {
      tests: file.tests,
      failures: file.failures,
      skipped: file.skipped,
    });
    caseCount += file.cases;
    sumTests += file.tests;
    sumFailures += file.failures;
    sumSkipped += file.skipped;
  }
  if (files.size === 0) {
    throw new ReplayInputError(
      `${where}: no outer file suites (empty coverage) in ${path}`
    );
  }
  if (
    sumTests !== report.root.tests ||
    sumFailures !== report.root.failures ||
    sumSkipped !== report.root.skipped
  ) {
    throw new ReplayInputError(
      `${where}: root totals tests=${report.root.tests} failures=${report.root.failures} skipped=${report.root.skipped} ` +
        `do not reconcile with outer suites tests=${sumTests} failures=${sumFailures} skipped=${sumSkipped}`
    );
  }
  return { files, caseCount };
};

interface Options {
  readonly ordinaryDir: string;
  readonly isolateDir: string;
  readonly projectsPath: string;
  readonly ordinaryPattern: string;
  readonly isolatePattern: string;
  readonly expectProjects: number;
  readonly expectFiles: number;
  readonly expectCases: number;
  readonly jsonPath: string | null;
}

const parseOptions = (argv: readonly string[]): Options => {
  const values = new Map<string, string>();
  const flags = new Set([
    "--ordinary",
    "--isolate",
    "--projects",
    "--ordinary-pattern",
    "--isolate-pattern",
    "--expect-projects",
    "--expect-files",
    "--expect-cases",
    "--json",
  ]);
  for (let index = 0; index < argv.length; index += 1) {
    const flag = argv[index];
    if (flag === undefined) continue;
    if (!flags.has(flag)) throw new UsageError(`unknown argument ${flag}`);
    const value = argv[index + 1];
    if (value === undefined) throw new UsageError(`${flag} needs a value`);
    values.set(flag, value);
    index += 1;
  }

  const required = (flag: string): string => {
    const value = values.get(flag);
    if (value === undefined) throw new UsageError(`${flag} is required`);
    return value;
  };
  const integer = (flag: string, fallback: number): number => {
    const raw = values.get(flag);
    if (raw === undefined) return fallback;
    if (!INTEGER.test(raw))
      throw new UsageError(`${flag} needs a non-negative integer`);
    return Number(raw);
  };

  return {
    ordinaryDir: required("--ordinary"),
    isolateDir: required("--isolate"),
    projectsPath: required("--projects"),
    ordinaryPattern: values.get("--ordinary-pattern") ?? "{project}.junit.xml",
    isolatePattern: values.get("--isolate-pattern") ?? "{project}.junit.xml",
    expectProjects: integer("--expect-projects", DEFAULT_EXPECT_PROJECTS),
    expectFiles: integer("--expect-files", DEFAULT_EXPECT_FILES),
    expectCases: integer("--expect-cases", DEFAULT_EXPECT_CASES),
    jsonPath: values.get("--json") ?? null,
  };
};

interface Project {
  readonly name: string;
  readonly cwd: string;
}

const readProjects = (path: string): Project[] => {
  if (!existsSync(path))
    throw new ReplayInputError(`projects file not found: ${path}`);
  const text = readFileSync(path, "utf8");
  const projects: Project[] = [];
  const seen = new Set<string>();
  for (const rawLine of text.split("\n")) {
    const line = rawLine.replace(/\r$/u, "");
    if (line.trim() === "") continue;
    const [name, cwd] = line.split("\t");
    if (name === undefined || cwd === undefined || name === "" || cwd === "") {
      throw new ReplayInputError(
        `projects file ${path}: unusable row "${line}"`
      );
    }
    if (seen.has(name))
      throw new ReplayInputError(
        `projects file ${path}: duplicate project ${name}`
      );
    seen.add(name);
    projects.push({ name, cwd });
  }
  if (projects.length === 0)
    throw new ReplayInputError(`projects file ${path} lists no projects`);
  return projects;
};

const reportPath = (
  dir: string,
  pattern: string,
  project: Project
): string => join(dir, pattern.replace("{project}", project.name));

const readReport = (
  dir: string,
  pattern: string,
  project: Project,
  mode: string,
  grading: NativeGrading
): ParsedReport => {
  const path = reportPath(dir, pattern, project);
  if (!existsSync(path))
    throw new ReplayInputError(
      `${project.name}/${mode}: missing report ${path}`
    );
  const stats = statSync(path);
  if (!stats.isFile() || stats.size === 0) {
    throw new ReplayInputError(`${project.name}/${mode}: empty report ${path}`);
  }
  return gradedReport(project.name, mode, path, grading);
};

const describeOutcome = (outcome: FileOutcome): string =>
  `tests:${outcome.tests},failures:${outcome.failures},skipped:${outcome.skipped}`;

const outcomeDiffers = (left: FileOutcome, right: FileOutcome): boolean =>
  left.tests !== right.tests ||
  left.failures !== right.failures ||
  left.skipped !== right.skipped;

const main = (argv: readonly string[]): number => {
  const options = parseOptions(argv);
  const projects = readProjects(options.projectsPath);

  const reportPaths: string[] = [];
  for (const project of projects) {
    const ordinary = reportPath(
      options.ordinaryDir,
      options.ordinaryPattern,
      project
    );
    if (existsSync(ordinary)) reportPaths.push(ordinary);
    const isolate = reportPath(
      options.isolateDir,
      options.isolatePattern,
      project
    );
    if (existsSync(isolate)) reportPaths.push(isolate);
  }
  const grading = runNativeGrading(reportPaths);
  const wellFormednessFailures = [...grading.rejections.values()].filter(
    (rejection) => rejection.kind === "parse"
  ).length;

  const problems: string[] = [];
  const projectLines: string[] = [];
  const ordinaryFiles = new Map<string, FileOutcome>();
  const isolateFiles = new Map<string, FileOutcome>();
  let ordinaryCases = 0;
  let isolateCases = 0;
  let divergingProjects = 0;

  for (const project of projects) {
    let ordinary: ParsedReport;
    let isolate: ParsedReport;
    try {
      ordinary = readReport(
        options.ordinaryDir,
        options.ordinaryPattern,
        project,
        "ordinary",
        grading
      );
    } catch (error: unknown) {
      problems.push(
        `${project.name}: ${error instanceof Error ? error.message : String(error)}`
      );
      continue;
    }
    try {
      isolate = readReport(
        options.isolateDir,
        options.isolatePattern,
        project,
        "isolate",
        grading
      );
    } catch (error: unknown) {
      problems.push(
        `${project.name}: ${error instanceof Error ? error.message : String(error)}`
      );
      continue;
    }

    const key = (file: string): string => `${project.cwd}/${file}`;
    const names = [
      ...new Set([...ordinary.files.keys(), ...isolate.files.keys()]),
    ].sort();
    const details: string[] = [];

    for (const name of names) {
      const ordinaryOutcome = ordinary.files.get(name);
      const isolateOutcome = isolate.files.get(name);
      if (ordinaryOutcome === undefined || isolateOutcome === undefined) {
        if (ordinaryOutcome === undefined)
          details.push(`  only-in-isolate: ${name}`);
        if (isolateOutcome === undefined)
          details.push(`  only-in-ordinary: ${name}`);
        continue;
      }
      // Both modes executed the file, so it counts towards the graded file set
      // even when its outcome differs; only a missing file is ungraded.
      ordinaryFiles.set(key(name), ordinaryOutcome);
      isolateFiles.set(key(name), isolateOutcome);
      if (outcomeDiffers(ordinaryOutcome, isolateOutcome)) {
        details.push(
          `  outcome-mismatch: ${name} ordinary={${describeOutcome(ordinaryOutcome)}} ` +
            `isolate={${describeOutcome(isolateOutcome)}}`
        );
      }
    }

    ordinaryCases += ordinary.caseCount;
    isolateCases += isolate.caseCount;

    if (details.length === 0) {
      projectLines.push(
        `== ${project.name}: identical (${ordinary.files.size} files) ==`
      );
    } else {
      divergingProjects += 1;
      projectLines.push(`== ${project.name}: DIFFERS ==`);
      projectLines.push(...details);
      problems.push(
        `${project.name}: ${details.length} per-file difference(s)`
      );
    }
  }

  const inventory: string[] = [];
  if (projects.length !== options.expectProjects) {
    inventory.push(
      `expected ${options.expectProjects} projects, found ${projects.length}`
    );
  }
  if (ordinaryFiles.size !== options.expectFiles) {
    inventory.push(
      `expected ${options.expectFiles} ordinary files, found ${ordinaryFiles.size}`
    );
  }
  if (isolateFiles.size !== options.expectFiles) {
    inventory.push(
      `expected ${options.expectFiles} isolate files, found ${isolateFiles.size}`
    );
  }
  if (ordinaryCases !== options.expectCases) {
    inventory.push(
      `expected ${options.expectCases} ordinary cases, found ${ordinaryCases}`
    );
  }
  if (isolateCases !== options.expectCases) {
    inventory.push(
      `expected ${options.expectCases} isolate cases, found ${isolateCases}`
    );
  }
  if (ordinaryFiles.size !== isolateFiles.size) {
    inventory.push(
      `mode file sets differ: ordinary ${ordinaryFiles.size} vs isolate ${isolateFiles.size}`
    );
  }

  const lines = [
    ...projectLines,
    "",
    "=== aggregate ===",
    `projects: ${projects.length}`,
  ];
  lines.push(`distinct test files (ordinary): ${ordinaryFiles.size}`);
  lines.push(`distinct test files (isolate):  ${isolateFiles.size}`);
  lines.push(`test cases (ordinary): ${ordinaryCases}`);
  lines.push(`test cases (isolate):  ${isolateCases}`);
  lines.push(`projects with a per-file difference: ${divergingProjects}`);
  lines.push(
    `xml well-formedness (Bun.XML.parse): ${grading.checked} report(s) checked, ` +
      `${wellFormednessFailures} failure(s)`
  );
  lines.push(
    `native element grading (Bun.XML.parse {compact:false}): ${grading.outerSuites} outer file suite(s), ` +
      `${grading.testcaseElements} testcase element(s)`
  );

  const allProblems = [
    ...problems,
    ...inventory.map((line) => `inventory: ${line}`),
  ];
  if (allProblems.length === 0) {
    lines.push(
      "per-file grading: PASS (every project and file graded, both modes agree)"
    );
  } else {
    lines.push(`per-file grading: FAIL (${allProblems.length} problem(s))`);
    for (const problem of allProblems) lines.push(`  ${problem}`);
  }
  console.log(lines.join("\n"));

  const receipt = {
    ok: allProblems.length === 0,
    ordinaryDir: options.ordinaryDir,
    isolateDir: options.isolateDir,
    projectsPath: options.projectsPath,
    expected: {
      projects: options.expectProjects,
      files: options.expectFiles,
      cases: options.expectCases,
    },
    observed: {
      projects: projects.length,
      ordinaryFiles: ordinaryFiles.size,
      isolateFiles: isolateFiles.size,
      ordinaryCases,
      isolateCases,
      divergingProjects,
    },
    xmlWellFormedness: {
      parser: "Bun.XML.parse",
      runtime: Bun.version,
      checked: grading.checked,
      failures: wellFormednessFailures,
    },
    nativeElementGrading: {
      shape: "Bun.XML.parse(..., { compact: false }) element tree",
      outerSuites: grading.outerSuites,
      testcaseElements: grading.testcaseElements,
    },
    problems: allProblems,
  };
  if (options.jsonPath !== null) {
    writeFileSync(options.jsonPath, `${JSON.stringify(receipt, null, 2)}\n`);
  }

  return allProblems.length === 0 ? 0 : 1;
};

try {
  process.exitCode = main(process.argv.slice(2));
} catch (error: unknown) {
  if (error instanceof UsageError) {
    console.error(`usage error: ${error.message}`);
    process.exitCode = 2;
  } else if (error instanceof ReplayInputError) {
    console.error(`input error: ${error.message}`);
    process.exitCode = 1;
  } else {
    throw error;
  }
}
