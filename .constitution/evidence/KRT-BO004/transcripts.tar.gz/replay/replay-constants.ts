/**
 * Fixed project and file constants shared by the replay control harness and its
 * fixture-mutation helpers. Values are the recorded ones from the retained
 * corpus and must not change.
 */

/** Project/TSV file name for the retained `bun test` project inventory. */
export const PROJECTS_TSV = "bun-test-projects.tsv";

/** Project and file pair used for the equal-and-opposite swap: 2 and 1 cases. */
export const SWAP_PROJECT = "providers-testkit";
export const SWAP_FILE_FROM = "test/provider-testkit.test.ts";
export const SWAP_FILE_TO = "test/provider-conformance.test.ts";

/**
 * Real project whose retained report holds a single file, used as a whole
 * one-file corpus so a structural mutation can be isolated to one report.
 */
export const ONE_FILE_PROJECT = "telemetry-semconv";
