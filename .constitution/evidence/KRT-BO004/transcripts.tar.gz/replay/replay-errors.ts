/**
 * Error type shared by the replay control harness and its helper modules.
 *
 * A thrown `ControlError` means the harness or one of its helpers detected an
 * unusable input or an inconsistent mutation, which fails the run closed.
 */
export class ControlError extends Error {}
