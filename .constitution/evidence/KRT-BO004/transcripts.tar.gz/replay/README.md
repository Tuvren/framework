# KRT-BO004 corrected per-file JUnit replay

Additive correction for the archived probe `probe__compare-matrix-junit.ts`.
Nothing in the retained archive is modified or replaced: the extraction root was
re-verified byte-identical after this work (see *Corpus provenance* below).

## Defect being corrected

The retained probe already computed complete outer-file JUnit outcomes and
printed `DIFFERS` for a differing file, but it never set a failing exit status,
so `bun probe__compare-matrix-junit.ts` exited 0 whether or not it found a
difference. Its companion `assert-observations.mjs` graded only project-level
totals (`results-<mode>.tsv`). An equal-and-opposite per-file change therefore
passed both tools: move one test case from one file to another inside the same
project and 29 projects / 179 files / 1596 cases still agree.

Both retained tools stay exactly as archived. The corrected grader
`compare-matrix-junit-replay.ts` exits 1 for any missing project or file, any
malformed report, any invalid count and any per-file mismatch of tests, failures
or skipped, and it takes its corpus from the command line instead of the
recorded scratch constant `W`.

The first corrected version of that grader was itself incomplete, and review
found it: it read open tags and compared counts, so a report that kept every
counter and every testcase but lost its closing `</testsuite>` and
`</testsuites>` tags still graded as PASS. Structural validation now uses the
pinned runtime's own XML processor (see *XML well-formedness validation*
below), and five controls pin the closing-tag and no-false-positive cases.
`receipts/lead-finding-repro.log` shows the reported fixture grading as PASS on
the first corrected grader and FAIL on the current one.

A second review found the remaining half of the same premise: structural
validation was still a separate pass, and grading still counted raw `<testcase`
literals in the report text. A report that kept every counter but moved its only
test case into an XML comment — or hid a whole valid JUnit document in a comment
under an empty root — still graded as PASS. Grading now runs on the same parsed
element tree as the well-formedness verdict (see *Grading from the parsed
element tree* below), and six more controls pin the comment, CDATA and
unexpected-hierarchy cases.

## Tool mapping

| Retained member | Original recorded path |
| :--- | :--- |
| `probe__compare-matrix-junit.ts` | `<root>/scratch/compare-matrix-junit.ts` |
| `lead-raw__matrix__<mode>__<project>.junit.xml` | `<root>/raw/matrix/<mode>/<project>.junit.xml` |
| `lead-raw__bun-test-projects.tsv` | `<root>/raw/bun-test-projects.tsv` |
| `assert-observations.mjs` | `<root>/assert-observations.mjs` |

## Bun 1.4.2 JUnit shape

Taken from the pinned binary and the retained reports, not assumed. The
file-level `<testsuite>` carries `file` and no `line`; nested `describe()` suites
repeat `file` with `line` and count a subset of the outer suite, so they grade
inside their outer file suite rather than as extra file outcomes. Summing the
outer suites reproduces the root totals exactly and each
outer suite's `tests` equals its own `<testcase>` count. All 58 retained reports
and all 358 retained outer suites satisfy both properties, and
`replay__bun-junit-shape-probe__run.sh` reproduces the shape on the installed
binary (nested describe, skipped case, failing case).

## XML well-formedness validation

Counting open tags is not well-formedness. The first corrected grader compared
outer-suite counters and `<testcase>` counts, so a report that kept every
counter and every testcase but dropped its closing tags graded as PASS: the
scanner read the outer suite it could see, and the closing structure never
entered the comparison. `receipts/lead-finding-repro.log` records the reported
fixture (a valid one-test ordinary report and an isolate report truncated after
its valid content) grading as PASS before this change and FAIL after it.

Every report is now validated with the pinned runtime's own XML processor.

| Question | Measured answer |
| :--- | :--- |
| Is the API present on the pinned binary? | Yes. `bun --version` is 1.4.2 and `typeof Bun.XML.parse` is `function` (`receipts/xml-api-verification.log`) |
| What is the documented contract? | `bun-types@1.4.2` declares `Bun.XML.parse(input, options?)` and states it is "a conforming, non-validating XML processor" whose document "must be well-formed or a `SyntaxError` is thrown; there is no lenient mode" |
| Why not call it in-process? | The repository pins `@types/bun@1.3.14`, which predates the API: `tsc` reports `probe-xml-types.ts(1,17): error TS2339: Property 'XML' does not exist on type 'typeof import("bun")'` (exit 2) |
| How is it invoked? | One inline ESM program per run, spawned through `process.execPath` — the same pinned binary — with every report path as an argument. The child parses each report with `{ compact: false }` and prints canonical grading data as JSON: root totals and one record per outer file suite (`file`, `tests`, `failures`, `skipped`, and the actual `cases` element count), or a `{kind, error}` record for a report it rejects |
| What happens when the child cannot run? | The run fails closed. A nonzero child exit, or a record the parent cannot narrow, is an unusable input and the grader exits 1. Measured under Bun 1.3.13, which has no `Bun.XML`: the child exits 3 and the grader exits 1 with `native XML grading failed (exit 3): Bun.XML.parse is unavailable in this runtime` (`receipts/xml-parser-unavailable.log`) |

Measured parser behavior, all of it receipted by a control or the positive run:

| Document | `Bun.XML.parse` | Evidence |
| :--- | :--- | :--- |
| All 58 retained reports | accepted, 0 failures | `receipts/positive.log` |
| One-test report, both modes intact | accepted | `new-one-file-report-pristine` |
| Same report without `</testsuite></testsuites>` | `XML Parse error: Missing closing tag for element 'testsuite'` | `new-one-file-report-truncated`, `new-structural-truncated` |
| Same report with `</testsuite>` renamed to `</testsuit>` | `XML Parse error: Expected closing tag </testsuite> but found </testsuit>` | `new-mismatched-closing-tag` |
| XML comment inside the root | accepted | `new-one-file-report-comment` |
| Escaped text in attributes (`classname="nested &gt; outer"`) | accepted | the retained corpus (six ordinary reports carry `&gt;`) |

What the well-formedness change adds is one stdout line and one receipt field —
`xml well-formedness (Bun.XML.parse): 58 report(s) checked, 0 failure(s)` and
`xmlWellFormedness: {parser, runtime, checked, failures}`. The element-tree
grading change adds a second stdout line and receipt field (see below). No
counter, threshold, corpus, project list or testcase grading rule changes, and a
rejected report fails the run instead of being graded.

## Grading from the parsed element tree

Counting raw `<testcase` literals is not grading. The round-one grader validated
well-formedness with `Bun.XML.parse` but threw the tree away and then counted
`<testcase ` occurrences in the report text. The round-two reviewer proved the
gap: taking the full 29-project corpus and wrapping the one retained
`isolate/telemetry-semconv.junit.xml` testcase in an XML comment left every
counter and every tag literal intact, so the text scanner still counted it and
the run exited 0 with `per-file grading: PASS` even though the report no longer
held a single testcase element. `receipts/round2-controls-on-previous-checker.log`
replays the round-two controls against the preserved pre-round-two grader and
records that verdict.

Grading data now comes from the same parse tree that validates the report. The
grader calls `Bun.XML.parse(<report>, { compact: false })`, which returns the
root element as `{ name, attributes, children }`; comments and processing
instructions are objects in `children` that carry no `name`, and CDATA sections
and escaped text arrive as plain strings. Every count is taken from real
element nodes:

- the root must be an actual `<testsuites>` element, or the report is rejected
  (`root element is <X>, expected <testsuites>`);
- each element child of the root must be an actual outer `<testsuite file="..">`
  element with no `line` attribute, or the report is rejected
  (`unexpected <X> under <testsuites>`);
- inside a file suite, only `<testcase>` and nested `<testsuite line="..">`
  elements are accepted; a nested suite without `line`, or any other element,
  is rejected;
- a file suite's declared `tests` must equal the number of actual `<testcase>`
  element descendants, including those inside nested describe suites;
- the outer suites' totals must still reconcile with the root totals.

Text, CDATA, comments and processing instructions hold no elements, so the same
tag literals in commented-out or CDATA content cannot inflate a grade, and real
tag literals beside a testcase cannot cause a false failure. The parent narrows
the helper's JSON as `unknown` and never reads report text, so no regex or
`countOccurrences` call derives a grade after parsing.

`receipts/native-element-grading.log` records the actual tree the pinned runtime
returns (root, outer suite, and a synthetic document whose comment, CDATA and
processing instruction all sit in `children` without a `name`) and the official
current reference at `https://bun.sh/reference/bun/XML/parse`, whose
`{ compact: false }` overload returns `Node` with
`children: Array<string | Node | Comment | ProcessingInstruction>`.

The parent still fails closed: a child that does not run, exits nonzero, or
returns a record it cannot narrow is an unusable input, and the run exits 1.

## Exact commands and results

Run from the fix directory, with `REPLAY` the directory holding these files and
`SOURCE` the pristine extraction root.

```sh
# 1. Byte-verified replay corpus from the retained members (exit 0)
bun $REPLAY/build-replay-corpus.ts --source $SOURCE --out $REPLAY/corpus \
  --index <repo>/.constitution/evidence/KRT-BO004/transcript-index.json \
  --receipt $REPLAY/receipts/corpus-digests.json
# -> {"ok":true,"projects":29,"copies":58,"failures":[]}

# 2. The corrected grader over all 29 projects in both modes (exit 0)
bun $REPLAY/compare-matrix-junit-replay.ts --ordinary $REPLAY/corpus/ordinary \
  --isolate $REPLAY/corpus/isolate --projects $REPLAY/corpus/bun-test-projects.tsv \
  --json $REPLAY/receipts/positive.json
# -> projects: 29 / distinct test files (ordinary): 179 / (isolate): 179
#    test cases (ordinary): 1596 / (isolate): 1596
#    projects with a per-file difference: 0
#    xml well-formedness (Bun.XML.parse): 58 report(s) checked, 0 failure(s)
#    native element grading (Bun.XML.parse {compact:false}): 358 outer file suite(s), 3192 testcase element(s)
#    per-file grading: PASS (every project and file graded, both modes agree)

# 3. Every positive and negative control (exit 0)
bun $REPLAY/run-replay-controls.ts --work $REPLAY --source $SOURCE
# -> 27 controls, "failed": [], including the five structural and six
#    element-tree controls

# 4. Reporter-shape probe on the installed binary (exit 0)
bash $REPLAY/bun-junit-shape-probe/run.sh

# 5. Strict typecheck of the three replay tools (exit 0; the typeRoots entry is an
#    absolute recorded path to the repository's node_modules/@types)
<repo>/node_modules/.bin/tsc -p $REPLAY/tsconfig.typecheck.json

# 6. The reported structural fixture, before and after (exit 0 then exit 1)
bun <lead replay>/compare-matrix-junit-replay.ts --ordinary <lead fixture>/ordinary \
  --isolate <lead fixture>/isolate --projects <lead fixture>/projects.tsv \
  --expect-projects 1 --expect-files 1 --expect-cases 1
bun $REPLAY/compare-matrix-junit-replay.ts --ordinary <lead fixture>/ordinary \
  --isolate <lead fixture>/isolate --projects <lead fixture>/projects.tsv \
  --expect-projects 1 --expect-files 1 --expect-cases 1
# -> receipts/lead-finding-repro.log

# 7. The round-two controls against the preserved pre-round-two grader (exit 0).
#    Each element-tree negative still grades PASS on the raw-tag scanner.
# -> receipts/round2-controls-on-previous-checker.log
```

Receipts: `receipts/positive.log` and `receipts/positive.json` (command 2),
`receipts/<control>.log` and `receipts/control-matrix.json` (command 3),
`receipts/corpus-digests.json` (command 1, per-copy source/destination/counted
digests), `receipts/bun-junit-shape.log` (command 4), `receipts/typecheck.log`
(command 5), `receipts/lead-finding-repro.log` (command 6),
`receipts/native-element-grading.log` (the actual `{ compact: false }` tree, the
commented/CDATA/processing-instruction children, and the official reference),
`receipts/round2-controls-on-previous-checker.log` (command 7),
`receipts/round2-reviewer-repro.log` (the reviewer's own `comment-corpus/` and
`comment-fixture/` directories under the current grader), and
`receipts/round2-final-verification.log` (the round-two command ladder with
exits), `receipts/xml-api-verification.log` (the native-parser presence,
declaration and `TS2339` measurements) and `receipts/xml-parser-unavailable.log`
(the fail-closed path on a runtime without the API). `receipts/round1/` holds the
22 receipts of the first corrected run verbatim,
`receipts/preserved-round2/` holds the 32 receipts and three sources of the
second run verbatim, and `receipts/preserved-control-split/` holds the pre-split
`run-replay-controls.ts`, this README and the affected receipts — the superseded
evidence of each earlier round, kept so every round stays auditable. The control
harness is a thin orchestrator over `replay-xml.ts`, `replay-mutations.ts`,
`replay-scaffold.ts`, `replay-constants.ts` and `replay-errors.ts`; the
2026-09-30 split changed no control, expectation or receipt, and
`receipts/control-split-verification.log` records the split inventory, typecheck
and 27-control run.

## Control matrix

| Control | Mutation | Grader exit | Expected |
| :--- | :--- | ---: | ---: |
| `new-pristine` | none | 0 | 0 |
| `new-swap` | one case moved between two files of `providers-testkit` (2/1 -> 1/2) | 1 | 1 |
| `new-failure-mismatch` | one file `failures` 0 -> 1, root kept consistent | 1 | 1 |
| `new-skipped-mismatch` | one file `skipped` 0 -> 1, root kept consistent | 1 | 1 |
| `new-file-renamed-in-isolate` | one isolate `file` renamed (file disappears from ordinary) | 1 | 1 |
| `new-malformed-xml` | report truncated | 1 | 1 |
| `new-invalid-count` | one file `tests="abc"` | 1 | 1 |
| `new-unreconciled-root` | root `tests` 7 -> 8 | 1 | 1 |
| `new-empty-coverage` | one report reduced to an empty root | 1 | 1 |
| `new-missing-file` | one report removed | 1 | 1 |
| `new-structural-truncated` | one report loses its outer `</testsuite>` and root `</testsuites>` after 7 valid testcases; every counter unchanged | 1 | 1 |
| `new-mismatched-closing-tag` | one report's outer `</testsuite>` renamed to `</testsuit>`; every counter unchanged | 1 | 1 |
| `new-one-file-report-pristine` | one real retained report per mode, no structural change | 0 | 0 |
| `new-one-file-report-truncated` | same one-file corpus, isolate report loses `</testsuite></testsuites>` after its valid content | 1 | 1 |
| `new-one-file-report-comment` | same one-file corpus with one XML comment inserted inside the root | 0 | 0 |
| `new-commented-testcase-corpus` | full corpus; `isolate/telemetry-semconv.junit.xml`'s first self-closing testcase wrapped in an XML comment, every counter and tag literal unchanged | 1 | 1 |
| `new-comment-whole-junit-under-empty-root` | one-file corpus; isolate report replaced by `<empty><!-- <whole valid JUnit> --></empty>` | 1 | 1 |
| `new-cdata-fake-testcase` | one-file corpus; a CDATA section holding a fake `<testcase .../>` added to both modes, declared and root `tests` raised to keep raw counting self-consistent | 1 | 1 |
| `new-nested-unexpected-root` | one-file corpus; the `<testsuites>` element wrapped in `<document>` | 1 | 1 |
| `new-nested-unexpected-suite` | one-file corpus; the outer file `<testsuite>` wrapped in `<wrapper>` under the root | 1 | 1 |
| `new-fake-tag-literals-beside-testcase` | one-file corpus; fake `<testcase>`/`<testsuite>` literals added as a root comment and as escaped text beside the real testcase | 0 | 0 |
| `new-missing-input-root` | `--ordinary` points at an absent directory | 1 | 1 |
| `new-usage-error` | unknown flag | 2 | 2 |
| `historical-pristine` | archived probe on the pristine layout | 0 | 0 |
| `historical-swap` | archived probe on the swapped layout | 0 | 0 (defect) |
| `historical-assert-observations-pristine` | `assert-observations.mjs` on the pristine tree | 0 | 0 |
| `historical-assert-observations-swap` | `assert-observations.mjs` on the swapped tree | 0 | 0 (blind spot) |

The `new-swap` receipt shows the per-file detail while both modes keep 29
projects, 179 files and 1596 cases:

```text
== providers-testkit: DIFFERS ==
  outcome-mismatch: test/provider-conformance.test.ts ordinary={tests:2,...} isolate={tests:1,...}
  outcome-mismatch: test/provider-testkit.test.ts ordinary={tests:1,...} isolate={tests:2,...}
```

The two structural controls are the ones the counter-based grader missed. Both
mutate only the closing structure of one report, so their receipts still print
`projects with a per-file difference: 0` and exit 1 only because of the XML
processor:

```text
  providers-testkit: providers-testkit/ordinary: .../providers-testkit.junit.xml is not
    well-formed XML (Bun.XML.parse): XML Parse error: Missing closing tag for element 'testsuite'
  providers-testkit: providers-testkit/ordinary: .../providers-testkit.junit.xml is not
    well-formed XML (Bun.XML.parse): XML Parse error: Expected closing tag </testsuite> but found </testsuit>
```

The harness asserts both messages and asserts that the per-file comparison still
reports zero differing projects, so neither control can pass for an unrelated
reason. The `new-one-file-report-truncated` control is the reported fixture
exactly: one real report per mode, and only the isolate report loses its closing
tags after valid content.

The six element-tree controls are the ones the raw-tag scanner missed, and
`receipts/round2-controls-on-previous-checker.log` replays each one against the
preserved pre-round-two grader to show that verdict. Five negatives still grade
PASS there because the tag literals survive in text, and the positive grades FAIL
there because the scanner counts the fake literals:

| Control | Pre-round-two grader | Current grader |
| :--- | ---: | ---: |
| `new-commented-testcase-corpus` | 0 | 1 |
| `new-comment-whole-junit-under-empty-root` | 0 | 1 |
| `new-cdata-fake-testcase` | 0 | 1 |
| `new-nested-unexpected-root` | 0 | 1 |
| `new-nested-unexpected-suite` | 0 | 1 |
| `new-fake-tag-literals-beside-testcase` | 1 | 0 |

The commented-testcase control is the round-two reviewer reproducer exactly: the
full 29-project corpus with one retained `isolate/telemetry-semconv.junit.xml`
testcase wrapped in a comment. Its current receipt shows the declared/actual
mismatch while every counter stays as reported:

```text
  telemetry-semconv: telemetry-semconv/isolate: test/tuvren-runtime-telemetry.test.ts
    declares tests="1" but contains 0 testcase elements
```

The archived probe run against the identical swapped corpus prints the same
differing project and its aggregate line `projects with any per-file difference:
1`, then exits 0, which is the retained defect. The archived probe is run from a
relocated copy whose only changed line is its scratch constant; the harness
asserts that exactly one line differs and the line count is unchanged.

## Corpus provenance

`build-replay-corpus.ts --index ...` re-derives each copied member's SHA-256 and
byte count from `transcript-index.json` and compares them with both the extracted
member and the copy. Separately, extracting `transcripts.tar.gz` into a fresh
directory and running `diff -r` against the extraction root reported no
difference, and a per-member `sha256sum` comparison matched all 237 members.

## Regenerable directories (do not package as authority)

`corpus/`, `controls/` (including `controls/one-file-report-<name>/` and the
round-two fixtures), `scaffold/`, `raw-scaffold/`, `raw-scaffold-swap/`,
`historical-relocated/` and `bun-junit-shape-probe/work/` are all rebuilt by the
two commands above. `controls/` holds deliberately corrupted copies used only as
control inputs, and `historical-relocated/` holds a one-line-relocated copy of an
archived member; neither is a new authority. `verify-extract/` (if present) is
a throwaway re-extraction used for the integrity check and can be deleted.

## Additive packaging proposal

The lead owns packaging. Suggested additive member names, none of which collide
with an existing member:

```text
replay__README.md
replay__compare-matrix-junit-replay.ts
replay__build-replay-corpus.ts
replay__run-replay-controls.ts
replay__replay-constants.ts
replay__replay-errors.ts
replay__replay-mutations.ts
replay__replay-scaffold.ts
replay__replay-xml.ts
replay__bun-junit-shape-probe__run.sh
lead-replay__receipts__corpus-digests.json
lead-replay__receipts__positive.log
lead-replay__receipts__positive.json
lead-replay__receipts__control-matrix.json
lead-replay__receipts__control-split-verification.log
lead-replay__receipts__typecheck.log
lead-replay__receipts__lead-finding-repro.log
lead-replay__receipts__native-element-grading.log
lead-replay__receipts__round2-controls-on-previous-checker.log
lead-replay__receipts__round2-reviewer-repro.log
lead-replay__receipts__round2-final-verification.log
lead-replay__receipts__xml-api-verification.log
lead-replay__receipts__xml-parser-unavailable.log
lead-replay__receipts__<control>.log            (27 control logs)
lead-replay__receipts__bun-junit-shape.log
lead-replay__receipts__preserved-round2__<name>          (32 second-round receipts)
lead-replay__receipts__preserved-round2__sources__<name> (3 second-round sources)
lead-replay__receipts__preserved-control-split__<name>   (pre-split harness and receipts)
lead-replay__receipts__round1__<name>           (22 superseded round-one receipts)
```

`receipts/replay-artifacts.sha256.tsv` lists the SHA-256 and byte count of every
member above (`replay/` sources first, then the current receipts, then the
preserved second-round receipts and sources, then the preserved pre-split
harness and receipts, then the round-one receipts).

The relocated historical copy under `historical-relocated/` is a control input,
not a new authority; it differs from the retained member by one line and can be
regenerated by `run-replay-controls.ts`. All recorded absolute paths remain
recorded facts under the existing convention.

## EPIC prose proposal

The round-one closeout correction already says the corrected replay grader
"grades every one of the 179 files in both modes and exits nonzero on any
per-file disagreement". That statement stays accurate, so no new EPIC statement
is required; the element-tree premise is a correctness detail of this grader,
not a change to the graded inventory or the pass criteria.
