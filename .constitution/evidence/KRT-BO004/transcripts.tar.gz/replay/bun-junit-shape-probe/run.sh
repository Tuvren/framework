#!/usr/bin/env bash
# Prove the Bun 1.4.2 JUnit report shape the replay grader keys on, using the
# installed binary rather than an assumed protocol: the file-level <testsuite>
# has `file` and no `line`, nested describe() suites repeat `file` with `line`,
# the root totals equal the sum of the outer file suites, and a testcase's only
# element children are the measured reporter metadata (`<skipped/>`,
# `<failure>`). The last report decides which element names the hierarchy check
# must keep accepting inside a testcase.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$HERE/work"
rm -rf "$WORK"
mkdir -p "$WORK"
cd "$WORK"

cat >nested.test.ts <<'TS'
import { describe, expect, test } from "bun:test";
describe("outer", () => {
  test("ok", () => {
    expect(1).toBe(1);
  });
  test.skip("skipped one", () => {});
  describe("inner", () => {
    test("nested ok", () => {
      expect(2).toBe(2);
    });
  });
});
TS

cat >plain.test.ts <<'TS'
import { test } from "bun:test";
test("plain", () => {});
TS

cat >failing.test.ts <<'TS'
import { expect, test } from "bun:test";
test("fails", () => {
  expect(1).toBe(2);
});
TS

bun --version
bun test nested.test.ts plain.test.ts --reporter=junit --reporter-outfile=./pass.junit.xml
echo "pass exit=$?"
cat ./pass.junit.xml

set +e
bun test failing.test.ts --reporter=junit --reporter-outfile=./fail.junit.xml
echo "fail exit=$?"
cat ./fail.junit.xml

# Testcase metadata: a skipped case and a failing case are the only measured
# ways a Bun 1.4.2 report puts element children inside a <testcase>.
cat >metadata.test.ts <<'TS'
import { expect, test } from "bun:test";
test("passes", () => {
  expect(1).toBe(1);
});
test.skip("skipped one", () => {});
test("assertion failure", () => {
  expect(1).toBe(2);
});
test("thrown error", () => {
  throw new Error("boom");
});
TS
timeout 120 bun test metadata.test.ts --reporter=junit --reporter-outfile=./metadata.junit.xml
echo "metadata exit=$?"
cat ./metadata.junit.xml
echo "element names in the metadata report: $(grep -oE '<[a-z-]+' metadata.junit.xml | sort -u | tr '\n' ' ')"
