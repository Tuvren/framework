#!/usr/bin/env bun
/**
 * Rebuild a disposable replay corpus from the retained KRT-BO004 archive
 * members, without touching them.
 *
 * The retained members are extracted flat (`lead-raw__matrix__ordinary__<project>.junit.xml`).
 * This tool copies the 29 ordinary reports, the 29 isolated reports and the
 * project/cwd TSV into the plain `<dir>/<project>.junit.xml` layout that the
 * replay grader expects, and records the source and destination SHA-256 and
 * byte count for every copy. Nothing is written back into the extraction root.
 *
 * With `--index <transcript-index.json>` the tool additionally proves that each
 * source member still matches the digest pinned by the archived index, so a
 * replay cannot silently grade a mutated copy.
 *
 * Usage:
 *   bun build-replay-corpus.ts --source <extraction-root> --out <corpus-dir> \
 *     [--index <transcript-index.json>] [--receipt <path>]
 */
import {
  copyFileSync,
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
} from "node:fs";
import { dirname, join } from "node:path";
import { createHash } from "node:crypto";

interface IndexMember {
  readonly path: string;
  readonly sha256: string;
  readonly bytes: number;
}

interface CopyRecord {
  readonly project: string;
  readonly mode: string;
  readonly source: string;
  readonly sourceSha256: string;
  readonly sourceBytes: number;
  readonly destination: string;
  readonly destinationSha256: string;
  readonly destinationBytes: number;
  readonly indexedSha256: string | null;
  readonly indexedBytes: number | null;
}

class CorpusError extends Error {}

const digest = (path: string): { sha256: string; bytes: number } => {
  const contents = readFileSync(path);
  return {
    sha256: createHash("sha256").update(contents).digest("hex"),
    bytes: contents.byteLength,
  };
};

const flags = new Map<string, string>();
const argv = process.argv.slice(2);
for (let index = 0; index < argv.length; index += 1) {
  const flag = argv[index];
  if (flag === undefined) continue;
  if (!["--source", "--out", "--index", "--receipt"].includes(flag)) {
    throw new CorpusError(`unknown argument ${flag}`);
  }
  const value = argv[index + 1];
  if (value === undefined) throw new CorpusError(`${flag} needs a value`);
  flags.set(flag, value);
  index += 1;
}

/** Narrow an untyped JSON value to a plain object without a type assertion. */
const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const source = flags.get("--source");
const out = flags.get("--out");
if (source === undefined || out === undefined)
  throw new CorpusError("--source and --out are required");
if (!existsSync(source))
  throw new CorpusError(`source root not found: ${source}`);

const index = new Map<string, IndexMember>();
const indexPath = flags.get("--index");
if (indexPath !== undefined) {
  const parsed: unknown = JSON.parse(readFileSync(indexPath, "utf8"));
  if (!isRecord(parsed) || !Array.isArray(parsed["members"])) {
    throw new CorpusError(`${indexPath}: no members array`);
  }
  for (const member of parsed["members"]) {
    if (!isRecord(member)) continue;
    const path = member["path"];
    const sha256 = member["sha256"];
    const bytes = member["bytes"];
    if (
      typeof path === "string" &&
      typeof sha256 === "string" &&
      typeof bytes === "number"
    ) {
      index.set(path, { path, sha256, bytes });
    }
  }
}

const projectsTsv = join(source, "lead-raw__bun-test-projects.tsv");
if (!existsSync(projectsTsv))
  throw new CorpusError(`projects TSV not found: ${projectsTsv}`);
const projects = readFileSync(projectsTsv, "utf8")
  .split("\n")
  .map((line) => line.replace(/\r$/u, ""))
  .filter((line) => line.trim() !== "")
  .map((line) => {
    const [name, cwd] = line.split("\t");
    if (name === undefined || cwd === undefined || name === "" || cwd === "") {
      throw new CorpusError(`projects TSV: unusable row "${line}"`);
    }
    return { name, cwd };
  });
if (projects.length === 0)
  throw new CorpusError("projects TSV lists no projects");

const records: CopyRecord[] = [];
const failures: string[] = [];

const copyMember = (
  memberPath: string,
  destination: string,
  project: string,
  mode: string
): void => {
  const memberFile = join(source, memberPath);
  if (!existsSync(memberFile)) {
    failures.push(`missing retained member ${memberPath}`);
    return;
  }
  mkdirSync(dirname(destination), { recursive: true });
  copyFileSync(memberFile, destination);
  const sourceDigest = digest(memberFile);
  const destinationDigest = digest(destination);
  const pinned = index.get(memberPath) ?? null;
  if (
    pinned !== null &&
    (pinned.sha256 !== sourceDigest.sha256 ||
      pinned.bytes !== sourceDigest.bytes)
  ) {
    failures.push(
      `${memberPath}: retained member drifted from the archived index ` +
        `(index ${pinned.sha256}/${pinned.bytes}, member ${sourceDigest.sha256}/${sourceDigest.bytes})`
    );
  }
  if (
    sourceDigest.sha256 !== destinationDigest.sha256 ||
    sourceDigest.bytes !== destinationDigest.bytes
  ) {
    failures.push(
      `${memberPath}: copy is not byte-identical at ${destination}`
    );
  }
  records.push({
    project,
    mode,
    source: memberFile,
    sourceSha256: sourceDigest.sha256,
    sourceBytes: sourceDigest.bytes,
    destination,
    destinationSha256: destinationDigest.sha256,
    destinationBytes: destinationDigest.bytes,
    indexedSha256: pinned?.sha256 ?? null,
    indexedBytes: pinned?.bytes ?? null,
  });
};

for (const project of projects) {
  copyMember(
    `lead-raw__matrix__ordinary__${project.name}.junit.xml`,
    join(out, "ordinary", `${project.name}.junit.xml`),
    project.name,
    "ordinary"
  );
  copyMember(
    `lead-raw__matrix__isolate__${project.name}.junit.xml`,
    join(out, "isolate", `${project.name}.junit.xml`),
    project.name,
    "isolate"
  );
}

const projectsDestination = join(out, "bun-test-projects.tsv");
copyFileSync(projectsTsv, projectsDestination);
const tsvSourceDigest = digest(projectsTsv);
const tsvDestinationDigest = digest(projectsDestination);
const tsvPinned = index.get("lead-raw__bun-test-projects.tsv") ?? null;
if (tsvPinned !== null && tsvPinned.sha256 !== tsvSourceDigest.sha256) {
  failures.push(
    "lead-raw__bun-test-projects.tsv drifted from the archived index"
  );
}

const receipt = {
  ok: failures.length === 0,
  source,
  out,
  index: indexPath ?? null,
  projects: projects.length,
  copies: records.length,
  projectsTsv: {
    destination: projectsDestination,
    sourceSha256: tsvSourceDigest.sha256,
    destinationSha256: tsvDestinationDigest.sha256,
    indexedSha256: tsvPinned?.sha256 ?? null,
  },
  failures,
  records,
};

console.log(
  JSON.stringify(
    {
      ok: receipt.ok,
      projects: receipt.projects,
      copies: receipt.copies,
      failures: receipt.failures,
    },
    null,
    2
  )
);

const receiptPath = flags.get("--receipt");
if (receiptPath !== undefined)
  writeFileSync(receiptPath, `${JSON.stringify(receipt, null, 2)}\n`);
process.exitCode = failures.length === 0 ? 0 : 1;
