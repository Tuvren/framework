#!/usr/bin/env bash
# Prove the Bun 1.4.2 JUnit report shape the replay grader keys on, using the
# installed binary rather than an assumed protocol: the file-level <testsuite>
# has `file` and no `line`, nested describe() suites repeat `file` with `line`,
# and the root totals equal the sum of the outer file suites.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$HERE/work"
rm -rf "$WORK"
mkdir -p "$WORK"
cd "$WORK"

cat >nested.test.ts <<'TS'
import { describe, expect, test } from "bun:test";
describe("outer", () => {
  test("ok", () => {
    expect(1).toBe(1);
  });
  test.skip("skipped one", () => {});
  describe("inner", () => {
    test("nested ok", () => {
      expect(2).toBe(2);
    });
  });
});
TS

cat >plain.test.ts <<'TS'
import { test } from "bun:test";
test("plain", () => {});
TS

cat >failing.test.ts <<'TS'
import { expect, test } from "bun:test";
test("fails", () => {
  expect(1).toBe(2);
});
TS

bun --version
bun test nested.test.ts plain.test.ts --reporter=junit --reporter-outfile=./pass.junit.xml
echo "pass exit=$?"
cat ./pass.junit.xml

set +e
bun test failing.test.ts --reporter=junit --reporter-outfile=./fail.junit.xml
echo "fail exit=$?"
cat ./fail.junit.xml
