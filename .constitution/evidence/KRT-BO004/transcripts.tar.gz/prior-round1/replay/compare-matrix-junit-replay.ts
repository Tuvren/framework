#!/usr/bin/env bun
/**
 * KRT-BO004 replay grader for the retained ordinary / `--isolate` JUnit corpus.
 *
 * Why this file exists
 * --------------------
 * The historical probe retained unchanged as `probe__compare-matrix-junit.ts`
 * computed per-file differences and printed `DIFFERS`, but it never set a
 * failing exit status, and its companion `assert-observations.mjs` graded only
 * project-level totals. An equal-and-opposite per-file change (two files that
 * swap test counts inside one project) therefore left both tools at exit 0.
 * This replay grader exits nonzero for any missing project or file, any
 * malformed report, any invalid count and any per-file mismatch of tests,
 * failures or skipped, even when the project totals still agree. It reads its
 * corpus from the command line instead of a recorded scratch constant.
 *
 * Bun 1.4.2 JUnit report shape
 * ----------------------------
 * Established by inspecting the pinned reporter output and all 58 retained
 * reports, not assumed:
 *   - `<testsuites tests=".." failures=".." skipped="..">` is the single root
 *     element and carries no `file` attribute.
 *   - Each test file produces exactly one outer
 *     `<testsuite file=".." tests=".." failures=".." skipped="..">` element
 *     with no `line` attribute (358 outer suites in the retained corpus).
 *   - Nested `describe()` blocks produce further `<testsuite file=".." line="N">`
 *     elements that repeat the same `file` and count a subset of the outer
 *     suite (630 in the retained corpus), so they are skipped.
 *   - Summing the outer suites reproduces the root totals exactly, and each
 *     outer suite's `tests` equals the number of `<testcase>` elements it
 *     contains (true for 358/358 retained outer suites).
 * A tag ends at the first `>` outside a quoted attribute value; the retained
 * corpus has no raw `>` inside any attribute, and the scanner does not depend
 * on that being true.
 *
 * XML well-formedness
 * -------------------
 * Counting open tags is not well-formedness. A report that keeps every counter
 * and every testcase but loses its closing tags used to grade as PASS: the
 * scanner reads the outer suite it can see and the closing structure never
 * entered the comparison. Every report is now validated with the pinned
 * runtime's own XML processor, `Bun.XML.parse`, whose 1.4.2 declarations
 * describe it as "a conforming, non-validating XML processor" that throws
 * `SyntaxError` when the document "must be well-formed or ... there is no
 * lenient mode". The repository's pinned `@types/bun` is 1.3.14 and predates
 * the API, so `Bun.XML` cannot be called from typechecked code (`TS2339`); the
 * check therefore runs the parser in an inline ESM program spawned through
 * `process.execPath` — the same pinned binary — once per run for every report.
 * The check fails closed: when the child cannot run, or does not complete, the
 * run exits 1 instead of skipping the validation.
 *
 * Usage
 * -----
 *   bun compare-matrix-junit-replay.ts \
 *     --ordinary <dir>            # <dir>/<project>.junit.xml, ordinary mode
 *     --isolate  <dir>            # same naming, isolated mode
 *     --projects <path>           # TSV: project<TAB>cwd, one per expected project
 *     [--ordinary-pattern '{project}.junit.xml']
 *     [--isolate-pattern  '{project}.junit.xml']
 *     [--expect-projects 29] [--expect-files 179] [--expect-cases 1596]
 *     [--json <path>]             # write a machine-readable receipt
 *
 * `--expect-*` default to the KRT-BO004 retained inventory (29 projects,
 * 179 files, 1596 cases per mode). They guard against a truncated corpus
 * passing silently; override them for a different corpus.
 *
 * Exit codes: 0 all graded; 1 any data failure; 2 CLI usage error.
 */
import { existsSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { join } from "node:path";

/** Per-file outcome triple as emitted on an outer file suite. */
interface FileOutcome {
  readonly tests: number;
  readonly failures: number;
  readonly skipped: number;
}

/** One parsed JUnit report. */
interface ParsedReport {
  readonly files: Map<string, FileOutcome>;
  readonly caseCount: number;
}

/** Location and text of one `<testsuite ...>` open tag. */
interface SuiteTag {
  readonly start: number;
  readonly end: number;
  readonly text: string;
}

const ATTRIBUTE = /([A-Za-z_:][\w:.-]*)="([^"]*)"/g;
const UNSIGNED_INTEGER = /^\d+$/;
const SUITE_OPEN = "<testsuite ";
const ROOT_OPEN = "<testsuites ";
const TESTCASE_OPEN = "<testcase ";

const DEFAULT_EXPECT_PROJECTS = 29;
const DEFAULT_EXPECT_FILES = 179;
const DEFAULT_EXPECT_CASES = 1596;

const FAIL_PREFIX = "FAIL\t";
const DONE_PREFIX = "DONE\t";

/**
 * Inline ESM program that validates documents with the pinned runtime's own XML
 * processor. It is handed to `bun -e` of `process.execPath` — the binary this
 * grader is running on — because the repository's pinned `@types/bun` (1.3.14)
 * predates `Bun.XML`, so the call cannot live in typechecked TypeScript.
 *
 * Protocol: one `FAIL<TAB><path><TAB><message>` line per malformed document,
 * then a final `DONE<TAB><count>` line. Exit 3 means the parser is unavailable,
 * which the grader reports as an unusable input rather than as a pass.
 */
const XML_WELL_FORMEDNESS_PROGRAM = [
  "const paths = process.argv.slice(1);",
  "const xml = Bun.XML;",
  'if (xml === undefined || typeof xml.parse !== "function") {',
  '  console.error("Bun.XML.parse is unavailable in this runtime");',
  "  process.exit(3);",
  "}",
  'const { readFileSync } = require("node:fs");',
  "for (const path of paths) {",
  "  try {",
  '    xml.parse(readFileSync(path, "utf8"), { compact: false });',
  "  } catch (error) {",
  "    const message = error instanceof Error ? error.message : String(error);",
  '    process.stdout.write("FAIL\\t" + path + "\\t" + message.replace(/[\\t\\r\\n]+/gu, " ") + "\\n");',
  "  }",
  "}",
  'process.stdout.write("DONE\\t" + paths.length + "\\n");',
].join("\n");

/** Outcome of one well-formedness pass over every report a run will read. */
interface XmlValidation {
  readonly checked: number;
  readonly failures: ReadonlyMap<string, string>;
}

/** Raised for any unusable input; every instance fails the run. */
class ReplayInputError extends Error {}

const attributeMap = (tag: string): Map<string, string> => {
  const attributes = new Map<string, string>();
  for (const match of tag.matchAll(ATTRIBUTE)) {
    const name = match[1];
    const value = match[2];
    if (name !== undefined && value !== undefined) attributes.set(name, value);
  }
  return attributes;
};

const openTagAt = (
  xml: string,
  needle: string,
  from: number
): SuiteTag | null => {
  const start = xml.indexOf(needle, from);
  if (start < 0) return null;
  let inQuotes = false;
  for (let index = start; index < xml.length; index += 1) {
    const character = xml[index];
    if (character === '"') inQuotes = !inQuotes;
    else if (character === ">" && !inQuotes) {
      return { start, end: index, text: xml.slice(start + 1, index) };
    }
  }
  throw new ReplayInputError(`unterminated tag ${needle.trim()}`);
};

const collectSuiteTags = (xml: string): SuiteTag[] => {
  const tags: SuiteTag[] = [];
  let cursor = 0;
  for (;;) {
    const tag = openTagAt(xml, SUITE_OPEN, cursor);
    if (tag === null) return tags;
    tags.push(tag);
    cursor = tag.end + 1;
  }
};

const requireCount = (
  attributes: Map<string, string>,
  name: string,
  where: string
): number => {
  const raw = attributes.get(name);
  if (raw === undefined)
    throw new ReplayInputError(`${where}: missing ${name} attribute`);
  if (!UNSIGNED_INTEGER.test(raw)) {
    throw new ReplayInputError(
      `${where}: ${name}="${raw}" is not a non-negative integer`
    );
  }
  const value = Number(raw);
  if (!Number.isSafeInteger(value)) {
    throw new ReplayInputError(
      `${where}: ${name}="${raw}" is not a safe integer`
    );
  }
  return value;
};

const countOccurrences = (haystack: string, needle: string): number => {
  let count = 0;
  let cursor = 0;
  for (;;) {
    const found = haystack.indexOf(needle, cursor);
    if (found < 0) return count;
    count += 1;
    cursor = found + needle.length;
  }
};

/**
 * Parse one Bun 1.4.2 JUnit report into outer-file outcomes.
 *
 * Only outer file suites are retained: the file-level `<testsuite>` has a
 * `file` attribute and no `line`, while nested `describe()` suites repeat the
 * same `file` with a `line` attribute and would otherwise overwrite the
 * complete file outcome.
 */
const parseReport = (
  project: string,
  mode: string,
  path: string,
  xml: string
): ParsedReport => {
  const where = `${project}/${mode}`;
  const root = openTagAt(xml, ROOT_OPEN, 0);
  if (root === null)
    throw new ReplayInputError(`${where}: no <testsuites> root element`);
  const rootAttributes = attributeMap(root.text);
  const rootTests = requireCount(rootAttributes, "tests", `${where} root`);
  const rootFailures = requireCount(
    rootAttributes,
    "failures",
    `${where} root`
  );
  const rootSkipped = requireCount(rootAttributes, "skipped", `${where} root`);

  const outerTags: SuiteTag[] = [];
  const files = new Map<string, FileOutcome>();
  let caseCount = 0;
  let sumTests = 0;
  let sumFailures = 0;
  let sumSkipped = 0;

  for (const tag of collectSuiteTags(xml)) {
    const attributes = attributeMap(tag.text);
    if (attributes.has("line")) continue; // nested describe suite, not a file outcome
    const file = attributes.get("file");
    if (file === undefined || file.trim() === "") {
      throw new ReplayInputError(
        `${where}: outer suite without a usable file attribute`
      );
    }
    if (files.has(file)) {
      throw new ReplayInputError(
        `${where}: duplicate outer suite for file ${file}`
      );
    }
    const tests = requireCount(attributes, "tests", `${where} ${file}`);
    const failures = requireCount(attributes, "failures", `${where} ${file}`);
    const skipped = requireCount(attributes, "skipped", `${where} ${file}`);
    if (failures > tests || skipped > tests) {
      throw new ReplayInputError(
        `${where} ${file}: failures=${failures} skipped=${skipped} exceed tests=${tests}`
      );
    }
    files.set(file, { tests, failures, skipped });
    outerTags.push(tag);
    sumTests += tests;
    sumFailures += failures;
    sumSkipped += skipped;
  }

  if (files.size === 0) {
    throw new ReplayInputError(
      `${where}: no outer file suites (empty coverage) in ${path}`
    );
  }

  for (const [index, tag] of outerTags.entries()) {
    const next = outerTags[index + 1];
    const segment = xml.slice(
      tag.end + 1,
      next === undefined ? xml.length : next.start
    );
    const declared = attributeMap(tag.text).get("tests");
    const observed = countOccurrences(segment, TESTCASE_OPEN);
    if (String(observed) !== declared) {
      throw new ReplayInputError(
        `${where}: outer suite declares tests="${declared}" but contains ${observed} testcase elements`
      );
    }
    caseCount += observed;
  }

  if (
    sumTests !== rootTests ||
    sumFailures !== rootFailures ||
    sumSkipped !== rootSkipped
  ) {
    throw new ReplayInputError(
      `${where}: root totals tests=${rootTests} failures=${rootFailures} skipped=${rootSkipped} ` +
        `do not reconcile with outer suites tests=${sumTests} failures=${sumFailures} skipped=${sumSkipped}`
    );
  }

  return { files, caseCount };
};

interface Options {
  readonly ordinaryDir: string;
  readonly isolateDir: string;
  readonly projectsPath: string;
  readonly ordinaryPattern: string;
  readonly isolatePattern: string;
  readonly expectProjects: number;
  readonly expectFiles: number;
  readonly expectCases: number;
  readonly jsonPath: string | null;
}

class UsageError extends Error {}

const parseOptions = (argv: readonly string[]): Options => {
  const values = new Map<string, string>();
  const flags = new Set([
    "--ordinary",
    "--isolate",
    "--projects",
    "--ordinary-pattern",
    "--isolate-pattern",
    "--expect-projects",
    "--expect-files",
    "--expect-cases",
    "--json",
  ]);
  for (let index = 0; index < argv.length; index += 1) {
    const flag = argv[index];
    if (flag === undefined) continue;
    if (!flags.has(flag)) throw new UsageError(`unknown argument ${flag}`);
    const value = argv[index + 1];
    if (value === undefined) throw new UsageError(`${flag} needs a value`);
    values.set(flag, value);
    index += 1;
  }

  const required = (flag: string): string => {
    const value = values.get(flag);
    if (value === undefined) throw new UsageError(`${flag} is required`);
    return value;
  };
  const integer = (flag: string, fallback: number): number => {
    const raw = values.get(flag);
    if (raw === undefined) return fallback;
    if (!UNSIGNED_INTEGER.test(raw))
      throw new UsageError(`${flag} needs a non-negative integer`);
    return Number(raw);
  };

  return {
    ordinaryDir: required("--ordinary"),
    isolateDir: required("--isolate"),
    projectsPath: required("--projects"),
    ordinaryPattern: values.get("--ordinary-pattern") ?? "{project}.junit.xml",
    isolatePattern: values.get("--isolate-pattern") ?? "{project}.junit.xml",
    expectProjects: integer("--expect-projects", DEFAULT_EXPECT_PROJECTS),
    expectFiles: integer("--expect-files", DEFAULT_EXPECT_FILES),
    expectCases: integer("--expect-cases", DEFAULT_EXPECT_CASES),
    jsonPath: values.get("--json") ?? null,
  };
};

interface Project {
  readonly name: string;
  readonly cwd: string;
}

const readProjects = (path: string): Project[] => {
  if (!existsSync(path))
    throw new ReplayInputError(`projects file not found: ${path}`);
  const text = readFileSync(path, "utf8");
  const projects: Project[] = [];
  const seen = new Set<string>();
  for (const rawLine of text.split("\n")) {
    const line = rawLine.replace(/\r$/u, "");
    if (line.trim() === "") continue;
    const [name, cwd] = line.split("\t");
    if (name === undefined || cwd === undefined || name === "" || cwd === "") {
      throw new ReplayInputError(
        `projects file ${path}: unusable row "${line}"`
      );
    }
    if (seen.has(name))
      throw new ReplayInputError(
        `projects file ${path}: duplicate project ${name}`
      );
    seen.add(name);
    projects.push({ name, cwd });
  }
  if (projects.length === 0)
    throw new ReplayInputError(`projects file ${path} lists no projects`);
  return projects;
};

const reportPath = (
  dir: string,
  pattern: string,
  project: Project
): string => join(dir, pattern.replace("{project}", project.name));

/**
 * Validate every readable report once, in a single child process.
 *
 * The child is the pinned runtime itself (`process.execPath`), so the
 * well-formedness verdict comes from the same XML processor that produced the
 * retained reports. A child that does not run, or that stops before its
 * completion record, is an unusable input: the grader fails closed.
 */
const validateXmlWellFormedness = (paths: readonly string[]): XmlValidation => {
  const failures = new Map<string, string>();
  if (paths.length === 0) return { checked: 0, failures };
  const child = Bun.spawnSync({
    cmd: [process.execPath, "-e", XML_WELL_FORMEDNESS_PROGRAM, ...paths],
    stdout: "pipe",
    stderr: "pipe",
  });
  const stdout = child.stdout.toString();
  const stderr = child.stderr.toString().trim();
  const exit = child.exitCode ?? -1;
  if (exit !== 0) {
    throw new ReplayInputError(
      `native XML well-formedness check failed (exit ${exit}): ${
        stderr === "" ? stdout.trim() : stderr
      }`
    );
  }
  const lines = stdout.split("\n").filter((line) => line !== "");
  if (lines.at(-1) !== `${DONE_PREFIX}${paths.length}`) {
    throw new ReplayInputError(
      `native XML well-formedness check did not complete: ${stdout.trim()}`
    );
  }
  for (const line of lines.slice(0, -1)) {
    const rest = line.startsWith(FAIL_PREFIX)
      ? line.slice(FAIL_PREFIX.length)
      : "";
    const separator = rest.indexOf("\t");
    if (separator <= 0) {
      throw new ReplayInputError(
        `native XML well-formedness check produced an unusable line: ${line}`
      );
    }
    failures.set(rest.slice(0, separator), rest.slice(separator + 1));
  }
  return { checked: paths.length, failures };
};

const readReport = (
  dir: string,
  pattern: string,
  project: Project,
  mode: string,
  xmlValidation: XmlValidation
): ParsedReport => {
  const path = reportPath(dir, pattern, project);
  if (!existsSync(path))
    throw new ReplayInputError(
      `${project.name}/${mode}: missing report ${path}`
    );
  const stats = statSync(path);
  if (!stats.isFile() || stats.size === 0) {
    throw new ReplayInputError(`${project.name}/${mode}: empty report ${path}`);
  }
  const malformed = xmlValidation.failures.get(path);
  if (malformed !== undefined) {
    throw new ReplayInputError(
      `${project.name}/${mode}: ${path} is not well-formed XML (Bun.XML.parse): ${malformed}`
    );
  }
  return parseReport(project.name, mode, path, readFileSync(path, "utf8"));
};

const describeOutcome = (outcome: FileOutcome): string =>
  `tests:${outcome.tests},failures:${outcome.failures},skipped:${outcome.skipped}`;

const outcomeDiffers = (left: FileOutcome, right: FileOutcome): boolean =>
  left.tests !== right.tests ||
  left.failures !== right.failures ||
  left.skipped !== right.skipped;

const main = (argv: readonly string[]): number => {
  const options = parseOptions(argv);
  const projects = readProjects(options.projectsPath);

  const reportPaths: string[] = [];
  for (const project of projects) {
    const ordinary = reportPath(
      options.ordinaryDir,
      options.ordinaryPattern,
      project
    );
    if (existsSync(ordinary)) reportPaths.push(ordinary);
    const isolate = reportPath(
      options.isolateDir,
      options.isolatePattern,
      project
    );
    if (existsSync(isolate)) reportPaths.push(isolate);
  }
  const xmlValidation = validateXmlWellFormedness(reportPaths);

  const problems: string[] = [];
  const projectLines: string[] = [];
  const ordinaryFiles = new Map<string, FileOutcome>();
  const isolateFiles = new Map<string, FileOutcome>();
  let ordinaryCases = 0;
  let isolateCases = 0;
  let divergingProjects = 0;

  for (const project of projects) {
    let ordinary: ParsedReport;
    let isolate: ParsedReport;
    try {
      ordinary = readReport(
        options.ordinaryDir,
        options.ordinaryPattern,
        project,
        "ordinary",
        xmlValidation
      );
    } catch (error: unknown) {
      problems.push(
        `${project.name}: ${error instanceof Error ? error.message : String(error)}`
      );
      continue;
    }
    try {
      isolate = readReport(
        options.isolateDir,
        options.isolatePattern,
        project,
        "isolate",
        xmlValidation
      );
    } catch (error: unknown) {
      problems.push(
        `${project.name}: ${error instanceof Error ? error.message : String(error)}`
      );
      continue;
    }

    const key = (file: string): string => `${project.cwd}/${file}`;
    const names = [
      ...new Set([...ordinary.files.keys(), ...isolate.files.keys()]),
    ].sort();
    const details: string[] = [];

    for (const name of names) {
      const ordinaryOutcome = ordinary.files.get(name);
      const isolateOutcome = isolate.files.get(name);
      if (ordinaryOutcome === undefined || isolateOutcome === undefined) {
        if (ordinaryOutcome === undefined)
          details.push(`  only-in-isolate: ${name}`);
        if (isolateOutcome === undefined)
          details.push(`  only-in-ordinary: ${name}`);
        continue;
      }
      // Both modes executed the file, so it counts towards the graded file set
      // even when its outcome differs; only a missing file is ungraded.
      ordinaryFiles.set(key(name), ordinaryOutcome);
      isolateFiles.set(key(name), isolateOutcome);
      if (outcomeDiffers(ordinaryOutcome, isolateOutcome)) {
        details.push(
          `  outcome-mismatch: ${name} ordinary={${describeOutcome(ordinaryOutcome)}} ` +
            `isolate={${describeOutcome(isolateOutcome)}}`
        );
      }
    }

    ordinaryCases += ordinary.caseCount;
    isolateCases += isolate.caseCount;

    if (details.length === 0) {
      projectLines.push(
        `== ${project.name}: identical (${ordinary.files.size} files) ==`
      );
    } else {
      divergingProjects += 1;
      projectLines.push(`== ${project.name}: DIFFERS ==`);
      projectLines.push(...details);
      problems.push(
        `${project.name}: ${details.length} per-file difference(s)`
      );
    }
  }

  const inventory: string[] = [];
  if (projects.length !== options.expectProjects) {
    inventory.push(
      `expected ${options.expectProjects} projects, found ${projects.length}`
    );
  }
  if (ordinaryFiles.size !== options.expectFiles) {
    inventory.push(
      `expected ${options.expectFiles} ordinary files, found ${ordinaryFiles.size}`
    );
  }
  if (isolateFiles.size !== options.expectFiles) {
    inventory.push(
      `expected ${options.expectFiles} isolate files, found ${isolateFiles.size}`
    );
  }
  if (ordinaryCases !== options.expectCases) {
    inventory.push(
      `expected ${options.expectCases} ordinary cases, found ${ordinaryCases}`
    );
  }
  if (isolateCases !== options.expectCases) {
    inventory.push(
      `expected ${options.expectCases} isolate cases, found ${isolateCases}`
    );
  }
  if (ordinaryFiles.size !== isolateFiles.size) {
    inventory.push(
      `mode file sets differ: ordinary ${ordinaryFiles.size} vs isolate ${isolateFiles.size}`
    );
  }

  const lines = [
    ...projectLines,
    "",
    "=== aggregate ===",
    `projects: ${projects.length}`,
  ];
  lines.push(`distinct test files (ordinary): ${ordinaryFiles.size}`);
  lines.push(`distinct test files (isolate):  ${isolateFiles.size}`);
  lines.push(`test cases (ordinary): ${ordinaryCases}`);
  lines.push(`test cases (isolate):  ${isolateCases}`);
  lines.push(`projects with a per-file difference: ${divergingProjects}`);
  lines.push(
    `xml well-formedness (Bun.XML.parse): ${xmlValidation.checked} report(s) checked, ` +
      `${xmlValidation.failures.size} failure(s)`
  );

  const allProblems = [
    ...problems,
    ...inventory.map((line) => `inventory: ${line}`),
  ];
  if (allProblems.length === 0) {
    lines.push(
      "per-file grading: PASS (every project and file graded, both modes agree)"
    );
  } else {
    lines.push(`per-file grading: FAIL (${allProblems.length} problem(s))`);
    for (const problem of allProblems) lines.push(`  ${problem}`);
  }
  console.log(lines.join("\n"));

  const receipt = {
    ok: allProblems.length === 0,
    ordinaryDir: options.ordinaryDir,
    isolateDir: options.isolateDir,
    projectsPath: options.projectsPath,
    expected: {
      projects: options.expectProjects,
      files: options.expectFiles,
      cases: options.expectCases,
    },
    observed: {
      projects: projects.length,
      ordinaryFiles: ordinaryFiles.size,
      isolateFiles: isolateFiles.size,
      ordinaryCases,
      isolateCases,
      divergingProjects,
    },
    xmlWellFormedness: {
      parser: "Bun.XML.parse",
      runtime: Bun.version,
      checked: xmlValidation.checked,
      failures: xmlValidation.failures.size,
    },
    problems: allProblems,
  };
  if (options.jsonPath !== null) {
    writeFileSync(options.jsonPath, `${JSON.stringify(receipt, null, 2)}\n`);
  }

  return allProblems.length === 0 ? 0 : 1;
};

try {
  process.exitCode = main(process.argv.slice(2));
} catch (error: unknown) {
  if (error instanceof UsageError) {
    console.error(`usage error: ${error.message}`);
    process.exitCode = 2;
  } else if (error instanceof ReplayInputError) {
    console.error(`input error: ${error.message}`);
    process.exitCode = 1;
  } else {
    throw error;
  }
}
