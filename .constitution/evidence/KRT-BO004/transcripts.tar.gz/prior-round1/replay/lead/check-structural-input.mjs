import {mkdir} from "node:fs/promises";
const root="/home/oscar/.cache/pi-subagent/framework/wf-bo-pr-r1-fix/lead/structural-input";
await mkdir(root+"/ordinary",{recursive:true});await mkdir(root+"/isolate",{recursive:true});
const xml='<testsuites tests="1" failures="0" skipped="0"><testsuite file="a.test.ts" tests="1" failures="0" skipped="0"><testcase name="one" classname="a"/></testsuite></testsuites>';
await Bun.write(root+"/ordinary/project.junit.xml",xml);
await Bun.write(root+"/isolate/project.junit.xml",xml.replace("</testsuite></testsuites>",""));
await Bun.write(root+"/projects.tsv","project\t/scratch/project\n");
const p=Bun.spawn(["bun","/home/oscar/.cache/pi-subagent/framework/wf-bo-pr-r1-fix/replay/compare-matrix-junit-replay.ts","--ordinary",root+"/ordinary","--isolate",root+"/isolate","--projects",root+"/projects.tsv","--expect-projects","1","--expect-files","1","--expect-cases","1"],{stdout:"inherit",stderr:"inherit"});console.log("structurally-truncated exit="+await p.exited);

