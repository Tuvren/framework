/**
 * KRT-BO004: compare the per-file JUnit evidence of the ordinary and
 * `--isolate` Bun-backed project sweeps.
 *
 * Emits, per project: the file sets seen in each mode, their symmetric
 * difference, and per-file (tests, failures, skipped) for files where the two
 * modes disagree. Exit code 1 when any project's per-file outcomes differ.
 */
import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";

interface FileOutcome {
  tests: number;
  failures: number;
  skipped: number;
}

const W = "/home/oscar/.cache/pi-subagent/framework/wf-bo-m4/lead-replay";

function attr(tag: string, name: string): string | null {
  const match = tag.match(new RegExp(`${name}="([^"]*)"`));
  return match?.[1] ?? null;
}

function readJunit(path: string, cwd: string): Map<string, FileOutcome> {
  const xml = readFileSync(path, "utf8");
  const out = new Map<string, FileOutcome>();
  const suiteRe = /<testsuite ([^>]*)>/g;
  for (const match of xml.matchAll(suiteRe)) {
    const tag = match[1];
    if (tag === undefined) continue;
    const file = attr(tag, "file");
    const tests = attr(tag, "tests");
    const failures = attr(tag, "failures");
    const skipped = attr(tag, "skipped");
    // Ignore nested describe suites; keep the complete outer file outcome.
    if (file === null || tests === null || attr(tag, "line") !== null) continue;
    out.set(file.startsWith("/") ? file : `${cwd}/${file}`, {
      tests: Number(tests),
      failures: Number(failures ?? "0"),
      skipped: Number(skipped ?? "0"),
    });
  }
  return out;
}

function listProjects(): string[] {
  const dir = join(W, "raw/matrix/ordinary");
  return readdirSync(dir)
    .filter((n) => n.endsWith(".junit.xml"))
    .map((n) => n.replace(/\.junit\.xml$/, ""))
    .sort();
}

const cwdByProject = new Map<string, string>(
  readFileSync(join(W, "raw/bun-test-projects.tsv"), "utf8")
    .trim()
    .split("\n")
    .map((line) => {
      const [project, cwd] = line.split("\t");
      return [project ?? "", cwd ?? ""];
    })
);

const projects = listProjects();
if (projects.length === 0) {
  throw new Error("no ordinary-mode junit files; run the sweeps first");
}

let differences = 0;
const allFiles = new Map<string, { ordinary: FileOutcome; isolate: FileOutcome }>();
const filesOrdinary = new Set<string>();
const filesIsolate = new Set<string>();

for (const project of projects) {
  const cwd = cwdByProject.get(project) ?? project;
  const ordinary = readJunit(join(W, "raw/matrix/ordinary", `${project}.junit.xml`), cwd);
  const isolate = readJunit(join(W, "raw/matrix/isolate", `${project}.junit.xml`), cwd);
  const names = new Set([...ordinary.keys(), ...isolate.keys()]);
  const missingOrdinary: string[] = [];
  const missingIsolate: string[] = [];
  const mismatch: string[] = [];
  for (const name of [...names].sort()) {
    const o = ordinary.get(name);
    const i = isolate.get(name);
    if (o === undefined) missingOrdinary.push(name);
    else if (i === undefined) missingIsolate.push(name);
    else if (o.tests !== i.tests || o.failures !== i.failures || o.skipped !== i.skipped) {
      mismatch.push(
        `${name} ordinary={tests:${o.tests},failures:${o.failures},skipped:${o.skipped}} isolate={tests:${i.tests},failures:${i.failures},skipped:${i.skipped}}`
      );
    }
    if (o !== undefined && i !== undefined) allFiles.set(name, { ordinary: o, isolate: i });
    if (o !== undefined) filesOrdinary.add(name);
    if (i !== undefined) filesIsolate.add(name);
  }
  if (missingOrdinary.length > 0 || missingIsolate.length > 0 || mismatch.length > 0) {
    differences += 1;
    console.log(`## ${project}: DIFFERS`);
    for (const n of missingOrdinary) console.log(`  only-in-isolate: ${n}`);
    for (const n of missingIsolate) console.log(`  only-in-ordinary: ${n}`);
    for (const n of mismatch) console.log(`  outcome-mismatch: ${n}`);
  } else {
    console.log(`## ${project}: identical (${ordinary.size} files)`);
  }
}

const totalFiles = [...allFiles.values()].reduce((sum, v) => sum + v.ordinary.tests, 0);
const totalFailures = [...allFiles.values()].reduce((sum, v) => sum + v.ordinary.failures + v.isolate.failures, 0);
console.log("\n=== aggregate ===");
console.log(`projects: ${projects.length}`);
console.log(`distinct test files executed in ordinary mode: ${filesOrdinary.size}`);
console.log(`distinct test files executed in isolate mode:  ${filesIsolate.size}`);
console.log(`test cases executed (ordinary mode): ${totalFiles}`);
console.log(`failures across both modes: ${totalFailures}`);
console.log(`projects with any per-file difference: ${differences}`);
