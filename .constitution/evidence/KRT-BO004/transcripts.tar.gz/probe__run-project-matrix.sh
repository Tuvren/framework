#!/usr/bin/env bash
# KRT-BO004: run every Bun-backed Nx `test` target in one isolation mode and
# record a comparable outcome row (exit, pass/fail/skip, per-file evidence).
#
# The command for each project is exactly the `test` target command declared in
# that project's project.json, run from the project.json `cwd`. For the
# `--isolate` mode the flag is appended to that same command, so the only
# difference between modes is the runner isolation flag.
#
# Usage: run-project-matrix.sh <ordinary|isolate> [project-filter-regex]
set -uo pipefail

ROOT=/home/oscar/GitHub/Tuvren/framework-bo
W=/home/oscar/.cache/pi-subagent/framework/wf-bo-m4/lead-replay
MODE="${1:-ordinary}"
FILTER="${2:-.}"
case "$MODE" in
  ordinary) EXTRA=() ;;
  isolate) EXTRA=(--isolate) ;;
  *) echo "usage: $0 <ordinary|isolate> [filter]" >&2; exit 2 ;;
esac

OUT_DIR="$W/raw/matrix/$MODE"
mkdir -p "$OUT_DIR"
RESULTS="$W/raw/matrix/results-$MODE.tsv"
if [[ ! -f "$RESULTS" ]]; then
  printf 'mode\tproject\tcwd\texit\tpass\tfail\tskip\tfiles\tduration_s\tlog\tjunit\n' >"$RESULTS"
fi
export LC_ALL=C

while IFS=$'\t' read -r project cwd _cmd; do
  [[ "$project" =~ $FILTER ]] || continue
  log="$OUT_DIR/$project.log"
  junit="$OUT_DIR/$project.junit.xml"
  start=$(date +%s)
  (
    cd "$ROOT/$cwd" || exit 97
    printf '$ cd %s && bun test %s\n' "$ROOT/$cwd" "${EXTRA[*]-}" >"$log"
    timeout 1800 bun test "${EXTRA[@]-}" --reporter=junit --reporter-outfile="$junit" >>"$log" 2>&1
    printf 'exit=%s\n' "$?" >>"$log"
  )
  end=$(date +%s)
  exit_code=$(grep -o 'exit=[0-9]*' "$log" | tail -1 | cut -d= -f2)
  pass=$(grep -oE '^ *[0-9]+ pass$' "$log" | tail -1 | grep -oE '[0-9]+' || echo "")
  fail=$(grep -oE '^ *[0-9]+ fail$' "$log" | tail -1 | grep -oE '[0-9]+' || echo "")
  skip=$(grep -oE '^ *[0-9]+ skip$' "$log" | tail -1 | grep -oE '[0-9]+' || echo "")
  files=$(grep -oE 'across [0-9]+ files?' "$log" | tail -1 | grep -oE '[0-9]+' || echo "")
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$MODE" "$project" "$cwd" "$exit_code" "$pass" "$fail" "$skip" "$files" "$((end - start))" "$log" "$junit" >>"$RESULTS"
  printf '%-38s exit=%-3s pass=%-5s fail=%-5s skip=%-4s files=%-4s %ss\n' \
    "$project" "$exit_code" "$pass" "$fail" "$skip" "$files" "$((end - start))"
done <"$W/raw/bun-test-projects.tsv"
