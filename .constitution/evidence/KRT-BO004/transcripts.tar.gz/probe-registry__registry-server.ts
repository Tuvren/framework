/**
 * KRT-BO004 scratch npm registry used to measure Bun 1.4.2 registry-credential
 * scoping. Three listeners, all bound to loopback:
 *
 *   - `http-auth`   HTTP, requires `Authorization: Bearer <sentinel>` on tarballs.
 *   - `http-plain`  HTTP, no auth; used as the redirect target so we can observe
 *                   whether a credential is forwarded to a different origin.
 *   - `https-auth`  HTTPS with a scratch self-signed certificate; same routing as
 *                   `http-auth`, plus the downgrade redirect used by the
 *                   HTTPS -> HTTP probe.
 *
 * Every request is appended to `requests.jsonl` as booleans/shapes only. The
 * Authorization value is never logged; only its scheme and whether it equals
 * the synthetic sentinel token.
 *
 * No publishing happens anywhere: the listeners only serve this scratch byte
 * content, and the client side only installs it into scratch projects.
 */
import { appendFileSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

interface Fixture {
  readonly file: string;
  readonly integrity: string;
  readonly name: string;
  readonly sha1: string;
}

interface Bases {
  httpAuth: string;
  httpPlain: string;
  crossHost: string;
  https: string | null;
}

interface RequestRecord {
  readonly at: string;
  readonly listener: string;
  readonly method: string;
  readonly path: string;
  readonly hasAuthorization: boolean;
  readonly authorizationScheme: string | null;
  readonly authorizationMatchesSentinel: boolean;
}

const VERSION = "9.9.9-krtbo004";
const ROOT = process.env.KRT_BO004_REGISTRY_ROOT;
const SENTINEL = process.env.KRT_BO004_SENTINEL;
const CERT_PATH = process.env.KRT_BO004_TLS_CERT;
const KEY_PATH = process.env.KRT_BO004_TLS_KEY;

if (ROOT === undefined || SENTINEL === undefined) {
  throw new Error("KRT_BO004_REGISTRY_ROOT and KRT_BO004_SENTINEL are required");
}

const REQUEST_LOG = join(ROOT, "requests.jsonl");

function loadFixtures(): Map<string, Fixture> {
  const dir = join(ROOT ?? "", "tarballs");
  const fixtures = new Map<string, Fixture>();
  for (const file of readdirSync(dir)) {
    if (!file.endsWith(".tgz")) continue;
    const name = file.replace(`-${VERSION}.tgz`, "");
    const bytes = readFileSync(join(dir, file));
    fixtures.set(name, {
      file,
      name,
      integrity: `sha512-${new Bun.CryptoHasher("sha512").update(bytes).digest("base64")}`,
      sha1: new Bun.CryptoHasher("sha1").update(bytes).digest("hex"),
    });
  }
  return fixtures;
}

const fixtures = loadFixtures();

const bases: Bases = { httpAuth: "", httpPlain: "", crossHost: "", https: null };

function metadataFor(name: string, tarballUrl: string): string {
  const fixture = fixtures.get(name);
  if (fixture === undefined) {
    throw new Error(`unknown fixture ${name}`);
  }
  return JSON.stringify({
    name,
    "dist-tags": { latest: VERSION },
    versions: {
      [VERSION]: {
        name,
        version: VERSION,
        main: "index.js",
        scripts: { postinstall: "node ./scripts/postinstall.mjs" },
        dist: { tarball: tarballUrl, shasum: fixture.sha1, integrity: fixture.integrity },
      },
    },
  });
}

function recordRequest(listener: string, req: Request): void {
  const authorization = req.headers.get("authorization");
  const record: RequestRecord = {
    at: new Date().toISOString(),
    listener,
    method: req.method,
    path: new URL(req.url).pathname,
    hasAuthorization: authorization !== null,
    authorizationScheme: authorization === null ? null : (authorization.split(" ")[0] ?? null),
    authorizationMatchesSentinel: authorization === `Bearer ${SENTINEL}`,
  };
  appendFileSync(REQUEST_LOG, `${JSON.stringify(record)}\n`);
}

function tarballResponse(name: string): Response {
  const fixture = fixtures.get(name);
  if (fixture === undefined) {
    return new Response("not found\n", { status: 404 });
  }
  return new Response(readFileSync(join(ROOT ?? "", "tarballs", fixture.file)), {
    status: 200,
    headers: { "content-type": "application/octet-stream" },
  });
}

/** Tarball URL advertised per fixture name for the listener that serves it. */
function tarballUrlFor(name: string, base: string): string {
  const fileName = fixtures.get(name)?.file ?? "";
  switch (name) {
    case "krt-bo004-redir-same":
      return `${base}/redirect-same/${name}/-/${fileName}`;
    case "krt-bo004-redir-crosshost":
      return `${base}/redirect-crosshost/${name}/-/${fileName}`;
    case "krt-bo004-redir-crossport":
      return `${base}/redirect-crossport/${name}/-/${fileName}`;
    case "krt-bo004-downgrade":
      return bases.https === null
        ? `${bases.httpPlain}/${name}/-/${fileName}`
        : `${bases.https}/downgrade/${name}/-/${fileName}`;
    default:
      return `${base}/${name}/-/${fileName}`;
  }
}

function handle(listener: string, authRequired: boolean, base: string, req: Request): Response {
  recordRequest(listener, req);
  const path = new URL(req.url).pathname;

  if (path === "/" || path === "/-/ping") {
    return new Response("krt-bo004 scratch registry\n", { status: 200 });
  }

  const redirectMatch = path.match(
    /^\/(redirect-same|redirect-crosshost|redirect-crossport|downgrade)\/([^/]+)\/-\/(.+)$/
  );
  if (redirectMatch !== null) {
    const [, kind, name] = redirectMatch;
    const targetBase =
      kind === "redirect-same"
        ? base
        : kind === "redirect-crosshost"
          ? bases.crossHost
          : bases.httpPlain;
    const location = `${targetBase}/${name ?? ""}/-/${fixtures.get(name ?? "")?.file ?? ""}`;
    return new Response(null, { status: 302, headers: { location } });
  }

  const tarballMatch = path.match(/^\/([^/]+)\/-\/(.+)$/);
  if (tarballMatch !== null) {
    if (authRequired && req.headers.get("authorization") !== `Bearer ${SENTINEL}`) {
      return new Response(JSON.stringify({ error: "unauthorized" }), {
        status: 401,
        headers: { "content-type": "application/json" },
      });
    }
    return tarballResponse(tarballMatch[1] ?? "");
  }

  const name = path.slice(1);
  if (fixtures.has(name)) {
    return new Response(metadataFor(name, tarballUrlFor(name, base)), {
      status: 200,
      headers: { "content-type": "application/json" },
    });
  }

  return new Response("not found\n", { status: 404 });
}

const authServer = Bun.serve({
  port: 0,
  hostname: "127.0.0.1",
  fetch: (req) => handle("http-auth", true, bases.httpAuth, req),
});

const plainServer = Bun.serve({
  port: 0,
  hostname: "127.0.0.1",
  fetch: (req) => handle("http-plain", false, bases.httpPlain, req),
});

const tlsServer = Bun.serve({
  port: 0,
  hostname: "127.0.0.1",
  tls:
    CERT_PATH === undefined || KEY_PATH === undefined
      ? undefined
      : { cert: readFileSync(CERT_PATH, "utf8"), key: readFileSync(KEY_PATH, "utf8") },
  fetch: (req) => handle("https-auth", true, bases.https ?? "", req),
});

bases.httpAuth = `http://127.0.0.1:${authServer.port}`;
bases.httpPlain = `http://127.0.0.1:${plainServer.port}`;
bases.crossHost = `http://localhost:${plainServer.port}`;
bases.https = CERT_PATH === undefined ? null : `https://127.0.0.1:${tlsServer.port}`;

writeFileSync(
  join(ROOT, "ports.json"),
  `${JSON.stringify(
    {
      httpAuth: authServer.port,
      httpPlain: plainServer.port,
      httpsAuth: tlsServer.port,
      bases,
      tls: bases.https !== null,
    },
    null,
    2
  )}\n`
);
process.stdout.write(`[registry] listening ${JSON.stringify(bases)}\n`);
