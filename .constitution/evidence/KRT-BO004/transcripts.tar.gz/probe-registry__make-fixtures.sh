#!/usr/bin/env bash
# KRT-BO004 registry probe fixtures: build disposable packages inside the
# scratch data root and pack them with Bun's own CLI (`bun pm pack`), so the
# local registry serves real npm metadata.
#
# Only the scratch data subdirectories (`pkgs`, `tarballs`) are removed; this
# script lives in `scratch/registry-scripts/` and never deletes its own tree.
#
# Usage: bash make-fixtures.sh [scratch-root]
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRATCH_ROOT="${1:-$(dirname "$SCRIPT_DIR")}"
R="$SCRATCH_ROOT/scratch/registry"
export LC_ALL=C

rm -rf "$R/pkgs" "$R/tarballs"
mkdir -p "$R/pkgs" "$R/tarballs"

# Package names used by the probe. Every one carries the same harmless
# postinstall marker writer; only the trust declaration differs per scenario.
NAMES=(
  "krt-bo004-dep"
  "krt-bo004-redir-same"
  "krt-bo004-redir-crosshost"
  "krt-bo004-redir-crossport"
  "krt-bo004-downgrade"
  "esbuild"
)

for name in "${NAMES[@]}"; do
  dir="$R/pkgs/$name"
  mkdir -p "$dir/scripts"
  cat >"$dir/package.json" <<EOF
{
  "name": "$name",
  "version": "9.9.9-krtbo004",
  "private": false,
  "type": "module",
  "main": "index.js",
  "scripts": { "postinstall": "node ./scripts/postinstall.mjs" }
}
EOF
  cat >"$dir/scripts/postinstall.mjs" <<'EOF'
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const manifest = JSON.parse(readFileSync(join(process.cwd(), "package.json"), "utf8"));
const markerDir = process.env.KRT_BO004_MARKER_DIR;
const record = {
  package: manifest.name,
  cwd: process.cwd(),
  at: new Date().toISOString(),
};
process.stdout.write(`[KRT-BO004-POSTINSTALL] ${JSON.stringify(record)}\n`);
if (typeof markerDir === "string" && markerDir.length > 0) {
  mkdirSync(markerDir, { recursive: true });
  writeFileSync(join(markerDir, `${manifest.name}.marker`), `${JSON.stringify(record, null, 2)}\n`);
}
EOF
  printf 'export const name = "%s";\n' "$name" >"$dir/index.js"
  ( cd "$dir" && bun pm pack --destination "$R/tarballs" >/dev/null )
done

ls -la "$R/tarballs"
