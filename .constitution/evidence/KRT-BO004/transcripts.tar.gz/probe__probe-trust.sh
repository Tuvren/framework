#!/usr/bin/env bash
# KRT-BO004 trust probe: measure Bun 1.4.2 lifecycle-script trust scoping
# (explicit `trustedDependencies` and Bun's built-in default-trusted name list)
# for `file:` and linked dependencies, entirely inside a scratch directory.
#
# Every fixture is disposable and lives under the scratch root; no repository
# package is installed, trusted, untrusted or modified. `bun link` writes to
# BUN_INSTALL/install/global, which this script relocates into the scratch root
# so it never touches the real ~/.bun/install/global.
#
# Usage: bash probe-trust.sh [scratch-root]
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRATCH_ROOT="${1:-$(dirname "$SCRIPT_DIR")}"
T="$SCRATCH_ROOT/scratch/trust"
CACHE="$SCRATCH_ROOT/scratch/bun-cache"
OUT="$SCRATCH_ROOT/raw/trust"
SENTINEL="krt-bo004-sentinel-token-0f3a9c"
export LC_ALL=C
export KRT_BO004_MARKER_DIR="$T/markers"
export BUN_INSTALL="$T/bun-install"

mkdir -p "$OUT" "$CACHE" "$BUN_INSTALL" "$T/markers"
rm -rf "$T" "$OUT"/*.log "$OUT"/*.tsv
mkdir -p "$T/markers" "$BUN_INSTALL"

make_dep() {
  local dir="$1" name="$2"
  mkdir -p "$dir/scripts"
  cat >"$dir/package.json" <<EOF
{
  "name": "$name",
  "version": "1.0.0",
  "private": true,
  "type": "module",
  "scripts": { "postinstall": "node ./scripts/postinstall.mjs" }
}
EOF
  cat >"$dir/scripts/postinstall.mjs" <<'EOF'
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const manifest = JSON.parse(readFileSync(join(process.cwd(), "package.json"), "utf8"));
const markerDir = process.env.KRT_BO004_MARKER_DIR;
const record = {
  package: manifest.name,
  cwd: process.cwd(),
  lifecycle: process.env.npm_lifecycle_event ?? null,
  at: new Date().toISOString(),
};
process.stdout.write(`[KRT-BO004-POSTINSTALL] ${JSON.stringify(record)}\n`);
if (typeof markerDir === "string" && markerDir.length > 0) {
  mkdirSync(markerDir, { recursive: true });
  writeFileSync(join(markerDir, `${manifest.name}.marker`), `${JSON.stringify(record, null, 2)}\n`);
}
EOF
  printf 'export const name = "%s";\n' "$name" >"$dir/index.js"
}

make_consumer() {
  local dir="$1" dep_name="$2" dep_spec="$3" extra_json="${4:-}"
  mkdir -p "$dir"
  cat >"$dir/package.json" <<EOF
{
  "name": "krt-bo004-consumer-$(basename "$dir")",
  "version": "1.0.0",
  "private": true,
  "type": "module",
  "dependencies": { "$dep_name": "$dep_spec" }$extra_json
}
EOF
}

clear_markers() { rm -f "$T/markers"/*.marker; }
marker_list() { find "$T/markers" -name '*.marker' -printf '%f ' 2>/dev/null | sed 's/ $//'; }

record() {
  local scenario="$1" expect="$2" exit_code="$3" log="$4"
  local blocked
  blocked="$(grep -c 'Blocked\|blocked' "$log" 2>/dev/null; true)"
  local ran
  ran="$(grep -c 'KRT-BO004-POSTINSTALL' "$log" 2>/dev/null; true)"
  printf '%s\t%s\texit=%s\tmarkers=[%s]\trun-lines=%s\tblocked-lines=%s\tlog=%s\n' \
    "$scenario" "$expect" "$exit_code" "$(marker_list)" "$ran" "$blocked" "$log" >>"$OUT/results.tsv"
  printf '%-32s expect=%-26s exit=%-3s markers=[%s]\n' "$scenario" "$expect" "$exit_code" "$(marker_list)"
}

# --- fixtures -------------------------------------------------------------
make_dep "$T/deps/plain" "krt-bo004-dep"
make_dep "$T/deps/default-name" "esbuild"
ln -sfn "$T/deps/plain" "$T/deps/plain-named"
printf 'scenario\texpect\texit\tmarkers\trun-lines\tblocked-lines\tlog\n' >"$OUT/results.tsv"

# 1. untrusted name through file:
clear_markers
make_consumer "$T/c1-file-untrusted" "krt-bo004-dep" "file:../deps/plain"
( cd "$T/c1-file-untrusted" && timeout 300 bun install --cache-dir "$CACHE" ) >"$OUT/1-file-untrusted.log" 2>&1
code=$?
record "1-file-untrusted" "blocked, marker-absent" "$code" "$OUT/1-file-untrusted.log"

# 2. same dependency explicitly trusted through trustedDependencies
clear_markers
make_consumer "$T/c2-file-trusted" "krt-bo004-dep" "file:../deps/plain" ',
  "trustedDependencies": ["krt-bo004-dep"]'
( cd "$T/c2-file-trusted" && timeout 300 bun install --cache-dir "$CACHE" ) >"$OUT/2-file-trusted.log" 2>&1
code=$?
record "2-file-trusted" "allowed, marker-present" "$code" "$OUT/2-file-trusted.log"

# 3. a name Bun ships in its own default-trusted list, through file:
clear_markers
make_consumer "$T/c3-file-default-name" "esbuild" "file:../deps/default-name"
( cd "$T/c3-file-default-name" && timeout 300 bun install --cache-dir "$CACHE" ) >"$OUT/3-file-default-name.log" 2>&1
code=$?
record "3-file-default-name" "default-list-scope (file:)" "$code" "$OUT/3-file-default-name.log"

# 4. untrusted name through a Bun link (BUN_INSTALL relocated into scratch)
clear_markers
mkdir -p "$T/c4-link-untrusted"
printf '{ "name": "krt-bo004-consumer-c4", "version": "1.0.0", "private": true, "type": "module" }\n' >"$T/c4-link-untrusted/package.json"
( cd "$T/deps/plain" && timeout 120 bun link ) >"$OUT/4a-link-register.log" 2>&1
( cd "$T/c4-link-untrusted" && timeout 300 bun link krt-bo004-dep ) >"$OUT/4b-link-untrusted.log" 2>&1
code=$?
record "4-link-untrusted" "blocked, marker-absent" "$code" "$OUT/4b-link-untrusted.log"

# 5. default-trusted name through a Bun link
clear_markers
mkdir -p "$T/c5-link-default-name"
printf '{ "name": "krt-bo004-consumer-c5", "version": "1.0.0", "private": true, "type": "module" }\n' >"$T/c5-link-default-name/package.json"
( cd "$T/deps/default-name" && timeout 120 bun link ) >"$OUT/5a-link-register.log" 2>&1
( cd "$T/c5-link-default-name" && timeout 300 bun link esbuild ) >"$OUT/5b-link-default-name.log" 2>&1
code=$?
record "5-link-default-name" "default-list-scope (link)" "$code" "$OUT/5b-link-default-name.log"

# 6. explicitly trusted link
clear_markers
mkdir -p "$T/c6-link-trusted"
printf '{ "name": "krt-bo004-consumer-c6", "version": "1.0.0", "private": true, "type": "module", "trustedDependencies": ["krt-bo004-dep"] }\n' >"$T/c6-link-trusted/package.json"
( cd "$T/c6-link-trusted" && timeout 300 bun link krt-bo004-dep ) >"$OUT/6-link-trusted.log" 2>&1
code=$?
record "6-link-trusted" "allowed, marker-present" "$code" "$OUT/6-link-trusted.log"

# 7. escape hatch: bun pm trust <name>, then reinstall
clear_markers
make_consumer "$T/c7-file-pm-trust" "krt-bo004-dep" "file:../deps/plain"
( cd "$T/c7-file-pm-trust" && timeout 300 bun install --cache-dir "$CACHE" ) >"$OUT/7a-file-pm-trust-first-install.log" 2>&1
( cd "$T/c7-file-pm-trust" && timeout 120 bun pm trust krt-bo004-dep ) >"$OUT/7b-file-pm-trust-command.log" 2>&1
( cd "$T/c7-file-pm-trust" && timeout 300 bun install --cache-dir "$CACHE" ) >"$OUT/7c-file-pm-trust-reinstall.log" 2>&1
code=$?
record "7-file-pm-trust" "allowed after pm trust" "$code" "$OUT/7c-file-pm-trust-reinstall.log"

# 8. escape hatch: bun add --trust <file: spec>
clear_markers
mkdir -p "$T/c8-file-add-trust"
printf '{ "name": "krt-bo004-consumer-c8", "version": "1.0.0", "private": true, "type": "module" }\n' >"$T/c8-file-add-trust/package.json"
( cd "$T/c8-file-add-trust" && timeout 300 bun add --trust "file:../deps/plain" --cache-dir "$CACHE" ) >"$OUT/8-file-add-trust.log" 2>&1
code=$?
record "8-file-add-trust" "measure: add --trust file:" "$code" "$OUT/8-file-add-trust.log"

# 9. reporting surfaces
( cd "$T/c1-file-untrusted" && timeout 120 bun pm untrusted ) >"$OUT/9a-pm-untrusted-consumer.log" 2>&1
( cd "$T/c1-file-untrusted" && bun pm default-trusted ) | grep -xF " - esbuild" >"$OUT/9b-membership.log" 2>&1 || echo "esbuild NOT IN DEFAULT LIST" >>"$OUT/9b-membership.log"
( cd "$T/c1-file-untrusted" && bun pm default-trusted ) | grep -xF " - krt-bo004-dep" >>"$OUT/9b-membership.log" 2>&1 || echo "krt-bo004-dep NOT IN DEFAULT LIST" >>"$OUT/9b-membership.log"

# 10. scratch hygiene: nothing landed in the real global link registry, and no
#     sentinel token appears anywhere in the probe output.
{
  echo "=== relocated link registry (scratch) ==="
  find "$BUN_INSTALL" -maxdepth 4 -name 'krt-bo004-dep' -o -maxdepth 4 -name 'esbuild' 2>/dev/null
  echo "=== real global link registry (must not contain probe packages) ==="
  ls "${HOME}/.bun/install/global/node_modules" 2>/dev/null | grep -E 'krt-bo004|^esbuild$' || echo "no probe package in the real global link registry"
  echo "=== sentinel token scan over probe output ==="
  if grep -rn "$SENTINEL" "$OUT" >/dev/null 2>&1; then echo "UNEXPECTED token leak"; else echo "no sentinel token present"; fi
} >"$OUT/10-hygiene.log" 2>&1

echo "--- results.tsv ---"
cat "$OUT/results.tsv"
echo "--- hygiene ---"
cat "$OUT/10-hygiene.log"
