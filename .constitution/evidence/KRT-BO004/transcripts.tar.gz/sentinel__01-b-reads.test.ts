import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { test } from "bun:test";
import { bumpSharedCounter } from "./shared-counter.ts";

declare global {
  var __KRT_BO004_SENTINEL__: string | undefined;
}

interface SentinelRecord {
  readonly file: string;
  readonly moduleCounterSeen: number;
  readonly globalSeen: string | null;
}

test("01-b-reads: module state and a global sentinel", () => {
  const globalSeen = globalThis.__KRT_BO004_SENTINEL__ ?? null;
  const moduleCounterSeen = bumpSharedCounter();
  const record: SentinelRecord = {
    file: "01-b-reads.test.ts",
    moduleCounterSeen,
    globalSeen,
  };
  writeFileSync(
    join(import.meta.dir, "markers", "01-b-reads.json"),
    `${JSON.stringify(record, null, 2)}\n`
  );
  console.log(`[SENTINEL-01-b] ${JSON.stringify(record)}`);
});
