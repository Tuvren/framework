import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { test } from "bun:test";
import { bumpSharedCounter } from "./shared-counter.ts";

declare global {
  var __KRT_BO004_SENTINEL__: string | undefined;
}

interface SentinelRecord {
  readonly file: string;
  readonly moduleCounterSeen: number;
  readonly globalSeenBeforeWrite: string | null;
  readonly globalWritten: string;
}

test("00-a-sets: module state and a global sentinel", () => {
  const globalBefore = globalThis.__KRT_BO004_SENTINEL__ ?? null;
  const moduleCounterSeen = bumpSharedCounter();
  globalThis.__KRT_BO004_SENTINEL__ = "written-by-00-a";
  const record: SentinelRecord = {
    file: "00-a-sets.test.ts",
    moduleCounterSeen,
    globalSeenBeforeWrite: globalBefore,
    globalWritten: "written-by-00-a",
  };
  writeFileSync(
    join(import.meta.dir, "markers", "00-a-sets.json"),
    `${JSON.stringify(record, null, 2)}\n`
  );
  console.log(`[SENTINEL-00-a] ${JSON.stringify(record)}`);
});
