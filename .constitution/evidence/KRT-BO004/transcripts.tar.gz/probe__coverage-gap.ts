/**
 * KRT-BO004: which tracked test files does the canonical per-project `bun test`
 * discovery actually execute?
 *
 * Cross-references the tracked `git ls-files '*.test.ts' '*.spec.ts'` inventory
 * with the files reported by the JUnit reporter of each project's `test`
 * target, so a discovery gap (a tracked test file that no lane runs) is loud
 * rather than assumed.
 */
import { readFileSync } from "node:fs";
import { join } from "node:path";

const W = "/home/oscar/.cache/pi-subagent/framework/wf-bo-m4/lead-replay";

function attr(tag: string, name: string): string | null {
  return tag.match(new RegExp(`${name}="([^"]*)"`))?.[1] ?? null;
}

const rows = readFileSync(join(W, "raw/bun-test-projects.tsv"), "utf8")
  .trim()
  .split("\n")
  .map((line) => {
    const [project, cwd] = line.split("\t");
    return { project: project ?? "", cwd: cwd ?? "" };
  });

const tracked = readFileSync(join(W, "raw/tracked-tests.txt"), "utf8")
  .trim()
  .split("\n");

const reported = new Map<string, Set<string>>();
for (const { project, cwd } of rows) {
  const xml = readFileSync(join(W, "raw/matrix/ordinary", `${project}.junit.xml`), "utf8");
  const set = new Set<string>();
  for (const match of xml.matchAll(/<testsuite ([^>]*)>/g)) {
    const tag = match[1];
    if (tag === undefined) continue;
    const file = attr(tag, "file");
    if (file === null) continue;
    set.add(file.startsWith("/") ? file.replace(`${process.cwd()}/`, "") : join(cwd, file));
  }
  reported.set(project, set);
}

const ownerOf = new Map<string, string>();
for (const { project, cwd } of rows) {
  for (const f of tracked) {
    if (f.startsWith(`${cwd}/`)) ownerOf.set(f, `${project} (${cwd})`);
  }
}

const uncovered: string[] = [];
for (const f of tracked) {
  const owner = ownerOf.get(f);
  if (owner === undefined) {
    uncovered.push(`${f}\tNO-BUN-PROJECT`);
    continue;
  }
  const project = owner.slice(0, owner.indexOf(" "));
  const set = reported.get(project);
  if (set === undefined || !set.has(f)) uncovered.push(`${f}\tUNREPORTED-BY-${project}`);
}

console.log("=== tracked files not executed by any Bun-backed project `test` target ===");
for (const line of uncovered) console.log(line);
console.log(`\ntracked total: ${tracked.length}`);
console.log(`covered by Bun project targets: ${tracked.length - uncovered.length}`);
console.log(`uncovered: ${uncovered.length}`);
