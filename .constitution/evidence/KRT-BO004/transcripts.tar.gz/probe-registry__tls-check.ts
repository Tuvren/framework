/**
 * KRT-BO004 TLS verification sub-probe.
 *
 * Establishes whether a Bun 1.4.2 client actually validates certificates, so
 * the HTTPS leg of the registry probe is either a verified HTTPS endpoint or a
 * recorded limitation.
 *
 * Usage: bun tls-check.ts <https-base-url> <scratch-ca-pem>
 */
const httpsBase = process.argv[2];
const caPath = process.argv[3];

if (httpsBase === undefined || caPath === undefined) {
  throw new Error("usage: bun tls-check.ts <https-base-url> <scratch-ca-pem>");
}

interface ProbeResult {
  readonly case: string;
  readonly ok: boolean;
  readonly status?: number;
  readonly error?: string;
}

async function probe(caseName: string, url: string): Promise<ProbeResult> {
  try {
    const response = await fetch(url);
    await response.text();
    return { case: caseName, ok: true, status: response.status };
  } catch (error: unknown) {
    return {
      case: caseName,
      ok: false,
      error: error instanceof Error ? `${error.name}: ${error.message}` : String(error),
    };
  }
}

const results: ProbeResult[] = [];
results.push(await probe("loopback-self-signed-no-extra-ca", `${httpsBase}/`));
results.push(
  await probe("public-default-ca", "https://registry.npmjs.org/krt-bo004-not-a-package")
);

const loopbackWithCa = Bun.spawnSync({
  cmd: [
    "bun",
    "-e",
    `const r = await fetch("${httpsBase}/"); console.log(JSON.stringify({status: r.status}));`,
  ],
  env: { ...process.env, NODE_EXTRA_CA_CERTS: caPath },
});
results.push({
  case: "loopback-with-scratch-ca",
  ok: loopbackWithCa.exitCode === 0,
  error: loopbackWithCa.exitCode === 0 ? undefined : loopbackWithCa.stderr.toString().split("\n")[0],
});

const publicWithCa = Bun.spawnSync({
  cmd: [
    "bun",
    "-e",
    'const r = await fetch("https://registry.npmjs.org/krt-bo004-not-a-package"); console.log(JSON.stringify({status: r.status}));',
  ],
  env: { ...process.env, NODE_EXTRA_CA_CERTS: caPath },
});
results.push({
  case: "public-with-scratch-extra-ca",
  ok: publicWithCa.exitCode === 0,
  error: publicWithCa.exitCode === 0 ? undefined : publicWithCa.stderr.toString().split("\n")[0],
});

for (const result of results) {
  console.log(JSON.stringify(result));
}
