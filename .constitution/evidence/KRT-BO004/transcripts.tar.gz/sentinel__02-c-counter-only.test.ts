import { test } from "bun:test";
import { bumpSharedCounter } from "./shared-counter.ts";

test("02-c-counter-only: third file module counter", () => {
  console.log(`[SENTINEL-02-c] {"moduleCounterSeen":${bumpSharedCounter()}}`);
});
