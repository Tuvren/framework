#!/usr/bin/env bash
# KRT-BO004 one-command rerun of every measured probe.
#
# Everything runs inside the scratch root; no repository tracked file is
# written. The probes intentionally run the same inventories twice (ordinary and
# --isolate), because that comparison is the milestone's acceptance evidence.
#
# Usage: bash run-all-probes.sh
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRATCH_ROOT="$(dirname "$SCRIPT_DIR")"
export LC_ALL=C

echo "=== HEAD ==="
git -C /home/oscar/GitHub/Tuvren/framework-bo rev-parse HEAD | tee "$SCRATCH_ROOT/raw/head.txt"
echo "=== bun --version ==="
bun --version | tee "$SCRATCH_ROOT/raw/bun-version.txt"
echo "=== bun test --help ==="
bun test --help >"$SCRATCH_ROOT/raw/bun-test-help.txt" 2>&1
echo "captured $(wc -l <"$SCRATCH_ROOT/raw/bun-test-help.txt") help lines"

echo "=== 1. default-isolation sentinel ==="
bash "$SCRIPT_DIR/probe-isolation-default.sh" "$SCRATCH_ROOT"

echo "=== 2. per-project ordinary sweep ==="
bash "$SCRIPT_DIR/run-project-matrix.sh" ordinary

echo "=== 3. per-project --isolate sweep ==="
bash "$SCRIPT_DIR/run-project-matrix.sh" isolate

echo "=== 4. per-file JUnit comparison ==="
bun "$SCRIPT_DIR/compare-matrix-junit.ts" | tee "$SCRATCH_ROOT/raw/matrix/junit-comparison.txt"

echo "=== 5. tracked-file coverage gap ==="
bun "$SCRIPT_DIR/coverage-gap.ts" | tee "$SCRATCH_ROOT/raw/matrix/coverage-gap.txt"

echo "=== 6. tools/** test files (no Nx owner) ==="
bash "$SCRIPT_DIR/run-tools-matrix.sh"

echo "=== 7. trust scoping ==="
bash "$SCRIPT_DIR/probe-trust.sh" "$SCRATCH_ROOT"

echo "=== 8. registry credential scoping ==="
bash "$SCRIPT_DIR/registry-scripts/make-fixtures.sh" "$SCRATCH_ROOT"
bash "$SCRIPT_DIR/registry-scripts/probe-registry-auth.sh" "$SCRATCH_ROOT"

echo "=== done; raw logs under $SCRATCH_ROOT/raw ==="
