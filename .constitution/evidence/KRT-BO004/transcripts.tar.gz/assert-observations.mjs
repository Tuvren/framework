import{readFile}from"node:fs/promises";
const root=process.argv[2];if(!root)throw new Error("Pass raw output root");
const rows=async path=>(await readFile(root+"/"+path,"utf8")).trim().split("\n").slice(1).filter(Boolean).map(line=>line.replaceAll("\\t","\t").split("\t"));
const require=(condition,message)=>{if(!condition)throw new Error(message);};
const ordinary=await rows("matrix/results-ordinary.tsv"),isolated=await rows("matrix/results-isolate.tsv");
require(ordinary.length===29&&isolated.length===29,"Expected29 projects in BOTH modes");
let files=0,cases=0;
for(const a of ordinary){const b=isolated.find(x=>x[1]===a[1]);require(b,"Missing isolated project"+a[1]);require(a[3]==="0"&&b[3]==="0"&&a[5]==="0"&&b[5]==="0","Project failed"+a[1]);require(a[4]===b[4]&&a[5]===b[5]&&a[6]===b[6]&&a[7]===b[7],"Outcome mismatch"+a[1]);files+=Number(a[7]);cases+=Number(a[4]);}
require(files===179&&cases===1596,"Expected179files/1596cases");
const tools=await rows("matrix/results-tools.tsv");require(tools.length===18,"Expected9tools files x2modes");
for(const a of tools.filter(x=>x[1]==="ordinary")){const b=tools.find(x=>x[0]===a[0]&&x[1]==="isolate");require(b&&a[2]==="0"&&b[2]==="0"&&a[3]===b[3]&&a[4]==="0"&&b[4]==="0","Tools mismatch"+a[0]);}
const trust=await rows("trust/results.tsv");require(trust.length===8,"Expected8 local-trust scenarios");
for(const r of trust){require(r[2]==="exit=0","Trust install failed"+r[0]);const allow=/^(2-|6-|7-|8-)/u.test(r[0]);require(allow?!r[3].includes("markers=[]"):r[3].includes("markers=[]"),"Trust marker mismatch"+r[0]);}
const registry=await rows("registry/results.tsv");require(registry.length===14,"Expected14registry scenarios");
for(const r of registry){const expected=/^s(?:3-|4-|11-|14-)/u.test(r[0])?1:0;require(r[2]==="exit="+expected,"Registry exit mismatch"+r[0]);}
const scope=await rows("registry/scoping-summary.tsv");require(scope.length===14,"Expected14request summaries");
for(const r of scope)require(r[3]==="0","Sentinel forwarded to plain listener"+r[0]);
for(const name of ["s1-http-authorized","s2-bunfig-registry","s8-https-authorized"]){const r=scope.find(x=>x[0]===name);require(r&&Number(r[2])>0,"Authorized origin missing token"+name);}
const scan=await readFile(root+"/registry/sentinel-scan.log","utf8");require(scan.includes("no sentinel token"),"Output leakage scan missing");
const markerText=await readFile(root+"/isolate-default/results.tsv","utf8");
const markerRows=markerText.trim().split("\n").map(l=>l.replaceAll("\\t","\t").split("\t"));
const bare=markerRows.find(r=>r[0]==="bare-default"),iso=markerRows.find(r=>r[0]==="explicit-isolate");
require(bare&&bare.includes("exit=0")&&bare.includes("00-a.counter=1")&&bare.includes("01-b.counter=2")&&bare.some(v=>v.startsWith("01-b.globalSeen=")&&v.includes("written-by-00-a")),"Default sharing probe missing");
require(iso&&iso.includes("exit=0")&&iso.includes("00-a.counter=1")&&iso.includes("01-b.counter=1")&&iso.includes("01-b.globalSeen=null"),"Explicit isolation missing");
console.log(JSON.stringify({projects:29,files:179,cases:1596,toolsFiles:9,localTrustScenarios:8,registryScenarios:14,authorizedOriginToken:true,crossOriginToken:false,outputLeak:false,defaultIsolated:false,explicitIsolated:true}));
