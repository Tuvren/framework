#!/usr/bin/env bash
# KRT-BO004 registry-auth probe: measure how Bun 1.4.2 scopes registry
# credentials with a local scratch registry and a synthetic sentinel token.
#
# Proves / measures, without publishing and without touching any real
# credential file or registry:
#   1. an authorized origin receives the exact sentinel token;
#   2. a mismatched host key does not (401, no Authorization sent);
#   3. same-origin redirects vs cross-host / cross-port redirects;
#   4. HTTPS -> HTTP downgrade behavior with a scratch certificate;
#   5. no sentinel token appears in install error/verbose output;
#   6. lifecycle-script trust scoping for registry installs.
#
# Layout: scripts live in scratch/registry-scripts/, all data (fixtures,
# certificates, projects, caches, request log, ports) in scratch/registry/.
# Every listener is stopped at the end of the run.
#
# Usage: bash probe-registry-auth.sh [scratch-root]
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRATCH_ROOT="${1:-$(dirname "$(dirname "$SCRIPT_DIR")")}"
R="$SCRATCH_ROOT/scratch/registry"
OUT="$SCRATCH_ROOT/raw/registry"
CACHE_ROOT="$SCRATCH_ROOT/scratch/registry-cache"
SENTINEL="krt-bo004-sentinel-token-0f3a9c"
VERSION="9.9.9-krtbo004"
OPENSSL="/nix/store/clvbx203wyqkdnqc5ngyhjlhcqn5s9x9-openssl-3.6.2-bin/bin/openssl"
export LC_ALL=C

mkdir -p "$OUT" "$CACHE_ROOT" "$R"
rm -f "$OUT"/*.log "$OUT"/*.txt "$OUT"/results.tsv "$OUT"/scoping-summary.tsv
rm -rf "$R/certs" "$R/markers" "$R/projects" "$CACHE_ROOT"
mkdir -p "$R/certs" "$R/markers" "$CACHE_ROOT"

# --- scratch TLS material --------------------------------------------------
"$OPENSSL" version >"$OUT/openssl-version.log" 2>&1
"$OPENSSL" req -x509 -newkey rsa:2048 -nodes -days 2 \
  -keyout "$R/certs/ca.key" -out "$R/certs/ca.pem" \
  -subj "/CN=krt-bo004-scratch-ca" -addext "basicConstraints=critical,CA:TRUE" \
  >>"$OUT/openssl-version.log" 2>&1
"$OPENSSL" req -newkey rsa:2048 -nodes -days 2 \
  -keyout "$R/certs/server.key" -out "$R/certs/server.csr" \
  -subj "/CN=127.0.0.1" >>"$OUT/openssl-version.log" 2>&1
printf 'subjectAltName=IP:127.0.0.1,DNS:localhost\n' >"$R/certs/san.cnf"
"$OPENSSL" x509 -req -days 2 -in "$R/certs/server.csr" -CA "$R/certs/ca.pem" \
  -CAkey "$R/certs/ca.key" -CAcreateserial -out "$R/certs/server.pem" \
  -extfile "$R/certs/san.cnf" >>"$OUT/openssl-version.log" 2>&1
head -1 "$OUT/openssl-version.log"

# --- start the scratch registry -------------------------------------------
KRT_BO004_REGISTRY_ROOT="$R" \
KRT_BO004_SENTINEL="$SENTINEL" \
KRT_BO004_TLS_CERT="$R/certs/server.pem" \
KRT_BO004_TLS_KEY="$R/certs/server.key" \
  bun "$SCRIPT_DIR/registry-server.ts" >"$OUT/registry-server.log" 2>&1 &
SERVER_PID=$!
echo "$SERVER_PID" >"$OUT/registry-server.pid"

for _ in $(seq 1 100); do
  [[ -f "$R/ports.json" ]] && break
  sleep 0.1
done
if [[ ! -f "$R/ports.json" ]]; then
  echo "registry did not start; log follows" >&2
  cat "$OUT/registry-server.log" >&2
  exit 1
fi

read_base() { python3 -c "import json;print(json.load(open('$R/ports.json'))$1)"; }
HTTP_AUTH="$(read_base "['bases']['httpAuth']")"
HTTP_PLAIN="$(read_base "['bases']['httpPlain']")"
HTTPS_AUTH="$(read_base "['bases']['https']")"
PORT_AUTH="$(read_base "['httpAuth']")"
PORT_PLAIN="$(read_base "['httpPlain']")"
PORT_TLS="$(read_base "['httpsAuth']")"
cp "$R/ports.json" "$OUT/ports.json"
echo "base: http-auth=$HTTP_AUTH http-plain=$HTTP_PLAIN https-auth=$HTTPS_AUTH"

# --- TLS verification sub-probe (fetch client) -----------------------------
bun "$SCRIPT_DIR/tls-check.ts" "$HTTPS_AUTH" "$R/certs/ca.pem" >"$OUT/tls-verification-probe.log" 2>&1
echo "tls verification probe:"
cat "$OUT/tls-verification-probe.log"

printf 'scenario\tpackage\texit\tmarkers\tlog\n' >"$OUT/results.tsv"

log_lines() { if [[ -f "$R/requests.jsonl" ]]; then wc -l <"$R/requests.jsonl" | tr -d ' '; else echo 0; fi; }

summarize_since() {
  local start="$1" file="$2"
  python3 - "$start" "$R/requests.jsonl" <<'PY' >"$file" 2>&1
import json, sys
start = int(sys.argv[1])
with open(sys.argv[2]) as fh:
    rows = [json.loads(line) for line in fh if line.strip()]
for row in rows[start:]:
    print(
        f"{row['listener']:11s} {row['method']:5s} {row['path']:74s} "
        f"auth={row['hasAuthorization']} scheme={row['authorizationScheme']} "
        f"sentinel={row['authorizationMatchesSentinel']}"
    )
PY
}

# make_project <dir> <registry-base> <token-host-key|-> <extra-json> <config-mode>
# config-mode: npmrc (default) | bunfig (registry in bunfig.toml, token in .npmrc)
make_project() {
  local dir="$1" base="$2" token_host="$3" extra_json="${4:-}" mode="${5:-npmrc}"
  mkdir -p "$dir"
  cat >"$dir/package.json" <<EOF
{
  "name": "krt-bo004-consumer-$(basename "$dir")",
  "version": "1.0.0",
  "private": true,
  "type": "module"$extra_json
}
EOF
  if [[ "$mode" == "bunfig" ]]; then
    printf '[install]\nregistry = "%s/"\n' "$base" >"$dir/bunfig.toml"
    {
      if [[ "$token_host" != "-" ]]; then
        printf '//%s/:_authToken=%s\n' "$token_host" "$SENTINEL"
      fi
    } >"$dir/.npmrc"
  else
    {
      printf 'registry=%s/\n' "$base"
      if [[ "$token_host" != "-" ]]; then
        printf '//%s/:_authToken=%s\n' "$token_host" "$SENTINEL"
      fi
    } >"$dir/.npmrc"
  fi
}

# run_scenario <label> <dir> <pkg> [extra args...]
SCENARIO_ENV=()
run_scenario() {
  local label="$1" dir="$2" pkg="$3"
  shift 3
  local start
  start="$(log_lines)"
  local cache="$CACHE_ROOT/$label"
  mkdir -p "$cache" "$R/markers/$label"
  ( cd "$dir" && KRT_BO004_MARKER_DIR="$R/markers/$label" timeout 300 \
      env "${SCENARIO_ENV[@]}" bun install "$pkg@$VERSION" --cache-dir "$cache" "$@" ) >"$OUT/$label.log" 2>&1
  local code=$?
  local markers
  markers="$(find "$R/markers/$label" -name '*.marker' -printf '%f ' 2>/dev/null | sed 's/ $//')"
  summarize_since "$start" "$OUT/$label.requests.txt"
  printf '%s\t%s\texit=%s\tmarkers=[%s]\tlog=%s\n' "$label" "$pkg" "$code" "$markers" "$OUT/$label.log" >>"$OUT/results.tsv"
  printf '%-30s exit=%-3s markers=[%s]\n' "$label" "$code" "$markers"
}

# --- scenarios -------------------------------------------------------------
P="$R/projects"

make_project "$P/s1-http-authorized" "$HTTP_AUTH" "127.0.0.1:$PORT_AUTH"
run_scenario "s1-http-authorized" "$P/s1-http-authorized" "krt-bo004-dep"

make_project "$P/s2-bunfig-registry" "$HTTP_AUTH" "127.0.0.1:$PORT_AUTH" "" "bunfig"
run_scenario "s2-bunfig-registry" "$P/s2-bunfig-registry" "krt-bo004-dep"

make_project "$P/s3-mismatched-host" "$HTTP_AUTH" "localhost:$PORT_AUTH"
run_scenario "s3-mismatched-host" "$P/s3-mismatched-host" "krt-bo004-dep"

make_project "$P/s4-no-token" "$HTTP_AUTH" "-"
run_scenario "s4-no-token" "$P/s4-no-token" "krt-bo004-dep"

make_project "$P/s5-redir-same" "$HTTP_AUTH" "127.0.0.1:$PORT_AUTH"
run_scenario "s5-redir-same" "$P/s5-redir-same" "krt-bo004-redir-same"

make_project "$P/s6-redir-crosshost" "$HTTP_AUTH" "127.0.0.1:$PORT_AUTH"
run_scenario "s6-redir-crosshost" "$P/s6-redir-crosshost" "krt-bo004-redir-crosshost"

make_project "$P/s7-redir-crossport" "$HTTP_AUTH" "127.0.0.1:$PORT_AUTH"
run_scenario "s7-redir-crossport" "$P/s7-redir-crossport" "krt-bo004-redir-crossport"

make_project "$P/s8-https-authorized" "$HTTPS_AUTH" "127.0.0.1:$PORT_TLS"
SCENARIO_ENV=("NODE_EXTRA_CA_CERTS=$R/certs/ca.pem")
run_scenario "s8-https-authorized" "$P/s8-https-authorized" "krt-bo004-dep"
SCENARIO_ENV=()

make_project "$P/s9-https-crossport-redirect" "$HTTPS_AUTH" "127.0.0.1:$PORT_TLS"
SCENARIO_ENV=("NODE_EXTRA_CA_CERTS=$R/certs/ca.pem")
run_scenario "s9-https-crossport-redirect" "$P/s9-https-crossport-redirect" "krt-bo004-redir-crossport"
SCENARIO_ENV=()

make_project "$P/s10-https-downgrade" "$HTTPS_AUTH" "127.0.0.1:$PORT_TLS"
SCENARIO_ENV=("NODE_EXTRA_CA_CERTS=$R/certs/ca.pem")
run_scenario "s10-https-downgrade" "$P/s10-https-downgrade" "krt-bo004-downgrade"
SCENARIO_ENV=()

# HTTPS registry with the scratch CA deliberately NOT trusted.
make_project "$P/s11-https-untrusted-ca" "$HTTPS_AUTH" "127.0.0.1:$PORT_TLS"
SCENARIO_ENV=()
run_scenario "s11-https-untrusted-ca" "$P/s11-https-untrusted-ca" "krt-bo004-dep"

make_project "$P/s12-trusted-dep" "$HTTP_AUTH" "127.0.0.1:$PORT_AUTH" ',
  "trustedDependencies": ["krt-bo004-dep"]'
run_scenario "s12-trusted-dep" "$P/s12-trusted-dep" "krt-bo004-dep"

make_project "$P/s13-default-trusted-name" "$HTTP_AUTH" "127.0.0.1:$PORT_AUTH"
run_scenario "s13-default-trusted-name" "$P/s13-default-trusted-name" "esbuild"

make_project "$P/s14-verbose-failure" "$HTTP_AUTH" "localhost:$PORT_AUTH"
run_scenario "s14-verbose-failure" "$P/s14-verbose-failure" "krt-bo004-dep" "--verbose"

# --- stop listeners --------------------------------------------------------
kill "$SERVER_PID" 2>/dev/null
wait "$SERVER_PID" 2>/dev/null
sleep 0.3
{
  echo "=== listener shutdown check ==="
  for port in "$PORT_AUTH" "$PORT_PLAIN" "$PORT_TLS"; do
    if (exec 3<>"/dev/tcp/127.0.0.1/$port") 2>/dev/null; then
      echo "port $port STILL OPEN"
    else
      echo "port $port closed"
    fi
  done
} >"$OUT/listener-shutdown.log" 2>&1
cat "$OUT/listener-shutdown.log"

# --- scoping summary and sentinel hygiene ----------------------------------
{
  printf 'scenario\trequests\tsentinel-on-auth-listener\tsentinel-on-plain-listener\n'
  for f in "$OUT"/s*.requests.txt; do
    scenario="$(basename "$f" .requests.txt)"
    total="$(wc -l <"$f" | tr -d ' ')"
    auth="$(grep 'sentinel=True' "$f" 2>/dev/null | wc -l | tr -d ' ')"
    plain="$(grep 'http-plain' "$f" 2>/dev/null | grep 'sentinel=True' 2>/dev/null | wc -l | tr -d ' ')"
    printf '%s\t%s\t%s\t%s\n' "$scenario" "$total" "$auth" "$plain"
  done
} | tee "$OUT/scoping-summary.tsv"

{
  echo "=== sentinel token scan over probe output (scratch client config files excluded by design) ==="
  if grep -rn "$SENTINEL" "$OUT" 2>/dev/null | grep -v '\.requests\.txt'; then
    echo "UNEXPECTED: sentinel token present in probe output"
  else
    echo "no sentinel token in install output, verbose output, request summaries, or registry log"
  fi
  echo "=== registry request log never stores credential values ==="
  grep -c 'sentinel' "$R/requests.jsonl" 2>/dev/null || echo 0
} >"$OUT/sentinel-scan.log" 2>&1
cat "$OUT/sentinel-scan.log"

echo "--- results.tsv ---"
cat "$OUT/results.tsv"
