#!/usr/bin/env bash
# KRT-BO004 reusable probe: measure whether Bun test isolation is the default.
#
# Runs a disposable two-file global-state/module-cache sentinel under a scratch
# directory with several explicit flag combinations, and records the observed
# marker contents. No repository file is read or written by this probe.
#
# Usage: bash probe-isolation-default.sh [scratch-root]
#   scratch-root defaults to the directory holding this script's parent.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRATCH_ROOT="${1:-$(dirname "$SCRIPT_DIR")}"
SENTINEL_DIR="$SCRATCH_ROOT/scratch/sentinel"
OUT_DIR="$SCRATCH_ROOT/raw/isolate-default"
export LC_ALL=C

mkdir -p "$OUT_DIR" "$SENTINEL_DIR/markers"
: >"$OUT_DIR/results.tsv"

run_case() {
  local label="$1"
  shift
  rm -f "$SENTINEL_DIR"/markers/*.json
  local log="$OUT_DIR/${label}.log"
  (
    cd "$SENTINEL_DIR" || exit 1
    printf '$ bun test %s\n' "$*" >"$log"
    bun test "$@" >>"$log" 2>&1
    printf 'exit=%s\n' "$?" >>"$log"
  )
  local exit_code
  exit_code="$(grep -o 'exit=[0-9]*' "$log" | tail -1 | cut -d= -f2)"
  local a_counter b_counter b_global c_counter
  a_counter="$(sed -n 's/.*"moduleCounterSeen":\([0-9]*\).*/\1/p' "$OUT_DIR/../isolate-default/${label}.log" 2>/dev/null | head -1)"
  a_counter="$(grep -o '\[SENTINEL-00-a\].*' "$log" | sed -E 's/.*"moduleCounterSeen":([0-9]+).*/\1/' | head -1)"
  b_counter="$(grep -o '\[SENTINEL-01-b\].*' "$log" | sed -E 's/.*"moduleCounterSeen":([0-9]+).*/\1/' | head -1)"
  b_global="$(grep -o '\[SENTINEL-01-b\].*' "$log" | sed -E 's/.*"globalSeen":("[^"]*"|null).*/\1/' | head -1)"
  c_counter="$(grep -o '\[SENTINEL-02-c\].*' "$log" | sed -E 's/.*"moduleCounterSeen":([0-9]+).*/\1/' | head -1)"
  printf '%s\tflags=%s\texit=%s\t00-a.counter=%s\t01-b.counter=%s\t01-b.globalSeen=%s\t02-c.counter=%s\n' \
    "$label" "$*" "$exit_code" "$a_counter" "$b_counter" "$b_global" "$c_counter" | tee -a "$OUT_DIR/results.tsv"
}

run_case "bare-default"
run_case "explicit-isolate" --isolate
run_case "explicit-no-isolate" --no-isolate
run_case "parallel-2" --parallel=2
run_case "parallel-2-no-isolate" --parallel=2 --no-isolate
run_case "isolate-then-no-isolate" --isolate --no-isolate
run_case "no-isolate-then-isolate" --no-isolate --isolate
run_case "explicit-order-no-isolate" --no-isolate 01-b-reads.test.ts 00-a-sets.test.ts
run_case "explicit-order-isolate" --isolate 01-b-reads.test.ts 00-a-sets.test.ts
run_case "rerun-each-2" --rerun-each=2

echo "--- results.tsv ---"
cat "$OUT_DIR/results.tsv"
