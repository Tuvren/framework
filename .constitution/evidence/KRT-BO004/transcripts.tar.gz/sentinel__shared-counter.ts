/**
 * KRT-BO004 sentinel helper: module-level mutable state that two test files
 * both import. If the runner gives each test file a fresh module registry,
 * each file observes counter === 1. If the runner shares one registry across
 * the files of a process/worker, the second file observes 2.
 */
let counter = 0;

export function bumpSharedCounter(): number {
  counter += 1;
  return counter;
}

export function readSharedCounter(): number {
  return counter;
}
