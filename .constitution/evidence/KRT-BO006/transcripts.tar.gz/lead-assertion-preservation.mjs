import { strict as assert } from "node:assert";
import { readFile } from "node:fs/promises";
import ts from "/home/oscar/GitHub/Tuvren/framework-bo/node_modules/typescript/lib/typescript.js";
const root = "/home/oscar/GitHub/Tuvren/framework-bo";
const paths = ["typescript/host/repl/test/repl-test-helpers.ts", "typescript/host/repl/test/repl.aimock-openai.test.ts", "typescript/host/repl/test/repl.aimock-matrix.test.ts"];
function assertions(text, path) {
  const file = ts.createSourceFile(path, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const found = new Map();
  function visit(node, context) {
    let currentContext = context;
    if (ts.isFunctionDeclaration(node) && node.name) currentContext = node.name.text;
    if (ts.isCallExpression(node) && node.expression.getText(file) === "test" && ts.isStringLiteral(node.arguments[0])) currentContext = node.arguments[0].text;
    if (ts.isCallExpression(node) && ts.isPropertyAccessExpression(node.expression)) {
      const name = node.expression.name.text;
      const receiver = node.expression.expression.getText(file);
      if (/^to[A-Z]/.test(name) && /^expect\(/.test(receiver)) {
        const key = JSON.stringify([currentContext, name, receiver.includes(".not") ? "not" : "positive", node.arguments.map(a => a.getText(file).replace(/\s+/g, ""))]);
        found.set(key, (found.get(key) ?? 0) + 1);
      }
    }
    ts.forEachChild(node, child => visit(child, currentContext));
  }
  visit(file, "top-level");
  return found;
}
let total = 0;
for (const path of paths) {
  const old = Bun.spawn(["git", "show", "672711d:" + path], { cwd: root, stdout: "pipe", stderr: "pipe" });
  const oldText = await new Response(old.stdout).text();
  assert.equal(await old.exited, 0);
  const currentText = await readFile(root + "/" + path, "utf8");
  const before = assertions(oldText, path);
  const after = assertions(currentText, path);
  let count = 0;
  for (const [key, n] of before) {
    assert.ok((after.get(key) ?? 0) >= n, path + ": removed/changed matcher or expected value " + key);
    count += n;
  }
  total += count;
  console.log(path + ": preserved " + count + " matcher/expected-value assertions in their original named test/helper contexts");
}
console.log("Preserved total=" + total + ". Actual subject expressions and guard semantics require the companion source diff review.");

