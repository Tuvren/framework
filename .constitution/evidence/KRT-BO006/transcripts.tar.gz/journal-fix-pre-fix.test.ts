/**
 * Copyright 2026 Oscar Yáñez Cisterna (@SkrOYC)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { describe, expect, test } from "bun:test";
import type { JournalBody } from "@copilotkit/aimock";
import { isChatCompletionBody, LLMock } from "@copilotkit/aimock";
import {
  assertStructuredResponseFormat,
  hasApprovalToolContinuation,
  hasSearchToolContinuation,
} from "./repl-test-helpers.ts";

/**
 * Journal bodies that are not chat-completion requests. `JournalBody` is
 * `ChatCompletionRequest | Record<string, unknown>`, and aimock's own guard
 * discriminates on `messages` + `model`, so these are the shapes the host-repl
 * helpers must reject explicitly instead of reading a chat-only field off them.
 */
const NON_CHAT_JOURNAL_BODIES: readonly (JournalBody | null | undefined)[] = [
  null,
  undefined,
  { model: "gpt-4o-mini" },
  { messages: "Run tools", model: "gpt-4o-mini" },
  { model: "gpt-4o-mini-2024-07-18", training_file: "file-abc123" },
  {
    __aimock_truncated: true,
    note: "body truncated by aimock journal cap (64 KB limit)",
    originalByteSize: 70_000,
  },
];

const CHAT_COMPLETION_BODY: JournalBody = {
  messages: [
    {
      content: "Run streaming",
      role: "user",
    },
  ],
  model: "gpt-4o-mini",
};

const SEARCH_CONTINUATION_BODY: JournalBody = {
  messages: [
    {
      role: "assistant",
      tool_calls: [
        {
          function: {
            arguments: JSON.stringify({ query: "docs" }),
            name: "search",
          },
          id: "aimock-call-search",
          type: "function",
        },
      ],
    },
    {
      content: JSON.stringify({
        hits: [{ title: "Tuvren", url: "https://example.invalid/tuvren" }],
        query: "docs",
      }),
      role: "tool",
      tool_call_id: "aimock-call-search",
    },
  ],
  model: "gpt-4o-mini",
};

const APPROVAL_CONTINUATION_BODY: JournalBody = {
  messages: [
    {
      role: "assistant",
      tool_calls: [
        {
          function: {
            arguments: JSON.stringify({ query: "latest status" }),
            name: "search",
          },
          id: "aimock-call-search",
          type: "function",
        },
        {
          function: {
            arguments: JSON.stringify({
              subject: "Status update",
              to: "ops@example.com",
            }),
            name: "email",
          },
          id: "aimock-call-email",
          type: "function",
        },
      ],
    },
    {
      content: JSON.stringify({
        hits: [{ title: "Tuvren", url: "https://example.invalid/tuvren" }],
        query: "latest status",
      }),
      role: "tool",
      tool_call_id: "aimock-call-search",
    },
    {
      content: JSON.stringify({
        approval: {
          editedInput: {
            subject: "Edited status update",
            to: "ops@example.com",
          },
          originalInput: {
            subject: "Status update",
            to: "ops@example.com",
          },
          type: "edit",
        },
        result: { sent: true, to: "ops@example.com" },
      }),
      role: "tool",
      tool_call_id: "aimock-call-email",
    },
  ],
  model: "gpt-4o-mini",
};

const STRUCTURED_CHAT_BODY: JournalBody = {
  messages: [
    {
      content: "Run structured",
      role: "user",
    },
  ],
  model: "gpt-4o-mini",
  response_format: {
    json_schema: {
      name: "repl_summary",
      schema: {
        properties: {
          scenario: { type: "string" },
          status: { type: "string" },
        },
        required: ["scenario", "status"],
        type: "object",
      },
    },
    type: "json_schema",
  },
};

describe("repl aimock journal body narrowing", () => {
  test("isChatCompletionBody rejects every non-chat journal shape", () => {
    for (const body of NON_CHAT_JOURNAL_BODIES) {
      expect(isChatCompletionBody(body)).toBe(false);
    }

    expect(isChatCompletionBody(CHAT_COMPLETION_BODY)).toBe(true);
    expect(isChatCompletionBody(SEARCH_CONTINUATION_BODY)).toBe(true);
    expect(isChatCompletionBody(APPROVAL_CONTINUATION_BODY)).toBe(true);
    expect(isChatCompletionBody(STRUCTURED_CHAT_BODY)).toBe(true);
  });

  test("continuation helpers reject non-chat journal bodies explicitly", () => {
    for (const body of NON_CHAT_JOURNAL_BODIES) {
      expect(hasSearchToolContinuation(body)).toBe(false);
      expect(hasApprovalToolContinuation(body)).toBe(false);
    }
  });

  test("continuation helpers still recognize real chat continuation bodies", () => {
    expect(hasSearchToolContinuation(SEARCH_CONTINUATION_BODY)).toBe(true);
    expect(hasApprovalToolContinuation(APPROVAL_CONTINUATION_BODY)).toBe(true);
    expect(hasSearchToolContinuation(APPROVAL_CONTINUATION_BODY)).toBe(false);
    expect(hasApprovalToolContinuation(SEARCH_CONTINUATION_BODY)).toBe(false);
  });

  test("assertStructuredResponseFormat rejects non-chat bodies and validates json_schema", () => {
    for (const body of NON_CHAT_JOURNAL_BODIES) {
      expect(() => assertStructuredResponseFormat(body)).toThrow(
        "structured response_format requires a chat completion request body"
      );
    }

    expect(() => assertStructuredResponseFormat(CHAT_COMPLETION_BODY)).toThrow(
      "structured response_format was not an object"
    );

    assertStructuredResponseFormat(STRUCTURED_CHAT_BODY);
  });

  test("rejects a non-chat body the aimock journal actually recorded", async () => {
    const mock = new LLMock({
      logLevel: "silent",
      port: 0,
    });

    await mock.start();

    try {
      const response = await fetch(`${mock.url}/v1/fine_tuning/jobs`, {
        body: JSON.stringify({
          model: "gpt-4o-mini-2024-07-18",
          training_file: "file-abc123",
        }),
        headers: { "content-type": "application/json" },
        method: "POST",
      });
      const journalBody = mock.getLastRequest()?.body ?? null;

      expect(response.status).toBe(200);
      expect(isChatCompletionBody(journalBody)).toBe(false);
      expect(hasSearchToolContinuation(journalBody)).toBe(false);
      expect(hasApprovalToolContinuation(journalBody)).toBe(false);
    } finally {
      await mock.stop();
    }
  });

  test("rejects the journal-cap truncation marker aimock substitutes for an oversized body", async () => {
    const mock = new LLMock({
      logLevel: "silent",
      port: 0,
    });

    await mock.start();

    try {
      const response = await fetch(`${mock.url}/v1/chat/completions`, {
        body: JSON.stringify({
          messages: [{ content: "x".repeat(70_000), role: "user" }],
          model: "gpt-4o-mini",
        }),
        headers: { "content-type": "application/json" },
        method: "POST",
      });
      const journalBody = mock.getLastRequest()?.body ?? null;

      expect(response.status).toBe(404);
      expect(isChatCompletionBody(journalBody)).toBe(false);
      expect(hasSearchToolContinuation(journalBody)).toBe(false);
      expect(hasApprovalToolContinuation(journalBody)).toBe(false);
    } finally {
      await mock.stop();
    }
  });
});
