---
epic: EPIC-BO
epic_file: .constitution/tasks/epics/EPIC-BO-bun-refresh.yaml
kind: epic
planned_by: self
wave: 0
merge_position: 1
lanes_in_wave: 1
worktree: /home/oscar/GitHub/Tuvren/framework-bo
branch: chores/epic-bo-bun-refresh-buffer-ownership
base_branch: master
planned_at_commit: dff2df9f8dd5dd37fe4054081bcf22479745bd82
siblings: []
models:
  epic_lead: { runtime: codex, model: inherited-session }
  worker: { runtime: pi, model: opencode-go/deepseek-v4.1-flash }
  spec_patch_worker: { runtime: pi, model: opencode-go/deepseek-v4.1-flash }
  milestone_reviewer: { runtime: codex, model: gpt-5.6-sol }
  fix_worker: { runtime: pi, model: opencode-go/deepseek-v4.1-flash }
review_panel:
  - { runtime: codex, model: gpt-5.6-sol, mode: full }
  - { runtime: codex, model: gpt-6.1-sol, mode: full }
pr_review:
  fix_worker: { runtime: pi, model: opencode-go/deepseek-v4.1-flash }
  review_escalate_at: 4
  stop: one verification round with no new Act-on finding
autonomy:
  policy:
    - { trigger: blocker, action: adopt_recommendation }
    - { trigger: open_decision, action: adopt_recommendation }
    - { trigger: plan_drift, action: amend_plan }
    - { trigger: spec_drift, action: amend_plan }
    - { trigger: test_failure, action: retry, max_attempts: 3 }
    - { trigger: review_nonconvergence, action: escalate_strategy }
    - { trigger: rebase_conflict, action: resolve_and_rereview }
    - { trigger: budget_threshold, action: switch_to_fallback }
    - { trigger: stall, action: retry, max_attempts: 1 }
budget:
  usage_ceiling_note: "No ceiling: track usage, retain the selected models, and never switch or stop because of cost."
  threshold_pct: 100
  fallback_models: {}
liveness:
  stall_after_minutes: 120
  side_effects: [commit, push, worktree_change, pr_update, plan_amendment]
verbatim_project_rules:
  - "Use `bun` for package management and TypeScript runtime entry points."
  - "Read `docs/KrakenKernelSpecification.md` before changing kernel behavior."
  - "Read `docs/KrakenFrameworkSpecification.md` before changing framework behavior."
  - "Keep `contracts/`, `conformance/`, `interop/`, generated artifacts, and compatibility evidence aligned when semantics change."
  - "Make generators leave checked-in artifacts formatter-clean; do not rely on a one-off manual format after regeneration."
  - "Run `bun run services:up` once at the start of a session when postgres or another devenv-managed service is required. It wraps `devenv up -d` idempotently (a second call is a no-op instead of a hard failure), so it is safe to re-run. This is a manual session helper only — do not embed it inside scripts, Nx targets, or runner commands."
  - "Run `bun run services:down` (or `devenv processes down`) to stop all devenv-managed services cleanly at the end of a session or to recover from a stale daemon that is blocking a new start."
  - "Run `bun run verify` before claiming broad workspace readiness."
  - "Keep package-local tests near the package they verify."
  - "Validate public behavior and durable state, not object existence or generic completion."
open_decisions: []
---
# EPIC-BO execution plan

## Repository state
Source wave 1 contains only BO; standalone wave=0. Inspected clean master dff2df9.
The existing devenv profile is Bun 1.3.10, Weaver 0.21.2, PostgreSQL 17.9. Root packageManager is bun@1.3.11.
Ambient Bun 1.4.2 is not the repo profile. Unchanged memory tests pass 77/77 on repo Bun and fail precisely three dataView cases on 1.4.2.
Constitution validate has zero errors with the repo profile and four known future-OXC TS-004 warnings.
Legacy Weaver manifest and telemetry codegen reader are present; migration is missing.
Aimock manifest and stack pin remain 1.15.1. Registry latest is 1.43.0; its published ESM declarations export isChatCompletionBody(body: JournalBody | null | undefined): body is ChatCompletionRequest.
Tracked standard Bun test patterns enumerate 201 baseline files (192 TypeScript, 9 tools); 204 is not an authoritative inventory.
No open register decision blocks BO. OD-04 is closed context. .codex is a regular empty file.

## Milestones
Read each ticket's full YAML verbatim at dispatch; retain its acceptance evidence, stop conditions and scope.

M1 / KRT-BO001 / contract_test plus reference-host-memory-scenario:
Fix ownership before decoding/validation, on backend ingress/egress and internal stored-buffer decode paths, preserving encoding and all original 77 tests. Add only the approved test/buffer-ownership.test.ts and the memory patch changeset.
State assertions: original tests unchanged; known 1.4.2 baseline failure is exactly the three reproduced cases.
Verification: bun run nx run backend-memory:test; backend-memory:typecheck and build; the same suite on candidate Bun 1.4.2; bun run changeset:check --base=dff2df9f8dd5dd37fe4054081bcf22479745bd82; live recipe.
Ownership tests cover caller mutation after write, returned-buffer mutation, decoder side effects and transaction rollback. New tests begin red; original suite remains byte-identical.

M2 / KRT-BO002 / runbook_probe:
Use devenv update nixpkgs; atomically rename the Weaver manifest, replace legacy fields with schema_url https://tuvren.dev/schemas/telemetry/0.1.0, update its generator reader and owned references, regenerate the four declared outputs, and extend the changeset for telemetry-semconv. Keep pkgs.postgresql_17 explicit.
State assertions: M1 reviewed, legacy manifest/reader present, original telemetry vocabulary available for comparison.
Verification: refreshed worktree-profile versions and command paths; weaver registry check; bun run nx run telemetry-spec:codegen twice with a stable second run; bun run codegen; bun run verify; changeset check.
Reject any unowned generated output and semantic-vocabulary drift. Use refreshed worktree environment, not main's old profile. Regeneration must be formatter-clean. No existing .constitution/reports files may change.

M3 / KRT-BO003 / contract_test:
Set packageManager with bun pm pkg set to actual latest available refreshed-pin Bun 1.4.x (>=1.4.1; 1.4.2 verified now), remove only the three Bun Dependabot holds, and use Bun CLI for any lock transition.
State assertions: M2 full gate passed, memory fix reviewed, refreshed binary version measured.
Verification: binary equals packageManager; two bun install --frozen-lockfile runs keep bun.lock unchanged; bun run nx run backend-memory:test; bun run verify. Preserve unrelated locked versions.

M4 / KRT-BO004 / runbook_probe:
Inventory all actual tracked Bun test files with git ls-files '*.test.ts' '*.spec.ts'; record additions since the 201-file baseline rather than claiming 204.
Capture installed bun test --help, compare ordinary and --isolate runs with identical per-project inventories/services, and run a disposable global/module-state probe to establish the default.
Probe trust and registry-auth scope with disposable local registry projects and sentinel credentials; prove trusted versus untrusted lifecycle scripts and cross-origin/downgrade/error-output behavior without publishing or real credentials.
State assertions: M3 reviewed, binary/manifests aligned, unchanged production semantics.
Verification: equivalent test outcomes, trust/auth pass criteria, and bun run verify. Only evidence plus bounded allowed manifest/workflow changes; route any production-source requirement upstream.

M5 / KRT-BO005 / invariant:
Fresh pi spec-patch worker edits only stack.yaml. Settle Bun against measured binary, packageManager, frozen install and evidence; align shared refreshed tool revisions and observed versions.
State assertions: M4 measurements passed.
Verification: constitution validate, explicit installed-tool/lock-pin comparison, bun run verify. Separate spec-only commit and independent document review; no code or changelog changes.

M6 / KRT-BO006 / contract_test plus reference-host-memory-scenario:
Bun CLI upgrades host-repl devDependency to registry-verified aimock latest (1.43.0 verified now), removes its Dependabot hold, narrows all JournalBody reads using exported isChatCompletionBody, and adds explicit non-chat rejection assertions. Preserve every existing assertion including json_schema. Explain all seven historical draft failures with isolated and service-ready reproductions; do not modify host production sources.
State assertions: M4/M5 reviewed, relevant helpers match inspected baseline, new version/API reverified.
Verification: bun run nx run host-repl:typecheck; bun run nx run host-repl:test; live recipe; bun run verify.
Attached SP1: fresh pi spec-patch worker updates aimock's stack.yaml pin to the actual locked version. Validate combined M6+SP1, commit code first then spec immediately, record intermediate TS-004 mismatch, validate final, independently review both commits and their combined head. No other error is waived.

## Evidence and gates
Lead alone writes evidence/KRT-BO001 through KRT-BO006 under .constitution with digest/byte-count manifests, producing commands/commits and pass criteria.
Live recipe: bun run nx run host-repl:build; prescribed python3 file doctor; bun run nx run host-repl:scenario; capture the streaming-scenario line; cleanup.
Every milestone: narrow tests then required broader gate, DEBUG sweep, scope/authority sweep, direct public changeset coverage, constitution validate, commit, fresh independent Sol/high review. Fix blockers using fresh DeepSeek workers and re-review.
Except the approved instantaneous M6/SP1 transition, require zero constitution errors and no new unexplained warnings. The four planned OXC warnings remain out of BO.
Workers never write .constitution or commit; spec-patch workers may write only stack.yaml. Generated Rust is produced by its source-owned generator; hand-authored Rust would require rust-core-logic.

## Step-0 rulings
User: DeepSeek 4.1 Flash for executors/fixers. All pi leaf roles use explicit opencode-go/deepseek-v4.1-flash at high thinking; fresh agent per milestone/fix/spec patch. User additionally ruled that every DeepSeek worker, fixer and spec-patch dispatch receives timeoutMs: 7200000 (two hours), with no earlier elapsed-time cancellation. Liveness stall_after_minutes is 120; monitor progress throughout. A minimal live connectivity probe returned READY successfully.
User: two Codex reviewers. Milestone reviewer gpt-5.6-sol/high; PR panel gpt-5.6-sol/high plus gpt-6.1-sol/high, full mode.
User: no ceiling. Track journal usage; no hard PI_WF_BUDGET and no model substitution.
User: merge and reconcile. Ready PR against master, rebase merge/delete only after review-clean and green head CI; then reconcile --epic BO and derive --write, in separate constitution-only commits, and push.
User: exact test-scope extension test/buffer-ownership.test.ts authorized; record ticket deviations.
User: paired aimock code/spec transition authorized as above, preserving separate commits/reviews and disclosing the temporary error.
Default: six ticket milestones in rendered order, SP1 attached after M6, one worker at a time. Keep review diffs below 30 files/1500 lines by recorded amendments when needed.
Default: adopt bounded interim recommendations; amend owned plan for drift; isolated physical stack patches; defer work requiring unowned paths or semantic/boundary changes. Test failure max 3 attempts; stalled worker one replacement after 120 minutes; review loop changes strategy at round 4 and continues until a verification round has no new Act-on findings.
Default inventory ruling: measure all discovered active files and route stale 204 restatements to Stage 3 through closeout, without editing ADR-0074/guidelines.

## Cross-lane facts
None; single standalone lane, source wave 1.

## Project runtime rules
User says devenv is already active. Reuse existing profile for baseline. Execution worktree must evaluate its own profile once created; refresh it after devenv.lock changes, probe executable paths and tool versions, and keep verification on that profile.
Start PostgreSQL only when full/kernel/service gates require it using bun run services:up at lead/session level; stop only services owned by this run. Never embed lifecycle commands in runners.
Pi scripts/prompts/logs/journals/scratch remain under /home/oscar/.cache/pi-subagent/framework. The worktree is /home/oscar/GitHub/Tuvren/framework-bo after amendment A1; package installs in that authorized worktree are allowed. Use zsh. Workers get full repository instructions and relevant rules verbatim; no GUI, nested agents or git writes.
Step0 planning was read-only. The approved plan and execution worktree were created after the user requested implementation.

## Amendments
A1 — 2026-09-29, M2 plan_drift → amend_plan: relocate the isolated worktree from ~/.cache/pi-subagent/framework/worktrees/EPIC-BO to /home/oscar/GitHub/Tuvren/framework-bo. Pinned Biome 2.5.14 ignores the entire former root because the shipped Ultracite preset strongly excludes **/.cache. The exact pinned binary passes 1260 files in the main checkout; the apparent seven baseline errors came from its stale 2.4.10 install, not the pinned toolchain. No root lint config or product source correction is authorized or needed. This is a reversible environment correction. Keep branch/base/milestones/models unchanged. Scratch/journals remain under the harness cache root; permit native package installation inside the relocated worktree. Re-evaluate its devenv profile and restart only the run-owned service; rerun M2 full verification before acceptance. Future workers/probes/reviewers use the new cwd; historical logs retain original paths and labels.


A2 — 2026-09-30, M2 test_failure → bounded prerequisite fix: user authorized a separately reviewed prerequisite and autonomous continuation. Exact pinned Biome has no source defect. Native controls establish six durable/live JSON prototype failures and three SDK source/dist constructor identity failures. Authorize only typescript/runtime/src/lib/runtime-core-recovery.ts; new runtime/test/runtime-core-recovery-comparison.test.ts; typescript/sdk/tsconfig.json; new sdk/test/module-resolution.test.ts; and direct @tuvren/runtime/@tuvren/sdk patch coverage in the BO changeset. Restore data-only recovery comparison through the measured isDeepStrictEqual(...,{skipPrototype:true}) API (Bun1.4.2 and Node24.20.0); delete only SDK root's unused ~/~/* override to retain inherited source aliases. Existing assertions, public constructor signatures, encodings and authority fields stay intact. Do not sweep unrelated nonfailing comparisons. Fresh pi fixer, tests-first, package checks and full gate; separate KRT-BO002 prerequisite commit and independent review, then M2 migration acceptance/commit/review. Record exact ticket deviations, new implementation conventions and upstream alignment needs; preserve the six original ticket milestones and model/merge rules.

A3 — 2026-09-30, M6 acceptance-proof drift → amend_plan: permit the bounded fresh legacy-control executor to run alongside the journal regression fixer. The fixer writes only the new repl.aimock-journal-body.test.ts; the verification executor leaves the production worktree read-only and overlays only the three stable original aimock helper/test files plus package/lock into its independent scratch copy, excluding the concurrently edited new regression file. This preserves an exact 129-test historical scenario corpus and independent package links. Both use the approved DeepSeek model with the full two-hour allowance; no product scope, milestone/review order, logical contract, or merge policy changes. The lead rejects unsupported historical partitions and will retain measured controls plus any remaining limits honestly before M6 acceptance.

A3 sequencing continuation: after the journal fixer finishes, permit the attached stack-only SP1 worker alongside the already isolated read-only legacy controls. The control copy is complete and never reads the mutable live stack file; SP1 writes only stack.yaml. One production writer remains active, and the combined verification/commit/review gates remain sequential.

A4 — 2026-09-30, M6 assumed historical acceptance premise drift → amend_plan, adopting independent Sol judgment. Preserve the original ticket description and acceptance clause about seven draft failures verbatim. The recoverable exact PR130 snapshot, current Bun1.4.2, assertion-preserving JournalBody guards and clean builds reproduced every named category: two SDK constructor-identity steering failures, two approval invalid_stream_event failures from the bundled OpenAI3.0.118 provider parallel tool-start order, and two additional failures when PostgreSQL connection variables were removed. The maximum observed count is six, never seven; the original draft/base/lock/test list and any seventh identity remain unavailable. Supersede the execution interpretation of that assumed count with causal reproduction of every named category, exact observed test names/counts, and explicit disclosure of the irrecoverable draft/count premise. Do not claim seven causes known or adopt the rejected2+2+3 partition. Promotion requires the decisive provider comparison repeated with native Bun package declarations, retained mutation/current135plain+isolate/79assertions/full33/live proof, and independent review agreement on this amendment. No product source, semantics, compatibility boundary or scope changes; BO retains OpenAI3.0.53. Record the ticket deviation, corrected evidence ledger/manifest and closeout limitation; route OpenAI3.0.118 stream-order compatibility to Stage3/4 before a future dependency upgrade. Reconciliation writes the proposed tasks changelog entry after merge; no changelog mutation during execution.
