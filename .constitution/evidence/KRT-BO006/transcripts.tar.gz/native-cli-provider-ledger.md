# M6 decisive-pair native-CLI reproof — empirical ledger

Producer: fresh bounded verification executor. Job root:
`/home/oscar/.cache/pi-subagent/framework/wf-bo-m6-openai-cli-reproof` (all copies, installs,
logs, evidence here). Production worktree read-only.

Purpose: re-prove the `wf-bo-m6-pr130-controls` result — pre-PR AI family = 129/0,
`@ai-sdk/openai` 3.0.118 alone = 127/2 approval `invalid_stream_event` — **through native
`bun` package-management CLI only**, replacing that job's manual/Python package substitutions.

## 0. Verdict

- Decisive pair **REPRODUCED** with compliant native Bun CLI declarations.
- Correct statement: **controlled provider-compatibility finding**, not recovery of the
  original draft identity. No claim of "7 causes known".
- Original 7-draft count remains unavailable; maximum reproduction here is **129/0 baseline /
  127/2 openai-bumped** (PG ready). Task's "6 PG-unset" scope was not re-run (not requested here).

## 1. Environment (inherited, nothing restarted)

| item | value |
| --- | --- |
| Bun | `1.4.2 (744846f84)` — `/nix/store/qkydg77xf2s395md9fq0a6djjpq7fzh4-bun-1.4.2/bin/bun` |
| devenv env | inherited from the running direnv/devenv shell (not re-evaluated) |
| PostgreSQL | `17.11`, `PGHOST=/run/user/1000/devenv-6178225/postgres`, `PGPORT=5432`; `pg_isready` accepting before/after every run |
| production HEAD | `672711dcb43a1c1059644010b9149b3d09b54ece`, `git status --porcelain` = 9 entries, unchanged |
| services | none started/stopped by this job; `devenv` / `bun run services:*` never invoked |

## 2. Exact PR130 identity

| item | value | source |
| --- | --- | --- |
| head | `7ec8ee0e4c598027a280061867e508e3484d5861` | scratch repo `refs/remotes/origin/pr130-head` |
| head tree | `e89b077fe253d2a13fdaa0bff1abc502e8fc0356` | `git rev-parse` |
| base | `bccc66ccfecad6ba6c8208d32f01ad345cc52e24` | scratch repo |
| merge ref tree | `e89b077f…` (identical to head tree) | `git rev-parse e876392…^{tree}` |
| PR130 lock | `eb10a0ae6ca874ed38dd1765fc5cdd5be4858a81bb294a05242600dd7a51d422` | sha256 of archived `bun.lock` |

## 3. Copy construction (native `git archive`, no inherited artifacts)

```
cd /home/oscar/.cache/pi-subagent/framework/wf-bo-m6-pr130-controls/repo
git archive refs/remotes/origin/pr130-head | tar -x -C <job>/copy     # 1967 files, exit 0
```

No `node_modules`, `dist`, or `.nx` existed in the archive (verified by find). Independent
workspace links: every `@tuvren/*` link resolves **inside** `copy/` (e.g.
`copy/typescript/host/repl/node_modules/@tuvren/core -> ../../../../core`); every non-workspace
package resolves into `copy/node_modules/.bun/…`. The live worktree is never symlinked.

`bun install --frozen-lockfile` → exit 0, **604 packages** (matches the PR130 lock).

## 4. Overlays (exact reviewed snapshots, zero new implementation)

Patches from `/home/oscar/.cache/pi-subagent/framework/wf-bo-m6-pr130-controls/overlays/patches`:

| patch | sha256 | `git apply --check` | `git apply` |
| --- | --- | --- | --- |
| `m1.patch` | `f18b482d9c9684d8ac22a59c55f7f7cdcbbb4e3989de4e38b33f8414a3ff25a1` | exit 0 | exit 0 |
| `a2.patch` | `7c979974a0363472ff0e545d200c2f40bc4379ade89ef9e2c33df5fe0c6af753` | exit 0 | exit 0 |

Post-apply source hashes are byte-identical to the control's recorded overlays:

```
b2bd8b5d… memory-backend.ts           94ba938f… memory-backend-lineage.ts
d2eb7fc8… memory-backend-turn-tree.ts 485c4727… memory-backend-buffer-isolation.ts (new)
08b1d927… runtime-core-recovery.ts    adec35a3… sdk/tsconfig.json
```

Minimal assertion-preserving `JournalBody` guard: exact snapshot copy of the 3 reviewed files
(helper + openai test adapted, matrix test untouched).

| file | PR-head sha256 | copy sha256 | assertions |
| --- | --- | --- | --- |
| `repl-test-helpers.ts` | `eb4673d1…` | `af96b871…` | `expect(` 14 → 14 |
| `repl.aimock-openai.test.ts` | `4d4769cf…` | `788ad6a7…` | `expect(` 31 → 31; `assertStructuredResponseFormat` 2 → 2 |
| `repl.aimock-matrix.test.ts` | `ad1f91c3…` | `ad1f91c3…` | unchanged/byte-identical |

Diff is only: helper narrows `hasSearchToolContinuation` / `hasApprovalToolContinuation` to
`JournalBody | null | undefined` with an `isChatCompletionBody` early return; openai test
narrows `request.body` once before the `response_format` assertions. **No assertion text,
value, or count deleted or weakened.**

`host-repl:typecheck` in the final restored state → exit 0, **0 `error TS`**.

## 5. Native Bun CLI pin declarations (the corrected process)

All declarations via `bun add -E` (exact) run from the declaring workspace member. `-d` used
where the original group is `devDependencies`. No JSON edits, no text substitution, no Python.

| # | cwd | command | exit |
| --- | --- | --- | --- |
| 1 | `typescript/host/repl` | `bun add -E @ag-ui/core@0.0.52 @ai-sdk/anthropic@3.0.66 @ai-sdk/google@3.0.64 @ai-sdk/openai@3.0.53 @ai-sdk/provider@3.0.8` | 0 |
| 2 | `typescript/providers/bridge-ai-sdk` | `bun add -E @ai-sdk/provider@3.0.8 ai@6.0.142` | 0 |
| 3 | `typescript/runtime` | `bun add -E -d @ag-ui/core@0.0.52` | 0 |
| 4 | `typescript/streaming/agui` | `bun add -E @ag-ui/core@0.0.52` | 0 |
| 5 | `typescript/certification` | `bun add -E @ag-ui/core@0.0.52` | 0 |
| 6 | `typescript/providers/certification` | `bun add -E @ai-sdk/provider@3.0.8` | 0 |

Manifest delta vs PR130 head = **exactly the 11 AI-family declaration values** (verified by
`diff` against `git show <head>:<file>`); no group moves, no reordering, no reformatting.
Delta vs **base** = only non-AI-family PR130 bumps that stay as declared
(`@copilotkit/aimock` 1.43.0, `ajv` 8.20.0).

Installed (resolved) after pin — `@ai-sdk/openai 3.0.53`, `@ai-sdk/provider 3.0.8`,
`@ai-sdk/anthropic 3.0.66`, `@ai-sdk/google 3.0.64`, `@ag-ui/core 0.0.52`,
`@copilotkit/aimock 1.43.0`, `ai` (bridge) 6.0.142.

Required transitive deltas (lock, PR130 → pre-PR pin): `@ai-sdk/provider-utils`
4.0.54 → 4.0.21/4.0.22/4.0.23 (per-consumer), `@ai-sdk/gateway` 3.0.202 → 3.0.84,
`@vercel/oidc` 3.2.0 → 3.1.0, `undici@6.29.0` dropped, `@swc/*` dropped.
Lock hash PR130 `eb10a0ae…`; baseline lock kept at `evidence/bun.lock.baseline-prepin-openai`.

## 6. Native bootstrap + clean build

```
bun tools/scripts/kernel-interop-governance.ts codegen            # exit 0
  kernel_services_pb.ts 4963f870be1c5e44ab708caa78d5f891abd78d3adfe30a3c3965df7bff210a1e
  kernel_types_pb.ts    77902e9b15521907219c037c34538f68d8a6090b9b9d800d36e15548ca4756c6
```
Generated bindings were absent from the archive (gitignored); no Weaver-manifest migration was
required at this head.

Clean build = all `typescript/**/dist` removed, then
`bun run nx run host-repl:build` (26 dependency tasks) → exit 0.
Dist hashes are **identical for both provider configurations** (provider is external, not bundled):

```
host/repl/dist/cli.js                       5b89a36d85be6e2b8f61ea4321df793534862a512a93348eadf9f2a8951045de
runtime/dist/index.js                       ed67e1ac532bfa5bb08c412a1763a20c8a82f009fbcbe5aee3afc32b75f62ab3
kernel/backends/memory/dist/index.js        c9fc5e2587824b23106171800be0329b2d1d08578bf0cd4407fadf16662ee710
sdk/dist/index.js                           3e1a1db214a477c9103d04bf22d8b0fb3d00959f2d0e80ed5f70044c16e63ca9
core/dist/index.js                          7d24d04e0758ff332cf5671f4dfe039034641d0fdc4e35be13093b0a08136117
```
Decisive builds were re-run with `--skipNxCache` and all `dist` removed, so nothing was reused.

## 7. Corpus (unchanged grading slice)

`typescript/host/repl/test/` — 6 test files at PR130 head (no `repl.aimock-journal-body.test.ts`,
which is the M6 fixer's later 6-test file). Test-block counts sum exactly:
2 (`repl-serve-ws.e2e`) + 4 (`repl-transcript-redaction`) + 5 (`repl-transcript-scope`)
+ 9 (`repl.aimock-matrix`) + 9 (`repl.aimock-openai`) + 100 (`repl.test`) = **129**.
Bun reports `Ran 129 tests across 6 files` in every run below.

## 8. Decisive pair (native `bun test`, PG ready)

| id | configuration | result | exit | log |
| --- | --- | --- | --- | --- |
| B | PR130 source + M1 + A2 guard + **pre-PR AI family** | **129 pass / 0 fail** | 0 | `logs/05-baseline-host-test-pgenv.log` |
| N-plain | B, `bun add -E @ai-sdk/openai@3.0.118` only | **127 pass / 2 fail** | 1 | `logs/12-openai118-host-test-final-pgenv.log` |
| N-isolate | same as N-plain, `bun test --isolate` | **127 pass / 2 fail** | 1 | `logs/13-openai118-host-test-isolate-pgenv.log` |
| F | after `bun add -E @ai-sdk/openai@3.0.53` restore | **129 pass / 0 fail** | 0 | `logs/16-restored-host-test-pgenv.log` |

The two failures, identical in both N runs and both pre-existing in the control:

1. `repl host scenarios aimock matrix > runs approval pause and edited approval resume through aimock across all provider families`
   — `expect(report.status.phase).toBe("completed")` received `"failed"` (`repl.aimock-matrix.test.ts:231`)
2. `repl host scenarios aimock openai > runs approval pause and edited approval resume through aimock`
   — same assertion at `repl.aimock-openai.test.ts:275`

Only `@ai-sdk/openai` moved between B and N. Manifest hashes of the other five files are
byte-identical across the upgrade (`evidence/manifests-before/after-openai-upgrade.tsv`), and the
upgrade lock delta is exactly `@ai-sdk/openai` 3.0.53→3.0.118 with nested
`@ai-sdk/provider` 3.0.8→3.0.17, `@ai-sdk/provider-utils` 4.0.23→4.0.54, `undici@6.29.0` added.

## 9. Measured mechanism (`invalid_stream_event`)

Temporary scratch-only `console.error` in the copy's
`typescript/runtime/src/lib/runtime-core-assistant-validation.ts` mismatch branch
(`logs/10-...`, removed afterwards — file sha256 then `0b04cae301dbc8a0e3b4b1e7faefe85816b11bc0f3593bc8e8770431da00e789`,
byte-identical to PR130 head). No assertion touched.

```
[scratch-diagnostic] event mismatch index=2
  actual  = ["message.start","tool_call.start","tool_call.start","tool_call.done","tool_call.done","message.done"]
  expected= ["message.start","tool_call.start","tool_call.done","tool_call.start","tool_call.done","message.done"]
  actualEvent   = {"type":"tool_call.start","name":"email", ...}
  expectedEvent = {"type":"tool_call.done","name":"search", ...}
```

Error code at that branch: `invalid_stream_event`; message
`runner-emitted assistant events must match the durable assistant message`.
Same length, same multiset, different order: with `@ai-sdk/openai@3.0.118` the provider streams
both parallel tool-call **starts** before either **done**, while
`synthesizeAssistantValidationEvents` assumes per-call start/done pairing. On `3.0.53` the orders
agree, hence 129/0. This is a measurement of the existing published package's stream behavior;
no protocol implementation or product fix was authored.

## 10. Provenance / integrity of the final copy

`diff -rq copy pristine` (excluding `node_modules`, `dist`, `.nx`, `*.tsbuildinfo`) yields exactly:
6 `package.json` (AI-family pins), `bun.lock`, 2 adapted host test files, the 4 M1 memory files
(1 new), `runtime-core-recovery.ts`, `sdk/tsconfig.json`, `sdk/test/module-resolution.test.ts`
(A2), and the gitignored `kernel/grpc-client/src/lib/generated/`. `repl.aimock-matrix.test.ts`
is byte-identical to PR130 head. No other product source changed.

## 11. Cleanup / durability

- Copy left at the **restored** configuration (OpenAI 3.0.53), lock byte-identical (`cmp`) to the
  pre-upgrade baseline, manifests identical (`evidence/`).
- Copy's Nx daemon (pid 3559048) killed; no remaining process references the job copy; no mock
  servers or `bun test` processes linger. The production Nx daemon was left running; PostgreSQL
  untouched and still accepting connections.
- Production worktree: `HEAD=672711d`, `git status --porcelain` identical at 9 entries; no product
  commit, no `.constitution` write.
- No global installs, no service lifecycle, no external publish, no nested agents, no GUI.
- Disclosure: one transient `git show … > /tmp/x` slip (406 bytes) during a manifest-diff loop;
  deleted immediately (`/tmp/x` absent). Nothing depended on it; all real artifacts live under the
  job root.

## 12. Boundaries of the claim

- This is a **controlled provider-compatibility finding**: the exact PR130 head, plus reviewed
  M1/A2 source overlays and the minimal reviewed test guard, passes 129/0 with the pre-PR AI family
  and fails 127/2 when only `@ai-sdk/openai` moves to 3.0.118.
- It is **not** a recovery of the original Bun-refresh draft identity; the draft, its base,
  lockfile, and exact seven failure names remain unavailable.
- Historical claim "7 causes known" is **not** supported: the reproducible set here is 2 approval
  failures attributable to the openai bump, on a 129-test corpus.
