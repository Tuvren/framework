import { strict as assert } from "node:assert";
import { readFile } from "node:fs/promises";
const root = "/home/oscar/GitHub/Tuvren/framework-bo";
const oldProcess = Bun.spawn(["git", "show", "672711d:bun.lock"], {cwd: root, stdout:"pipe"});
const before = Bun.JSONC.parse(await new Response(oldProcess.stdout).text());
assert.equal(await oldProcess.exited, 0);
const after = Bun.JSONC.parse(await readFile(root + "/bun.lock", "utf8"));
const removed = Object.keys(before.packages).filter(n => !Object.hasOwn(after.packages, n));
const added = Object.keys(after.packages).filter(n => !Object.hasOwn(before.packages, n));
assert.deepEqual(added, []);
for (const [name, record] of Object.entries(after.packages)) {
  if (name === "@copilotkit/aimock") {
    assert.equal(record[0], "@copilotkit/aimock@1.43.0");
    assert.equal(record[3], "sha512-V8D8cjSMtAR4rHaD2ulp3DR/ZguXQjDNOqwKDNvjb/OJL/KR1I0SDf5xpRCd+TYKjhmf9fM8Xpg3QBKPmV9Kmw==");
  } else assert.deepEqual(record, before.packages[name], name + ": unrelated locked entry changed");
}
for (const name of removed) {
  assert.ok(name.startsWith("@swc/"), "Unexpected removal: " + name);
  for (const [owner, record] of Object.entries(after.packages)) {
    const metadata = record[2];
    if (!metadata) continue;
    assert.equal(metadata.dependencies?.[name], undefined, name + ": still hard-required by " + owner);
    assert.equal(metadata.optionalDependencies?.[name], undefined, name + ": still optional-required by " + owner);
    if (metadata.peerDependencies?.[name]) assert.ok(metadata.optionalPeers?.includes(name), name + ": still mandatory peer of " + owner);
  }
  for (const [owner, workspace] of Object.entries(after.workspaces)) {
    for (const group of ["dependencies", "devDependencies", "optionalDependencies"]) assert.equal(workspace[group]?.[name], undefined, name + ": workspace requirement " + owner);
  }
}
const expected = structuredClone(before);
expected.workspaces["typescript/host/repl"].devDependencies["@copilotkit/aimock"] = "1.43.0";
expected.packages = after.packages;
assert.deepEqual(after, expected, "Only aimock host declaration and package entries may change");
console.log("Aimock1.15.1 ->1.43.0; published integrity exact; all retained unrelated resolutions/metadata unchanged.");
console.log("Native Bun add pruned " + removed.length + " @swc entries with no retained dependency requirement; remaining peer references are optional: " + removed.join(", "));
console.log("New locked package entries:0; workspace/format changes: only host aimock declaration. PASS");

