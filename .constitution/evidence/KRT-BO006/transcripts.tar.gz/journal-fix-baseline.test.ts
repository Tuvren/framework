// @ts-nocheck
/**
 * Scratch baseline copy of the two integration cases as they were BEFORE the
 * M6 journal-proof fix, rewritten only to resolve imports from the scratch
 * directory. Used to show which mutations the pre-fix assertions missed.
 */
import { describe, expect, test } from "bun:test";
import type { JournalBody } from "/home/oscar/GitHub/Tuvren/framework-bo/typescript/host/repl/node_modules/@copilotkit/aimock/dist/index.js";
import { isChatCompletionBody, LLMock } from "/home/oscar/GitHub/Tuvren/framework-bo/typescript/host/repl/node_modules/@copilotkit/aimock/dist/index.js";
import {
  assertStructuredResponseFormat,
  hasApprovalToolContinuation,
  hasSearchToolContinuation,
} from "/home/oscar/GitHub/Tuvren/framework-bo/typescript/host/repl/test/repl-test-helpers.ts";

const NON_CHAT_JOURNAL_BODIES: readonly (JournalBody | null | undefined)[] = [
  null,
  undefined,
  { model: "gpt-4o-mini" },
  { messages: "Run tools", model: "gpt-4o-mini" },
  { model: "gpt-4o-mini-2024-07-18", training_file: "file-abc123" },
  {
    __aimock_truncated: true,
    note: "body truncated by aimock journal cap (64 KB limit)",
    originalByteSize: 70_000,
  },
];

const CHAT_COMPLETION_BODY: JournalBody = {
  messages: [
    {
      content: "Run streaming",
      role: "user",
    },
  ],
  model: "gpt-4o-mini",
};

/**
 * Scratch mutation harness (not part of the repository).
 *
 * Injected into copies of the target test file so the lead's fix can be shown
 * to be load-bearing: each MUTATION removes/mutates something the strengthened
 * assertions must catch.
 */
const MUTATION = process.env.MUTATION ?? "none";
const originalStart = LLMock.prototype.start;

LLMock.prototype.start = async function start(this: LLMock, ...args: []) {
  const url = await originalStart.apply(this, args);
  const originalGetLastRequest = this.getLastRequest.bind(this);

  if (MUTATION === "null-entry") {
    this.getLastRequest = () => null;
  }

  if (MUTATION === "missing-body") {
    this.getLastRequest = () => {
      const entry = originalGetLastRequest();

      return entry === null ? null : { ...entry, body: undefined };
    };
  }

  if (MUTATION === "wrong-payload") {
    this.getLastRequest = () => {
      const entry = originalGetLastRequest();

      return entry === null
        ? null
        : { ...entry, body: { model: "wrong-model", training_file: "file-wrong" } };
    };
  }

  return url;
};
describe("repl aimock journal body narrowing", () => {
  test("rejects a non-chat body the aimock journal actually recorded", async () => {
    const mock = new LLMock({
      logLevel: "silent",
      port: 0,
    });

    await mock.start();

    try {
      const response = await fetch(`${mock.url}/v1/fine_tuning/jobs`, {
        body: JSON.stringify({
          model: "gpt-4o-mini-2024-07-18",
          training_file: "file-abc123",
        }),
        headers: { "content-type": "application/json" },
        method: "POST",
      });
      const journalBody = mock.getLastRequest()?.body ?? null;

      expect(response.status).toBe(200);
      expect(isChatCompletionBody(journalBody)).toBe(false);
      expect(hasSearchToolContinuation(journalBody)).toBe(false);
      expect(hasApprovalToolContinuation(journalBody)).toBe(false);
    } finally {
      await mock.stop();
    }
  });

  test("rejects the journal-cap truncation marker aimock substitutes for an oversized body", async () => {
    const mock = new LLMock({
      logLevel: "silent",
      port: 0,
    });

    await mock.start();

    try {
      const response = await fetch(`${mock.url}/v1/chat/completions`, {
        body: JSON.stringify({
          messages: [{ content: "x".repeat(70_000), role: "user" }],
          model: "gpt-4o-mini",
        }),
        headers: { "content-type": "application/json" },
        method: "POST",
      });
      const journalBody = mock.getLastRequest()?.body ?? null;

      expect(response.status).toBe(404);
      expect(isChatCompletionBody(journalBody)).toBe(false);
      expect(hasSearchToolContinuation(journalBody)).toBe(false);
      expect(hasApprovalToolContinuation(journalBody)).toBe(false);
    } finally {
      await mock.stop();
    }
  });
});

void CHAT_COMPLETION_BODY;
void assertStructuredResponseFormat;
void NON_CHAT_JOURNAL_BODIES;
