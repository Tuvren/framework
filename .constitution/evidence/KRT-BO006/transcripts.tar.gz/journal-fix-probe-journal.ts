import { isChatCompletionBody, LLMock } from "/home/oscar/GitHub/Tuvren/framework-bo/typescript/host/repl/node_modules/@copilotkit/aimock/dist/index.js";

const mock = new LLMock({ logLevel: "silent", port: 0 });
await mock.start();

try {
  const fineTuningPayload = {
    model: "gpt-4o-mini-2024-07-18",
    training_file: "file-abc123",
  };
  const fineTuningResponse = await fetch(`${mock.url}/v1/fine_tuning/jobs`, {
    body: JSON.stringify(fineTuningPayload),
    headers: { "content-type": "application/json" },
    method: "POST",
  });

  console.log("fine_tuning.status", fineTuningResponse.status);
  console.log("fine_tuning.entry", JSON.stringify(mock.getLastRequest(), null, 2));
  console.log(
    "fine_tuning.bodyKeys",
    Object.keys(mock.getLastRequest()?.body ?? {})
  );
  console.log(
    "fine_tuning.isChat",
    isChatCompletionBody(mock.getLastRequest()?.body)
  );
  console.log("fine_tuning.url", mock.url);

  const oversizedPayload = {
    messages: [{ content: "x".repeat(70_000), role: "user" }],
    model: "gpt-4o-mini",
  };
  const serializedOversized = JSON.stringify(oversizedPayload);
  const oversizedResponse = await fetch(`${mock.url}/v1/chat/completions`, {
    body: serializedOversized,
    headers: { "content-type": "application/json" },
    method: "POST",
  });

  console.log("oversized.status", oversizedResponse.status);
  console.log(
    "oversized.entry",
    JSON.stringify(mock.getLastRequest(), null, 2).slice(0, 1200)
  );

  const body = mock.getLastRequest()?.body;
  console.log("oversized.bodyKeys", Object.keys(body ?? {}));
  console.log(
    "oversized.originalByteSize",
    body === null || body === undefined ? "n/a" : Reflect.get(body, "originalByteSize")
  );
  console.log("oversized.serializedSentBytes", Buffer.byteLength(serializedOversized, "utf8"));
  console.log("oversized.isChat", isChatCompletionBody(body));

  const reSerialized = JSON.stringify(JSON.parse(serializedOversized));
  console.log("oversized.reSerializedMatchesSent", reSerialized === serializedOversized);
  console.log("oversized.reSerializedBytes", Buffer.byteLength(reSerialized, "utf8"));
} finally {
  await mock.stop();
}
