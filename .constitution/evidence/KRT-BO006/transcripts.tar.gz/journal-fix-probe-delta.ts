import { LLMock } from "/home/oscar/GitHub/Tuvren/framework-bo/typescript/host/repl/node_modules/@copilotkit/aimock/dist/index.js";

const sentBody = JSON.stringify({
  messages: [{ content: "x".repeat(70_000), role: "user" }],
  model: "gpt-4o-mini",
});
const sentBodyByteSize = Buffer.byteLength(sentBody, "utf8");
const withMarker = JSON.stringify({
  ...JSON.parse(sentBody),
  _endpointType: "chat",
});
console.log("sentBytes", sentBodyByteSize);
console.log("withEndpointMarkerBytes", Buffer.byteLength(withMarker, "utf8"));
console.log("markerDelta", Buffer.byteLength(withMarker, "utf8") - sentBodyByteSize);

const mock = new LLMock({ logLevel: "silent", port: 0 });
await mock.start();
try {
  const response = await fetch(`${mock.url}/v1/chat/completions`, {
    body: sentBody,
    headers: { "content-type": "application/json" },
    method: "POST",
  });
  console.log("status", response.status);
  const recorded = Reflect.get(mock.getLastRequest() ?? {}, "body");
  console.log("recordedMarker", JSON.stringify(recorded));
  console.log(
    "recordedEqualsReconstructedWithMarker",
    JSON.stringify(recorded) === JSON.stringify({ __aimock_truncated: true, originalByteSize: Buffer.byteLength(withMarker, "utf8"), note: "body truncated by aimock journal cap (64 KB limit)" })
  );
} finally {
  await mock.stop();
}
