import { strict as assert } from "node:assert";
import { readFile } from "node:fs/promises";
import { parse } from "/home/oscar/GitHub/Tuvren/framework-bo/node_modules/yaml/dist/index.js";
const root = "/home/oscar/GitHub/Tuvren/framework-bo";
async function fromGit(path) {
  const p = Bun.spawn(["git", "show", "672711d:" + path], {cwd:root, stdout:"pipe", stderr:"pipe"});
  const text = await new Response(p.stdout).text();
  assert.equal(await p.exited,0,path);
  return text;
}
const stack = parse(await readFile(root+"/.constitution/tech-spec/stack.yaml","utf8"));
const before = parse(await fromGit(".constitution/tech-spec/stack.yaml"));
for (const r of before.bill_of_materials) {
  if (r.name !== "@copilotkit/aimock") assert.deepEqual(stack.bill_of_materials.find(c=>c.name===r.name),r,r.name+": unrelated stack change");
}
assert.equal(stack.bill_of_materials.length,before.bill_of_materials.length);
assert.deepEqual(stack.compatibility_policy,before.compatibility_policy);
const rec = stack.bill_of_materials.find(r=>r.name==="@copilotkit/aimock");
const host = JSON.parse(await readFile(root+"/typescript/host/repl/package.json","utf8"));
const lock = Bun.JSONC.parse(await readFile(root+"/bun.lock","utf8"));
const installed = JSON.parse(await readFile(root+"/typescript/host/repl/node_modules/@copilotkit/aimock/package.json","utf8"));
for(const version of [rec.version,host.devDependencies["@copilotkit/aimock"],installed.version]) assert.equal(version,"1.43.0");
assert.equal(lock.packages["@copilotkit/aimock"][0],"@copilotkit/aimock@1.43.0");
const decl = await readFile(root+"/typescript/host/repl/node_modules/@copilotkit/aimock/dist/journal.d.ts","utf8");
assert.match(decl,/function isChatCompletionBody\(body: JournalBody \| null \| undefined\): body is ChatCompletionRequest/);
const aimock = await import(Bun.resolveSync("@copilotkit/aimock",root+"/typescript/host/repl"));
assert.equal(typeof aimock.isChatCompletionBody,"function");
assert.equal(aimock.isChatCompletionBody({model:"x",training_file:"file-control"}),false);
assert.equal(aimock.isChatCompletionBody({model:"x",messages:[]}),true);
const bproc = Bun.spawn(["bun","--version"],{stdout:"pipe"});
assert.equal((await new Response(bproc.stdout).text()).trim(),"1.4.2");
assert.equal(await bproc.exited,0);
assert.equal(JSON.parse(await readFile(root+"/package.json","utf8")).packageManager,"bun@1.4.2");
const deps = parse(await readFile(root+"/.github/dependabot.yml","utf8"));
const oldDeps = parse(await fromGit(".github/dependabot.yml"));
oldDeps.updates.find(u=>u["package-ecosystem"]==="bun").ignore = oldDeps.updates.find(u=>u["package-ecosystem"]==="bun").ignore.filter(i=>i["dependency-name"]!=="@copilotkit/aimock");
assert.deepEqual(deps,oldDeps,"Only the aimock hold may be removed");
console.log("Aimock installed/declared/locked/spec1.43.0 agree; exact published guard signature/import/negative control PASS.");
console.log("Bun binary/packageManager1.4.2; every other stack/policy record unchanged; Dependabot only aimock hold removed. PASS.");

