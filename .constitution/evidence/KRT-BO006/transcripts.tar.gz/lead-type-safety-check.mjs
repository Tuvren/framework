import {strict as assert} from "node:assert";
import {readFile} from "node:fs/promises";
import ts from "/home/oscar/GitHub/Tuvren/framework-bo/node_modules/typescript/lib/typescript.js";
const paths=["typescript/host/repl/test/repl-test-helpers.ts","typescript/host/repl/test/repl.aimock-openai.test.ts","typescript/host/repl/test/repl.aimock-matrix.test.ts","typescript/host/repl/test/repl.aimock-journal-body.test.ts"];
function features(text,path){const f=ts.createSourceFile(path,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);const out={any:0,cast:0,nonNull:0,suppression:(text.match(/biome-ignore|eslint-disable|@ts-ignore|@ts-expect-error/g)??[]).length};function walk(n){if(n.kind===ts.SyntaxKind.AnyKeyword)out.any++;if(ts.isAsExpression(n)||ts.isTypeAssertionExpression(n))out.cast++;if(ts.isNonNullExpression(n))out.nonNull++;ts.forEachChild(n,walk);}walk(f);return out;}
for(const path of paths){const p=Bun.spawn(["git","show","672711d:"+path],{cwd:"/home/oscar/GitHub/Tuvren/framework-bo",stdout:"pipe",stderr:"pipe"});const beforeText=await new Response(p.stdout).text();const status=await p.exited;const before=features(status===0?beforeText:"",path);const after=features(await readFile("/home/oscar/GitHub/Tuvren/framework-bo/"+path,"utf8"),path);for(const [key,n]of Object.entries(after))assert.ok(n<=before[key],path+":"+key+" increased");console.log(path,JSON.stringify({before,after}));}
console.log("No added any/cast/non-null assertion/suppression. Existing const assertions unchanged. PASS.");

