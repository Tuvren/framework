/**
 * Scratch mutation harness (not part of the repository).
 *
 * Injected into copies of the target test file so the lead's fix can be shown
 * to be load-bearing: each MUTATION removes/mutates something the strengthened
 * assertions must catch.
 */
const MUTATION = process.env.MUTATION ?? "none";
const originalStart = LLMock.prototype.start;

LLMock.prototype.start = async function start(this: LLMock, ...args: []) {
  const url = await originalStart.apply(this, args);
  const originalGetLastRequest = this.getLastRequest.bind(this);

  if (MUTATION === "null-entry") {
    this.getLastRequest = () => null;
  }

  if (MUTATION === "missing-body") {
    this.getLastRequest = () => {
      const entry = originalGetLastRequest();

      return entry === null ? null : { ...entry, body: undefined };
    };
  }

  if (MUTATION === "wrong-payload") {
    this.getLastRequest = () => {
      const entry = originalGetLastRequest();

      return entry === null
        ? null
        : { ...entry, body: { model: "wrong-model", training_file: "file-wrong" } };
    };
  }

  return url;
};
