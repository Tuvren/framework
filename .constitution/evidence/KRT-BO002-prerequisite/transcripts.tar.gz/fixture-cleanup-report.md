# wf-bo-m2-fixture-cleanup — A2 regression fixture suppression removal

## Touched files (2, both previously untracked)
- `typescript/runtime/test/runtime-core-recovery-comparison.test.ts`
- `typescript/sdk/test/module-resolution.test.ts`

No other file created/edited/deleted. Nothing under `.constitution/`. No git write commands.

## Changes
1. Removed the file-wide `// biome-ignore-all lint/suspicious/useAwait: ...` comment from both files.
2. runtime fixture runner double (only sync methods):
   - `async execute(context) { ...; return { ... }; }` → `execute: (context) => { <same expect>; return Promise.resolve({ ...same payload... }); }`
   - `async resume() { throw new Error("resume was not expected"); }` → `resume: () => Promise.reject(new Error("resume was not expected"))`
   - `satisfies RuntimeRunner` retained; `context` type inferred contextually from `RuntimeRunner["execute"]` (RunnerExecutionContext); unchanged assertions/data/imports.
3. sdk fixture: suppression comment only; no other line changed (nothing in that file needed a non-async conversion — every async function there already awaits).

## Preservation
- test/expect counts identical to pre-edit baselines: runtime 10 tests / 16 expects; sdk 2 tests / 7 expects.
- diff contains only the hunks above (see diff-runtime-fixture.patch, diff-sdk-fixture.patch).
- No casts, `any`, `as const`, non-null assertions, `.only`/`.skip`, or suppressions added.

## Checks (LC_ALL=C, full log in evidence.txt)
| # | check | exit |
|---|-------|------|
| 1 | cwd typescript/runtime: `bun test test/runtime-core-recovery-comparison.test.ts` (10 pass, 0 fail, 16 expects) | 0 |
| 2 | cwd typescript/sdk: `bun test test/module-resolution.test.ts` (2 pass, 0 fail, 7 expects) | 0 |
| 3 | `nx run framework-runtime:typecheck --skip-nx-cache` | 0 |
| 4 | `nx run sdk:typecheck --skip-nx-cache` | 0 |
| 5 | `nx run framework-runtime:lint --skip-nx-cache` (132 files, no fixes) | 0 |
| 6 | `nx run sdk:lint --skip-nx-cache` (21 files, no fixes) | 0 |
| 7 | `biome check` on the two files directly | 0 |
| 8 | adjacent original suites `runtime-core.recovery.test.ts` + `runtime-core.stale-step-recovery.test.ts` (15 pass) | 0 |
| 9 | full sdk package suite (`bun test`, cwd typescript/sdk) 91 pass / 0 fail / 229 expects | 0 |

repo biome (`ultracite/config/biome/core/biome.jsonc`) sets `lint/suspicious/useAwait: "error"`; with the comments removed neither file produces any useAwait (or unused-suppression) diagnostic, so the sdk suppression was suppressing nothing.

## Behavior notes / drift
- `resume` stub: the rejected promise is now created inside the arrow (lazily on call) instead of by an async body; observable behavior on invocation is unchanged, and it is never invoked in this scenario.
- `execute` failure path: the in-body `expect` throwing now surfaces as a synchronous throw instead of a rejected promise. The only caller, `executeRunner` in `typescript/runtime/src/lib/runtime-core-runner-support.ts:257`, wraps `await runner.execute(context)` in try/catch, so both forms map identically to the hard `fail` resolution. No production file changed.
- Pre-existing pending worktree changes untouched (same 14-entry `git status --porcelain` set before and after: `.changeset/toolchain-bo-bun-refresh.md`, 4 `.constitution/evidence/KRT-BO001/*`, `.constitution/tasks/epics/EPIC-BO-bun-refresh.yaml`, `devenv.lock`, `spec/telemetry/README.md`, deleted `spec/telemetry/semconv/registry_manifest.yaml`, `tools/scripts/telemetry-codegen.ts`, `typescript/runtime/src/lib/runtime-core-recovery.ts`, `typescript/sdk/tsconfig.json`, new `spec/telemetry/semconv/manifest.yaml`, plus the two fixtures).

## Files in this scratch dir
- `baseline/` pre-edit copies, `diff-runtime-fixture.patch`, `diff-sdk-fixture.patch`, `sha256-after.txt`, `git-status-after.txt`, `evidence.txt`, `REPORT.md`
