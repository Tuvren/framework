import fs from 'node:fs';
const proof='/home/oscar/.codex/plans/tuvren-bq-session/m10r';
for(const file of ['adapt-proof.mjs','finish-adjustments.mjs','repair-proof.mjs'])fs.unlinkSync(`${proof}/${file}`);
fs.writeFileSync(`${proof}/before-native-selection.exit`,'0\n');
let finalize=fs.readFileSync(`${proof}/finalize.mjs`,'utf8');
finalize=finalize.replace("const versions=",`const baseline=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
assert.equal(baseline,'45f0aa3329d6f896edefd5b1dda7ad7bee390384');
const versions=`);
fs.writeFileSync(`${proof}/finalize.mjs`,finalize);
