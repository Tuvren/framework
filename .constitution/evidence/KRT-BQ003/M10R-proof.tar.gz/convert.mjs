import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
const root=process.cwd();
const proof='/home/oscar/.codex/plans/tuvren-bq-session/m10r';
const ts=await import(path.join(root,'node_modules/typescript/lib/typescript.js'));
const cfg=ts.readConfigFile('typescript/kernel/protocol/tsconfig.typecheck.json',ts.sys.readFile);
assert.ok(!cfg.error);
const config=ts.parseJsonConfigFileContent(cfg.config,ts.sys,path.resolve('typescript/kernel/protocol'));
const program=ts.createProgram(config.fileNames,config.options);
const checker=program.getTypeChecker();
const printer=ts.createPrinter();
const files=['kernel-cddl.test.ts','kernel-protocol-fixtures.ts','kernel-contract-test-helpers.ts'].map(name=>`typescript/kernel/protocol/test/${name}`);
const plan={baselineCommit:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),typescript:ts.version,files:[]};
assert.equal(plan.baselineCommit,'45f0aa3329d6f896edefd5b1dda7ad7bee390384');
for(const file of files){
 const text=fs.readFileSync(file,'utf8');
 const source=program.getSourceFile(path.resolve(file));
 assert.ok(source);
 fs.writeFileSync(path.join(proof,`${path.basename(file)}.before`),text);
 const declarations=source.statements.filter(ts.isFunctionDeclaration);
 const movableTables=source.statements.filter(node=>ts.isVariableStatement(node)&&node.declarationList.declarations.some(d=>['NON_EMPTY_GROUP_FIELDS','NON_NEGATIVE_SAFE_INTEGER_FIELDS'].includes(d.name.getText(source))));
 const named=[...declarations.map(node=>({name:node.name,node})),...movableTables.map(node=>({name:node.declarationList.declarations[0].name,node}))];
 const bySymbol=new Map(named.map(({name,node})=>[checker.getSymbolAtLocation(name),{name:name.text,node}]));
 const dependencies=node=>{
  const names=new Set();
  const visit=current=>{if(ts.isIdentifier(current)){const target=bySymbol.get(checker.getSymbolAtLocation(current));if(target)names.add(target.name);}ts.forEachChild(current,visit);};
  visit(node);return [...names];
 };
 const graph=[];
 const converted=new Map();
 for(const declaration of declarations){
  assert.ok(declaration.name&&declaration.type&&declaration.body);
  const lexical=[];
  const visit=node=>{if(node.kind===ts.SyntaxKind.ThisKeyword||(ts.isMetaProperty(node)&&node.keywordToken===ts.SyntaxKind.NewKeyword)||(ts.isIdentifier(node)&&node.text==='arguments')||(ts.isFunctionLike(node)&&node.asteriskToken))lexical.push(node.getText(source));ts.forEachChild(node,visit);};
  visit(declaration.body);assert.equal(lexical.length,0);
  const deps=dependencies(declaration.body);assert.ok(!deps.includes(declaration.name.text));
  graph.push({name:declaration.name.text,dependencies:deps,lexical});
  const assertion=ts.isTypePredicateNode(declaration.type)&&declaration.type.assertsModifier;
  let annotation='';
  if(assertion){const signature=checker.getSignaturesOfType(checker.getTypeAtLocation(declaration.name),ts.SignatureKind.Call);assert.equal(signature.length,1);const callable=checker.signatureToSignatureDeclaration(signature[0],ts.SyntaxKind.FunctionType,source,ts.NodeBuilderFlags.NoTruncation);assert.ok(callable);annotation=`: ${printer.printNode(ts.EmitHint.Unspecified,callable,source)}`;}
  const leading=text.slice(declaration.getFullStart(),declaration.getStart(source));
  const exported=declaration.modifiers?.some(m=>m.kind===ts.SyntaxKind.ExportKeyword)?'export ':'';
  const signature=text.slice(declaration.name.end,declaration.body.getStart(source)).trim();
  const concise=declaration.body.statements.length===1&&ts.isReturnStatement(declaration.body.statements[0])&&declaration.body.statements[0].expression;
  const body=concise?declaration.body.statements[0].expression.getText(source):declaration.body.getText(source);
  converted.set(declaration.name.text,`${leading}${exported}const ${declaration.name.text}${annotation} = ${signature} => ${body};`);
 }
 for(const table of movableTables){const name=table.declarationList.declarations[0].name.text;graph.push({name,dependencies:[],pureTable:true});converted.set(name,text.slice(table.getFullStart(),table.end));}
 const done=new Set(),active=new Set(),ordered=[],chunks=[];
 const emit=name=>{if(done.has(name))return;assert.ok(!active.has(name),'Unexpected cycle');active.add(name);for(const dep of graph.find(x=>x.name===name).dependencies)emit(dep);active.delete(name);done.add(name);ordered.push(name);chunks.push(converted.get(name));};
 const nonCallable=[];
 for(const statement of source.statements){
  if(ts.isFunctionDeclaration(statement)){emit(statement.name.text);continue;}
  if(movableTables.includes(statement))continue;
  for(const needed of dependencies(statement))emit(needed);
  nonCallable.push(statement.getText(source));chunks.push(text.slice(statement.getFullStart(),statement.end));
 }
 for(const item of graph)emit(item.name);
 fs.writeFileSync(file,`${chunks.join('')}\n`);
 plan.files.push({file,count:declarations.length,assertionCount:declarations.filter(d=>ts.isTypePredicateNode(d.type)&&d.type.assertsModifier).length,overloadCount:0,graph,ordered,movedPureTables:movableTables.map(n=>n.declarationList.declarations[0].name.text),nonCallable});
}
fs.writeFileSync(path.join(proof,'conversion-plan.json'),`${JSON.stringify(plan,null,2)}\n`);
console.log(plan.files.map(({file,count,assertionCount,movedPureTables})=>({file,count,assertionCount,movedPureTables})));
