#!/usr/bin/env zsh
set -uo pipefail
proof=/home/oscar/.codex/plans/tuvren-bq-session/m10r
phase=$1
gate() {
  local gate_name=$1
  shift
  "$@" > "$proof/$phase-$gate_name.log" 2>&1
  local gate_exit=$?
  print -r -- "$gate_exit" > "$proof/$phase-$gate_name.exit"
  print -r -- "$gate_name: $gate_exit"
  if (( gate_exit != 0 )); then tail -40 "$proof/$phase-$gate_name.log"; return "$gate_exit"; fi
}
for mode in syntactic typeaware; do
  args=()
  if [[ $mode == typeaware ]]; then args+=(--type-aware); fi
  bunx --bun oxlint "${args[@]}" --format json typescript/kernel/protocol > "$proof/$phase-protocol-$mode.json" 2> "$proof/$phase-protocol-$mode.stderr"
  print -r -- $? > "$proof/$phase-protocol-$mode.exit"
done
gate scoped bun run nx run-many -t typecheck,test -p kernel-contract-protocol,kernel-runtime --parallel=1 || exit $?
gate fresh-process bun test typescript/kernel/protocol/test/kernel-module-initialization.test.ts || exit $?
if [[ $phase == after ]]; then
  gate format-touched bunx --bun oxfmt --check typescript/kernel/protocol/test/kernel-cddl.test.ts typescript/kernel/protocol/test/kernel-protocol-fixtures.ts typescript/kernel/protocol/test/kernel-contract-test-helpers.ts || exit $?
  gate retained-biome bunx --bun @biomejs/biome lint typescript/kernel/protocol typescript/kernel/runtime || exit $?
  gate lint bun run lint || exit $?
  gate changeset bun run changeset:check || exit $?
  gate diff-check git diff --check || exit $?
fi
