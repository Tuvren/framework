import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
const root = process.cwd();
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m11r';
const ts = await import(path.join(root, 'node_modules/typescript/lib/typescript.js'));
const plan = JSON.parse(fs.readFileSync(path.join(proof, 'conversion-plan.json'), 'utf8'));
const configFile = ts.readConfigFile('typescript/kernel/runtime/tsconfig.typecheck.json', ts.sys.readFile);
const config = ts.parseJsonConfigFileContent(configFile.config, ts.sys, path.resolve('typescript/kernel/runtime'));
const printer = ts.createPrinter({removeComments: true});
const hash = text => createHash('sha256').update(text).digest('hex');
const normalized = (node, source) => node ? printer.printNode(ts.EmitHint.Unspecified, node, source) : null;
const beforeHost = ts.createCompilerHost(config.options);
const originalRead = beforeHost.readFile.bind(beforeHost);
beforeHost.readFile = filename => {
  const item = plan.files.find(entry => path.resolve(entry.file) === path.resolve(filename));
  return item ? fs.readFileSync(path.join(proof, `${path.basename(item.file)}.before`), 'utf8') : originalRead(filename);
};
const programs = {
  before: ts.createProgram(config.fileNames, config.options, beforeHost),
  after: ts.createProgram(config.fileNames, config.options),
};
const checkers = Object.fromEntries(Object.entries(programs).map(([phase, program]) => [phase, program.getTypeChecker()]));
const body = (node, source) => {
  if (ts.isBlock(node) && node.statements.length === 1 && ts.isReturnStatement(node.statements[0]) && node.statements[0].expression) { let expression = node.statements[0].expression; while (ts.isParenthesizedExpression(expression)) expression = expression.expression; return normalized(expression, source); }
  while (ts.isParenthesizedExpression(node)) node = node.expression;
  return normalized(node, source);
};
const checks = [];
const canonicalType = (checker, type) => type.isUnion()
  ? { union: type.types.map(member => canonicalType(checker, member)).sort((a,b) => JSON.stringify(a).localeCompare(JSON.stringify(b))) }
  : { text: checker.typeToString(type) };
for (const item of plan.files) {
  const before = programs.before.getSourceFile(path.resolve(item.file));
  const after = programs.after.getSourceFile(path.resolve(item.file));
  const allDeclarations = before.statements.filter(ts.isFunctionDeclaration);
  const declarations = allDeclarations.filter(node => node.body);
  const arrows = new Map(after.statements.filter(ts.isVariableStatement).flatMap(statement => statement.declarationList.declarations.filter(declaration => item.ordered.includes(declaration.name.getText(after)) && !item.movedPureTables.includes(declaration.name.getText(after))).map(declaration => [declaration.name.getText(after), {declaration, statement}])));
  assert.equal(arrows.size, item.count);
  assert.equal(after.statements.filter(ts.isFunctionDeclaration).length, 0);
  const signatures = [];
  for (const old of declarations) {
    const name = old.name.text;
    const {declaration, statement} = arrows.get(name);
    let arrow = declaration.initializer;
    if (ts.isSatisfiesExpression(arrow)) arrow = arrow.expression;
    while (ts.isParenthesizedExpression(arrow)) arrow = arrow.expression;
    assert.ok(old.asteriskToken ? ts.isFunctionExpression(arrow) : ts.isArrowFunction(arrow), `${name}: callable form`);
    assert.equal(!!old.asteriskToken, !!arrow.asteriskToken, `${name}: generator`);
    if (old.asteriskToken) assert.equal(arrow.name?.text, old.name.text, `${name}: generator function name`);
    assert.equal(body(old.body, before), body(arrow.body, after), `${name}: body/evaluation order`);
    assert.deepEqual(old.parameters.map(node => normalized(node, before)), arrow.parameters.map(node => normalized(node, after)), `${name}: parameters/defaults`);
    assert.equal(normalized(old.type, before), normalized(arrow.type, after), `${name}: return type`);
    assert.deepEqual(old.typeParameters?.map(node => normalized(node, before)), arrow.typeParameters?.map(node => normalized(node, after)), `${name}: generic/readonly contract`);
    for (const kind of [ts.SyntaxKind.ExportKeyword]) assert.equal(old.modifiers?.some(modifier => modifier.kind === kind) ?? false, statement.modifiers?.some(modifier => modifier.kind === kind) ?? false, `${name}: export`);
    assert.equal(old.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.AsyncKeyword) ?? false, arrow.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.AsyncKeyword) ?? false, `${name}: async`);
    const oldSignatures = checkers.before.getSignaturesOfType(checkers.before.getTypeAtLocation(old.name), ts.SignatureKind.Call).map(signature => checkers.before.signatureToString(signature));
    const newSignatures = checkers.after.getSignaturesOfType(checkers.after.getTypeAtLocation(declaration.name), ts.SignatureKind.Call).map(signature => checkers.after.signatureToString(signature));
    const callable = (checker, nameNode) => checker.getSignaturesOfType(checker.getTypeAtLocation(nameNode), ts.SignatureKind.Call).map(signature => ({
      parameters: signature.parameters.map(parameter => ({name:parameter.name, type:canonicalType(checker,checker.getTypeOfSymbolAtLocation(parameter,nameNode))})),
      returns: canonicalType(checker,checker.getReturnTypeOfSignature(signature)),
    }));
    // Reordering declarations can change TypeScript's internal union member
    // IDs and therefore its display order. Compare the same members as a set;
    // exact parameter/default/generic/return AST equality is checked above.
    assert.deepEqual(callable(checkers.before,old.name), callable(checkers.after,declaration.name), `${name}: callable`);
    if (ts.isTypePredicateNode(old.type) && old.type.assertsModifier) assert.ok(declaration.type && (ts.isFunctionTypeNode(declaration.type) || ts.isTypeLiteralNode(declaration.type)), `${name}: explicit assertion callable`);
    const comments = node => node.jsDoc?.map(doc => doc.getText()).join('\n') ?? '';
    assert.equal(comments(allDeclarations.find(node => node.name.text === name)), comments(statement), `${name}: docs`);
    signatures.push({name, signature: newSignatures[0]});
  }
  const untouched = source => source.statements.filter(node => !ts.isFunctionDeclaration(node) && !(ts.isVariableStatement(node) && node.declarationList.declarations.some(declaration => item.ordered.includes(declaration.name.getText(source))))).map(node => normalized(node, source));
  assert.deepEqual(untouched(before), untouched(after), `${item.file}: imports/re-exports`);
  const actualOrder = after.statements.filter(ts.isVariableStatement).flatMap(statement => statement.declarationList.declarations.map(declaration => declaration.name.getText(after))).filter(name => item.ordered.includes(name));
  for (const name of item.movedPureTables) {
    const table = source => source.statements.find(node => ts.isVariableStatement(node) && node.declarationList.declarations.some(declaration => declaration.name.getText(source) === name));
    assert.equal(normalized(table(before), before), normalized(table(after), after), name + ': pure table values and property order');
  }
  const graphSymbols = new Map(after.statements.filter(ts.isVariableStatement).flatMap(statement => statement.declarationList.declarations.filter(declaration => item.ordered.includes(declaration.name.getText(after))).map(declaration => [checkers.after.getSymbolAtLocation(declaration.name), statement])));
  for (const statement of after.statements) {
    const checkUse = current => {
      if (ts.isIdentifier(current)) {
        const owner = graphSymbols.get(checkers.after.getSymbolAtLocation(current));
        if (owner && owner !== statement) assert.ok(owner.pos < statement.pos, current.text + ': precedes every top-level statement dependency');
      }
      ts.forEachChild(current, checkUse);
    };
    checkUse(statement);
  }
  assert.deepEqual(actualOrder, item.ordered);
  for (const entry of item.graph) for (const dependency of entry.dependencies) assert.ok(actualOrder.indexOf(dependency) < actualOrder.indexOf(entry.name), `${entry.name}: dependency ${dependency}`);
  fs.writeFileSync(path.join(proof, `${path.basename(item.file)}.after`), after.text);
  checks.push({file: item.file, functions: declarations.length, generatorFunctions: item.generatorCount, assertionFunctions: item.assertionCount, overloadDeclarations: item.overloadCount, bodiesParametersDefaultsGenericsReadonlyReturnsExportsAsyncDocsAndCallableSignaturesEqual: true, dependenciesPrecedeUse: true, nonCallableStatementsEqual: true, statefulTopLevelOrderEqual: true, pureTablesEqual: item.movedPureTables, signatures});
}
const targetRules = new Set(['eslint(func-style)', 'eslint(no-use-before-define)', 'typescript(no-use-before-define)']);
const modes = {};
const diagnosticIdentity = diagnostic => JSON.stringify([diagnostic.filename, diagnostic.code, diagnostic.message, diagnostic.help]);
for (const mode of ['syntactic', 'typeaware']) {
  const reports = Object.fromEntries(['before', 'after'].map(phase => [phase, JSON.parse(fs.readFileSync(path.join(proof, `${phase}-runtime-${mode}.json`), 'utf8'))]));
  const targets = phase => reports[phase].diagnostics.filter(diagnostic => plan.files.some(item => item.file === diagnostic.filename));
  const counts = diagnostics => Object.fromEntries([...new Set(diagnostics.map(diagnostic => diagnostic.code))].sort().map(code => [code, diagnostics.filter(diagnostic => diagnostic.code === code).length]));
  const target = Object.fromEntries(['before', 'after'].map(phase => [phase, {all: targets(phase).length, targetRules: targets(phase).filter(diagnostic => targetRules.has(diagnostic.code)).length, byRule: counts(targets(phase)), byFile: Object.fromEntries(plan.files.map(item => [item.file, counts(targets(phase).filter(diagnostic => diagnostic.filename === item.file))]))}]));
  assert.ok(target.before.targetRules > 0);
  assert.equal(target.after.targetRules, 0);
  const unrelated = phase => reports[phase].diagnostics.filter(diagnostic => !(plan.files.some(item => item.file === diagnostic.filename) && targetRules.has(diagnostic.code))).map(diagnosticIdentity).sort();
  assert.deepEqual(unrelated('before'), unrelated('after'), `${mode}: unrelated diagnostic debt`);
  assert.equal(reports.before.number_of_files, reports.after.number_of_files);
  assert.equal(reports.before.number_of_rules, reports.after.number_of_rules);
  modes[mode] = {before: reports.before.diagnostics.length, after: reports.after.diagnostics.length, numberOfFiles: reports.after.number_of_files, numberOfRules: reports.after.number_of_rules, target, unrelatedDiagnosticDebtEqual: true};
}
const changedFiles = execFileSync('git', ['diff', '--name-only'], {encoding:'utf8'}).trim().split('\n');
assert.deepEqual([...changedFiles].sort(), plan.files.map(item => item.file).sort());
fs.writeFileSync(path.join(proof,'baseline-target-failures.json'), JSON.stringify(Object.fromEntries(Object.entries(modes).map(([mode,value]) => [mode,value.target.before])),null,2)+'\n');
const selection = phase => fs.readFileSync(path.join(proof,phase+'-native-selection.log'),'utf8').split('\n').filter(line => line.startsWith('typescript/kernel/runtime/')).sort();
assert.ok(selection('before').length > 0);
assert.deepEqual(selection('before'),selection('after'),'native discovery selection');
const sourceHashes = Object.fromEntries(plan.files.map(item => [item.file, Object.fromEntries(['before','after'].map(phase => [phase, hash(fs.readFileSync(path.join(proof, `${path.basename(item.file)}.${phase}`)))]))]));
const diff = execFileSync('git', ['diff', '--numstat'], {encoding:'utf8'}).trim().split('\n').map(line => {const [added, removed, file] = line.split('\t'); return {file, added: Number(added), removed: Number(removed)};});
const lineCounts = Object.fromEntries(plan.files.map(item => [item.file, Object.fromEntries(['before','after'].map(phase => [phase, fs.readFileSync(path.join(proof, `${path.basename(item.file)}.${phase}`),'utf8').split('\n').length-1]))]));
for (const [file, counts] of Object.entries(lineCounts)) assert.ok(counts.after <= counts.before, file + ': legacy-size non-growth');
const gates = Object.fromEntries(fs.readdirSync(proof).filter(file => file.endsWith('.exit')).sort().map(file => [file.replace(/\.exit$/, ''), Number(fs.readFileSync(path.join(proof,file),'utf8').trim())]));
fs.writeFileSync(path.join(proof, 'structural-details.json'), `${JSON.stringify(checks,null,2)}\n`);
const result = {baselineCommit:plan.baselineCommit, changedFiles, diff:{files:diff, added:diff.reduce((sum,item)=>sum+item.added,0), removed:diff.reduce((sum,item)=>sum+item.removed,0)}, sourceHashes, lineCounts, conversion:{functions:checks.reduce((sum,item)=>sum+item.functions,0), arrows:checks.reduce((sum,item)=>sum+item.functions-item.generatorFunctions,0), assertions:checks.reduce((sum,item)=>sum+item.assertionFunctions,0), generators:checks.reduce((sum,item)=>sum+item.generatorFunctions,0), files:checks.map(({signatures,...item}) => item)}, nativeDiagnostics:modes, gates, introducedPatterns:[], newDependencies:[], newConventions:[], newContractShapes:[], intentionalApiChanges:[], subdivisionRecommendation:null, deferredTicketWideChecks:['aggregate typecheck','same-tree conformance'], drift:[], notes:[
 'Only declaration-to-expression conversion and dependency ordering; all async, generator, await, yield, transaction, staging, lease, error and event operations remain in their original function bodies.',
 'walkBack and walkBackFromTx become named async generator expressions retaining their original function names and exported names; lazy generator execution is retained without wrappers or added boundaries.',
 'Recursive toKernelRecord keeps explicit return typing and identical recursive operations; self references stay within its deferred body.',
 'Compiler callable comparison canonicalizes union member display order only; exact parameter/default/generic/return type ASTs remain equal.',
 'Existing 1162/1055-line legacy modules do not grow, under the plan size exception.',
 'Both native modes retain unrelated diagnostic debt and discovery selection; expected exit 1 remains until later batches.',
 'No authority, configuration, changeset, test expectation, or constitution changes; no commits.',
 'Current compiler signatures verified against installed TypeScript 6.0.2 declarations; native CLI options verified against installed help. Exa is unavailable.'

]};
fs.writeFileSync(path.join(proof,'summary.json'),`${JSON.stringify(result,null,2)}\n`);
console.log(JSON.stringify({conversion:result.conversion.functions, assertions:result.conversion.assertions, diff:result.diff, nativeDiagnostics:modes,gates},null,2));
