import fs from 'node:fs';
import assert from 'node:assert/strict';
import path from 'node:path';
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m12r';
const extract = name => {
  const lines = fs.readFileSync(path.join(proof, name), 'utf8').replace(/\x1b\[[0-9;]*m/g, '').replace(/\r/g, '').split('\n');
  const lanes = {};
  for (let index = 0; index < lines.length; index++) {
    const match = /^(?:([\w-]+): )?\{$/.exec(lines[index]);
    if (!match) continue;
    const project = match[1];
    const block = ['{'];
    for (index++; index < lines.length; index++) {
      const prefix = project ? project + ': ' : '';
      if (!lines[index].startsWith(prefix)) continue;
      const line = lines[index].slice(prefix.length);
      block.push(line);
      if (line === '}') break;
    }
    const result = JSON.parse(block.join('\n'));
    if (!result.adapterId) continue;
    const identity = result.adapterId;
    assert.equal(result.status, 'pass', identity);
    assert.equal(result.summary.failedChecks, 0, identity);
    assert.ok(!lanes[identity], identity + ': duplicate lane');
    lanes[identity] = result;
  }
  assert.equal(Object.keys(lanes).length, 11, name + ': lane count');
  return Object.fromEntries(Object.entries(lanes).sort(([a], [b]) => a.localeCompare(b)));
};
const baseline = extract('baseline-m4-conformance.log');
const latest = extract('latest-m7-conformance.log');
const current = extract('after-conformance.log');
assert.deepEqual(current, baseline, 'M4 pre-reorder outcomes and counts');
assert.deepEqual(current, latest, 'M7 latest preserved raw outcomes and counts');
const result = {
  laneCount: 11,
  matchesPreReorderM4: true,
  matchesLatestPreservedM7: true,
  latestReviewedM11R: 'Independent reviewer confirmed all 11 lanes and archived counts; raw M7 is the latest preserved durable log.',
  provenance: {
    baseline: '/home/oscar/.codex/plans/tuvren-bq-session/m4/conformance.log',
    latest: '/home/oscar/.codex/plans/tuvren-bq-session/m7/after-conformance.log',
  },
  lanes: current,
};
fs.writeFileSync(path.join(proof, 'conformance-comparison.json'), JSON.stringify(result, null, 2) + '\n');
console.log('All 11 conformance lane identities, outcomes and counts match M4 and M7.');
