import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
const root=process.cwd();
const proof='/home/oscar/.codex/plans/tuvren-bq-session/m12r';
const baselineCommit='e94425942992b87b7119a4aecd2a63dea32073b2';
assert.equal(execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),baselineCommit);
assert.equal(execFileSync('git',['status','--porcelain'],{encoding:'utf8'}).trim(),'');
const ts=await import(path.join(root,'node_modules/typescript/lib/typescript.js'));
assert.equal(ts.version,'6.0.2');
const cfg=ts.readConfigFile('typescript/kernel/runtime/tsconfig.typecheck.json',ts.sys.readFile);
assert.ok(!cfg.error);
const config=ts.parseJsonConfigFileContent(cfg.config,ts.sys,path.resolve('typescript/kernel/runtime'));
const program=ts.createProgram(config.fileNames,config.options);
const checker=program.getTypeChecker();
const files=["src/lib/runtime-kernel.ts","src/lib/runtime-kernel-runs.ts","test/runtime-kernel.turn-tree-chunking.test.ts","test/runtime-kernel-reclamation.test.ts","test/runtime-kernel-lineage.apply-staged-results.test.ts","test/runtime-kernel-storage.chunk-aware.test.ts","test/runtime-kernel-storage.chunk-constant-agreement.test.ts","test/runtime-kernel-test-helpers.ts"].map(name=>`typescript/kernel/runtime/${name}`);
const plan={baselineCommit,typescript:ts.version,files:[]};
const targetRules=new Set(['eslint(func-style)','eslint(no-use-before-define)','typescript(no-use-before-define)']);
const baseline=Object.fromEntries(['syntactic','typeaware'].map(mode=>{
 const report=JSON.parse(fs.readFileSync(path.join(proof,`before-runtime-${mode}.json`),'utf8'));
 const failures=report.diagnostics.filter(d=>files.includes(d.filename)&&targetRules.has(d.code));
 assert.ok(failures.length>0);
 return [mode,{targetRuleFailures:failures.length,byFile:Object.fromEntries(files.map(file=>[file,failures.filter(d=>d.filename===file).length]))}];
}));
fs.writeFileSync(path.join(proof,'baseline-target-failures.json'),`${JSON.stringify(baseline,null,2)}\n`);
for(const file of files){
 const text=fs.readFileSync(file,'utf8');
 const source=program.getSourceFile(path.resolve(file));
 assert.ok(source);
 const declarations=source.statements.filter(ts.isFunctionDeclaration);
 const bySymbol=new Map(declarations.map(node=>[checker.getSymbolAtLocation(node.name),node.name.text]));
 const dependencies=node=>{
  const names=new Set();
  const visit=current=>{if(ts.isIdentifier(current)){const name=bySymbol.get(checker.getSymbolAtLocation(current));if(name)names.add(name);}ts.forEachChild(current,visit);};
  visit(node);return [...names];
 };
 const graph=[],converted=new Map();
 for(const declaration of declarations){
  assert.ok(declaration.name&&declaration.type&&declaration.body);
  const lexical=[];
  const visit=node=>{if(node.kind===ts.SyntaxKind.ThisKeyword||(ts.isMetaProperty(node)&&node.keywordToken===ts.SyntaxKind.NewKeyword)||(ts.isIdentifier(node)&&node.text==='arguments'))lexical.push(node.getText(source));ts.forEachChild(node,visit);};
  visit(declaration.body);assert.equal(lexical.length,0);
  assert.ok(!(ts.isTypePredicateNode(declaration.type)&&declaration.type.assertsModifier),'Unexpected assertion callable');
  const uses=[...new Set([...declaration.parameters.flatMap(dependencies),...dependencies(declaration.body)])];
  const recursive=uses.includes(declaration.name.text);
  const deps=uses.filter(name=>name!==declaration.name.text);
  const generator=!!declaration.asteriskToken;
  const async=declaration.modifiers?.some(m=>m.kind===ts.SyntaxKind.AsyncKeyword)??false;
  graph.push({name:declaration.name.text,dependencies:deps,generator,async,recursive,lexical});
  const leading=text.slice(declaration.getFullStart(),declaration.getStart(source));
  const exported=declaration.modifiers?.some(m=>m.kind===ts.SyntaxKind.ExportKeyword)?'export ':'';
  const signature=text.slice(declaration.name.end,declaration.body.getStart(source)).trim();
  const concise=!generator&&declaration.body.statements.length===1&&ts.isReturnStatement(declaration.body.statements[0])&&declaration.body.statements[0].expression;
  const body=concise?`(${declaration.body.statements[0].expression.getText(source)})`:declaration.body.getText(source);
  const callable=generator?`${async?'async ':''}function* ${declaration.name.text}${signature} ${body}`:`${async?'async ':''}${signature} => ${body}`;
  converted.set(declaration.name.text,`${leading}${exported}const ${declaration.name.text} = ${callable};`);
 }
 const done=new Set(),active=new Set(),ordered=[],chunks=[];
 const emit=name=>{if(done.has(name))return;assert.ok(!active.has(name),'Unexpected cycle: '+name);active.add(name);for(const dep of graph.find(x=>x.name===name).dependencies)emit(dep);active.delete(name);done.add(name);ordered.push(name);chunks.push(converted.get(name));};
 for(const statement of source.statements){
  if(ts.isFunctionDeclaration(statement)){emit(statement.name.text);continue;}
  for(const needed of dependencies(statement))emit(needed);
  chunks.push(text.slice(statement.getFullStart(),statement.end));
 }
 for(const item of graph)emit(item.name);
 fs.writeFileSync(path.join(proof,`${path.basename(file)}.before`),text);
 plan.files.push({file,count:declarations.length,assertionCount:0,overloadCount:0,generatorCount:graph.filter(x=>x.generator).length,graph,ordered,movedPureTables:[]});
 const output=`${chunks.join('')}\n`;
 const parsed=ts.createSourceFile(file,output,ts.ScriptTarget.Latest,true);
 assert.equal(parsed.parseDiagnostics.length,0);
 converted.set('output',output);
 // Delay writes until the graph and generated syntax for both modules pass.
 plan.files.at(-1).output=output;
}
for(const item of plan.files){fs.writeFileSync(item.file,item.output);delete item.output;}
fs.writeFileSync(path.join(proof,'conversion-plan.json'),`${JSON.stringify(plan,null,2)}\n`);
console.log(plan.files.map(({file,count,generatorCount})=>({file,count,generatorCount})));
