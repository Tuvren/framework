#!/usr/bin/env zsh
set -uo pipefail
proof=/home/oscar/.codex/plans/tuvren-bq-session/m12r
phase=$1
gate() {
  local gate_name=$1
  shift
  "$@" > "$proof/$phase-$gate_name.log" 2>&1
  local gate_exit=$?
  print -r -- "$gate_exit" > "$proof/$phase-$gate_name.exit"
  print -r -- "$gate_name: $gate_exit"
  if (( gate_exit != 0 )); then tail -40 "$proof/$phase-$gate_name.log"; return "$gate_exit"; fi
}
for mode in syntactic typeaware; do
  args=()
  if [[ $mode == typeaware ]]; then args+=(--type-aware); fi
  bunx --bun oxlint "${args[@]}" --format json typescript/kernel/runtime > "$proof/$phase-runtime-$mode.json" 2> "$proof/$phase-runtime-$mode.stderr"
  print -r -- $? > "$proof/$phase-runtime-$mode.exit"
done
gate native-selection bunx --bun oxlint --debug=files typescript/kernel/runtime || exit $?
gate scoped bun run nx run-many -t typecheck,test -p kernel-contract-protocol,kernel-runtime --parallel=1 || exit $?
gate fresh-process bun test typescript/kernel/protocol/test/kernel-module-initialization.test.ts || exit $?
if [[ $phase == after ]]; then
  for mode in syntactic typeaware; do
    args=()
    if [[ $mode == typeaware ]]; then args+=(--type-aware); fi
    bunx --bun oxlint "${args[@]}" --format json typescript/kernel/protocol > "$proof/after-protocol-$mode.json" 2> "$proof/after-protocol-$mode.stderr"
    print -r -- $? > "$proof/after-protocol-$mode.exit"
  done
  gate protocol-native-selection bunx --bun oxlint --debug=files typescript/kernel/protocol || exit $?
  gate format-touched bunx --bun oxfmt --check typescript/kernel/runtime/src/lib/runtime-kernel.ts typescript/kernel/runtime/src/lib/runtime-kernel-runs.ts typescript/kernel/runtime/test/runtime-kernel.turn-tree-chunking.test.ts typescript/kernel/runtime/test/runtime-kernel-reclamation.test.ts typescript/kernel/runtime/test/runtime-kernel-lineage.apply-staged-results.test.ts typescript/kernel/runtime/test/runtime-kernel-storage.chunk-aware.test.ts typescript/kernel/runtime/test/runtime-kernel-storage.chunk-constant-agreement.test.ts typescript/kernel/runtime/test/runtime-kernel-test-helpers.ts || exit $?
  gate format-full bun run format:check || exit $?
  gate typecheck bun run typecheck || exit $?
  gate retained-biome bunx --bun @biomejs/biome lint typescript/kernel/protocol typescript/kernel/runtime || exit $?
  gate lint bun run lint || exit $?
  gate changeset bun run changeset:check || exit $?
  gate conformance bun run conformance || exit $?
  gate diff-check git diff --check || exit $?
fi
