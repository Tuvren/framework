import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {execFileSync,spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const proof='/home/oscar/.codex/plans/tuvren-bq-session/m12r';
const capture=(name,command,args) => {
  const result=spawnSync(command,args,{encoding:'utf8'});
  fs.writeFileSync(path.join(proof,`${name}.log`),(result.stdout??'')+(result.stderr??''));
  fs.writeFileSync(path.join(proof,`${name}.exit`),`${result.status}\n`);
  return result;
};
const baseline=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
assert.equal(baseline,'e94425942992b87b7119a4aecd2a63dea32073b2');
const versions=[['bun',['--version']],['bunx',['--bun','oxlint','--version']],['bunx',['--bun','oxfmt','--version']],['bunx',['--bun','biome','--version']]].map(([command,args])=>({command:[command,...args].join(' '),version:execFileSync(command,args,{encoding:'utf8'}).trim()}));
fs.writeFileSync(path.join(proof,'installed-versions.json'),`${JSON.stringify(versions,null,2)}\n`);
const declarations=fs.readFileSync('node_modules/typescript/lib/typescript.d.ts','utf8').split('\n');
const selected=declarations.map((line,index)=>`${index+1}: ${line}`).filter(line=>/function (createSourceFile|createProgram|createCompilerHost|createPrinter|readConfigFile|parseJsonConfigFileContent|forEachChild|isFunctionDeclaration|isFunctionExpression|isTypePredicateNode|isTypeLiteralNode|isFunctionTypeNode|isArrowFunction|isVariableStatement|isSatisfiesExpression|isParenthesizedExpression|isParenthesizedTypeNode)|signatureToSignatureDeclaration\(|signatureToString\(|getSignatureFromDeclaration\(|getSignaturesOfType\(|getSymbolAtLocation\(|getTypeAtLocation\(|getReturnTypeOfSignature\(|typeToString\(|getTypeOfSymbolAtLocation\(|isUnion\(/.test(line));
fs.writeFileSync(path.join(proof,'compiler-api-verification.txt'),`${selected.join('\n')}\n`);
assert.equal(Number(fs.readFileSync(path.join(proof,'after-native-selection.exit'),'utf8')),0);
const conformance=capture('conformance-comparison','bun',[path.join(proof,'compare-conformance.mjs')]);
assert.equal(conformance.status,0,conformance.stdout+conformance.stderr);
const structural=capture('structural-proof','bun',[path.join(proof,'prove.mjs')]);
assert.equal(structural.status,0,structural.stdout+structural.stderr);
const summary=JSON.parse(fs.readFileSync(path.join(proof,'summary.json'),'utf8'));
summary.gates['structural-proof']=0;
summary.validation={scopedTestsBefore:148,scopedTestsAfter:148,protocolTests:92,runtimeTests:56,freshProcessCasesBefore:6,freshProcessCasesAfter:6,failures:0};
summary.conformance=JSON.parse(fs.readFileSync(path.join(proof,'conformance-comparison.json'),'utf8'));
const indexPath='typescript/kernel/runtime/src/index.ts';
const indexBefore=execFileSync('git',['show',baseline+':'+indexPath]);
const indexAfter=fs.readFileSync(indexPath);
assert.deepEqual(indexBefore,indexAfter);
summary.unchangedBarrel={path:indexPath,sha256:createHash('sha256').update(indexAfter).digest('hex'),directivePreserved:true};
const changeset=fs.readFileSync('.changeset/toolchain-bq-kernel-lint-pilot.md','utf8');
for(const pkg of ['@tuvren/kernel-protocol','@tuvren/kernel-runtime']) assert.ok(changeset.includes(`"${pkg}": patch`),pkg+': direct patch coverage');
summary.directPatchCoverage=['@tuvren/kernel-protocol','@tuvren/kernel-runtime'];
for(const [gate,code] of Object.entries(summary.gates)) if(!gate.includes('-syntactic')&&!gate.includes('-typeaware')) assert.equal(code,0,gate);
summary.nativeDiagnostics=Object.fromEntries(Object.entries(summary.nativeDiagnostics).map(([mode,value])=>[mode,{
  before:value.before,after:value.after,numberOfFiles:value.numberOfFiles,numberOfRules:value.numberOfRules,
  targetRulesBefore:value.target.before.targetRules,targetRulesAfter:value.target.after.targetRules,
  targetRuleDelta:{'eslint(func-style)':-19,'eslint(no-use-before-define)':0},
  unrelatedDiagnosticDebtEqual:value.unrelatedDiagnosticDebtEqual,
}]));
summary.conformance={
  laneCount:summary.conformance.laneCount,
  matchesPreReorderM4:summary.conformance.matchesPreReorderM4,
  matchesLatestPreservedM7:summary.conformance.matchesLatestPreservedM7,
  provenance:summary.conformance.provenance,
  details:'conformance-comparison.json',
};
fs.writeFileSync(path.join(proof,'summary.json'),`${JSON.stringify(summary,null,2)}\n`);
fs.writeFileSync(path.join(proof,'m12r.patch'),execFileSync('git',['diff','--binary'],{encoding:'utf8'}));
fs.writeFileSync(path.join(proof,'final-status.txt'),execFileSync('git',['status','--short'],{encoding:'utf8'}));
const members=fs.readdirSync(proof).filter(name=>!['proof-index.json','m12r-proof.tar.gz'].includes(name)).sort();
assert.equal(members.length,new Set(members).size);
for(const name of members) assert.ok(fs.statSync(path.join(proof,name)).isFile());
execFileSync('tar',['-czf',path.join(proof,'m12r-proof.tar.gz'),'-C',proof,...members]);
const archiveMembers=execFileSync('tar',['-tzf',path.join(proof,'m12r-proof.tar.gz')],{encoding:'utf8'}).trim().split('\n');
assert.deepEqual(archiveMembers,members);
const digest=name=>{const data=fs.readFileSync(path.join(proof,name)); return {path:name,sha256:createHash('sha256').update(data).digest('hex'),bytes:data.length};};
const digested=members.map(digest);
const archiveDigest=digest('m12r-proof.tar.gz');
fs.writeFileSync(path.join(proof,'proof-index.json'),`${JSON.stringify({baselineCommit:summary.baselineCommit,archive:'m12r-proof.tar.gz',uniqueMembers:members.length,artifacts:digested,archiveDigest},null,2)}\n`);
console.log({summary:path.join(proof,'summary.json'),archiveMembers:members.length,archiveBytes:archiveDigest.bytes,changedFiles:summary.changedFiles,nativeDiagnostics:summary.nativeDiagnostics,testPasses:148,freshProcessPasses:6});
