import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
const root = process.cwd();
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m5';
const plan = JSON.parse(fs.readFileSync(path.join(proof, 'conversion-plan.json'), 'utf8'));
const exports = plan.graph.map(item => item.name).filter(name => !['hashTurnNodeIdentity', 'hashTurnTreeIdentity'].includes(name));
const captures = {};
const sourceHashes = {};
for (const phase of ['before', 'after']) {
  const directory = path.join(proof, 'local-runtime-mirror', phase);
  fs.mkdirSync(directory, {recursive: true});
  const source = fs.readFileSync(phase === 'before' ? path.join(proof, 'kernel-identity.before.ts') : path.join(root, 'typescript/kernel/protocol/src/lib/kernel-identity.ts'), 'utf8');
  sourceHashes[phase] = createHash('sha256').update(source).digest('hex');
  const extension = `\nexport { ${exports.join(', ')} };\n`;
  fs.writeFileSync(path.join(directory, 'kernel-identity.ts'), source + extension);
  fs.writeFileSync(path.join(directory, 'tsconfig.json'), JSON.stringify({compilerOptions: {paths: {'@tuvren/core': [path.join(root, 'typescript/core/src/index.ts')]}}}));
  const target = path.join(directory, 'kernel-record-identity.ts');
  if (!fs.existsSync(target)) fs.symlinkSync(path.join(root, 'typescript/kernel/protocol/src/lib/kernel-record-identity.ts'), target);
  const dependencies = path.join(directory, 'node_modules');
  if (!fs.existsSync(dependencies)) fs.symlinkSync(path.join(root, 'node_modules'), dependencies);
  const module = await import(path.join(directory, 'kernel-identity.ts'));
  captures[phase] = Object.fromEntries(plan.graph.map(({name}) => {
    const callable = module[name];
    if (typeof callable !== 'function') throw new Error(`Missing local runtime callable ${name}`);
    return [name, {name: callable.name, length: callable.length, constructor: callable.constructor.name}];
  }).sort(([a], [b]) => a.localeCompare(b)));
}
const equal = JSON.stringify(captures.before) === JSON.stringify(captures.after);
fs.writeFileSync(path.join(proof, 'local-runtime-compatibility.json'), JSON.stringify({sourceHashes, sourceModification: 'Append-only exports of otherwise private helpers in external scratch mirrors; measured source bytes otherwise unchanged.', before: captures.before, after: captures.after, equal}, null, 2) + '\n');
if (!equal) throw new Error('Local runtime callable name, arity, or async constructor changed');
console.log('All 28 local runtime callable names, arities and async constructors match baseline in external append-only export mirrors.');
