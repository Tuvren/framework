import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m5';
const phase = process.argv[2];
if (!['before', 'after'].includes(phase)) throw new Error('Phase missing');
const identity = await import(path.join(root, 'typescript/kernel/protocol/src/lib/kernel-identity.ts'));
const entrypoint = await import(path.join(root, 'typescript/kernel/protocol/src/index.ts'));
const outputs = {};
for (const [label, module] of [['identity', identity], ['entrypoint', entrypoint]]) {
  outputs[label] = Object.fromEntries(Object.entries(module).filter(([, value]) => typeof value === 'function').map(([key, value]) => [key, {name: value.name, length: value.length, constructor: value.constructor.name}]));
}
const errors = {};
try { identity.hashTurnTreeIdentity('', {}, {}); } catch (error) { errors.tree = {mode: 'synchronous', name: error.name, code: error.code, message: error.message, details: error.details}; }
const pending = identity.hashTurnNodeIdentity({});
if (!(pending instanceof Promise)) throw new Error('Node hash must return a promise');
try { await pending; } catch (error) { errors.node = {mode: 'promise-rejection', name: error.name, code: error.code, message: error.message, details: error.details}; }
const result = {outputs, errors};
fs.writeFileSync(path.join(proof, `runtime-${phase}.json`), JSON.stringify(result, null, 2) + '\n');
if (phase === 'after') {
  const baseline = JSON.parse(fs.readFileSync(path.join(proof, 'runtime-before.json'), 'utf8'));
  if (JSON.stringify(baseline) !== JSON.stringify(result)) throw new Error('Public names/arities/async constructors or synchronous/rejection error behavior changed');
}
console.log(`${Object.values(outputs).reduce((sum, module) => sum + Object.keys(module).length, 0)} exported runtime callable observations captured; tree synchronous failure and node async rejection preserved.`);
