import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m5';
const ts = await import(path.join(root, 'node_modules/typescript/lib/typescript.js'));
const file = 'typescript/kernel/protocol/src/lib/kernel-identity.ts';
const text = fs.readFileSync(file, 'utf8');
fs.writeFileSync(path.join(proof, 'kernel-identity.before.ts'), text);
const configFile = ts.readConfigFile('typescript/kernel/protocol/tsconfig.typecheck.json', ts.sys.readFile);
if (configFile.error) throw new Error(ts.flattenDiagnosticMessageText(configFile.error.messageText, '\n'));
const config = ts.parseJsonConfigFileContent(configFile.config, ts.sys, path.resolve('typescript/kernel/protocol'));
const program = ts.createProgram(config.fileNames, config.options);
const checker = program.getTypeChecker();
const source = program.getSourceFile(path.resolve(file));
if (!source) throw new Error('Module absent from source-only compiler program');
const declarations = source.statements.filter(ts.isFunctionDeclaration);
const bySymbol = new Map(declarations.map(declaration => [checker.getSymbolAtLocation(declaration.name), declaration]));
const graph = declarations.map(declaration => {
  const dependencies = new Set();
  const lexical = [];
  const visit = node => {
    if (node.kind === ts.SyntaxKind.ThisKeyword || ts.isMetaProperty(node) || (ts.isIdentifier(node) && node.text === 'arguments') || (ts.isFunctionLike(node) && node.asteriskToken)) {
      lexical.push({kind: ts.SyntaxKind[node.kind], source: node.getText(source)});
    }
    if (ts.isIdentifier(node)) {
      const target = bySymbol.get(checker.getSymbolAtLocation(node));
      if (target && target !== declaration) dependencies.add(target.name.text);
    }
    ts.forEachChild(node, visit);
  };
  visit(declaration.body);
  if (lexical.length > 0) throw new Error(`Lexical-sensitive function ${declaration.name.text}: ${JSON.stringify(lexical)}`);
  return {name: declaration.name.text, dependencies: [...dependencies], lexical};
});
const ordered = [];
const done = new Set();
while (ordered.length < graph.length) {
  const next = graph.find(item => !done.has(item.name) && item.dependencies.every(name => done.has(name)));
  if (!next) throw new Error('Cyclic local helper dependencies');
  done.add(next.name);
  ordered.push(next.name);
}
const printer = ts.createPrinter();
const converted = new Map(declarations.map(declaration => {
  if (!declaration.name || !declaration.type || !declaration.body) throw new Error('Incomplete declaration');
  const name = declaration.name.text;
  const comments = text.slice(declaration.getFullStart(), declaration.getStart(source));
  const exported = declaration.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.ExportKeyword) ? 'export ' : '';
  const asyncPrefix = declaration.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.AsyncKeyword) ? 'async ' : '';
  const open = declaration.getChildren(source).find(node => node.kind === ts.SyntaxKind.OpenParenToken);
  if (!open) throw new Error('Function parameters missing');
  const signature = text.slice(open.getStart(source), declaration.body.getStart(source)).trimEnd();
  let callable = `${asyncPrefix}${signature} => ${declaration.body.getText(source)}`;
  let annotation = '';
  if (ts.isTypePredicateNode(declaration.type) && declaration.type.assertsModifier) {
    const functionType = ts.factory.createFunctionTypeNode(declaration.typeParameters, declaration.parameters, declaration.type);
    annotation = `: ${printer.printNode(ts.EmitHint.Unspecified, functionType, source)}`;
    callable = `${asyncPrefix}(${declaration.parameters.map(parameter => parameter.name.getText(source)).join(', ')}) => ${declaration.body.getText(source)}`;
  }
  return [name, `${comments}${exported}const ${name}${annotation} = ${callable};`];
}));
const prefix = text.slice(0, declarations[0].getFullStart());
const candidate = prefix + ordered.map(name => converted.get(name)).join('') + '\n';
fs.writeFileSync(path.join(proof, 'kernel-identity.candidate.ts'), candidate);
fs.writeFileSync(path.join(proof, 'conversion-plan.json'), JSON.stringify({typescript: ts.version, file, graph, ordered, count: declarations.length}, null, 2) + '\n');
console.log(JSON.stringify({functions: declarations.length, order: ordered, lexicalSensitiveUses: 0}));
