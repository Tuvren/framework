import fs from 'node:fs';
import path from 'node:path';
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m5';
const file = 'typescript/kernel/protocol/src/lib/kernel-identity.ts';
const counts = diagnostics => Object.fromEntries([...new Set(diagnostics.map(item => item.code))].sort().map(code => [code, diagnostics.filter(item => item.code === code).length]));
const reports = [];
for (const phase of ['before', 'after']) for (const scope of ['protocol', 'runtime']) for (const mode of ['syntactic', 'typeaware']) {
  const name = `${phase}-${scope}-${mode}`;
  const report = JSON.parse(fs.readFileSync(path.join(proof, `${name}.json`), 'utf8'));
  const own = report.diagnostics.filter(item => item.filename === file);
  const outside = report.diagnostics.filter(item => item.filename !== file);
  const result = {phase, scope, mode, filename: `${name}.json`, filesSelected: report.number_of_files, rules: report.number_of_rules, total: report.diagnostics.length, identityTotal: own.length, identityRuleCounts: counts(own), outsideRuleCounts: counts(outside), stderr: fs.readFileSync(path.join(proof, `${name}.stderr`), 'utf8'), commandExit: Number(fs.readFileSync(path.join(proof, `${name}.exit`), 'utf8'))};
  if (result.filesSelected === 0 || result.stderr.length !== 0) throw new Error(`Unexpected native selection/backend stderr in ${name}`);
  if (phase === 'after' && own.some(item => ['eslint(func-style)', 'eslint(no-use-before-define)'].includes(item.code))) throw new Error(`Requested diagnostic still fires: ${name}`);
  reports.push(result);
}
for (const scope of ['protocol', 'runtime']) for (const mode of ['syntactic', 'typeaware']) {
  const before = reports.find(item => item.phase === 'before' && item.scope === scope && item.mode === mode);
  const after = reports.find(item => item.phase === 'after' && item.scope === scope && item.mode === mode);
  if (before.filesSelected !== after.filesSelected || before.rules !== after.rules || JSON.stringify(before.outsideRuleCounts) !== JSON.stringify(after.outsideRuleCounts)) throw new Error('Unrelated native diagnostics or selected coverage changed');
  const expected = Object.fromEntries(Object.entries(before.identityRuleCounts).filter(([code]) => !['eslint(func-style)', 'eslint(no-use-before-define)'].includes(code)));
  if (JSON.stringify(expected) !== JSON.stringify(after.identityRuleCounts)) throw new Error('Unexpected diagnostic changes inside identity');
}
fs.writeFileSync(path.join(proof, 'native-summary.json'), JSON.stringify(reports, null, 2) + '\n');
for (const report of reports) console.log(`${report.phase} ${report.scope} ${report.mode}: total=${report.total}, identity=${report.identityTotal}, files=${report.filesSelected}, rules=${report.rules}, func-style=${report.identityRuleCounts['eslint(func-style)'] ?? 0}, no-use-before-define=${report.identityRuleCounts['eslint(no-use-before-define)'] ?? 0}`);
