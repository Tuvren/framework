import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m5';
const ts = await import(path.join(root, 'node_modules/typescript/lib/typescript.js'));
const file = 'typescript/kernel/protocol/src/lib/kernel-identity.ts';
const configFile = ts.readConfigFile('typescript/kernel/protocol/tsconfig.typecheck.json', ts.sys.readFile);
if (configFile.error) throw new Error(ts.flattenDiagnosticMessageText(configFile.error.messageText, '\n'));
const config = ts.parseJsonConfigFileContent(configFile.config, ts.sys, path.resolve('typescript/kernel/protocol'));
const printer = ts.createPrinter();
// Concise arrow bodies are equivalent only to a block with one return of that
// exact expression. No other statement or control-flow rewrite is normalized.
const bodyNode = body => ts.isBlock(body) && body.statements.length === 1 && ts.isReturnStatement(body.statements[0]) && body.statements[0].expression ? body.statements[0].expression : body;
const capture = baseline => {
  const host = ts.createCompilerHost(config.options);
  const originalRead = host.readFile.bind(host);
  if (baseline) host.readFile = filename => path.resolve(filename) === path.resolve(file) ? fs.readFileSync(path.join(proof, 'kernel-identity.before.ts'), 'utf8') : originalRead(filename);
  const program = ts.createProgram(config.fileNames, config.options, host);
  const checker = program.getTypeChecker();
  const source = program.getSourceFile(path.resolve(file));
  if (!source) throw new Error('Identity source missing');
  const printType = type => {
    const node = checker.typeToTypeNode(type, source, ts.NodeBuilderFlags.NoTruncation);
    if (!node) throw new Error('Missing full type AST');
    return printer.printNode(ts.EmitHint.Unspecified, node, source);
  };
  const callable = symbol => {
    const type = checker.getTypeOfSymbolAtLocation(symbol, source);
    return checker.getSignaturesOfType(type, ts.SignatureKind.Call).map(signature => {
      const node = checker.signatureToSignatureDeclaration(signature, ts.SyntaxKind.FunctionType, source, ts.NodeBuilderFlags.NoTruncation);
      if (!node || !ts.isFunctionTypeNode(node)) throw new Error('Missing callable AST');
      const predicate = checker.getTypePredicateOfSignature(signature);
      return {
        signature: printer.printNode(ts.EmitHint.Unspecified, node, source),
        predicate: predicate ? {kind: ts.TypePredicateKind[predicate.kind], parameterName: predicate.parameterName, parameterIndex: predicate.parameterIndex, type: predicate.type ? printType(predicate.type) : null} : null,
      };
    });
  };
  const locals = {};
  for (const statement of source.statements) {
    const declaration = ts.isFunctionDeclaration(statement) ? statement : ts.isVariableStatement(statement) ? statement.declarationList.declarations[0] : undefined;
    if (!declaration || !declaration.name || !ts.isIdentifier(declaration.name)) continue;
    const body = ts.isFunctionDeclaration(declaration) ? declaration.body : declaration.initializer && ts.isArrowFunction(declaration.initializer) ? declaration.initializer.body : undefined;
    if (!body) continue;
    const symbol = checker.getSymbolAtLocation(declaration.name);
    if (!symbol) throw new Error('Missing local callable symbol');
    const fn = ts.isFunctionDeclaration(declaration) ? declaration : declaration.initializer;
    locals[declaration.name.text] = {callSignatures: callable(symbol), body: printer.printNode(ts.EmitHint.Unspecified, bodyNode(body), source), async: fn.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.AsyncKeyword) ?? false,
      parameters: fn.parameters.map(parameter => ({name: parameter.name.getText(source), optional: Boolean(parameter.questionToken), rest: Boolean(parameter.dotDotDotToken), default: parameter.initializer ? printer.printNode(ts.EmitHint.Unspecified, parameter.initializer, source) : null}))};
  }
  const publicModules = {};
  for (const moduleFile of [file, 'typescript/kernel/protocol/src/index.ts']) {
    const moduleSource = program.getSourceFile(path.resolve(moduleFile));
    const moduleSymbol = moduleSource && checker.getSymbolAtLocation(moduleSource);
    if (!moduleSymbol) throw new Error('Public module missing');
    publicModules[moduleFile] = Object.fromEntries(checker.getExportsOfModule(moduleSymbol).map(symbol => [symbol.name, callable(symbol)]).sort(([a], [b]) => a.localeCompare(b)));
  }
  return {locals: Object.fromEntries(Object.entries(locals).sort(([a], [b]) => a.localeCompare(b))), publicModules};
};
const before = capture(true);
const after = capture(false);
const equal = JSON.stringify(before) === JSON.stringify(after);
fs.writeFileSync(path.join(proof, 'callable-compatibility.json'), JSON.stringify({typescript: ts.version, baselineCommit: 'a400c05376c54e03e8d4210b89885d1af2c04b7a', localCount: Object.keys(before.locals).length, before, after, equal}, null, 2) + '\n');
if (!equal) {
  for (const key of Object.keys(before.locals)) if (JSON.stringify(before.locals[key]) !== JSON.stringify(after.locals[key])) console.error('Mismatch:', key);
  throw new Error('Callable/body/parameter/public export compatibility mismatch');
}
console.log(`${Object.keys(before.locals).length} local callable signatures, predicates/assertions, parameters, async flags and bodies match; all exports/callable signatures at identity and package entrypoints match.`);
