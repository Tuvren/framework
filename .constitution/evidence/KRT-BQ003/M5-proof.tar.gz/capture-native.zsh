#!/usr/bin/env zsh
set -uo pipefail
source /home/oscar/.codex/plans/tuvren-bq-session/m5/environment.zsh
proof_root=/home/oscar/.codex/plans/tuvren-bq-session/m5
phase="${1:?phase}"
for package_root in protocol runtime; do
  for mode in syntactic typeaware; do
    flags=()
    if [[ "$mode" == typeaware ]]; then
      flags+=(--type-aware)
    fi
    bunx --bun oxlint "${flags[@]}" --format=json "typescript/kernel/$package_root" > "$proof_root/$phase-$package_root-$mode.json" 2> "$proof_root/$phase-$package_root-$mode.stderr"
    print -r -- "$?" > "$proof_root/$phase-$package_root-$mode.exit"
  done
done
