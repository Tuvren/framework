import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m7';
const file = 'typescript/kernel/protocol/src/lib/kernel-validation-runtime.ts';
const baselineCommit = '26c4930bd01bf6861f0a599a6ef240a750282f57';
const hash = content => createHash('sha256').update(content).digest('hex');
const before = fs.readFileSync(path.join(proof, 'kernel-validation-runtime.ts.before'));
const after = fs.readFileSync(file);
if (!before.equals(execFileSync('git', ['show', `${baselineCommit}:${file}`]))) throw new Error('Before snapshot does not match dispatched HEAD');
if (!after.equals(fs.readFileSync(path.join(proof, 'kernel-validation-runtime.ts.after')))) throw new Error('Final bytes changed after gates');
const gates = Object.fromEntries(['scoped','fresh-process','retained-biome','format-touched','typecheck','changeset','conformance','api-freeze','format','lint'].map(name => [name, Number(fs.readFileSync(path.join(proof, `after-${name}.exit`),'utf8'))]));
const assertions = Object.fromEntries(['callable-compatibility','structural-proof','signature-controls','structural-controls','runtime-compatibility','native-summary','changeset-proof','conformance-comparison','diff-check'].map(name => [name, Number(fs.readFileSync(path.join(proof, `${name}.exit`),'utf8'))]));
if (Object.values({...gates,...assertions}).some(code=>code!==0)) throw new Error('Final gate or required assertion failed');
const changedFiles = execFileSync('git',['diff','--name-only'],{encoding:'utf8'}).trim().split('\n');
if (JSON.stringify(changedFiles)!==JSON.stringify([file])) throw new Error('M7 scope drift');
const diffCounts = execFileSync('git',['diff','--numstat'],{encoding:'utf8'}).trim().split('\t');
const summary = {
  milestone:'M7', ticket:'KRT-BQ003', baselineCommit, changedFiles,
  diff:{added:Number(diffCounts[0]),deleted:Number(diffCounts[1]),total:Number(diffCounts[0])+Number(diffCounts[1]),finalLines:after.toString().trimEnd().split('\n').length},
  sourceHashes:{before:hash(before),after:hash(after)},
  versions:{typescript:'6.0.2',bun:'1.4.2',oxlint:'1.86.0',oxfmt:'0.71.0',biome:'2.5.14'},
  conversion:{implementations:36,overloadDeclarationsPreserved:2,initialTargetedStructuralAssertionExit:Number(fs.readFileSync(path.join(proof,'before-targeted-assertion.exit'),'utf8')),initialFunctionStyleDiagnostics:35,initialNoUseBeforeDefineDiagnostics:17,finalRequestedDiagnostics:0},
  gates,assertions,
  tests:{protocol:92,runtime:56,total:148,freshProcessCases:6},
  conformance:{lanes:11,matchReviewedM4:true,matchReviewedM6:true},
  apiFreeze:{unchanged:true,entrypoints:14,exports:404},
  preservation:{fullCompilerSignaturesPredicatesOverloads:true,parameterDefaultsOptionalityRestAndFlowTypes:true,bodyEvaluationTreesAndOrder:true,nonCallableAstsAndInitializationOrder:true,legacyDirectives:true,lexicalSensitiveUses:[],runtimeCallableMetadata:36,orderedValidationOutcomes:2674},
  native:{protocol:{syntactic:[386,334],typeaware:[644,592],files:23,rules:[419,474]},runtime:{syntactic:[211,211],typeaware:[283,283],files:17,rules:[419,474]},outsideTargetDiagnosticCountsUnchanged:true,residualTargetDiagnostics:{syntactic:3,typeaware:7},admissionClaimed:false},
  notes:[
    'API snapshots use lossless compiler AST serialization. Package type-only export capture proves presence, while all non-callable definitions remain separately unchanged: structural-proof.json and the one-file git diff scope. No type-only export structure is inferred from getTypeOfSymbolAtLocation.',
    'Body normalization uses the shared ast-proof.mjs helper: sole-return to concise-arrow normalization and only transparent outer grouping removal. Full inner operator trees remain compared; grouped-evaluation negative control passes.',
    'Initial post-conversion TS2345 and subsequent retained-Biome noInferrableTypes conflict are preserved in after-scoped-attempt1 and after-retained-biome-attempt1 logs. A measured satisfies implementation context resolves both without changing defaults or exposed overloads.',
    'External Biome stdin probe was inconclusive; exact installed configuration in a mirror selected one candidate file and passed. The final actual repository retained check selected54 files and passed.',
    'Services were already running and were not started or stopped. No dependencies, configs, changesets, authority assets, golden values or constitution files changed. No commit created.',
    'Exa unavailable; installed compiler declarations and pinned native CLI help verify used APIs and versions. No unverified runtime API assumption remains.',
    'Evidence drivers and raw logs are external support artifacts, not cross-language authority. This completes M7 only and makes no full release-readiness claim.'
  ],
  introduced:{dependencies:[],patterns:[{path:file,symbol:'assertTurnTreeManifest',pattern:'Explicit exported two-overload callable annotation plus satisfies against the precise non-overloaded implementation callable supplies contextual parameter types without a redundant default-parameter type annotation.',approvedByEpicLead:true,route:'Stage3 alignment at epic closeout'}],conventions:[],contractShapes:[]},
  blockers:[],drift:['Measured satisfies implementation-context pattern accepted by epic lead; retained checker policy unchanged.'],usage:'Token/cost usage unavailable to the worker.',
  archive:{name:'m7-proof.tar.gz',index:'proof-index.json (outside archive)',excluded:['environment.zsh','contextual-typing-mirror/','local-runtime-mirror/','m7-proof.tar.gz','proof-index.json']}
};
fs.writeFileSync(path.join(proof,'summary.json'),JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify({changedFiles,diff:summary.diff,sourceHashes:summary.sourceHashes,gates,assertions},null,2));
