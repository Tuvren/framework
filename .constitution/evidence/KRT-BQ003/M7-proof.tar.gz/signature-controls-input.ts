
declare function required(value: string | undefined): void;
declare function optional(value?: string): void;
declare function readonlyCollection(value: readonly string[]): void;
declare function mutableCollection(value: string[]): void;
declare function asserted(value: unknown): asserts value is string;
declare function guarded(value: unknown): value is string;
declare function assertedNumber(value: unknown): asserts value is number;
declare function generic<T extends string>(value: T): T;
declare function erased(value: string): string;
declare function rest(value: string, ...others: readonly string[]): void;
declare function requiredTail(value: string, others: readonly string[]): void;
declare function overloaded(value: unknown, label?: string): asserts value is string;
declare function overloaded(value: unknown, schema: {id: string}, label?: string): asserts value is string;
declare function droppedOverload(value: unknown, label?: string): asserts value is string;
