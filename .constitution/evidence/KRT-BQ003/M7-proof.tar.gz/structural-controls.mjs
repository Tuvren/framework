import fs from 'node:fs';
import path from 'node:path';
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m7';
const ts = await import(path.join(process.cwd(), 'node_modules/typescript/lib/typescript.js'));
import {bodyNode, bodyAst} from './ast-proof.mjs';
const print = text => {
  const source = ts.createSourceFile('control.ts', text, ts.ScriptTarget.Latest, true);
  if (source.parseDiagnostics.length) throw new Error('Control must parse');
  return source.statements.map(statement => bodyAst(statement, source));
};
const controls = [
  {name: 'fixture property insertion order', before: 'const variants = [{timestamp: 1, active: true}, {active: true, timestamp: 1}];', changed: 'const variants = [{active: true, timestamp: 1}, {active: true, timestamp: 1}];'},
  {name: 'fixture value', before: 'const bytes = new Uint8Array([1, 2, 3]);', changed: 'const bytes = new Uint8Array([1, 2, 4]);'},
  {name: 'stateful initialization order', before: 'const encoder = createEncoder(); const decoder = createDecoder();', changed: 'const decoder = createDecoder(); const encoder = createEncoder();'},
  {name: 'changed grouped evaluation tree', before: 'const calculate = (a,b,c) => (a+b)*c;', changed: 'const calculate = (a,b,c) => a+b*c;'},
  {name: 'error evaluation order', before: 'const validate = () => { assertFirst(); assertSecond(); };', changed: 'const validate = () => { assertSecond(); assertFirst(); };'},
].map(control => ({...control, detected: JSON.stringify(print(control.before)) !== JSON.stringify(print(control.changed))}));
if (controls.some(control => !control.detected)) throw new Error('Structural comparison lost an ordering/value distinction');
const formattingOnlyControl = JSON.stringify(print('const call = () => Reflect.apply(fn, undefined, [\n a,\n b,\n]);')) === JSON.stringify(print('const call = () => Reflect.apply(fn, undefined, [a, b]);'));
if (!formattingOnlyControl) throw new Error('AST comparison must ignore array line-layout metadata');

const normalizedArrowBody = text => {
  const source = ts.createSourceFile('grouping-control.ts', text, ts.ScriptTarget.Latest, true);
  const initializer = source.statements[0].declarationList.declarations[0].initializer;
  if (!ts.isArrowFunction(initializer)) throw new Error('Expected control arrow');
  return bodyAst(bodyNode(initializer.body), source);
};
const outerGroupingTransparent = JSON.stringify(normalizedArrowBody('const calculate = (a,b) => (a+b);')) === JSON.stringify(normalizedArrowBody('const calculate = (a,b) => a+b;'));
const groupedEvaluationTreeDetected = JSON.stringify(normalizedArrowBody('const calculate = (a,b,c) => (a+b)*c;')) !== JSON.stringify(normalizedArrowBody('const calculate = (a,b,c) => a+b*c;'));
if (!outerGroupingTransparent || !groupedEvaluationTreeDetected) throw new Error('Normalized body proof lost grouping evaluation structure');
fs.writeFileSync(path.join(proof, 'structural-controls.json'), JSON.stringify({typescript: ts.version, controls, formattingOnlyControl, outerGroupingTransparent, groupedEvaluationTreeDetected}, null, 2) + '\n');
console.log('AST controls detect fixture property sorting/collapse, fixture value changes, stateful initialization reorder and validation error reorder.');
