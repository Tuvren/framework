import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root = process.cwd();
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m7';
const candidatePath = process.argv[2];
const plan = JSON.parse(fs.readFileSync(path.join(proof, 'conversion-plan.json'), 'utf8'));
const item = plan.files[0];
const snapshots = {};
const sourceHashes = {};
for (const phase of ['before', 'after']) {
  const directory = path.join(proof, 'local-runtime-mirror', phase);
  fs.mkdirSync(directory, {recursive: true});
  fs.cpSync(path.join(root, 'typescript/kernel/protocol/src'), path.join(directory, 'src'), {recursive: true});
  fs.writeFileSync(path.join(directory, 'tsconfig.json'), JSON.stringify({compilerOptions: {paths: {'@tuvren/core': [path.join(root, 'typescript/core/src/index.ts')]}}}));
  if (!fs.existsSync(path.join(directory, 'node_modules'))) fs.symlinkSync(path.join(root, 'node_modules'), path.join(directory, 'node_modules'));
  const source = fs.readFileSync(phase === 'before' ? path.join(proof, 'kernel-validation-runtime.ts.before') : candidatePath ?? path.join(root, item.file), 'utf8');
  sourceHashes[phase] = createHash('sha256').update(source).digest('hex');
  const target = path.join(directory, 'src/lib/kernel-validation-runtime.ts');
  const output = path.join(proof, `${candidatePath ? 'candidate-' : ''}runtime-${phase}.json`);
  const observations = `
// External append-only observation; never written to repository.
const measuredFs = await import('node:fs');
const measuredCallables = {${item.graph.map(entry => entry.name).join(', ')}};
const measuredSnapshot = (value) => {
  if (value === undefined) return {undefined: true};
  if (typeof value === 'number' && (!Number.isFinite(value) || Object.is(value, -0))) return {number: String(value), negativeZero: Object.is(value, -0)};
  if (value === null || typeof value !== 'object') return value;
  if (value instanceof Uint8Array) return {bytes: Array.from(value)};
  return {prototype: Object.getPrototypeOf(value) === null ? null : Object.getPrototypeOf(value).constructor.name, entries: Object.entries(value).map(([key, nested]) => [key, measuredSnapshot(nested)]), ...(Array.isArray(value) ? {length: value.length} : {})};
};
const measuredHash = 'a'.repeat(64);
const measuredSchema = {schemaId:'probe', paths:[{path:'messages', collection:'ordered'},{path:'summary', collection:'single'}], incorporationRules:[{objectType:'message',targetPath:'messages'}]};
const measuredValues = [undefined, null, false, 0, '', 'ordered', 'single', 'completed', 'running', 'paused', 'HardFail', 'proceed', measuredHash, [], [measuredHash], [measuredHash,,measuredHash], {}, Object.create(null), {schemaId:'',paths:[],incorporationRules:[]}, measuredSchema, {messages:[measuredHash],summary:null}, {messages:[measuredHash]}, {'bad..path':null}, {id:'step',deterministic:true,sideEffects:false}, {id:'step',deterministic:true,sideEffects:false,metadata:undefined}, {annotations:[{label:'probe'}],signals:[null]}, {kind:'proceed'}, {kind:'abort',disposition:'HardFail',reason:'probe'}, {kind:'modify',transform:{value:1}}, {kind:'pause',reason:'probe',resumptionSchema:{}}, {kind:'retry',adjustment:[]}, {kind:'unknown'}, {kind:'abort',disposition:'bad',reason:''}];
const measuredOutcomes = [];
const measuredInvoke = (name, args, variant) => {
  try { const result = Reflect.apply(measuredCallables[name], undefined, args); measuredOutcomes.push({name,variant,result:measuredSnapshot(result)}); }
  catch (error) { measuredOutcomes.push({name,variant,error:{name:error.name,code:measuredSnapshot(error.code),message:error.message,details:measuredSnapshot(error.details)}}); }
};
for (const name of ${JSON.stringify(item.graph.filter(entry=>source.includes(`export function ${entry.name}`)||source.includes(`export const ${entry.name}`)).map(entry=>entry.name))}) {
  for (const [index,value] of measuredValues.entries()) {
    measuredInvoke(name,[value],index+':default');
    measuredInvoke(name,[value,'probe'],index+':label');
    measuredInvoke(name,[value,measuredSchema,'probe'],index+':schema');
  }
}
for (const [index,value] of measuredValues.entries()) for (const kind of ['ordered','single','unknown']) measuredInvoke('assertPathValueForCollectionKind',[value,kind,'probe'],index+':'+kind);
const measuredReads = [];
const measuredInvalidSchema = {get schemaId(){measuredReads.push('schemaId');return '';}, get paths(){measuredReads.push('paths');return [];}, get incorporationRules(){measuredReads.push('incorporationRules');return [];}};
measuredInvoke('assertTurnTreeSchema',[measuredInvalidSchema,'ordered-read-probe'],'getter-order');
const measuredMetadata = Object.fromEntries(Object.entries(measuredCallables).map(([name,callable])=>[name,{name:callable.name,length:callable.length,constructor:callable.constructor.name}]));
measuredFs.writeFileSync(${JSON.stringify(output)},JSON.stringify({metadata:measuredMetadata,outcomes:measuredOutcomes,readOrder:measuredReads},null,2)+'\\n');
`;
  fs.writeFileSync(target, source + observations);
  const result = spawnSync(process.execPath, [target], {cwd:directory,encoding:'utf8'});
  fs.writeFileSync(path.join(proof, `${candidatePath ? 'candidate-' : ''}local-${phase}.log`),result.stdout+result.stderr);
  if (result.status !== 0) throw new Error(`Runtime mirror failed: ${result.stderr}`);
  snapshots[phase] = JSON.parse(fs.readFileSync(output,'utf8'));
}
const equal = JSON.stringify(snapshots.before) === JSON.stringify(snapshots.after);
fs.writeFileSync(path.join(proof, `${candidatePath ? 'candidate-' : ''}runtime-compatibility.json`), JSON.stringify({sourceHashes,appendOnlyExternalObservation:true,callableCount:plan.files[0].count,outcomeCount:snapshots.after.outcomes.length,before:snapshots.before,after:snapshots.after,equal},null,2)+'\n');
if (!equal) throw new Error('Runtime callable metadata, validation outcomes/error ordering or getter reads differ');
console.log(`${plan.files[0].count} callable names/arities/constructors and ${snapshots.after.outcomes.length} validation outcomes with error details/order and getter reads match baseline.`);
