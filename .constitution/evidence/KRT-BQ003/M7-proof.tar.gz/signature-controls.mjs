import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m7';
const ts = await import(path.join(root, 'node_modules/typescript/lib/typescript.js'));
const file = path.join(proof, 'signature-controls-input.ts');
fs.writeFileSync(file, `
declare function required(value: string | undefined): void;
declare function optional(value?: string): void;
declare function readonlyCollection(value: readonly string[]): void;
declare function mutableCollection(value: string[]): void;
declare function asserted(value: unknown): asserts value is string;
declare function guarded(value: unknown): value is string;
declare function assertedNumber(value: unknown): asserts value is number;
declare function generic<T extends string>(value: T): T;
declare function erased(value: string): string;
declare function rest(value: string, ...others: readonly string[]): void;
declare function requiredTail(value: string, others: readonly string[]): void;
declare function overloaded(value: unknown, label?: string): asserts value is string;
declare function overloaded(value: unknown, schema: {id: string}, label?: string): asserts value is string;
declare function droppedOverload(value: unknown, label?: string): asserts value is string;
`);
const program = ts.createProgram([file], {noEmit: true, strict: true, target: ts.ScriptTarget.ESNext});
const checker = program.getTypeChecker();
const source = program.getSourceFile(file);
const printer = ts.createPrinter();
const signatures = Object.fromEntries(source.statements.filter(ts.isFunctionDeclaration).map(declaration => {
  const callableSignatures = checker.getSignaturesOfType(checker.getTypeAtLocation(declaration.name), ts.SignatureKind.Call);
  return [declaration.name.text, callableSignatures.map(signature => {
    const functionType = checker.signatureToSignatureDeclaration(signature, ts.SyntaxKind.FunctionType, source, ts.NodeBuilderFlags.NoTruncation);
    if (!functionType || !ts.isFunctionTypeNode(functionType)) throw new Error('Control callable AST missing');
    return printer.printNode(ts.EmitHint.Unspecified, functionType, source);
  })];
}));
const controls = [['required', 'optional'], ['readonlyCollection', 'mutableCollection'], ['asserted', 'guarded'], ['asserted', 'assertedNumber'], ['generic', 'erased'], ['rest', 'requiredTail'], ['overloaded', 'droppedOverload']].map(([left, right]) => ({left, right, detected: JSON.stringify(signatures[left]) !== JSON.stringify(signatures[right])}));
if (controls.some(control => !control.detected)) throw new Error('Signature comparison lost a contractual distinction');
fs.writeFileSync(path.join(proof, 'signature-controls.json'), JSON.stringify({typescript: ts.version, signatures, controls}, null, 2) + '\n');
console.log('Compiler signature controls detect required/optional, readonly/mutable, assertion/guard, assertion target, generic erasure, rest-parameter replacement and overload-drop differences.');
