import path from 'node:path';
const ts = await import(path.join(process.cwd(), 'node_modules/typescript/lib/typescript.js'));
// Concise arrows replace a sole return. Oxfmt removes an optional outer grouping
// node; unwrap only that outer node, retaining the complete expression/operator AST.
export const bodyNode = body => {
  let expression = ts.isBlock(body) && body.statements.length === 1 && ts.isReturnStatement(body.statements[0]) && body.statements[0].expression ? body.statements[0].expression : body;
  while (ts.isParenthesizedExpression(expression)) expression = expression.expression;
  return expression;
};
// Compare every ordered semantic AST child. Printer line-layout metadata is
// deliberately excluded: Oxfmt collapses one newly concise call argument array.
export const bodyAst = (node, source) => {
  const children = [];
  ts.forEachChild(node, child => { children.push(bodyAst(child, source)); });
  return children.length ? {kind: ts.SyntaxKind[node.kind], children} : {kind: ts.SyntaxKind[node.kind], text: node.getText(source)};
};
