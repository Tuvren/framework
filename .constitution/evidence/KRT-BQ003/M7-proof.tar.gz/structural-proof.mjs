import fs from 'node:fs';
import path from 'node:path';
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m7';
const ts = await import(path.join(process.cwd(), 'node_modules/typescript/lib/typescript.js'));
const plan = JSON.parse(fs.readFileSync(path.join(proof, 'conversion-plan.json'), 'utf8'));
const unwrapInitializer = node => {
  let current = node;
  while (current && (ts.isParenthesizedExpression(current) || ts.isSatisfiesExpression(current))) current = current.expression;
  return current;
};
const results = [];
for (const item of plan.files) {
  const text = fs.readFileSync(item.file, 'utf8');
  const source = ts.createSourceFile(item.file, text, ts.ScriptTarget.Latest, true);
  if (source.statements.some(ts.isFunctionDeclaration)) throw new Error('Function declarations remain');
  const indices = new Map();
  const callables = [];
  source.statements.forEach((statement, index) => {
    if (!ts.isVariableStatement(statement) || statement.declarationList.declarations.length !== 1) return;
    const declaration = statement.declarationList.declarations[0];
    if (!declaration.initializer || !ts.isArrowFunction(unwrapInitializer(declaration.initializer))) return;
    // Syntax inspection avoids mixing compiler flag bits with hand-built arithmetic.
    if (statement.declarationList.getFirstToken(source)?.kind !== ts.SyntaxKind.ConstKeyword) throw new Error('Callable is not const');
    indices.set(declaration.name.getText(source), index);
    callables.push(declaration.name.getText(source));
  });
  if (callables.length !== item.count || JSON.stringify(callables) !== JSON.stringify(item.ordered)) throw new Error('Unexpected callable count or order');
  for (const entry of item.graph) for (const dependency of entry.dependencies) if (indices.get(dependency) >= indices.get(entry.name)) throw new Error('Function dependency not initialized first');
  const printer = ts.createPrinter({removeComments: true});
  const nonCallables = source.statements.filter(statement => !ts.isVariableStatement(statement) || !statement.declarationList.declarations.some(declaration => declaration.initializer && ts.isArrowFunction(unwrapInitializer(declaration.initializer))));
  if (nonCallables.length !== item.nonCallable.length) throw new Error('Other top-level statement count changed');
  for (const [index, statement] of nonCallables.entries()) {
    const original = item.nonCallable[index];
    for (const dependency of original.dependencies) if (indices.get(dependency) >= source.statements.indexOf(statement)) throw new Error('Top-level use precedes lazy function initialization');
    const parsed = ts.createSourceFile(item.file, original.text, ts.ScriptTarget.Latest, true);
    if (printer.printNode(ts.EmitHint.Unspecified, statement, source) !== printer.printNode(ts.EmitHint.Unspecified, parsed.statements[0], parsed)) throw new Error('Top-level non-callable AST changed');
  }
  const baseline = fs.readFileSync(path.join(proof, `${path.basename(item.file)}.before`), 'utf8');
  const directives = value => value.split('\n').filter(line => line.includes('biome-ignore'));
  if (JSON.stringify(directives(baseline)) !== JSON.stringify(directives(text))) throw new Error('Suppression added/changed');
  results.push({file: item.file, count: callables.length, declarationsAllLazyConstArrows: true, functionDependencyOrderValid: true, topLevelUsesInitializedFirst: true, nonCallableAstsAndOrderUnchanged: true, directivesUnchanged: true, lexicalSensitiveUses: item.graph.flatMap(entry => entry.lexical), selfRecursiveHelpers: item.graph.filter(entry => entry.recursive).map(entry => entry.name)});
}
fs.writeFileSync(path.join(proof, 'structural-proof.json'), JSON.stringify({typescript: ts.version, files: results}, null, 2) + '\n');
console.log('All 36 const arrows are lazy and dependency-ordered; non-callable initialization sequence, fixture AST values/property order and suppressions match baseline.');
