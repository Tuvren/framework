source /home/oscar/.codex/plans/tuvren-bq-session/m7/environment.zsh
proof=/home/oscar/.codex/plans/tuvren-bq-session/m7
phase=$1
for area in protocol runtime; do
  for mode in syntactic typeaware; do
    args=()
    if [[ $mode == typeaware ]]; then args+=(--type-aware); fi
    bunx --bun oxlint "${args[@]}" --format json typescript/kernel/$area > $proof/$phase-$area-$mode.json 2> $proof/$phase-$area-$mode.stderr
    print -r -- $? > $proof/$phase-$area-$mode.exit
  done
done
