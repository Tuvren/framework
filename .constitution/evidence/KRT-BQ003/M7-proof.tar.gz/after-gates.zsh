#!/usr/bin/env zsh
set -uo pipefail
source /home/oscar/.codex/plans/tuvren-bq-session/m7/environment.zsh
proof_root=/home/oscar/.codex/plans/tuvren-bq-session/m7
run_gate() {
  local gate_name="$1"
  shift
  "$@" > "$proof_root/after-$gate_name.log" 2>&1
  local gate_exit=$?
  print -r -- "$gate_exit" > "$proof_root/after-$gate_name.exit"
  print -r -- "$gate_name: exit $gate_exit"
  if (( gate_exit != 0 )); then
    tail -50 "$proof_root/after-$gate_name.log"
    return "$gate_exit"
  fi
}
run_gate fresh-process bun test typescript/kernel/protocol/test/kernel-module-initialization.test.ts || exit $?
run_gate retained-biome bunx --bun @biomejs/biome check typescript/kernel/protocol typescript/kernel/runtime || exit $?
run_gate format-touched bunx --bun oxfmt --check typescript/kernel/protocol/src/lib/kernel-validation-runtime.ts || exit $?
run_gate typecheck bun run typecheck || exit $?
run_gate changeset bun run changeset:check || exit $?
run_gate conformance bun run conformance || exit $?
run_gate api-freeze bun run api-freeze:check || exit $?
run_gate format bun run format:check || exit $?
run_gate lint bun run lint || exit $?
