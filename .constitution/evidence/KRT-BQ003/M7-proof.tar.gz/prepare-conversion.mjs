import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
const root = process.cwd();
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m7';
const ts = await import(path.join(root, 'node_modules/typescript/lib/typescript.js'));
const file = 'typescript/kernel/protocol/src/lib/kernel-validation-runtime.ts';
const configFile = ts.readConfigFile('typescript/kernel/protocol/tsconfig.typecheck.json', ts.sys.readFile);
if (configFile.error) throw new Error('Invalid config');
const config = ts.parseJsonConfigFileContent(configFile.config, ts.sys, path.resolve('typescript/kernel/protocol'));
const baselineCommit = '26c4930bd01bf6861f0a599a6ef240a750282f57';
const text = execFileSync('git', ['show', `${baselineCommit}:${file}`], {encoding: 'utf8'});
const host = ts.createCompilerHost(config.options);
const readFile = host.readFile.bind(host);
host.readFile = filename => path.resolve(filename) === path.resolve(file) ? text : readFile(filename);
const program = ts.createProgram(config.fileNames, config.options, host);
const checker = program.getTypeChecker();
const printer = ts.createPrinter();
fs.writeFileSync(path.join(proof, `${path.basename(file)}.before`), text);
const source = program.getSourceFile(path.resolve(file));
if (!source) throw new Error('Source absent');
const declarations = source.statements.filter(ts.isFunctionDeclaration);
const implementations = declarations.filter(declaration => declaration.body);
const bySymbol = new Map(implementations.map(declaration => [checker.getSymbolAtLocation(declaration.name), declaration]));
const dependencies = node => {
  const result = new Set();
  const visit = current => {
    if (ts.isIdentifier(current)) {
      const target = bySymbol.get(checker.getSymbolAtLocation(current));
      if (target) result.add(target);
    }
    ts.forEachChild(current, visit);
  };
  visit(node);
  return [...result];
};
const graph = implementations.map(declaration => {
  const lexical = [];
  const visit = node => {
    if (node.kind === ts.SyntaxKind.ThisKeyword || ts.isMetaProperty(node) || (ts.isIdentifier(node) && node.text === 'arguments') || (ts.isFunctionLike(node) && node.asteriskToken)) lexical.push(node.getText(source));
    ts.forEachChild(node, visit);
  };
  visit(declaration);
  if (lexical.length) throw new Error(`Lexical-sensitive function ${declaration.name.text}`);
  return {name: declaration.name.text, dependencies: dependencies(declaration.body).filter(target => target !== declaration).map(target => target.name.text), recursive: dependencies(declaration.body).includes(declaration), lexical};
});
const converted = new Map(implementations.map(declaration => {
  if (!declaration.name || !declaration.type || !declaration.body || declaration.typeParameters?.length) throw new Error('Unexpected signature');
  const open = declaration.getChildren(source).find(node => node.kind === ts.SyntaxKind.OpenParenToken);
  if (!open) throw new Error('Parameters missing');
  const overloads = declarations.filter(item => item.name.text === declaration.name.text && !item.body);
  const annotation = ts.isTypePredicateNode(declaration.type) && declaration.type.assertsModifier;
  let callableType = '';
  if (annotation || overloads.length) {
    const signatures = checker.getSignaturesOfType(checker.getTypeAtLocation(declaration.name), ts.SignatureKind.Call);
    const fullSignatures = signatures.map(signature => {
      const node = checker.signatureToSignatureDeclaration(signature, overloads.length ? ts.SyntaxKind.CallSignature : ts.SyntaxKind.FunctionType, source, ts.NodeBuilderFlags.NoTruncation);
      if (!node) throw new Error('Full callable signature absent');
      return printer.printNode(ts.EmitHint.Unspecified, node, source);
    });
    callableType = `: ${overloads.length ? `{\n${fullSignatures.join('\n')}\n}` : fullSignatures[0]}`;
  }
  const exported = declaration.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.ExportKeyword) ? 'export ' : '';
  const asyncPrefix = declaration.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.AsyncKeyword) ? 'async ' : '';
  const firstDeclaration = overloads[0] ?? declaration;
  const leading = text.slice(firstDeclaration.getFullStart(), firstDeclaration.getStart(source));
  let signature = text.slice(open.getStart(source), declaration.body.getStart(source)).trimEnd();
  const concise = declaration.body.statements.length === 1 && ts.isReturnStatement(declaration.body.statements[0]) && declaration.body.statements[0].expression;
  const body = concise ? declaration.body.statements[0].expression.getText(source) : declaration.body.getText(source);
  let initializer = `${asyncPrefix}${signature} => ${body}`;
  if (overloads.length) {
    const implementationSignature = checker.getSignatureFromDeclaration(declaration);
    if (!implementationSignature) throw new Error('Implementation signature missing');
    const implementationType = checker.signatureToSignatureDeclaration(implementationSignature, ts.SyntaxKind.FunctionType, source, ts.NodeBuilderFlags.NoTruncation);
    if (!implementationType) throw new Error('Full implementation callable annotation missing');
    initializer = `(${initializer}) satisfies ${printer.printNode(ts.EmitHint.Unspecified, implementationType, source)}`;
  }
  return [declaration.name.text, `${leading}${exported}const ${declaration.name.text}${callableType} = ${initializer};`];
}));
const ordered = [];
const done = new Set();
const active = new Set();
const chunks = [];
const emit = name => {
  if (done.has(name)) return;
  if (active.has(name)) throw new Error('Mutually recursive helpers need subdivision');
  active.add(name);
  const entry = graph.find(item => item.name === name);
  for (const dependency of entry.dependencies) emit(dependency);
  active.delete(name);
  done.add(name);
  ordered.push(name);
  chunks.push(converted.get(name));
};
const nonCallable = [];
for (const statement of source.statements) {
  if (ts.isFunctionDeclaration(statement)) continue;
  const needed = dependencies(statement).map(target => target.name.text);
  for (const name of needed) emit(name);
  nonCallable.push({kind: ts.SyntaxKind[statement.kind], dependencies: needed, text: statement.getText(source)});
  chunks.push(text.slice(statement.getFullStart(), statement.end));
}
for (const item of graph) emit(item.name);
fs.writeFileSync(path.join(proof, `${path.basename(file)}.candidate`), chunks.join('') + '\n');
const plan = {typescript: ts.version, baselineCommit: '26c4930bd01bf6861f0a599a6ef240a750282f57', files: [{file, count: implementations.length, overloadDeclarations: declarations.length - implementations.length, graph, ordered, nonCallable}]};
fs.writeFileSync(path.join(proof, 'conversion-plan.json'), JSON.stringify(plan, null, 2) + '\n');
console.log({count: implementations.length, overloadDeclarations: declarations.length - implementations.length, order: ordered});
