import fs from 'node:fs';
import path from 'node:path';
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m7';
const capture = filename => {
  const groups = new Map();
  for (const raw of fs.readFileSync(filename, 'utf8').split('\n')) {
    const line = raw.replace(/\u001b\[[0-9;]*m/g, '');
    const split = line.match(/^([a-z][a-z0-9-]*): (.*)$/);
    const label = split?.[1] ?? 'unprefixed';
    const body = split?.[2] ?? line;
    if (!groups.has(label)) groups.set(label, []);
    groups.get(label).push(body);
  }
  const summaries = [];
  for (const lines of groups.values()) {
    let buffer = null;
    for (const line of lines) {
      if (line === '{') buffer = [];
      if (buffer !== null) buffer.push(line);
      if (line !== '}' || buffer === null) continue;
      try {
        const value = JSON.parse(buffer.join('\n'));
        if (value.adapterId && value.suiteId && value.summary) summaries.push(value);
      } catch { /* Non-JSON build output cannot be a conformance summary. */ }
      buffer = null;
    }
  }
  return summaries.sort((a, b) => `${a.adapterId}/${a.suiteId}`.localeCompare(`${b.adapterId}/${b.suiteId}`));
};
const baselineLog = '/home/oscar/.codex/plans/tuvren-bq-session/m4/conformance.log';
const currentLog = path.join(proof, 'after-conformance.log');
const baseline = capture(baselineLog);
const current = capture(currentLog);
const reviewedM6Log = '/home/oscar/.codex/plans/tuvren-bq-session/m6/after-conformance.log';
const reviewedM6 = capture(reviewedM6Log);
if (reviewedM6.length !== 11 || JSON.stringify(baseline) !== JSON.stringify(reviewedM6)) throw new Error('Reviewed M4 and M6 baselines disagree');
if (baseline.length !== 11 || current.length !== 11 || current.some(value => value.status !== 'pass' || value.summary.failedChecks !== 0)) throw new Error(`Incomplete or failing conformance summaries: baseline=${baseline.length} current=${current.length}`);
const equal = JSON.stringify(baseline) === JSON.stringify(current);
fs.writeFileSync(path.join(proof, 'conformance-comparison.json'), JSON.stringify({baselineLog, currentLog, baseline, reviewedM6Log, reviewedM6, current, equal}, null, 2) + '\n');
if (!equal) throw new Error('Conformance outcomes differ from reviewed M4 pre-reorder baseline');
console.log('All 11 conformance lane status/summary/suite identities match the reviewed pre-reorder baseline.');
