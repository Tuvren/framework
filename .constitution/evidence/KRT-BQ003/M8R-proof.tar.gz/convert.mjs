import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
const root = process.cwd();
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m8r';
const ts = await import(path.join(root, 'node_modules/typescript/lib/typescript.js'));
const configFile = ts.readConfigFile('typescript/kernel/protocol/tsconfig.typecheck.json', ts.sys.readFile);
if (configFile.error) throw new Error('Invalid config');
const config = ts.parseJsonConfigFileContent(configFile.config, ts.sys, path.resolve('typescript/kernel/protocol'));
const program = ts.createProgram(config.fileNames, config.options);
const checker = program.getTypeChecker();
const printer = ts.createPrinter();
const files = ['records', 'stored'].map(name => `typescript/kernel/protocol/src/lib/kernel-validation-${name}.ts`);
const plan = { baselineCommit: execFileSync('git', ['rev-parse', 'HEAD'], {encoding: 'utf8'}).trim(), typescript: ts.version, files: [] };
for (const file of files) {
  const text = fs.readFileSync(file, 'utf8');
  const source = program.getSourceFile(path.resolve(file));
  if (!source) throw new Error(`Missing ${file}`);
  fs.writeFileSync(path.join(proof, `${path.basename(file)}.before`), text);
  const declarations = source.statements.filter(ts.isFunctionDeclaration);
  const bySymbol = new Map(declarations.map(declaration => [checker.getSymbolAtLocation(declaration.name), declaration]));
  const dependencies = node => {
    const result = new Set();
    const visit = current => {
      if (ts.isIdentifier(current)) {
        const target = bySymbol.get(checker.getSymbolAtLocation(current));
        if (target) result.add(target.name.text);
      }
      ts.forEachChild(current, visit);
    };
    visit(node);
    return [...result];
  };
  const graph = [];
  const converted = new Map();
  for (const declaration of declarations) {
    if (!declaration.name || !declaration.type || !declaration.body || declaration.typeParameters?.length) throw new Error('Unexpected signature');
    const lexical = [];
    const visit = node => {
      if (node.kind === ts.SyntaxKind.ThisKeyword || ts.isMetaProperty(node) || (ts.isIdentifier(node) && node.text === 'arguments') || (ts.isFunctionLike(node) && node.asteriskToken)) lexical.push(node.getText(source));
      ts.forEachChild(node, visit);
    };
    visit(declaration.body);
    if (lexical.length) throw new Error(`Lexical-sensitive function ${declaration.name.text}`);
    const deps = dependencies(declaration.body);
    if (deps.includes(declaration.name.text)) throw new Error('Unexpected recursion');
    graph.push({name: declaration.name.text, dependencies: deps, lexical});
    const assertion = ts.isTypePredicateNode(declaration.type) && declaration.type.assertsModifier;
    let annotation = '';
    if (assertion) {
      const signatures = checker.getSignaturesOfType(checker.getTypeAtLocation(declaration.name), ts.SignatureKind.Call);
      if (signatures.length !== 1) throw new Error('Unexpected overloads');
      const signature = checker.signatureToSignatureDeclaration(signatures[0], ts.SyntaxKind.FunctionType, source, ts.NodeBuilderFlags.NoTruncation);
      if (!signature) throw new Error('Missing callable signature');
      annotation = `: ${printer.printNode(ts.EmitHint.Unspecified, signature, source)}`;
    }
    const open = declaration.getChildren(source).find(node => node.kind === ts.SyntaxKind.OpenParenToken);
    if (!open) throw new Error('Missing parameters');
    const leading = text.slice(declaration.getFullStart(), declaration.getStart(source));
    const exported = declaration.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.ExportKeyword) ? 'export ' : '';
    const asyncPrefix = declaration.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.AsyncKeyword) ? 'async ' : '';
    const signature = text.slice(open.getStart(source), declaration.body.getStart(source)).trimEnd();
    const concise = declaration.body.statements.length === 1 && ts.isReturnStatement(declaration.body.statements[0]) && declaration.body.statements[0].expression;
    const body = concise ? declaration.body.statements[0].expression.getText(source) : declaration.body.getText(source);
    converted.set(declaration.name.text, `${leading}${exported}const ${declaration.name.text}${annotation} = ${asyncPrefix}${signature} => ${body};`);
  }
  const done = new Set();
  const active = new Set();
  const ordered = [];
  const chunks = [];
  const emit = name => {
    if (done.has(name)) return;
    if (active.has(name)) throw new Error('Mutual recursion requires review');
    active.add(name);
    for (const dependency of graph.find(item => item.name === name).dependencies) emit(dependency);
    active.delete(name);
    done.add(name);
    ordered.push(name);
    chunks.push(converted.get(name));
  };
  const nonCallable = [];
  for (const statement of source.statements) {
    if (ts.isFunctionDeclaration(statement)) continue;
    const needed = dependencies(statement);
    if (needed.length) throw new Error('Top-level callable dependency requires review');
    nonCallable.push(statement.getText(source));
    chunks.push(text.slice(statement.getFullStart(), statement.end));
  }
  for (const item of graph) emit(item.name);
  fs.writeFileSync(file, `${chunks.join('')}\n`);
  plan.files.push({file, count: declarations.length, assertionCount: declarations.filter(node => ts.isTypePredicateNode(node.type) && node.type.assertsModifier).length, graph, ordered, nonCallable});
}
fs.writeFileSync(path.join(proof, 'conversion-plan.json'), `${JSON.stringify(plan, null, 2)}\n`);
console.log(plan.files.map(({file, count, assertionCount}) => ({file, count, assertionCount})));
