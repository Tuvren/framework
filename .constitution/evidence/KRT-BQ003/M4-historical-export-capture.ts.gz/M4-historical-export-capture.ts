const repo = "/home/oscar/GitHub/Tuvren/framework-EPIC-BQ";
for (const path of ["src/index.ts", "src/lib/kernel-validation.ts"]) {
  const surface = await import(`${repo}/typescript/kernel/protocol/${path}`);
  const exports = Object.entries(surface).map(([name, value]) => ({ name, type: typeof value, length: typeof value === "function" ? value.length : null }));
  process.stdout.write(JSON.stringify({ path, exports }) + "\n");
}
