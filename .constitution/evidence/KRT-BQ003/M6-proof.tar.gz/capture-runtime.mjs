import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m6';
const phase = process.argv[2];
if (!['before', 'after'].includes(phase)) throw new Error('Phase missing');
const identity = await import(path.join(root, 'typescript/kernel/protocol/src/lib/kernel-record-identity.ts'));
const entrypoint = await import(path.join(root, 'typescript/kernel/protocol/src/index.ts'));
const fixtures = await import(path.join(root, 'typescript/kernel/protocol/test/kernel-record-fixtures.ts'));
const outputs = {};
for (const [label, module] of [['identity', identity], ['entrypoint', entrypoint], ['fixtures', fixtures]]) outputs[label] = Object.fromEntries(Object.entries(module).filter(([, value]) => typeof value === 'function').map(([key, value]) => [key, {name: value.name, length: value.length, constructor: value.constructor.name}]));
const snapshot = value => {
  if (typeof value === 'function') return {function: {name: value.name, length: value.length, constructor: value.constructor.name}};
  if (typeof value === 'bigint') return {bigint: value.toString()};
  if (typeof value === 'number' && (!Number.isFinite(value) || Object.is(value, -0))) return {number: String(value), negativeZero: Object.is(value, -0)};
  if (value === undefined) return {undefined: true};
  if (value === null || typeof value !== 'object') return value;
  if (value instanceof Uint8Array) return {bytes: Buffer.from(value).toString('hex')};
  if (value instanceof Date) return {date: value.toISOString()};
  if (value instanceof Map) return {map: Array.from(value, ([key, nested]) => [snapshot(key), snapshot(nested)])};
  if (value instanceof Set) return {set: Array.from(value, snapshot)};
  if (Array.isArray(value)) return value.map(snapshot);
  return {prototype: Object.getPrototypeOf(value) === null ? null : Object.getPrototypeOf(value).constructor.name, entries: Object.entries(value).map(([key, nested]) => [key, snapshot(nested)])};
};
const fixtureValues = Object.fromEntries(Object.entries(fixtures).filter(([, value]) => typeof value !== 'function').map(([key, value]) => [key, snapshot(value)]));
const records = [...fixtures.kernelRecordInsertionOrderVariants, null, false, '', 0, 4294967296, -4294967297, new Uint8Array([1, 2, 3]), {a: {z: 1, b: 2}, x: [1, 'x', null]}];
const encodings = [];
for (const record of records) {
  const encoded = identity.encodeDeterministicKernelRecord(record);
  encodings.push({canonical: snapshot(identity.canonicalizeKernelRecord(record)), bytes: Buffer.from(encoded).toString('hex'), hash: await identity.hashKernelRecord(record), decoded: snapshot(identity.decodeDeterministicKernelRecord(encoded)), fixtureBytes: Buffer.from(fixtures.encodeDeterministicKernelRecord(record)).toString('hex'), fixtureHash: await fixtures.sha256Hex(encoded)});
}
const errors = [];
for (const bytes of [[], [0xa1], [0xa1, 1, 2], [0xa2, 0x61, 0x62, 1, 0x61, 0x61, 2], [0xfa, 0x3f, 0xc0, 0, 0], [0xf7]]) {
  try { identity.decodeDeterministicKernelRecord(Uint8Array.from(bytes)); errors.push({bytes, accepted: true}); }
  catch (error) { errors.push({bytes, mode: 'synchronous', name: error.name, code: error.code, message: error.message, details: snapshot(error.details)}); }
}
for (const invalid of fixtures.invalidKernelRecordFixtures) {
  try { identity.encodeDeterministicKernelRecord(invalid); errors.push({invalid: snapshot(invalid), accepted: true}); }
  catch (error) { errors.push({invalid: snapshot(invalid), mode: 'synchronous', name: error.name, code: error.code, message: error.message, details: snapshot(error.details)}); }
}
const backing = Uint8Array.from([7, 1, 2, 3, 8]);
const opaque = [];
for (const bytes of [new Uint8Array(), backing, backing.subarray(1, 4), new Uint8Array(new SharedArrayBuffer(3))]) opaque.push({input: snapshot(bytes), hash: await identity.hashOpaqueObjectBytes(bytes)});
const result = {outputs, fixtureValues, encodings, errors, opaque};
fs.writeFileSync(path.join(proof, `runtime-${phase}.json`), JSON.stringify(result, null, 2) + '\n');
if (phase === 'after' && fs.readFileSync(path.join(proof, 'runtime-before.json'), 'utf8') !== JSON.stringify(result, null, 2) + '\n') throw new Error('Runtime names/arities/async flags, fixture values/order, canonical bytes/hashes, decode outcomes or error ordering changed');
console.log(`${encodings.length} canonical record/fixture byte/hash cases, ${errors.length} ordered decode/validation outcomes, ${opaque.length} raw/view/shared-buffer digests and all exported names/arities/async constructors match baseline (${phase}).`);
