import fs from 'node:fs';
import path from 'node:path';
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m6';
const ts = await import(path.join(process.cwd(), 'node_modules/typescript/lib/typescript.js'));
const plan = JSON.parse(fs.readFileSync(path.join(proof, 'conversion-plan.json'), 'utf8'));
const converted = [];
for (const item of plan.files) {
  const text = fs.readFileSync(item.file, 'utf8');
  const source = ts.createSourceFile(item.file, text, ts.ScriptTarget.Latest, true);
  const edits = [];
  for (const statement of source.statements) {
    if (!ts.isVariableStatement(statement)) continue;
    for (const declaration of statement.declarationList.declarations) {
      const arrow = declaration.initializer;
      if (!arrow || !ts.isArrowFunction(arrow) || !ts.isBlock(arrow.body) || arrow.body.statements.length !== 1) continue;
      const returned = arrow.body.statements[0];
      if (!ts.isReturnStatement(returned) || !returned.expression) continue;
      let replacement = returned.expression.getText(source);
      if (ts.isObjectLiteralExpression(returned.expression)) replacement = `(${replacement})`;
      edits.push({start: arrow.body.getStart(source), end: arrow.body.end, replacement});
      converted.push({file: item.file, name: declaration.name.getText(source)});
    }
  }
  let result = text;
  for (const edit of edits.reverse()) result = result.slice(0, edit.start) + edit.replacement + result.slice(edit.end);
  fs.writeFileSync(item.file, result);
}
if (converted.length !== 8) throw new Error('Expected exactly eight introduced arrow-body diagnostics');
fs.writeFileSync(path.join(proof, 'concise-arrow-conversions.json'), JSON.stringify(converted, null, 2) + '\n');
console.log('Converted eight single-return arrow bodies to identical concise expressions.');
