import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m6';
const ts = await import(path.join(root, 'node_modules/typescript/lib/typescript.js'));
const plan = JSON.parse(fs.readFileSync(path.join(proof, 'conversion-plan.json'), 'utf8'));
const files = plan.files.map(item => item.file);
const configFile = ts.readConfigFile('typescript/kernel/protocol/tsconfig.typecheck.json', ts.sys.readFile);
if (configFile.error) throw new Error('Config invalid');
const config = ts.parseJsonConfigFileContent(configFile.config, ts.sys, path.resolve('typescript/kernel/protocol'));
const printer = ts.createPrinter();
const bodyNode = body => ts.isBlock(body) && body.statements.length === 1 && ts.isReturnStatement(body.statements[0]) && body.statements[0].expression ? body.statements[0].expression : body;
// Compare every ordered semantic AST child. Printer line-layout metadata is
// deliberately excluded: Oxfmt collapses one newly concise call argument array.
const bodyAst = (node, source) => {
  const children = [];
  ts.forEachChild(node, child => { children.push(bodyAst(child, source)); });
  return children.length ? {kind: ts.SyntaxKind[node.kind], children} : {kind: ts.SyntaxKind[node.kind], text: node.getText(source)};
};
const capture = baseline => {
  const host = ts.createCompilerHost(config.options);
  const originalRead = host.readFile.bind(host);
  if (baseline) host.readFile = filename => {
    const file = files.find(item => path.resolve(item) === path.resolve(filename));
    return file ? fs.readFileSync(path.join(proof, `${path.basename(file)}.before`), 'utf8') : originalRead(filename);
  };
  const program = ts.createProgram([...new Set([...config.fileNames, ...files.map(file => path.resolve(file))])], config.options, host);
  const checker = program.getTypeChecker();
  const captures = {};
  for (const file of files) {
    const source = program.getSourceFile(path.resolve(file));
    if (!source) throw new Error('Source missing');
    const printType = type => {
      const node = checker.typeToTypeNode(type, source, ts.NodeBuilderFlags.NoTruncation);
      if (!node) throw new Error('Full type AST missing');
      return printer.printNode(ts.EmitHint.Unspecified, node, source);
    };
    const callable = symbol => checker.getSignaturesOfType(checker.getTypeOfSymbolAtLocation(symbol, source), ts.SignatureKind.Call).map(signature => {
      const node = checker.signatureToSignatureDeclaration(signature, ts.SyntaxKind.FunctionType, source, ts.NodeBuilderFlags.NoTruncation);
      if (!node || !ts.isFunctionTypeNode(node)) throw new Error('Full callable AST missing');
      const predicate = checker.getTypePredicateOfSignature(signature);
      return {signature: printer.printNode(ts.EmitHint.Unspecified, node, source), predicate: predicate ? {kind: ts.TypePredicateKind[predicate.kind], parameterName: predicate.parameterName, parameterIndex: predicate.parameterIndex, type: predicate.type ? printType(predicate.type) : null} : null};
    });
    const locals = {};
    const nonCallable = [];
    for (const statement of source.statements) {
      const declaration = ts.isFunctionDeclaration(statement) ? statement : ts.isVariableStatement(statement) && statement.declarationList.declarations.length === 1 ? statement.declarationList.declarations[0] : undefined;
      const fn = declaration && (ts.isFunctionDeclaration(declaration) ? declaration : declaration.initializer && ts.isArrowFunction(declaration.initializer) ? declaration.initializer : undefined);
      if (!fn?.body || !declaration.name || !ts.isIdentifier(declaration.name)) { nonCallable.push(printer.printNode(ts.EmitHint.Unspecified, statement, source)); continue; }
      const symbol = checker.getSymbolAtLocation(declaration.name);
      if (!symbol) throw new Error('Callable symbol missing');
      locals[declaration.name.text] = {callSignatures: callable(symbol), body: bodyAst(bodyNode(fn.body), source), async: fn.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.AsyncKeyword) ?? false, typeParameters: fn.typeParameters?.map(parameter => printer.printNode(ts.EmitHint.Unspecified, parameter, source)) ?? [], parameters: fn.parameters.map(parameter => ({name: parameter.name.getText(source), optional: Boolean(parameter.questionToken), rest: Boolean(parameter.dotDotDotToken), default: parameter.initializer ? printer.printNode(ts.EmitHint.Unspecified, parameter.initializer, source) : null}))};
    }
    const moduleSymbol = checker.getSymbolAtLocation(source);
    if (!moduleSymbol) throw new Error('Module symbol missing');
    captures[file] = {locals: Object.fromEntries(Object.entries(locals).sort(([a], [b]) => a.localeCompare(b))), nonCallable, exports: Object.fromEntries(checker.getExportsOfModule(moduleSymbol).map(symbol => [symbol.name, {callSignatures: callable(symbol), fullType: printType(checker.getTypeOfSymbolAtLocation(symbol, source))}]).sort(([a], [b]) => a.localeCompare(b)))};
  }
  const entrypoint = program.getSourceFile(path.resolve('typescript/kernel/protocol/src/index.ts'));
  const symbol = entrypoint && checker.getSymbolAtLocation(entrypoint);
  if (!symbol) throw new Error('Entrypoint missing');
  captures.packageExports = Object.fromEntries(checker.getExportsOfModule(symbol).map(symbol => {
    const type = checker.getTypeOfSymbolAtLocation(symbol, entrypoint);
    const node = checker.typeToTypeNode(type, entrypoint, ts.NodeBuilderFlags.NoTruncation);
    if (!node) throw new Error('Full public export type missing');
    return [symbol.name, printer.printNode(ts.EmitHint.Unspecified, node, entrypoint)];
  }).sort(([a], [b]) => a.localeCompare(b)));
  return captures;
};
const before = capture(true);
const after = capture(false);
const equal = JSON.stringify(before) === JSON.stringify(after);
fs.writeFileSync(path.join(proof, 'callable-compatibility.json'), JSON.stringify({typescript: ts.version, baselineCommit: plan.baselineCommit, count: plan.files.reduce((sum, item) => sum + item.count, 0), before, after, equal}, null, 2) + '\n');
if (!equal) {
  for (const file of files) {
    for (const name of Object.keys(before[file].locals)) if (JSON.stringify(before[file].locals[name]) !== JSON.stringify(after[file].locals[name])) console.error('Callable mismatch:', file, name);
    if (JSON.stringify(before[file].nonCallable) !== JSON.stringify(after[file].nonCallable)) console.error('Non-callable mismatch:', file);
    if (JSON.stringify(before[file].exports) !== JSON.stringify(after[file].exports)) console.error('Export mismatch:', file);
  }
  throw new Error('Callable/body/parameter/public export/non-callable compatibility mismatch');
}
console.log('All 29 local signatures, predicates, bodies, async flags, parameter defaults/optionality/rest and full public export types match; all other top-level ASTs match in original order, including fixture property insertion order.');
