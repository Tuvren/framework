import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m6';
const root = process.cwd();
const hash = data => createHash('sha256').update(data).digest('hex');
const read = filename => JSON.parse(fs.readFileSync(path.join(proof, filename), 'utf8'));
const plan = read('conversion-plan.json');
const baselineCommit = execFileSync('git', ['rev-parse', 'HEAD'], {encoding: 'utf8'}).trim();
if (!baselineCommit.startsWith('983dbb7')) throw new Error('Unexpected HEAD drift');
const files = plan.files.map(item => item.file);
const changedFiles = execFileSync('git', ['diff', '--name-only'], {encoding: 'utf8'}).trim().split('\n');
if (JSON.stringify([...changedFiles].sort()) !== JSON.stringify([...files].sort())) throw new Error('Source scope drift');
const local = read('local-runtime-compatibility.json');
const sourceHashes = {};
const diff = {added: 0, removed: 0, total: 0, perFile: []};
for (const file of files) {
  const before = fs.readFileSync(path.join(proof, `${path.basename(file)}.before`));
  const after = fs.readFileSync(file);
  if (hash(execFileSync('git', ['show', `${baselineCommit}:${file}`])) !== hash(before)) throw new Error('Baseline snapshot differs from assigned HEAD');
  sourceHashes[file] = {before: hash(before), after: hash(after)};
  if (local.sourceHashes.before[file] !== hash(before) || local.sourceHashes.after[file] !== hash(after)) throw new Error('Final source/runtime proof mismatch');
  fs.writeFileSync(path.join(proof, `${path.basename(file)}.after`), after);
  const [added, removed] = execFileSync('git', ['diff', '--numstat', '--', file], {encoding: 'utf8'}).split('\t').map(Number);
  diff.added += added;
  diff.removed += removed;
  diff.perFile.push({file, added, removed});
}
diff.total = diff.added + diff.removed;
if (diff.total > 1500) throw new Error('Review budget exceeded');
fs.writeFileSync(path.join(proof, 'm6.patch'), execFileSync('git', ['diff', '--', ...files]));
const gates = ['scoped', 'initialization', 'retained-biome', 'format-touched', 'runtime', 'bench', 'typecheck', 'changeset', 'conformance', 'format', 'lint', 'api-freeze'];
const gateExits = Object.fromEntries(gates.map(gate => [gate, Number(fs.readFileSync(path.join(proof, `after-${gate}.exit`), 'utf8'))]));
const proofChecks = ['callable-compatibility', 'local-runtime-compatibility', 'structural-proof', 'signature-controls', 'structural-controls', 'native-summary', 'changeset-proof', 'conformance-comparison'];
for (const check of proofChecks) gateExits[check] = Number(fs.readFileSync(path.join(proof, `${check}.exit`), 'utf8'));
if (Object.values(gateExits).some(code => code !== 0)) throw new Error('Final gate/proof failed');
const callables = read('callable-compatibility.json');
const conformance = read('conformance-comparison.json');
if (!callables.equal || !local.equal || !conformance.equal) throw new Error('Compatibility proof failed');
const immediateBaseline = JSON.parse(fs.readFileSync('/home/oscar/.codex/plans/tuvren-bq-session/m5/conformance-comparison.json', 'utf8')).current;
if (JSON.stringify(immediateBaseline) !== JSON.stringify(conformance.current)) throw new Error('Conformance differs from immediate reviewed M5 baseline');
const native = read('native-summary.json');
const summary = {
  milestone: 'M6 / KRT-BQ003 partial', mode: 'contract_test', baselineCommit,
  sourceFilesChanged: changedFiles, diff, sourceHashes,
  conversions: {declarations: 29, perFile: plan.files.map(item => ({file: item.file, count: item.count})), assertionCallableAnnotations: 0, predicateSignaturesPreserved: true, dependencyOrder: 'Compiler-symbol-based topological order; lazily initialized function dependencies are emitted before their earliest top-level use while other top-level statements retain original order', dynamicThisArgumentsNewTargetGenerators: 0, conciseArrowBodies: 8, recursiveHelpersPreserved: read('structural-proof.json').files.flatMap(item => item.selfRecursiveHelpers)},
  diagnostics: native,
  targetDiagnosticReduction: {funcStyle: 29, noUseBeforeDefine: 27, total: 56, appliesToBothSyntacticAndTypeAwareReports: true, finalAllFourFilesTargetRules: 0, unrelatedDiagnosticsSelectionAndRuleCountsUnchanged: true},
  callableProof: {localSignatures: 29, fullPublicExportTypesMatch: true, allLocalRuntimeNamesAritiesAsyncConstructorsMatch: true, bodiesMatchAfterOnlySingleReturnToConciseExpressionNormalization: true, parameterDefaultsOptionalityRestGenericsAndReadonlyContractsMatch: true, negativeSignatureControls: 5, negativeStructuralControls: 4},
  runtimeProof: {scopedProtocolTests: 92, scopedRuntimeTests: 56, freshProcessTests: 6, canonicalRecordAndFixtureByteHashCases: 10, orderedDecodeAndValidationOutcomes: 15, opaqueBufferViewAndSharedBufferDigestCases: 4, allFixtureRuntimeValuesAndPropertyOrderMatch: true, distinctInsertionOrderFixtureVariantsPreserved: true, statefulTopLevelInitializationOrderUnchanged: true, benchmarkBeforeAndAfterExit: 0, conformanceLaneOutcomesMatch: 11, conformanceBaseline: ['reviewed pre-reorder M4 baseline', 'immediate reviewed M5 baseline'], apiFreeze: {entrypoints: 14, exports: 404}},
  directChangeset: read('changeset-proof.json'), gateExits,
  forbiddenChanges: {constitution: false, otherSources: false, config: false, dependencies: false, targets: false, authorityOrGoldenFixtureValues: false,services: false,commits: false},
  newDependenciesPatternsConventionsOrContractShapesOutsideSpec: [],
  decisions: ['No subdivision required: exactly four approved files and 621 changed lines.', 'No repository tests added; existing behavioral and fresh-process tests plus external compiler/runtime/structural comparisons exercise the transformation.', 'Eight introduced arrow-body-style diagnostics resolved only through equivalent concise-expression conversions; all other native debt remains untouched.'],
  limitations: ['Only func-style and no-use-before-define are cleared in this assigned scope; remaining native debt stays planned.', 'Full verify/release ladder belongs to the epic lead; no broad workspace readiness claim.', 'Exa tools are not available in this worker; compiler APIs were verified against the installed TypeScript 6.0.2 declarations and official upstream v6.0.2 source.'],
  verificationReferences: {typescriptVersion: '6.0.2', compilerApi: 'node_modules/typescript/lib/typescript.d.ts', upstreamCompilerApi: 'https://raw.githubusercontent.com/microsoft/TypeScript/v6.0.2/src/compiler/types.ts', oxlintVersion: '1.86.0', oxfmtVersion: '0.71.0', biomeVersion: '2.5.14', bunVersion: '1.4.2'},
  usage: {elapsedApproxMinutes: 11, subagents: 0, commits: 0, dependencyInstalls: 0, exactTokenAndCostCounters: 'Not exposed to worker'},
  evidence: [...proofChecks.map(check => `${check}.json`), ...gates.map(gate => `after-${gate}.log`), 'runtime-before.json', 'runtime-after.json', 'conversion-plan.json', 'compiler-api-verification.txt', 'm6.patch'],
};
fs.writeFileSync(path.join(proof, 'summary.json'), JSON.stringify(summary, null, 2) + '\n');
const included = fs.readdirSync(proof).filter(filename => /\.(json|log|exit|stderr|mjs|before|after|patch|txt)$/.test(filename)).sort();
const manifest = included.map(filename => ({file: filename, bytes: fs.statSync(path.join(proof, filename)).size, sha256: hash(fs.readFileSync(path.join(proof, filename)))}));
fs.writeFileSync(path.join(proof, 'proof-index.json'), JSON.stringify({baselineCommit, files: manifest, excluded: ['environment.zsh', 'run-native.zsh', '*.candidate', 'local-runtime-mirror/'], reason: 'Environment exports and scratch filesystem mirrors are excluded from deliverables; final source snapshots and measurement outputs are included.'}, null, 2) + '\n');
execFileSync('tar', ['-czf', path.join(proof, 'm6-proof.tar.gz'), '-C', proof, ...included, 'proof-index.json']);
console.log(`Final M6 proof: four files, +${diff.added}/-${diff.removed} (${diff.total} lines); 29 declarations converted; 56 targeted diagnostics cleared; all ${Object.keys(gateExits).length} final gates/proofs pass; all 11 conformance outcomes match both baselines. Environment exports excluded from m6-proof.tar.gz.`);
