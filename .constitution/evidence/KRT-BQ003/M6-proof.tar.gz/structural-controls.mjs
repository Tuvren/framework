import fs from 'node:fs';
import path from 'node:path';
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m6';
const ts = await import(path.join(process.cwd(), 'node_modules/typescript/lib/typescript.js'));
const bodyAst = (node, source) => {
  const children = [];
  ts.forEachChild(node, child => { children.push(bodyAst(child, source)); });
  return children.length ? {kind: ts.SyntaxKind[node.kind], children} : {kind: ts.SyntaxKind[node.kind], text: node.getText(source)};
};
const print = text => {
  const source = ts.createSourceFile('control.ts', text, ts.ScriptTarget.Latest, true);
  if (source.parseDiagnostics.length) throw new Error('Control must parse');
  return source.statements.map(statement => bodyAst(statement, source));
};
const controls = [
  {name: 'fixture property insertion order', before: 'const variants = [{timestamp: 1, active: true}, {active: true, timestamp: 1}];', changed: 'const variants = [{active: true, timestamp: 1}, {active: true, timestamp: 1}];'},
  {name: 'fixture value', before: 'const bytes = new Uint8Array([1, 2, 3]);', changed: 'const bytes = new Uint8Array([1, 2, 4]);'},
  {name: 'stateful initialization order', before: 'const encoder = createEncoder(); const decoder = createDecoder();', changed: 'const decoder = createDecoder(); const encoder = createEncoder();'},
  {name: 'error evaluation order', before: 'const validate = () => { assertFirst(); assertSecond(); };', changed: 'const validate = () => { assertSecond(); assertFirst(); };'},
].map(control => ({...control, detected: JSON.stringify(print(control.before)) !== JSON.stringify(print(control.changed))}));
if (controls.some(control => !control.detected)) throw new Error('Structural comparison lost an ordering/value distinction');
const formattingOnlyControl = JSON.stringify(print('const call = () => Reflect.apply(fn, undefined, [\n a,\n b,\n]);')) === JSON.stringify(print('const call = () => Reflect.apply(fn, undefined, [a, b]);'));
if (!formattingOnlyControl) throw new Error('AST comparison must ignore array line-layout metadata');
fs.writeFileSync(path.join(proof, 'structural-controls.json'), JSON.stringify({typescript: ts.version, controls, formattingOnlyControl}, null, 2) + '\n');
console.log('AST controls detect fixture property sorting/collapse, fixture value changes, stateful initialization reorder and validation error reorder.');
