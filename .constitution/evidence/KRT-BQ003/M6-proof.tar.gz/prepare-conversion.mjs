import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m6';
const ts = await import(path.join(root, 'node_modules/typescript/lib/typescript.js'));
const files = ['src/lib/kernel-record-identity.ts', 'bench/kernel-identity.bench.ts', 'test/kernel-record-fixtures.ts', 'test/kernel-contract-deterministic.test.ts'].map(file => `typescript/kernel/protocol/${file}`);
const configFile = ts.readConfigFile('typescript/kernel/protocol/tsconfig.typecheck.json', ts.sys.readFile);
if (configFile.error) throw new Error(ts.flattenDiagnosticMessageText(configFile.error.messageText, '\n'));
const config = ts.parseJsonConfigFileContent(configFile.config, ts.sys, path.resolve('typescript/kernel/protocol'));
const program = ts.createProgram([...new Set([...config.fileNames, ...files.map(file => path.resolve(file))])], config.options);
const checker = program.getTypeChecker();
const plans = [];
for (const file of files) {
  const text = fs.readFileSync(file, 'utf8');
  fs.writeFileSync(path.join(proof, `${path.basename(file)}.before`), text);
  const source = program.getSourceFile(path.resolve(file));
  if (!source) throw new Error('Source absent');
  const declarations = source.statements.filter(ts.isFunctionDeclaration);
  const bySymbol = new Map(declarations.map(declaration => [checker.getSymbolAtLocation(declaration.name), declaration]));
  const dependencies = node => {
    const result = new Set();
    const visit = current => {
      if (ts.isIdentifier(current)) {
        const target = bySymbol.get(checker.getSymbolAtLocation(current));
        if (target) result.add(target);
      }
      ts.forEachChild(current, visit);
    };
    visit(node);
    return [...result];
  };
  const graph = declarations.map(declaration => {
    const lexical = [];
    const visit = node => {
      if (node.kind === ts.SyntaxKind.ThisKeyword || ts.isMetaProperty(node) || (ts.isIdentifier(node) && node.text === 'arguments') || (ts.isFunctionLike(node) && node.asteriskToken)) lexical.push(node.getText(source));
      ts.forEachChild(node, visit);
    };
    visit(declaration);
    if (lexical.length) throw new Error(`Lexical-sensitive function ${declaration.name.text}`);
    return {name: declaration.name.text, dependencies: dependencies(declaration.body).filter(target => target !== declaration).map(target => target.name.text), recursive: dependencies(declaration.body).includes(declaration), lexical};
  });
  const converted = new Map(declarations.map(declaration => {
    if (!declaration.name || !declaration.type || !declaration.body || declaration.typeParameters?.length) throw new Error('Unexpected signature; inspect manually');
    const open = declaration.getChildren(source).find(node => node.kind === ts.SyntaxKind.OpenParenToken);
    if (!open) throw new Error('Parameters missing');
    if (ts.isTypePredicateNode(declaration.type) && declaration.type.assertsModifier) throw new Error('Assertion needs explicit callable annotation');
    const exported = declaration.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.ExportKeyword) ? 'export ' : '';
    const asyncPrefix = declaration.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.AsyncKeyword) ? 'async ' : '';
    const leading = text.slice(declaration.getFullStart(), declaration.getStart(source));
    const signature = text.slice(open.getStart(source), declaration.body.getStart(source)).trimEnd();
    return [declaration.name.text, `${leading}${exported}const ${declaration.name.text} = ${asyncPrefix}${signature} => ${declaration.body.getText(source)};`];
  }));
  const ordered = [];
  const done = new Set();
  const active = new Set();
  const chunks = [];
  const emit = name => {
    if (done.has(name)) return;
    if (active.has(name)) throw new Error('Mutually recursive helpers need subdivision');
    active.add(name);
    const entry = graph.find(item => item.name === name);
    for (const dependency of entry.dependencies) emit(dependency);
    active.delete(name);
    done.add(name);
    ordered.push(name);
    chunks.push(converted.get(name));
  };
  const nonCallable = [];
  for (const statement of source.statements) {
    if (ts.isFunctionDeclaration(statement)) continue;
    const needed = dependencies(statement).map(target => target.name.text);
    for (const name of needed) emit(name);
    nonCallable.push({kind: ts.SyntaxKind[statement.kind], dependencies: needed, text: statement.getText(source)});
    chunks.push(text.slice(statement.getFullStart(), statement.end));
  }
  for (const item of graph) emit(item.name);
  const candidate = chunks.join('') + '\n';
  fs.writeFileSync(path.join(proof, `${path.basename(file)}.candidate`), candidate);
  plans.push({file, count: declarations.length, graph, ordered, nonCallable});
}
fs.writeFileSync(path.join(proof, 'conversion-plan.json'), JSON.stringify({typescript: ts.version, baselineCommit: '983dbb7', files: plans}, null, 2) + '\n');
console.log(plans.map(plan => ({file: plan.file, count: plan.count, order: plan.ordered})));
