import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root = process.cwd();
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m6';
const plan = JSON.parse(fs.readFileSync(path.join(proof, 'conversion-plan.json'), 'utf8'));
const captures = {};
const sourceHashes = {};
for (const phase of ['before', 'after']) {
  const directory = path.join(proof, 'local-runtime-mirror', phase);
  fs.mkdirSync(directory, {recursive: true});
  fs.writeFileSync(path.join(directory, 'tsconfig.json'), JSON.stringify({compilerOptions: {paths: {'@tuvren/core': [path.join(root, 'typescript/core/src/index.ts')]}}}));
  const dependencies = path.join(directory, 'node_modules');
  if (!fs.existsSync(dependencies)) fs.symlinkSync(path.join(root, 'node_modules'), dependencies);
  captures[phase] = {};
  sourceHashes[phase] = {};
  for (const item of plan.files) {
    const relative = item.file.slice('typescript/kernel/protocol/'.length);
    const target = path.join(directory, relative);
    fs.mkdirSync(path.dirname(target), {recursive: true});
    const source = fs.readFileSync(phase === 'before' ? path.join(proof, `${path.basename(item.file)}.before`) : path.join(root, item.file), 'utf8');
    sourceHashes[phase][item.file] = createHash('sha256').update(source).digest('hex');
    const captureFile = path.join(directory, `${path.basename(item.file)}.callables.json`);
    const names = item.graph.map(entry => entry.name);
    const extension = `\nconst measurementFs = await import('node:fs');\nmeasurementFs.writeFileSync(${JSON.stringify(captureFile)}, JSON.stringify(Object.fromEntries([${names.join(', ')}].map(callable => [callable.name, {name: callable.name, length: callable.length, constructor: callable.constructor.name}]))));\n`;
    if (fs.existsSync(target) && fs.lstatSync(target).isSymbolicLink()) fs.unlinkSync(target);
    fs.writeFileSync(target, source + extension);
    for (const [subdirectory, originalDirectory] of [['src', 'src'], ['test', 'test']]) {
      const ownDirectory = path.join(directory, subdirectory);
      fs.mkdirSync(ownDirectory, {recursive: true});
      for (const filename of fs.readdirSync(path.join(root, 'typescript/kernel/protocol', originalDirectory))) {
        const original = path.join(root, 'typescript/kernel/protocol', originalDirectory, filename);
        if (!fs.statSync(original).isFile() || plan.files.some(entry => path.resolve(entry.file) === path.resolve(original))) continue;
        const mirror = path.join(ownDirectory, filename);
        if (!fs.existsSync(mirror)) fs.symlinkSync(original, mirror);
      }
    }
    const isTest = relative.endsWith('.test.ts');
    const result = spawnSync(process.execPath, isTest ? ['test', target] : [target], {cwd: directory, encoding: 'utf8'});
    fs.writeFileSync(path.join(proof, `local-${phase}-${path.basename(item.file)}.log`), result.stdout + result.stderr);
    if (result.status !== 0) throw new Error(`Local runtime mirror failed for ${item.file}: ${result.stderr}`);
    const metadata = JSON.parse(fs.readFileSync(captureFile, 'utf8'));
    if (Object.keys(metadata).length !== item.count) throw new Error('Missing local callable');
    captures[phase][item.file] = metadata;
  }
}
const equal = JSON.stringify(captures.before) === JSON.stringify(captures.after);
fs.writeFileSync(path.join(proof, 'local-runtime-compatibility.json'), JSON.stringify({sourceHashes, sourceModification: 'Append-only metadata observation of otherwise unchanged source bytes in external mirrors; relative sibling dependencies linked to current implementation.', before: captures.before, after: captures.after, equal}, null, 2) + '\n');
if (!equal) throw new Error('Local runtime callable name, arity, or async constructor changed');
console.log('All 29 local runtime callable names, arities and async constructors match in append-only external mirrors; both benchmark module evaluations and both deterministic test mirrors exit successfully.');
