import fs from 'node:fs';
import path from 'node:path';
const proof = '/home/oscar/.codex/plans/tuvren-bq-session/m6';
const files = JSON.parse(fs.readFileSync(path.join(proof, 'conversion-plan.json'), 'utf8')).files.map(item => item.file);
const counts = diagnostics => Object.fromEntries([...new Set(diagnostics.map(item => item.code))].sort().map(code => [code, diagnostics.filter(item => item.code === code).length]));
const reports = [];
for (const phase of ['before', 'after']) for (const scope of ['protocol', 'runtime']) for (const mode of ['syntactic', 'typeaware']) {
  const name = `${phase}-${scope}-${mode}`;
  const report = JSON.parse(fs.readFileSync(path.join(proof, `${name}.json`), 'utf8'));
  const own = report.diagnostics.filter(item => files.includes(item.filename));
  const outside = report.diagnostics.filter(item => !files.includes(item.filename));
  const result = {phase, scope, mode, filename: `${name}.json`, filesSelected: report.number_of_files, rules: report.number_of_rules, total: report.diagnostics.length, targetTotal: own.length, targetRuleCounts: counts(own), perFile: Object.fromEntries(files.map(file => [file, counts(own.filter(item => item.filename === file))])), outsideRuleCounts: counts(outside), stderr: fs.readFileSync(path.join(proof, `${name}.stderr`), 'utf8'), commandExit: Number(fs.readFileSync(path.join(proof, `${name}.exit`), 'utf8'))};
  if (result.filesSelected === 0 || result.stderr.length !== 0) throw new Error(`Unexpected native selection/backend stderr in ${name}`);
  if (phase === 'after' && own.some(item => ['eslint(func-style)', 'eslint(no-use-before-define)'].includes(item.code))) throw new Error(`Requested diagnostic still fires: ${name}`);
  reports.push(result);
}
for (const scope of ['protocol', 'runtime']) for (const mode of ['syntactic', 'typeaware']) {
  const before = reports.find(item => item.phase === 'before' && item.scope === scope && item.mode === mode);
  const after = reports.find(item => item.phase === 'after' && item.scope === scope && item.mode === mode);
  if (before.filesSelected !== after.filesSelected || before.rules !== after.rules || JSON.stringify(before.outsideRuleCounts) !== JSON.stringify(after.outsideRuleCounts)) throw new Error('Unrelated native diagnostics or selected coverage changed');
  const expected = Object.fromEntries(Object.entries(before.targetRuleCounts).filter(([code]) => !['eslint(func-style)', 'eslint(no-use-before-define)'].includes(code)));
  if (JSON.stringify(expected) !== JSON.stringify(after.targetRuleCounts)) { console.error({expected, actual: after.targetRuleCounts}); throw new Error('Unexpected diagnostic changes inside target'); }
}
fs.writeFileSync(path.join(proof, 'native-summary.json'), JSON.stringify(reports, null, 2) + '\n');
for (const report of reports) console.log(`${report.phase} ${report.scope} ${report.mode}: total=${report.total}, target=${report.targetTotal}, files=${report.filesSelected}, rules=${report.rules}, func-style=${report.targetRuleCounts['eslint(func-style)'] ?? 0}, no-use-before-define=${report.targetRuleCounts['eslint(no-use-before-define)'] ?? 0}`);
