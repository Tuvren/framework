# M9b-F1 annotation fix — evidence index

Worktree: /home/oscar/GitHub/Tuvren/framework-bp
HEAD: 3cf948f5dbc3a881e027b73a11eb5d1412a6df11 (not committed)
Epic base: ce53193c7d955c218934aa2086e6926e14c25978 (ancestor of HEAD)

## Product edit (only these two files)
- tools/scripts/generator-oxfmt.test.ts
  - `import { spawnSync, type SpawnSyncReturns } from "node:child_process";`
    -> top-level `import type { SpawnSyncReturns } from "node:child_process";`
  - `function runGenerator(...): ReturnType<typeof spawnSync>`
    -> `SpawnSyncReturns<string>`
- tools/scripts/oxc-preparation.test.ts
  - same type-only import correction for `SpawnSyncReturns`
  - `function runBun(...): ReturnType<typeof spawnSync>` -> `SpawnSyncReturns<string>`

Rationale: installed @types/node 25.5.0 overload
`spawnSync(command, args, options?: SpawnSyncOptions)` resolves the last
overload `SpawnSyncReturns<string | NonSharedBuffer>`; `ReturnType<typeof spawnSync>`
therefore widened stdout/stderr. UTF-8 call sites actually match the
`SpawnSyncOptionsWithStringEncoding` overload returning `SpawnSyncReturns<string>`.
`no-duplicates` is not triggered by a top-level type import, and
`import/consistent-type-specifier-style` (prefer-top-level) is satisfied.
Runtime behavior is unchanged (type-only import + return annotation are erased).

## Six-error before -> after proof
Exact pre-fix capture: `final-oxlint.prefix.json` (sha of the M9b worker run).
Fresh post-fix capture: `final-oxlint.json`.

Before (6 in the two files):
```
generator-oxfmt.test.ts  TS2769  line 351 col 27
generator-oxfmt.test.ts  TS2769  line 351 col 47
oxc-preparation.test.ts  TS2769  line 124 col 25
oxc-preparation.test.ts  TS2769  line 124 col 45
oxc-preparation.test.ts  TS2345  line 125 col 45
oxc-preparation.test.ts  TS2345  line 352 col 48
```
After: 0 TS-coded diagnostics in either file (`f1/after-ts.txt`, diff
`f1/prefix-ts.txt` vs `f1/after-ts.txt` removes exactly those six).

## Restated measured counts (fresh raw output)
- before: files 626, rules 474, diagnostics 19608, real TS 15, resolution 0
- after:  files 626, rules 474, diagnostics 19599, real TS 9, resolution 0
- delta: -9 = 6 fixed TS diagnostics + 3 `typescript(restrict-template-expressions)`
  in the same two files (downstream of the narrowed stdout/stderr type);
  no new rule diagnostics (import consistent-type-specifier-style stayed 734).
- adapters unchanged by this fix: framework 1598/197/0 TS/26 files,
  kernel 357/84/0/4, providers 369/57/0/4 (recomputed from fresh capture).

Nine pre-existing real TS diagnostics remain, byte-identical to the pre-fix
capture and blamed to epics before BP (Y, AL, Q, R):
run.ts:796; fixture source.ts:1; portability-gate.ts:843; release-check.ts:97;
telemetry-codegen.ts:400-404. Not suppressed or repaired.

## Gates
- focused tests `bun test generator-oxfmt.test.ts oxc-preparation.test.ts
  oxc-project-discovery.test.ts`: 36 pass / 0 fail, 1169 expect() calls
  (`f1/focused-tests-toplevel.log`)
- retained lint `bun run lint`: exit 0, no fixes (`f1/retained-lint-toplevel.log`)
- native Oxfmt `bunx --bun oxfmt -c oxfmt.config.ts --check <two files>`:
  exit 0, 2 files clean (`f1/oxfmt-check-toplevel.log`)
- type-aware lane `final-oxlint.json` (stdout) / `final-oxlint.err` (0 bytes),
  exit status 1 (`f1/oxlint-exit.txt`)

All top-level Bun/Oxfmt/Oxlint calls ran under
`flock .../devenv-bp.lock devenv shell -- zsh -c ...` with
`TMPDIR=/home/oscar/.cache/pig-subagent/framework/BP-m9b/f1-tmp`.

Drift: top-level `import type` chosen over inline `type` specifier because the
inline form added two `import(consistent-type-specifier-style)` rule
diagnostics; the top-level form adds none and triggers no `import/no-duplicates`.
