// M9b measurement summary. Reads the raw oxlint JSON captures and emits an
// independently checkable report. Run with bun from the scratch directory.
import { readFileSync, writeFileSync } from "node:fs";

const S = "/home/oscar/.cache/pig-subagent/framework/BP-m9b";
const read = (f) => JSON.parse(readFileSync(`${S}/${f}`, "utf8"));

const baseline = read("baseline-oxlint.json");
const after = read("final-oxlint.json");
const syntax = read("syntax-only.json");

const isTsError = (code) =>
  typeof code === "string" &&
  (/^typescript\(TS\d+\)$/.test(code) || code === "typescript(tsconfig-error)");

const RESOLUTION_CODES = new Set([
  "typescript(tsconfig-error)",
  "typescript(TS2307)",
  "typescript(TS2591)",
  "typescript(TS2868)",
  "typescript(TS2503)",
  "typescript(TS6059)",
  "typescript(TS6307)",
  "typescript(TS7006)",
  "typescript(TS2304)",
]);

function counts(diagnostics) {
  const byCode = {};
  for (const d of diagnostics) {
    byCode[d.code] = (byCode[d.code] ?? 0) + 1;
  }
  return byCode;
}

function area(filename) {
  if (filename.startsWith("typescript/conformance-adapter")) {
    return "conformance-adapter (framework)";
  }
  if (filename.startsWith("typescript/kernel/conformance-adapter")) {
    return "conformance-adapter (kernel)";
  }
  if (filename.startsWith("typescript/providers/conformance-adapter")) {
    return "conformance-adapter (providers)";
  }
  if (filename.startsWith("typescript/certification")) return "certification (framework)";
  if (filename.startsWith("typescript/kernel/certification")) return "certification (kernel)";
  if (filename.startsWith("typescript/providers/certification")) return "certification (providers)";
  if (filename.startsWith("typescript/")) return `typescript/${filename.split("/")[1]}`;
  if (filename.startsWith("tools/")) return "tools";
  return "other";
}

const afterRuleIds = new Set(after.diagnostics.map((d) => d.code));
const syntaxRuleIds = new Set(syntax.diagnostics.map((d) => d.code));
const typeAwareRules = new Set(
  [...afterRuleIds].filter(
    (code) => !syntaxRuleIds.has(code) && code !== undefined && !isTsError(code)
  )
);

const tsErrors = after.diagnostics.filter((d) => isTsError(d.code));
const resolutionErrors = tsErrors.filter((d) => RESOLUTION_CODES.has(d.code));
const realTypeErrors = tsErrors.filter((d) => !RESOLUTION_CODES.has(d.code));

const adapterAreas = [
  "conformance-adapter (framework)",
  "conformance-adapter (kernel)",
  "conformance-adapter (providers)",
];
const adapters = {};
for (const name of adapterAreas) {
  const rows = after.diagnostics.filter((d) => area(d.filename) === name);
  const tsRows = rows.filter((d) => isTsError(d.code));
  const typeAwareRows = rows.filter(
    (d) => typeAwareRules.has(d.code) && !isTsError(d.code)
  );
  adapters[name] = {
    total: rows.length,
    tsErrors: tsRows.length,
    tsErrorCodes: counts(tsRows),
    typeAwareRuleDiagnostics: typeAwareRows.length,
    typeAwareRuleCounts: counts(typeAwareRows),
    otherRuleDiagnostics: rows.length - tsRows.length - typeAwareRows.length,
    files: new Set(rows.map((d) => d.filename)).size,
  };
}

const summary = {
  toolVersions: {
    oxlint: "1.86.0",
    oxlintTsgolint: "7.0.2003",
    oxfmt: "0.71.0",
    typescript: "6.0.2",
  },
  command:
    "bunx --bun oxlint --type-aware --type-check --format=json .",
  exitStatus: 1,
  baseline: {
    filesLinted: baseline.number_of_files,
    rules: baseline.number_of_rules,
    totalDiagnostics: baseline.diagnostics.length,
    tsErrors: baseline.diagnostics.filter((d) => isTsError(d.code)).length,
    resolutionErrors: baseline.diagnostics.filter((d) =>
      RESOLUTION_CODES.has(d.code)
    ).length,
  },
  resolved: {
    filesLinted: after.number_of_files,
    rules: after.number_of_rules,
    totalDiagnostics: after.diagnostics.length,
    tsErrors: tsErrors.length,
    resolutionErrors: resolutionErrors.length,
    realTypeErrors: realTypeErrors.length,
    realTypeErrorCodes: counts(realTypeErrors),
    realTypeErrorFiles: [...new Set(realTypeErrors.map((d) => d.filename))].sort(),
    typeAwareRulesObserved: typeAwareRules.size,
  },
  adapters,
};

writeFileSync(`${S}/summary.json`, `${JSON.stringify(summary, null, 2)}\n`);

const lines = [];
lines.push(`command: ${summary.command}`);
lines.push(`exit status: ${summary.exitStatus}`);
lines.push(
  `tools: oxlint ${summary.toolVersions.oxlint}, oxlint-tsgolint ${summary.toolVersions.oxlintTsgolint}, oxfmt ${summary.toolVersions.oxfmt}, typescript ${summary.toolVersions.typescript}`
);
lines.push(
  `baseline: ${baseline.number_of_files} files, ${baseline.diagnostics.length} diagnostics, ${summary.baseline.tsErrors} TS errors, ${summary.baseline.resolutionErrors} resolution errors`
);
lines.push(
  `resolved: ${after.number_of_files} files, ${after.diagnostics.length} diagnostics, ${tsErrors.length} TS errors, ${resolutionErrors.length} resolution errors, ${realTypeErrors.length} real type errors`
);
lines.push(`real type errors: ${JSON.stringify(summary.resolved.realTypeErrorCodes)}`);
for (const f of summary.resolved.realTypeErrorFiles) {
  const n = realTypeErrors.filter((d) => d.filename === f).length;
  lines.push(`  ${n}\t${f}`);
}
for (const [name, data] of Object.entries(adapters)) {
  lines.push(
    `${name}: ${data.total} diagnostics, ${data.typeAwareRuleDiagnostics} type-aware rule diagnostics, ${data.tsErrors} TS errors, ${data.files} files`
  );
}
writeFileSync(`${S}/summary.txt`, `${lines.join("\n")}\n`);
console.log(lines.join("\n"));
