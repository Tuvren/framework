from measure import *
import tarfile,io,shutil,re
B=json.loads((O/'baseline.json').read_text())
original=json.loads((R/'.constitution/evidence/KRT-BQ002/suppressions.json').read_text())
pre=json.loads((O/'pre-ledger.json').read_text())
def report(name): return json.loads((O/(name+'.json')).read_text())
def diagnostic(name): return json.loads(report(name)['stdout'])
config=diagnostic('oxlint-effective-config');shipped=diagnostic('shipped-effective-config');registry=diagnostic('oxlint-rules')
policy_keys=sorted((config.keys()|shipped.keys())-{'ignorePatterns'})
assert all(config.get(k)==shipped.get(k) for k in policy_keys)
assert config['ignorePatterns']==shipped['ignorePatterns']+['.constitution/**']
assert config['rules']['oxc/no-barrel-file']=='deny'
def severity(value): return (value[0] if isinstance(value,list) else value)
def key(rule): return ('' if rule['scope']=='eslint' else rule['scope']+'/')+rule['value']
effective_rule_maps=[config['rules']]+[o.get('rules',{}) for o in config.get('overrides',[])]
enabled=[r for r in registry if any(severity(rules.get(key(r),'allow')) not in ('allow','off',0) for rules in effective_rule_maps)]
ta=[r for r in enabled if r['type_aware']];nt=[r for r in enabled if not r['type_aware']]
for root in ROOTS:
 for flavor,count in [('type-aware',len(enabled)),('syntactic',len(nt))]:
  name='post-native-'+root.split('/')[-1]+'-'+flavor;raw=report(name);d=diagnostic(name)
  assert raw['exit_code']==0 and raw['stderr']=='' and d['diagnostics']==[]
  assert d['number_of_rules']==count,(name,d['number_of_rules'],count)
save('effective-rule-proof.json',{'status':'pass','allEffectivePolicyFieldsEqual':policy_keys,'enabledRuleUnionDerivation':'Union of root and as-shipped override rules. The shipped Astro import/no-commonjs override adds the one non-type-aware enabled rule beyond the root registry mapping; all rule/options/env/globals/plugins/settings/categories/overrides remain identical.','registeredRules':len(registry),'enabledRules':len(enabled),'enabledTypeAwareRules':len(ta),'enabledNonTypeAwareRules':len(nt),'enabledTypeAwareRegistryRecords':ta,'enabledNativeCandidate':{'rule':'oxc/no-barrel-file','severity':config['rules']['oxc/no-barrel-file']},'backendProof':{'typeAwareActualReportRuleCountsEqualRegisteredEnabledRules':True,'syntacticActualReportRuleCountsEqualNonTypeAwareRules':True,'zeroDiagnostics':True,'emptyNativeStderr':True,'noReportedBackendSkipOrResolutionError':True,'reports':['post-native-'+a+'-'+f+'.json' for a in ['protocol','runtime'] for f in ['syntactic','type-aware']]},'countsAreMeasuredNotQuota':True,'onlyEffectiveDifference':'.constitution/** ignore addition','completeInstalledVersionEvidence':{'ultracite':json.loads((R/'node_modules/ultracite/package.json').read_text())['version'],'retained_ultracite':json.loads((R/'node_modules/ultracite-biome/package.json').read_text())['version'],'oxlint_tsgolint':json.loads((R/'node_modules/oxlint-tsgolint/package.json').read_text())['version']}})
entries=[]
for old,current in zip(original['entries'],pre['entries']):
 assert old['identity']==current['identity'] and old['original_reason']==current['original_reason']
 area=old['path'].split('/')[2]
 native={'syntactic':'post-native-'+area+'-syntactic.json','type_aware':'post-native-'+area+'-type-aware.json','candidate':'oxc/no-barrel-file','enabled':True,'severity':'deny','equivalent_firing_diagnostics':[],'registry':'oxlint-rules.json','effective_config':'oxlint-effective-config.json'}
 e={**current,'original_measurement':{'ledger':'.constitution/evidence/KRT-BQ002/suppressions.json','probe':'.constitution/evidence/KRT-BQ002/probe.ts','measurement_commit':original['measurement_commit']},'measurement_commit':HEAD,'currently_retained':False,'original_reason_preserved':True,'current_native_proof':native,'native_proof':native,'producing_commit':HEAD,'retained_proof':current.get('current_pre_admission_retained_proof',current.get('early_deletion'))}
 if current['currently_retained']:
  e['retained_checker_disposition']='needed-under-retained-Biome-immediately-before-atomic-admission'
  e['native_admission_disposition']='removed-at-atomic-native-admission-no-firing-native-counterpart'
  e['native_admission_reason']='Enabled shipped oxc/no-barrel-file produces no diagnostic in fresh syntactic and full type-aware checks; no native suppression is justified.'
 else:
  e['early_deletion']['commit']=subprocess.check_output(['git','rev-parse','a400c05'],cwd=R,text=True).strip()
 entries.append(e)
ledger={'schema_version':1,'ticket':'KRT-BQ004','milestone':'M15R','baseline_commit':original['baseline_commit'],'measurement_commit':HEAD,'owned_paths':ROOTS,'identity_convention':original['identity_convention'],'historical_probe_attribution':pre['fresh_probe_attribution'],'original_ledger_sha256':sha((R/'.constitution/evidence/KRT-BQ002/suppressions.json').read_bytes()),'entries':entries}
def ledger_invariants(candidate):
 assert sorted(e['identity'] for e in candidate['entries'])==sorted(e['identity'] for e in original['entries']),'full identity set'
 for e in candidate['entries']:
  baseline=next(x for x in original['entries'] if x['identity']==e['identity'])
  assert e['original_reason']==baseline['original_reason'],'original reason'
  assert e['directive']==baseline['directive'],'original directive'
ledger_invariants(ledger)
for case in ['missing','reason']:
 bad=json.loads(json.dumps(ledger))
 if case=='missing':bad['entries'].pop()
 else:bad['entries'][0]['original_reason']='negative control'
 try:ledger_invariants(bad)
 except AssertionError:pass
 else:raise AssertionError('negative control not rejected')
save('suppressions.json',ledger)
all_changed=subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines()
external_allowed=['tools/scripts/biome-lint.test.ts','tools/scripts/lib/biome-lint-partition.test.ts','.constitution/tasks/epics/EPIC-BQ-kernel-lint-pilot.yaml']
external_observed=[p for p in all_changed if p in external_allowed]
changed=[p for p in all_changed if p not in external_allowed]
expected=[e['path'] for e in pre['entries'] if e['currently_retained']]+[r+'/project.json' for r in ROOTS]+['tools/biome-coverage/bq.json']
assert sorted(changed)==sorted(expected),(changed,expected)
assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True)
assert all(sha((R/f).read_bytes())==h for f,h in B['all_files'].items() if f not in all_changed)
save('external-repair-attribution.json',{'observedPaths':external_observed,'owner':'Root lead and bounded Luna fixer in this same team, explicitly confirmed in parent messages. Worker did not edit these paths; this is not external-session work.','scope':'Root recorded and validated scope deviation under newest autonomous-work instruction. This does not claim separate explicit filepath approval. Root reports both repairs complete: partition3tests/83assertions and routing22tests pass, with touched Biome/diff checks; root independently reruns all15suites and release ladder.','originalToolingFailure':'tooling-acceptance.json:139pass/2fail remains immutable.','workerOwnedPaths':changed})
for path in B['owned_files']:
 assert 'biome-ignore' not in (R/path).read_text()
for e in pre['entries']:
 if e['currently_retained']:
  before=subprocess.check_output(['git','show',HEAD+':'+e['path']],cwd=R,text=True)
  expected_source=before.replace(e['directive']+'\n','')
  # Oxfmt removes the single empty line that becomes redundant at a file-wide directive.
  expected_source=expected_source.replace(' */\n\n\n',' */\n\n')
  assert (R/e['path']).read_text()==expected_source,'only directive deletion and formatter whitespace allowed'
targets={}
nx=json.loads((R/'nx.json').read_text())
for root in ROOTS:
 path=root+'/project.json';after=json.loads((R/path).read_text());before=json.loads(subprocess.check_output(['git','show',HEAD+':'+path],cwd=R))
 target=after['targets']['lint'];assert target=={'executor':'nx:run-commands','options':{'cwd':'.','commands':['bunx --bun oxlint --type-aware '+root,'bun tools/scripts/json-check.ts '+root]}}
 assert 'inputs' not in target and 'inputs' not in before['targets']['lint']
 before['targets']['lint']=target;assert before==after
 targets[root]={'target':target,'inputs_inherited':nx['targetDefaults']['lint']['inputs'],'no_explicit_inputs':True}
assert json.loads((R/'tools/biome-coverage/bq.json').read_text())==[]
assert all(sha((R/f).read_bytes())==h for f,h in B['other_coverage'].items())
assert all(sha((R/f).read_bytes())==h for f,h in B['constitutional_files'].items() if f not in external_observed)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
selection=json.loads((O/'selection-ownership-proof.json').read_text())
assert selection['completePartition']['missing']==[] and selection['completePartition']['duplicates']==[]
source_hashes={f:{'before':B['all_files'][f],'after':sha((R/f).read_bytes())} for f in B['owned_files']}
save('source-hashes.json',{'baselineHEAD':HEAD,'allOwnedSources':source_hashes,'changedFiles':changed})
save('admission-invariant-result.json',{'status':'pass','baselineHEAD':HEAD,'canonicalTargetsAndInheritedInputs':targets,'originalIdentitiesAndReasons':len(entries),'earlyDeletion':1,'freshNeededDirectivesRemoved':5,'zeroAdmittedLegacyDirectives':True,'noNativeSuppressions':True,'atomicUncommittedMilestoneChangedPaths':changed,'externallyAuthoredSharedRepairsObserved':external_observed,'allOtherCoverageByteIdentical':True,'allConstitutionByteIdenticalExceptObservedLeadOwnedBookkeeping':True,'workerConstitutionEdits':[],'onlySourceChangesDirectiveDeletionAndRequiredWhitespace':True,'completeOwnership':True,'actualSelectionCounts':selection['counts'],'negativeControls':{'missingIdentityRejected':True,'alteredReasonRejected':True,'jsonOnlyRejectedBothCodeProjects':True,'formatterIgnoresDoNotNarrowJSONIntegrity':True},'noCommitCreated':True,'sourceBaselineHEAD':HEAD,'unchangedOtherCoverageSHA256':B['other_coverage']})
gates=[json.loads(x) for x in (O/'gates.jsonl').read_text().splitlines()]
latest={g['name']:g for g in gates}
drift=[]
for name in ['format','lint','changeset','api-freeze','tooling-acceptance','conformance','diff-check','typecheck','nx-lint','scoped-typecheck-tests']:
 g=latest[name]
 if g['exit_code']!=0:drift.append({'gate':name,'exit':g['exit_code'],'report':g['report'],'reason':'Original protected suites have two pre-admission bootstrap assumptions: biome-lint.test.ts:606 expects zero switched projects; biome-lint-partition.test.ts:156 supplies empty native selections and expects no gaps. Original139pass/2fail preserved; lead owns bounded shared-test repair and final reruns.' if name=='tooling-acceptance' else 'See exact raw command report.'})
summary={'milestone':'M15R / KRT-BQ004 atomic native admission','baselineHEAD':HEAD,'status':'complete' if not drift else 'implemented-with-verification-drift','changedFiles':changed,'externallyAuthoredSharedRepairsObserved':external_observed,'native':{'zeroSyntacticAndTypeAwareDiagnosticsBothPackages':True,'selection':selection['counts'],'allEnabledAsShippedRules':len(enabled),'typeAwareRules':len(ta),'noBackendSkipsOrResolutionErrorsReported':True,'completeEffectivePolicyEquality':True},'admissionInvariants':'admission-invariant-result.json','suppressions':'suppressions.json','sourceHashes':'source-hashes.json','gates':gates,'finalGates':latest,'drift':drift,'newDependencies':[],'newPatterns':[],'newConventions':[],'newContractShapes':[],'ruleCountDerivation':'Union of enabled root and as-shipped override rule maps, including Astro override import/no-commonjs; matches actual474/419reports and55enabledtype-aware registry records. No historical quota.','evidenceConventions':'Fresh external Python capture and Bun permanent-API probe, structured command reports, baseline/per-source hashes, flat digested archive: all required by dispatch; regular-file capture avoids observed 65536-byte CLI pipe truncation. No product convention introduced.','services':'No lifecycle calls; lead-managed services reused.','changeset':'Existing direct protocol/runtime/SDK MINOR coverage retained byte-identical; no wording change necessary.','readiness':'Lead independently performs milestone review and final release ladder; worker did not claim broad workspace readiness.','noConstitutionEdits':True,'noCommit':True}
save('summary.json',summary)
# Flatten every proof file and complete before/after source bytes into a unique archive.
M=O/'proof-members';M.mkdir(exist_ok=True)
for p in O.iterdir():
 if p.is_file() and p.name not in ['proof-index.json'] and not p.name.endswith('.tar.gz'):
  shutil.copyfile(p,M/p.name)
for f in B['owned_files']:
 for phase,data in [('before',subprocess.check_output(['git','show',HEAD+':'+f],cwd=R)),('after',(R/f).read_bytes())]:
  (M/('source-'+phase+'--'+f.replace('/','__'))).write_bytes(data)
for f in ['.constitution/evidence/KRT-BQ002/suppressions.json','.constitution/evidence/KRT-BQ002/probe.ts','.constitution/evidence/KRT-BQ003/M4-source-and-export-proof.json','.constitution/evidence/KRT-BQ003/M4-biome-before.json.gz','.constitution/evidence/KRT-BQ003/M4-biome-after.json.gz']:
 shutil.copyfile(R/f,M/('historical--'+f.replace('/','__')))
for f in changed:
 if f not in B['owned_files']:
  (M/('source-before--'+f.replace('/','__'))).write_bytes(subprocess.check_output(['git','show',HEAD+':'+f],cwd=R))
  (M/('source-after--'+f.replace('/','__'))).write_bytes((R/f).read_bytes())
diff=subprocess.check_output(['git','diff','--binary',HEAD,'--',*changed],cwd=R);(M/'atomic-admission.diff').write_bytes(diff)
if external_observed:
 (M/'externally-authored-shared-repairs.diff').write_bytes(subprocess.check_output(['git','diff','--binary',HEAD,'--',*external_observed],cwd=R))
files=sorted(M.iterdir());assert len(files)==len({p.name for p in files})
archive=O/'m15r-atomic-native-admission-proof.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=p.name)
index={'baselineHEAD':HEAD,'archive':{'path':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size},'members':[{'name':p.name,'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in files],'flatUniqueMemberNames':True,'finalSourceHashes':source_hashes}
save('proof-index.json',index)
with tarfile.open(archive,'r:gz') as tar:
 assert sorted(tar.getnames())==[p.name for p in files]
 for m in index['members']:
  data=tar.extractfile(m['name']).read();assert len(data)==m['bytes'] and sha(data)==m['sha256']
print(json.dumps({'status':summary['status'],'drift':drift,'native':summary['native'],'archiveMembers':len(files),'archive':index['archive']},indent=2))
