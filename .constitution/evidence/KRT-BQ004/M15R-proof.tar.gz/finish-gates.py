from capture import fullrun as run
import measure,json,re
(measure.O/'format.json').rename(measure.O/'format-initial-double-blanks.json')
run('format-touched',['bunx','--bun','oxfmt','--write','typescript/kernel/protocol/src/lib/kernel-identity.ts','typescript/kernel/protocol/src/lib/kernel-validation-stored.ts','typescript/kernel/protocol/src/lib/kernel-validation.ts'])
for root in measure.ROOTS:
 area=root.split('/')[-1]
 for flavor,args in [('syntactic',[]),('type-aware',['--type-aware'])]:
  r=run('post-native-'+area+'-'+flavor,['bunx','--bun','oxlint',*args,'--format=json',root]);assert json.loads(r['stdout'])['diagnostics']==[];assert not r['stderr']
run('selection-api-final',['bun',str(measure.O/'api-proof.ts')])
for name,cmd in [('format',['bun','run','format:check']),('lint',['bun','run','lint']),('changeset',['bun','run','changeset:check']),('api-freeze',['bun','run','api-freeze:check'])]:run(name,cmd,None)
verify=(measure.R/'tools/scripts/verify.ts').read_text();suites=[]
for key in ['ORIGINAL_BP_TOOLING_ACCEPTANCE_TESTS','FOLLOWUP_TOOLING_ACCEPTANCE_TESTS']:
 block=re.search(r'export const '+key+r': readonly string\[\] = \[(.*?)\];',verify,re.S).group(1)
 suites+=re.findall(r'"([^"]+\.test\.ts)"',block)
assert len(suites)==15
measure.save('tooling-suite-inventory.json',{'original':suites[:9],'followup':suites[9:]})
run('tooling-acceptance',['bun','test',*suites],None)
run('conformance',['bun','run','conformance'],None)
run('diff-check',['git','diff','--check'])
