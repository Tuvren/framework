import os, sys, json, pathlib, subprocess, hashlib, datetime
R=pathlib.Path('/home/oscar/GitHub/Tuvren/framework-EPIC-BQ')
O=pathlib.Path('/home/oscar/.codex/plans/tuvren-bq-session/m15r')
ROOTS=['typescript/kernel/protocol','typescript/kernel/runtime']
HEAD='9abbb6b6d70c85672ee2fd0af0b84f2516ea3f44'
def sha(b): return hashlib.sha256(b).hexdigest()
def save(name,data): (O/name).write_text(json.dumps(data,indent=2)+'\n')
def run(name,cmd,expected=0):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p=subprocess.run(cmd,cwd=R,capture_output=True,env={**os.environ,'NO_COLOR':'1','NX_SKIP_NX_CACHE':'true'})
    data={'command':cmd,'cwd':str(R),'environment_overrides':{'NO_COLOR':'1','NX_SKIP_NX_CACHE':'true'},'started_at':start,'exit_code':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}
    save(name+'.json',data)
    with (O/'gates.jsonl').open('a') as f: f.write(json.dumps({'name':name,'command':cmd,'exit_code':p.returncode,'report':name+'.json'})+'\n')
    print(name, p.returncode,flush=True)
    assert expected is None or p.returncode==expected, (name,p.returncode,data['stderr'][-2000:],data['stdout'][-2000:])
    return data
if __name__=='__main__':
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)
    files=sorted(set(subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=R).decode().split('\0'))-{''})
    deleted=set(subprocess.check_output(['git','ls-files','--deleted','-z'],cwd=R).decode().split('\0'))
    files=[f for f in files if f not in deleted]
    before={f:sha((R/f).read_bytes()) for f in files}
    save('baseline.json',{'head':HEAD,'clean':True,'predecessor_review':'Parent dispatch identifies this exact HEAD as independently reviewed M14R; worker does not fabricate a review artifact.','all_files':before,'owned_files':[f for f in files if any(f.startswith(x+'/') for x in ROOTS)],'other_coverage':{f:h for f,h in before.items() if f.startswith('tools/biome-coverage/') and f!='tools/biome-coverage/bq.json'},'constitutional_files':{f:h for f,h in before.items() if f.startswith('.constitution/')}})
    for area,cmd in [('bun',['bun','--version']),('oxlint',['bunx','--bun','oxlint','--version']),('oxfmt',['bunx','--bun','oxfmt','--version']),('biome',['bunx','--bun','@biomejs/biome','--version']),('ts',['bunx','--bun','tsc','--version'])]: run('version-'+area,cmd)
    run('oxlint-help',['bunx','--bun','oxlint','--help'])
    run('oxfmt-help',['bunx','--bun','oxfmt','--help'])
    run('oxlint-rules',['bunx','--bun','oxlint','--rules','--format=json'])
    run('oxlint-effective-config',['bunx','--bun','oxlint','--print-config'])
    for root in ROOTS:
        area=root.split('/')[-1]
        for flavor,args in [('syntactic',[]),('type-aware',['--type-aware'])]:
            r=run('pre-native-'+area+'-'+flavor,['bunx','--bun','oxlint',*args,'--format=json',root])
            d=json.loads(r['stdout']); assert d['diagnostics']==[]
        run('pre-selection-'+area,['bunx','--bun','oxlint','--type-aware','--debug=files',root])
        run('pre-json-'+area,['bun','tools/scripts/json-check.ts',root])
        r=run('pre-biome-'+area,['bunx','--bun','@biomejs/biome','check',root,'--reporter=json','--max-diagnostics=none'])
        assert json.loads(r['stdout'])['diagnostics']==[]
    ledger=json.loads((R/'.constitution/evidence/KRT-BQ002/suppressions.json').read_text())
    entries=[]
    for index,e in enumerate(ledger['entries'],1):
        source=(R/e['path']).read_text()
        if e['directive'] not in source:
            assert e['path'].endswith('/kernel-validation-runtime.ts')
            entries.append({**e,'currently_retained':False,'early_deletion':{'commit':'a400c05','proof':'.constitution/evidence/KRT-BQ003/M4-source-and-export-proof.json'},'retained_checker_disposition':'removed-early-after-cycle-removal-and-fresh-unsuppressed-retained-check-proves-noBarrelFile-dead','native_admission_disposition':'original-already-removed-with-retained-checker-proof-no-native-suppression-introduced'})
            continue
        assert source.count(e['directive'])==1
        scratch=O/'scratch'/e['path']; scratch.parent.mkdir(parents=True,exist_ok=True)
        scratch.write_text(source)
        assert sha(scratch.read_bytes())==before[e['path']]
        cmd=['bunx','--bun','@biomejs/biome','check','--config-path='+str(R/'biome.jsonc'),'--vcs-enabled=false',str(scratch),'--reporter=json','--max-diagnostics=none']
        a=run('pre-biome-suppressed-'+str(index),cmd)
        assert json.loads(a['stdout'])['diagnostics']==[]
        unsuppressed=source.replace(e['directive'],'')
        scratch.write_text(unsuppressed)
        b=run('pre-biome-unsuppressed-'+str(index),cmd,1)
        d=json.loads(b['stdout']); assert d['summary']['unchanged']==1
        matched=[x for x in d['diagnostics'] if x['category']==e['rule']]
        assert matched and all(x['location']['path']==str(scratch) for x in matched)
        assert sha((R/e['path']).read_bytes())==before[e['path']]
        entries.append({**e,'currently_retained':True,'current_pre_admission_retained_proof':{'suppressed':'pre-biome-suppressed-'+str(index)+'.json','unsuppressed':'pre-biome-unsuppressed-'+str(index)+'.json','source_sha256':before[e['path']],'virtual_unsuppressed_sha256':sha(unsuppressed.encode()),'matching_diagnostics':len(matched),'config_path':'biome.jsonc','config_sha256':before['biome.jsonc'],'discovery_adjustment':'--vcs-enabled=false only; exact repository config unchanged','product_bytes_unchanged':True},'current_native_proof':{'syntactic':'pre-native-'+e['path'].split('/')[2]+'-syntactic.json','type_aware':'pre-native-'+e['path'].split('/')[2]+'-type-aware.json','candidate':'oxc/no-barrel-file','enabled':True,'severity':'deny','equivalent_firing_diagnostics':[]}})
    assert sum(e['currently_retained'] for e in entries)==5
    save('pre-ledger.json',{'original_ledger':'.constitution/evidence/KRT-BQ002/suppressions.json','original_probe':'.constitution/evidence/KRT-BQ002/probe.ts','fresh_probe_attribution':'measure.py is a fresh M15R measurement using the M3 mirror mechanism; historical M3 is not replayed or edited. M3 expects six present directives and native debt exit 1; M15R expects five present, one reviewed early deletion and native zero diagnostics.','measurement_head':HEAD,'entries':entries})
    save('pre-proof.json',{'status':'pass','native_clean':True,'retained_needed_directives':5,'early_deleted':1,'source_unchanged':all(sha((R/f).read_bytes())==h for f,h in before.items()),'no_edits_before_proof':not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)})
