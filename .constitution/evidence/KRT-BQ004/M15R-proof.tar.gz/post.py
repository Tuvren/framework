import pathlib,sys,os,json,tempfile,subprocess
sys.path.insert(0,'/home/oscar/.codex/plans/tuvren-bq-session/m15r')
import measure
# Native CLI large JSON output must be redirected to regular files: capture pipes
# can truncate Bun-hosted CLI stdout at 65536 bytes. Preserve that failed capture.
original=measure.run
def fullrun(name,cmd,expected=0):
 import datetime
 with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
  p=subprocess.run(cmd,cwd=measure.R,stdout=out,stderr=err,env={**os.environ,'NO_COLOR':'1','NX_SKIP_NX_CACHE':'true'})
  out.seek(0);err.seek(0)
  data={'command':cmd,'cwd':str(measure.R),'environment_overrides':{'NO_COLOR':'1','NX_SKIP_NX_CACHE':'true'},'exit_code':p.returncode,'stdout':out.read().decode(),'stderr':err.read().decode(),'capture':'regular files to preserve complete bytes'}
 measure.save(name+'.json',data)
 with (measure.O/'gates.jsonl').open('a') as f:f.write(json.dumps({'name':name,'command':cmd,'exit_code':p.returncode,'report':name+'.json'})+'\n')
 print(name,p.returncode,flush=True)
 assert expected is None or p.returncode==expected,(name,p.returncode,data['stderr'][-3000:],data['stdout'][-1000:])
 return data
measure.run=fullrun
run=fullrun
for item in ['oxlint-rules','oxlint-effective-config']:
 (measure.O/(item+'.json')).rename(measure.O/(item+'-initial-pipe-capture.json'))
run('oxlint-rules',['bunx','--bun','oxlint','--rules','--format=json'])
run('oxlint-effective-config',['bunx','--bun','oxlint','--print-config'])
for root in measure.ROOTS:
 area=root.split('/')[-1]
 for flavor,args in [('syntactic',[]),('type-aware',['--type-aware'])]:
  r=run('post-native-'+area+'-'+flavor,['bunx','--bun','oxlint',*args,'--format=json',root]);assert json.loads(r['stdout'])['diagnostics']==[];assert not r['stderr']
 run('post-selection-'+area,['bunx','--bun','oxlint','--type-aware','--debug=files',root])
 run('post-json-'+area,['bun','tools/scripts/json-check.ts',root])
run('selection-api',['bun',str(measure.O/'api-proof.ts')])
run('shipped-effective-config',['bunx','--bun','oxlint','-c',str(measure.O/'shipped-core-config.json'),'--print-config'])
run('nx-lint',['bun','run','nx','run-many','-t','lint','-p','kernel-contract-protocol,kernel-runtime','--parallel=1','--skip-nx-cache'])
run('scoped-typecheck-tests',['bun','run','nx','run-many','-t','typecheck,test','-p','kernel-contract-protocol,kernel-runtime','--parallel=1','--skip-nx-cache'])
for name,cmd in [('typecheck',['bun','run','typecheck']),('format',['bun','run','format:check']),('lint',['bun','run','lint']),('changeset',['bun','run','changeset:check']),('api-freeze',['bun','run','api-freeze:check'])]:run(name,cmd)
verify=(measure.R/'tools/scripts/verify.ts').read_text()
import re
suites=[]
for key in ['ORIGINAL_BP_TOOLING_ACCEPTANCE_TESTS','FOLLOWUP_TOOLING_ACCEPTANCE_TESTS']:
 block=re.search(r'export const '+key+r': readonly string\[\] = \[(.*?)\];',verify,re.S).group(1)
 suites+=re.findall(r'"([^"]+\.test\.ts)"',block)
assert len(suites)==15
measure.save('tooling-suite-inventory.json',{'original':suites[:9],'followup':suites[9:]})
run('tooling-acceptance',['bun','test',*suites])
run('conformance',['bun','run','conformance'])
run('diff-check',['git','diff','--check'])
