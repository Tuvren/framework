import pathlib,sys,os,json,tempfile,subprocess
sys.path.insert(0,'/home/oscar/.codex/plans/tuvren-bq-session/m15r')
import measure
# Native CLI large JSON output must be redirected to regular files: capture pipes
# can truncate Bun-hosted CLI stdout at 65536 bytes. Preserve that failed capture.
original=measure.run
def fullrun(name,cmd,expected=0):
 import datetime
 with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
  p=subprocess.run(cmd,cwd=measure.R,stdout=out,stderr=err,env={**os.environ,'NO_COLOR':'1','NX_SKIP_NX_CACHE':'true'})
  out.seek(0);err.seek(0)
  data={'command':cmd,'cwd':str(measure.R),'environment_overrides':{'NO_COLOR':'1','NX_SKIP_NX_CACHE':'true'},'exit_code':p.returncode,'stdout':out.read().decode(),'stderr':err.read().decode(),'capture':'regular files to preserve complete bytes'}
 measure.save(name+'.json',data)
 with (measure.O/'gates.jsonl').open('a') as f:f.write(json.dumps({'name':name,'command':cmd,'exit_code':p.returncode,'report':name+'.json'})+'\n')
 print(name,p.returncode,flush=True)
 assert expected is None or p.returncode==expected,(name,p.returncode,data['stderr'][-3000:],data['stdout'][-1000:])
 return data
measure.run=fullrun
