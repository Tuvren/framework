/**
 * Copyright 2026 Oscar Yáñez Cisterna (@SkrOYC)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Kernel protocol contract for Tuvren's Kraken execution engine.
 *
 * This package expresses the language-neutral kernel boundary as TypeScript
 * types and guards: the {@link RuntimeKernel} syscall surface (30 operations
 * across 10 groups, docs/KrakenKernelSpecification.md §7), the
 * {@link RuntimeBackend} storage contract with its repositories and
 * capability descriptor (§8.1, §9), live and stored record shapes, the
 * canonical identity helpers used for content addressing (deterministic CBOR
 * plus SHA-256, §2.3), and runtime validation guards (`is*` / `assert*`) for
 * every protocol shape.
 *
 * Everything crossing this boundary is data — serializable, schema-driven,
 * inspectable (§1.1). The machine authority for this surface is the kernel
 * authority packet (spec/kernel/authority-packet.json) with its CDDL,
 * conformance plans, and committed fixtures; this package is the TypeScript
 * binding projection of that packet.
 *
 * `@tuvren/kernel-protocol` is published-internal: it exists on the registry
 * so host-facing packages' dependency graphs resolve (ADR-0057), is not
 * semver-guaranteed for hosts, and should not be imported directly by
 * applications (see docs/guides/publishing-and-adopter-onboarding.md).
 *
 * @file
 */

export {
  canonicalizeKernelRecord,
  decodeDeterministicKernelRecord,
  encodeDeterministicKernelRecord,
  hashKernelRecord,
  hashOpaqueObjectBytes,
  hashTurnNodeIdentity,
  hashTurnTreeIdentity,
} from "./lib/kernel-identity.js";
export type {
  AbortVerdict,
  BackendCapability,
  BranchHeadListEntry,
  BranchRecord,
  BranchRepository,
  ComposedVerdict,
  IncorporationRule,
  InterruptedStagedResult,
  InterruptedStoredStagedResult,
  KernelSignal,
  KernelThreadListCursor,
  ListThreadsCursorPayload,
  ModifyVerdict,
  ObjectRepository,
  ObserveAnnotationRepository,
  ObserveResult,
  OrderedPathChunkRepository,
  PathCollectionKind,
  PathDefinition,
  PathValue,
  PauseVerdict,
  ProceedVerdict,
  ReclamationOptions,
  ReclamationSummary,
  RecoveryState,
  RetryVerdict,
  RunCompletionStatus,
  RunRecord,
  RunRepository,
  RunStatus,
  RuntimeBackend,
  RuntimeBackendTx,
  RuntimeKernel,
  RuntimeKernelRunLiveness,
  SchemaRepository,
  SetHeadResult,
  SettledStagedResult,
  SettledStoredStagedResult,
  StagedResult,
  StagedResultRepository,
  StagedResultStatus,
  StepContext,
  StepDeclaration,
  StoredBranch,
  StoredChunkedOrderedTurnTreePath,
  StoredFlatOrderedTurnTreePath,
  StoredObject,
  StoredObserveAnnotation,
  StoredOrderedPathChunk,
  StoredRun,
  StoredSchema,
  StoredSingleTurnTreePath,
  StoredStagedResult,
  StoredThread,
  StoredTurn,
  StoredTurnNode,
  StoredTurnTree,
  StoredTurnTreePath,
  ThreadCreateResult,
  ThreadRecord,
  ThreadRepository,
  TurnNode,
  TurnNodeRepository,
  TurnRecord,
  TurnRepository,
  TurnTreeChangeSet,
  TurnTreeManifest,
  TurnTreePathRepository,
  TurnTreeRepository,
  TurnTreeSchema,
  Verdict,
  VerdictDisposition,
} from "./lib/kernel-types.js";
export {
  assertBranchHeadListEntry,
  assertBranchRecord,
  assertComposedVerdict,
  assertObserveResult,
  assertPathCollectionKind,
  assertPathValue,
  assertPathValueForCollectionKind,
  assertRecoveryState,
  assertRunCompletionStatus,
  assertRunRecord,
  assertRunStatus,
  assertSetHeadResult,
  assertStagedResult,
  assertStagedResultStatus,
  assertStepContext,
  assertStepDeclaration,
  assertStoredBranch,
  assertStoredObject,
  assertStoredObjectIdentity,
  assertStoredObserveAnnotation,
  assertStoredOrderedPathChunk,
  assertStoredOrderedPathChunkIdentity,
  assertStoredRun,
  assertStoredSchema,
  assertStoredStagedResult,
  assertStoredThread,
  assertStoredTurn,
  assertStoredTurnNode,
  assertStoredTurnNodeIdentity,
  assertStoredTurnTree,
  assertStoredTurnTreeIdentity,
  assertStoredTurnTreePath,
  assertThreadCreateResult,
  assertThreadRecord,
  assertTurnNode,
  assertTurnNodeIdentity,
  assertTurnRecord,
  assertTurnTreeChangeSet,
  assertTurnTreeManifest,
  assertTurnTreeSchema,
  assertVerdict,
  assertVerdictDisposition,
  isBranchHeadListEntry,
  isBranchRecord,
  isComposedVerdict,
  isObserveResult,
  isPathCollectionKind,
  isPathValue,
  isRecoveryState,
  isRunCompletionStatus,
  isRunRecord,
  isRunStatus,
  isSetHeadResult,
  isStagedResult,
  isStagedResultStatus,
  isStepContext,
  isStepDeclaration,
  isStoredBranch,
  isStoredObject,
  isStoredObserveAnnotation,
  isStoredOrderedPathChunk,
  isStoredRun,
  isStoredSchema,
  isStoredStagedResult,
  isStoredThread,
  isStoredTurn,
  isStoredTurnNode,
  isStoredTurnTree,
  isStoredTurnTreePath,
  isThreadCreateResult,
  isThreadRecord,
  isTurnNode,
  isTurnRecord,
  isTurnTreeSchema,
  isVerdict,
  isVerdictDisposition,
} from "./lib/kernel-validation.js";
