# M15R partition-test repair

Baseline HEAD: 9abbb6b6d70c85672ee2fd0af0b84f2516ea3f44

The first partition test supplied empty native selections, which ceased to represent current Nx metadata after valid native lint admission. It now discovers actual native project metadata; Oxlint code selection uses `collectOxlintSelectedFiles`, and scoped JSON selection uses `selectJsonInventory` across both mixed Oxlint-plus-JSON projects and JSON-only projects. No project discovery means the per-project loop is empty and both selections remain empty, so this helper never turns an empty selection into whole-repository JSON discovery. The coverage resolution still asserts exact equality against measured native selections and retains complete/disjoint partition checks.

Changed path: `tools/scripts/lib/biome-lint-partition.test.ts` only for this worker.

Verification command:
`direnv exec /home/oscar/GitHub/Tuvren/framework zsh -c 'cd /home/oscar/GitHub/Tuvren/framework-EPIC-BQ && bun test tools/scripts/lib/biome-lint-partition.test.ts && bunx biome check tools/scripts/lib/biome-lint-partition.test.ts'`

See `verification.log` and `verification.exit` for command output and exit status. `patch.diff`, `original.ts`, `after.ts`, `baseline-head.txt`, and `sha256.txt` preserve the exact change and file evidence.
