# M13R approved scope repairs

Repository: `/home/oscar/GitHub/Tuvren/framework-EPIC-BQ`
HEAD baseline: `f9d5c8651b6b54adaaeb7dc8ca4a264f2dcfccd6`

The before-working-tree copies preserve the exact pre-repair bytes (including the already modified M13R changeset); before-commit copies are `git show HEAD:<path>`. Hashes are in `hashes.sha256`. `diff-from-working-tree.patch` isolates this repair from the worker's pre-existing edits. `diff-from-head.patch` records the resulting exact 3-path working diff against HEAD.

## Changes

- Regenerated `tools/scripts/__snapshots__/api-surface/api-surface-snapshot.json` with `bun run api-freeze --major`. Generator verification found only `@tuvren/sdk#RuntimeBackend`, `@tuvren/sdk#RuntimeKernel`, and `@tuvren/sdk#RuntimeKernelRunLiveness` changed; all three prior ledger entries remain byte-for-byte equal in parsed form, and one `major` freeze ledger entry was appended. This legacy freeze classification records breaking stable-signature drift. Under ADR-0069, actual 0.x release coverage is MINOR.
- Updated the two stale code inventory expectations from 39 to 40 in `tools/scripts/lib/biome-lint-partition.test.ts`. The complete-partition assertions, 14 JSON checks, and negative controls are unchanged.
- Added direct `@tuvren/sdk: minor` coverage and the approved API explanation to `.changeset/toolchain-bq-kernel-lint-pilot.md`. Existing M13R classifications remain `@tuvren/kernel-protocol: minor` and `@tuvren/kernel-runtime: patch`.

Direct release classes: `@tuvren/kernel-protocol` MINOR, `@tuvren/kernel-runtime` PATCH, `@tuvren/sdk` MINOR.

## Verification

- `bun run api-freeze --major`: passed; snapshot refreshed with the three expected records.
- `bun run api-freeze:check`: passed; frozen surface unchanged (14 entrypoints, 404 exports).
- `bun test tools/scripts/lib/biome-lint-partition.test.ts`: passed, 3 tests / 81 assertions.
- Exact registered 15-file tooling acceptance command from `tools/scripts/verify.ts`: passed, 141 tests / 1569 assertions across all 15 files. Output is in `logs/tooling-acceptance-exact.log`.
- `bun run changeset:check`: passed; direct changeset coverage for 2 publishable packages.
- `bun run lint`: passed; all Biome batches, Oxfmt check, and Kraken surface gate clean.
- `bun run format:check`: passed across 1297 files.
- `git diff --check`: passed.

Commands were run through `direnv exec .`. No dependencies, tooling, freeze policy, source, authority, constitution, or service state were changed by this repair. No blocker or new dependency was found.
