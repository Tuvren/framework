# M14R partition-count alignment

Changed only `tools/scripts/lib/biome-lint-partition.test.ts`: both real Oxlint corpus expectations now use 42, matching the current protocol (23) plus runtime (19) selected files after the two async runtime files were added. All other assertions remain byte-for-byte unchanged, including full partition checks, 14 JSON checks, and the standalone-Oxlint negative control.

- Baseline HEAD: `2d123e7612c27a0cf6af05fc20c526e86b5753d7`
- Baseline file SHA-256: `011d5ee63e5038d7f6588e3a71c8d3bef060a8312b49b84a042a9e944e1f83db`
- Working-tree file SHA-256: `a5dad047950914b2b930d3d835618ed33ff04eca5f036c6c3ff626f4b051934e`
- Patch: `change.patch`
- Validation: focused Bun test passed (3 tests, 83 expectations); `git diff --check` passed.
- New dependencies, patterns, or API effects: none.
