#!/usr/bin/env zsh
set -uo pipefail
bq_proof=/home/oscar/.codex/plans/tuvren-bq-session/m14r
: > "$bq_proof/gates.tsv"
run_gate() {
  local bq_name="$1"
  shift
  "$@" >"$bq_proof/$bq_name.log" 2>&1
  local bq_exit=$?
  print -r -- "$bq_name\t$bq_exit\t${(j: :)${(q)@}}" >> "$bq_proof/gates.tsv"
  print -r -- "$bq_name: exit $bq_exit"
  if (( bq_exit != 0 )); then tail -50 "$bq_proof/$bq_name.log"; fi
}
run_gate scoped bun run nx run-many -t typecheck,test -p kernel-contract-protocol,kernel-runtime --parallel=1
run_gate focused bun test typescript/kernel/runtime/test/runtime-kernel-async.test.ts
run_gate typecheck bun run typecheck
run_gate native-syntactic bunx --bun oxlint typescript/kernel/runtime
run_gate native-type-aware bunx --bun oxlint --type-aware typescript/kernel/runtime
run_gate native-selection bunx --bun oxlint --debug=files typescript/kernel/runtime
run_gate native-selection-all bunx --bun oxlint --debug=files typescript/kernel/protocol typescript/kernel/runtime
run_gate native-json bun tools/scripts/json-check.ts typescript/kernel/runtime
run_gate retained-biome bunx --bun @biomejs/biome check typescript/kernel/runtime
run_gate format bun run format:check
run_gate lint bun run lint
run_gate changeset bun run changeset:check
run_gate api-freeze bun run api-freeze
run_gate build bun run nx run-many -t build -p kernel-contract-protocol,kernel-runtime --parallel=1
run_gate conformance bun run conformance
run_gate constitution bun run /home/oscar/.codex/skills/constitution-tooling/scripts/cli.ts validate --root .
