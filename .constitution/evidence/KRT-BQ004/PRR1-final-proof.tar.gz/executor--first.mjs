import {appendFileSync} from "node:fs";
const file=process.argv[2];
appendFileSync(file,JSON.stringify("first:start")+"\n");
await Bun.sleep(350);
if(process.argv[3]==="fail"){appendFileSync(file,JSON.stringify("first:fail")+"\n");process.exit(9);}
appendFileSync(file,JSON.stringify("first:end")+"\n");
