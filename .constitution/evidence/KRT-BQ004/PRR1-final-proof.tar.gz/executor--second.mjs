import {appendFileSync} from "node:fs";
const file=process.argv[2];
appendFileSync(file,JSON.stringify("second:start")+"\n");
appendFileSync(file,JSON.stringify("second:end")+"\n");
