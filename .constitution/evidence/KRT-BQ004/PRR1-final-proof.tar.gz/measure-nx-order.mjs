import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import path from 'node:path';
const repo='/home/oscar/GitHub/Tuvren/framework-EPIC-BQ';
const dest='/home/oscar/.codex/plans/tuvren-bq-session/pr-r1-executor-probe';
mkdirSync(dest,{recursive:true});
const schemaPath=repo+'/node_modules/nx/dist/src/executors/run-commands/schema.json';
const implPath=repo+'/node_modules/nx/dist/src/executors/run-commands/run-commands.impl.js';
const schema=JSON.parse(readFileSync(schemaPath,'utf8'));
const version=JSON.parse(readFileSync(repo+'/node_modules/nx/package.json','utf8')).version;
assert.equal(version,'22.7.12');
assert.equal(schema.properties.parallel.default,true);
const imported=await import(implPath);
const executor=typeof imported.default==='function'?imported.default:imported.default?.default;
assert.equal(typeof executor,'function');
const first=dest+'/first.mjs';
const second=dest+'/second.mjs';
writeFileSync(first,'import {appendFileSync} from "node:fs";\nconst file=process.argv[2];\nappendFileSync(file,JSON.stringify("first:start")+"\\n");\nawait Bun.sleep(350);\nif(process.argv[3]==="fail"){appendFileSync(file,JSON.stringify("first:fail")+"\\n");process.exit(9);}\nappendFileSync(file,JSON.stringify("first:end")+"\\n");\n');
writeFileSync(second,'import {appendFileSync} from "node:fs";\nconst file=process.argv[2];\nappendFileSync(file,JSON.stringify("second:start")+"\\n");\nappendFileSync(file,JSON.stringify("second:end")+"\\n");\n');
const quote=value=>"'"+value.replaceAll("'","'\\''")+"'";
const cases=[];
for(const [name,parallel,fail] of [['schema-default',true,false],['explicit-serial',false,false],['serial-first-fails',false,true]]){
  const caseDir=path.join(dest,name);mkdirSync(caseDir,{recursive:true});
  const eventsPath=caseDir+'/events.jsonl';writeFileSync(eventsPath,'');
  const options={commands:[`bun ${quote(first)} ${quote(eventsPath)}${fail?' fail':''}`,`bun ${quote(second)} ${quote(eventsPath)}`],cwd:caseDir,parallel,__unparsed__:[],usePty:false,streamOutput:false};
  const result=await executor(options,{root:repo,cwd:repo,isVerbose:false});
  const events=readFileSync(eventsPath,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse);
  if(name==='schema-default'){
    assert.equal(result.success,true);
    assert(events.indexOf('second:start')<events.indexOf('first:end'),'schema default should demonstrate overlap');
  }else if(name==='explicit-serial'){
    assert.equal(result.success,true);assert.deepEqual(events,['first:start','first:end','second:start','second:end']);
  }else{
    assert.equal(result.success,false);assert.deepEqual(events,['first:start','first:fail']);
  }
  const report={name,parallel,firstFails:fail,result,events};
  writeFileSync(caseDir+'/result.json',JSON.stringify(report,null,2)+'\n');cases.push(report);
}
const sha=b=>createHash('sha256').update(b).digest('hex');
writeFileSync(dest+'/summary.json',JSON.stringify({version,officialDocs:'https://nx.dev/docs/reference/nx/executors#chaining-commands',schemaDefaultParallel:true,baselineNote:'Direct executor calls explicitly apply the installed CLI schema default for the unsafe control; project omission receives true through Nx CLI normalization.',schemaSha256:sha(readFileSync(schemaPath)),executorSha256:sha(readFileSync(implPath)),cases,conclusion:'Explicit false serializes the command pair and prevents the JSON command from starting when Oxlint-equivalent first command fails.'},null,2)+'\n');
console.log('Nx22.7.12 isolated executor proof: default overlap, explicit serial order and first-failure short-circuit all verified.');
