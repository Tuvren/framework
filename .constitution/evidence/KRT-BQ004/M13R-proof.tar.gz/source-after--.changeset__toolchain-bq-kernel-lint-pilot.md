---
"@tuvren/kernel-protocol": minor
"@tuvren/kernel-runtime": patch
---

Apply lint cleanup to the kernel protocol and runtime. Protocol repository and syscall callables use property signatures, which reject implementations with narrower input parameters under strict function checking. Protocol `hashKernelRecord` and `hashTurnTreeIdentity` report invalid inputs through Promise rejection instead of synchronous throws; validation codes, messages, order, and canonical identities are preserved.
