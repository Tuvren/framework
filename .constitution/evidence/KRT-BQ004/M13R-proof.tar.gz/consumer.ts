import type { ObjectRepository, StoredObject } from "/home/oscar/GitHub/Tuvren/framework-EPIC-BQ/typescript/kernel/protocol/src/index.js";
declare const fullPut: (record: StoredObject) => Promise<void>;
declare const narrowedPut: (record: StoredObject & { requiredMarker: string }) => Promise<void>;
export const accepted: ObjectRepository["put"] = fullPut;
export const rejected: ObjectRepository["put"] = narrowedPut;
