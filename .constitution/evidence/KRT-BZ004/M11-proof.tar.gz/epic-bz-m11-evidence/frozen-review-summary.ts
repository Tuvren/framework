import {readFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import ts from '/home/oscar/GitHub/Tuvren/framework/.codex/worktrees/EPIC-BZ/node_modules/typescript/lib/typescript.js';
const r=JSON.parse(readFileSync('/tmp/bz-m10-independent-review.json','utf8'));
for(const f of r.files) console.log(JSON.stringify({file:f.name,exportOrAsyncDifferences:f.exportOrAsyncDifferences,classes:f.classes,eagerInitializers:f.eagerInitializers,hazards:f.after.flatMap(x=>x.hazards)}));
for(const s of r.stages) console.log(JSON.stringify({stage:s.name,classes:s.classes,eagerInitializers:s.eagerInitializers}));
for(const [name,lo,hi]of [['bridge',561,1150],['bridge',304,553],['utils',536,988],['utils',100,530]])console.log(JSON.stringify({cohort:name+' '+lo+'-'+hi,definitions:r.files.find(f=>f.name===name).before.filter(f=>f.range[0]>=lo&&f.range[1]<=hi).map(f=>({name:f.name,range:f.range}))}));
const root='/home/oscar/GitHub/Tuvren/framework/.codex/worktrees/EPIC-BZ/'; const rel='typescript/providers/bridge-ai-sdk/src/lib/';
for(const dir of ['bz-m10-candidates','bz-m10-resolved']){let total=0;for(const f of r.files){const base=f.name==='bridge'?'ai-sdk-provider-bridge.ts':`ai-sdk-provider-bridge-${f.name}.ts`;let s;try{s=execFileSync('git',['diff','--no-index','--numstat',root+rel+base,'/tmp/'+dir+'/'+rel+base],{encoding:'utf8'});}catch(e){if(e.status!==1)throw e;s=e.stdout;}const [a,b]=s.trim().split(/\s+/).map(Number);total+=a+b;}console.log(JSON.stringify({directory:dir,actualChangedLines:total}));}
const original=ts.createSourceFile('before.ts',readFileSync(root+rel+'ai-sdk-provider-bridge-utils.ts','utf8'),ts.ScriptTarget.Latest,true); const after=ts.createSourceFile('after.ts',readFileSync('/tmp/bz-m10-resolved/'+rel+'ai-sdk-provider-bridge-utils.ts','utf8'),ts.ScriptTarget.Latest,true);
const oldPublic=original.statements.find(s=>ts.isFunctionDeclaration(s)&&s.name?.text==='cloneJsonObject'); const oldPrivate=original.statements.find(s=>ts.isFunctionDeclaration(s)&&s.name?.text==='cloneJsonValue');
const newPrivate=after.statements.find(s=>ts.isVariableStatement(s)&&s.declarationList.declarations[0].name.getText(after)==='cloneJsonValue').declarationList.declarations[0].initializer;
const p=ts.createPrinter({removeComments:true}); const emit=(n,sf)=>p.printNode(ts.EmitHint.Unspecified,n,sf).replace(/\s+/g,' ');
console.log(JSON.stringify({privateObjectBranchEqualsOldPublicBody:emit(ts.factory.createBlock(newPrivate.body.statements.slice(2)),after)===emit(oldPublic.body,original),privatePrimitiveAndArrayBranchesUnchanged:oldPrivate.body.statements.slice(0,2).every((n,i)=>emit(n,original)===emit(newPrivate.body.statements[i],after))}));
