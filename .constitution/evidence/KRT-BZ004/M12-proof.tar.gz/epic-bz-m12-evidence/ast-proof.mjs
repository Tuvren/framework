import assert from "node:assert/strict";
import fs from "node:fs";
import ts from "/home/oscar/GitHub/Tuvren/framework/.codex/worktrees/EPIC-BZ/node_modules/typescript/lib/typescript.js";

const root = "/home/oscar/GitHub/Tuvren/framework/.codex/worktrees/EPIC-BZ";
const beforePath = "/tmp/bz-m10-stages/bridge-stage2/ai-sdk-provider-bridge.ts";
const candidatePath =
  "/tmp/bz-m10-resolved/typescript/providers/bridge-ai-sdk/src/lib/ai-sdk-provider-bridge.ts";
const afterPath = `${root}/typescript/providers/bridge-ai-sdk/src/lib/ai-sdk-provider-bridge.ts`;
const names = [
  "createAiSdkProviderBridge",
  "createAiSdkProviderBridgeFromProvider",
  "loadStreamResult",
  "assertProviderMediatedToolsSupported",
  "createCallOptions",
];
const nameSet = new Set(names);
const beforeText = fs.readFileSync(beforePath, "utf8");
const candidateText = fs.readFileSync(candidatePath, "utf8");
const afterText = fs.readFileSync(afterPath, "utf8");
assert.equal(afterText, candidateText, "lane must equal frozen resolved candidate");

const parse = (text) =>
  ts.createSourceFile("bridge.ts", text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
const before = parse(beforeText);
const after = parse(afterText);
assert.equal(before.parseDiagnostics.length, 0);
assert.equal(after.parseDiagnostics.length, 0);
const printer = ts.createPrinter({ removeComments: false });
const print = (node) =>
  printer.printNode(ts.EmitHint.Unspecified, node, node.getSourceFile());
const declarations = new Map(
  before.statements
    .filter((statement) => ts.isFunctionDeclaration(statement))
    .map((statement) => [statement.name.text, statement])
);
const converted = [];
const hazards = [];

for (const name of names) {
  const original = declarations.get(name);
  assert(original, `missing original declaration ${name}`);
  const statement = after.statements.find(
    (entry) =>
      ts.isVariableStatement(entry) &&
      entry.declarationList.declarations.length === 1 &&
      entry.declarationList.declarations[0].name.getText(after) === name
  );
  assert(statement, `missing converted binding ${name}`);
  assert.equal(statement.declarationList.flags, ts.NodeFlags.Const, `${name} const`);
  const arrow = statement.declarationList.declarations[0].initializer;
  assert(ts.isArrowFunction(arrow), `${name} arrow`);
  const signature = (node) => ({
    parameters: node.parameters.map(print),
    typeParameters: (node.typeParameters ?? []).map(print),
    returnType: node.type === undefined ? undefined : print(node.type),
  });
  assert.deepEqual(signature(arrow), signature(original), `${name} signature`);
  const originalBody = original.body;
  assert(originalBody, `${name} body`);
  if (
    ts.isBlock(originalBody) &&
    originalBody.statements.length === 1 &&
    ts.isReturnStatement(originalBody.statements[0]) &&
    originalBody.statements[0].expression !== undefined &&
    !ts.isBlock(arrow.body)
  ) {
    assert.equal(
      print(originalBody.statements[0].expression),
      print(arrow.body),
      `${name} concise body`
    );
  } else {
    assert.equal(print(originalBody), print(arrow.body), `${name} body`);
  }
  assert.deepEqual(
    (original.jsDoc ?? []).map((doc) => doc.getText(before)),
    (statement.jsDoc ?? []).map((doc) => doc.getText(after)),
    `${name} docs`
  );
  const originalExported = original.modifiers?.some(
    (modifier) => modifier.kind === ts.SyntaxKind.ExportKeyword
  ) ?? false;
  const convertedExported = statement.modifiers?.some(
    (modifier) => modifier.kind === ts.SyntaxKind.ExportKeyword
  ) ?? false;
  assert.equal(convertedExported, originalExported, `${name} export`);
  const originalAsync = original.modifiers?.some(
    (modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword
  ) ?? false;
  const convertedAsync = arrow.modifiers?.some(
    (modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword
  ) ?? false;
  assert.equal(convertedAsync, originalAsync, `${name} async`);
  const visit = (node) => {
    if (
      node.kind === ts.SyntaxKind.ThisKeyword ||
      node.kind === ts.SyntaxKind.SuperKeyword ||
      (ts.isIdentifier(node) && node.text === "arguments") ||
      ts.isMetaProperty(node)
    ) {
      hazards.push({ name, syntax: node.getText(before) });
    }
    ts.forEachChild(node, visit);
  };
  visit(originalBody);
  converted.push(name);
}
assert.equal(hazards.length, 0, "lexical hazards");
assert.deepEqual(
  after.statements
    .filter((statement) => ts.isFunctionDeclaration(statement))
    .map((statement) => statement.name.text),
  [],
  "remaining function declarations"
);
const withoutTarget = (sourceFile) =>
  sourceFile.statements
    .filter((statement) => {
      if (ts.isFunctionDeclaration(statement)) {
        return !nameSet.has(statement.name.text);
      }
      if (ts.isVariableStatement(statement)) {
        return !statement.declarationList.declarations.some((declaration) =>
          nameSet.has(declaration.name.getText(sourceFile))
        );
      }
      return true;
    })
    .map(print)
    .sort();
assert.deepEqual(withoutTarget(after), withoutTarget(before), "non-target AST multiset");

console.log(
  JSON.stringify(
    {
      candidateByteEqual: true,
      converted,
      signaturesEqual: true,
      bodiesEquivalent: true,
      docsEqual: true,
      exportAndAsyncEqual: true,
      lexicalHazards: hazards,
      nonTargetAstMultisetEqual: true,
      remainingFunctionDeclarations: [],
    },
    null,
    2
  )
);
