import assert from "node:assert/strict";
import fs from "node:fs";

const beforeDir = "/tmp/bz-m11-review/epic-bz-m11-evidence";
const afterDir = "/tmp/epic-bz-m12-evidence";
const file = "typescript/providers/bridge-ai-sdk/src/lib/ai-sdk-provider-bridge.ts";
const targetRules = new Set([
  "eslint(func-style)",
  "eslint(no-use-before-define)",
]);
const result = {};
const read = (path) => JSON.parse(fs.readFileSync(path, "utf8")).diagnostics;
const stable = (diagnostic) => {
  const copy = { ...diagnostic };
  delete copy.labels;
  delete copy.location;
  if (copy.code === "eslint(complexity)") {
    delete copy.message;
  }
  return JSON.stringify(copy);
};

for (const mode of ["", "type-aware-"]) {
  const before = read(`${beforeDir}/oxlint-${mode}after.json`);
  const after = read(`${afterDir}/oxlint-${mode}after.json`);
  const own = (diagnostic) => diagnostic.filename === file;
  const target = (diagnostic) => targetRules.has(diagnostic.code);
  const beforeTarget = before.filter((diagnostic) => own(diagnostic) && target(diagnostic));
  const afterTarget = after.filter((diagnostic) => own(diagnostic) && target(diagnostic));
  assert.equal(beforeTarget.length, 8, `${mode} before target`);
  assert.equal(afterTarget.length, 0, `${mode} after target`);
  assert.deepEqual(
    before.filter((diagnostic) => !own(diagnostic)).map(JSON.stringify).sort(),
    after.filter((diagnostic) => !own(diagnostic)).map(JSON.stringify).sort(),
    `${mode} unrelated diagnostics`
  );
  assert.deepEqual(
    before.filter((diagnostic) => own(diagnostic) && !target(diagnostic)).map(stable).sort(),
    after.filter((diagnostic) => own(diagnostic) && !target(diagnostic)).map(stable).sort(),
    `${mode} file non-target diagnostics`
  );
  result[mode === "" ? "syntactic" : "typeAware"] = {
    total: `${before.length} -> ${after.length}`,
    file: `${before.filter(own).length} -> ${after.filter(own).length}`,
    target: "8 -> 0",
    unrelatedExact: true,
    fileNonTargetStable: true,
    expectedComplexityMessageOnlyDrift: true,
  };
}

console.log(JSON.stringify(result, null, 2));
