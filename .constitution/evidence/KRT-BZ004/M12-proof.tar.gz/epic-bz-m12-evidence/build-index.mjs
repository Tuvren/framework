import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const directory = "/tmp/epic-bz-m12-evidence";
const sha256 = (buffer) =>
  crypto.createHash("sha256").update(buffer).digest("hex");
const names = () => fs.readdirSync(directory).sort();
const payloadNames = names().filter(
  (name) => name !== "evidence-index.json" && name !== "evidence-sha256.txt"
);
const checksumText = `${payloadNames
  .map((name) => `${sha256(fs.readFileSync(path.join(directory, name)))}  ${name}`)
  .join("\n")}\n`;
fs.writeFileSync(path.join(directory, "evidence-sha256.txt"), checksumText);
const indexedNames = names().filter((name) => name !== "evidence-index.json");
const index = {
  schemaVersion: 1,
  ticket: "KRT-BZ003",
  milestone: "M12",
  fileCount: indexedNames.length,
  files: indexedNames.map((name) => {
    const buffer = fs.readFileSync(path.join(directory, name));
    return { name, sha256: sha256(buffer), bytes: buffer.length };
  }),
};
fs.writeFileSync(
  path.join(directory, "evidence-index.json"),
  `${JSON.stringify(index, null, 2)}\n`
);
