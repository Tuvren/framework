#!/usr/bin/env zsh
setopt NO_ERREXIT

evidence=/tmp/epic-bz-m12-evidence
typeset -i failures=0

run_gate() {
  local name=$1
  shift
  "$@" > "$evidence/$name.log" 2>&1
  local status_code=$?
  print -r -- "$status_code" > "$evidence/$name.exit"
  print -r -- "$name\t$status_code"
  if (( status_code != 0 )); then
    (( failures += 1 ))
    tail -40 "$evidence/$name.log"
  fi
}

run_gate focused-ordering bun test \
  typescript/providers/bridge-ai-sdk/test/ai-sdk-provider-bridge-runtime.test.ts \
  typescript/providers/bridge-ai-sdk/test/ai-sdk-provider-bridge-rejections.test.ts \
  typescript/providers/bridge-ai-sdk/test/ai-sdk-provider-bridge-tool-calls.test.ts
run_gate bridge-test bun test typescript/providers/bridge-ai-sdk
run_gate bridge-typecheck bun run nx run providers-bridge-ai-sdk:typecheck
run_gate bridge-lint bun run nx run providers-bridge-ai-sdk:lint
run_gate bridge-build bun run nx run providers-bridge-ai-sdk:build
run_gate fresh-process-import bun -e \
  'const m=await import("./typescript/providers/bridge-ai-sdk/src/lib/ai-sdk-provider-bridge.ts"); console.log(JSON.stringify({exports:Object.keys(m).sort()}))'
run_gate fresh-process-comparison cmp \
  "$evidence/fresh-process-import.log" \
  /tmp/bz-m11-review/epic-bz-m11-evidence/fresh-process-import.log
run_gate formatter-check bunx --bun oxfmt --check \
  typescript/providers/bridge-ai-sdk/src/lib/ai-sdk-provider-bridge.ts
run_gate diff-check git diff --check
run_gate workspace-typecheck bun run typecheck
run_gate workspace-conformance bun run conformance
run_gate provider-testkit-conformance bun run nx run providers-testkit:conformance
run_gate provider-certification-conformance bun run nx run providers-typescript-certification:conformance
run_gate changeset-check bun run changeset:check --base=master
run_gate constitution-validate bun run \
  /home/oscar/.codex/skills/constitution-tooling/scripts/cli.ts validate --root .

print -r -- "$failures" > "$evidence/gate-failures.count"
(( failures == 0 ))
