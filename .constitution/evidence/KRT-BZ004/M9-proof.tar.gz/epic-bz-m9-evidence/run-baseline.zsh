#!/usr/bin/env zsh

set +e

evidence_dir=/tmp/epic-bz-m9-evidence
run_env=(
  direnv exec . env
  PGHOST=/run/user/1000/devenv-3ea1e50/postgres
  PGPORT=5432
)

${run_env[@]} bunx --bun oxlint --type-aware --format=json typescript/providers/testkit > $evidence_dir/oxlint-type-aware-before.json 2> $evidence_dir/oxlint-type-aware-before.stderr
print -r -- $? > $evidence_dir/oxlint-type-aware-before.exit

${run_env[@]} bun run nx run providers-testkit:typecheck > $evidence_dir/providers-testkit-typecheck-before.log 2>&1
print -r -- $? > $evidence_dir/providers-testkit-typecheck-before.exit

${run_env[@]} bun run nx run providers-testkit:test > $evidence_dir/providers-testkit-test-before.log 2>&1
print -r -- $? > $evidence_dir/providers-testkit-test-before.exit

${run_env[@]} bun -e 'const module = await import("./typescript/providers/testkit/src/index.ts"); const fixtures = module.providerTestkitFixtures; const provider = module.createStaticTuvrenProvider(); const response = await provider.generate(fixtures.prompt); console.log(JSON.stringify({ exports: Object.keys(module).sort(), fixturePrompt: fixtures.prompt, response }))' > $evidence_dir/fresh-process-before.log 2>&1
print -r -- $? > $evidence_dir/fresh-process-before.exit
