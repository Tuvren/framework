import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const ts = await import(path.join(root, "node_modules/typescript/lib/typescript.js"));
const target = process.argv[2];

if (target === undefined) {
  throw new Error("expected one target file");
}

const configFile = ts.readConfigFile(
  "typescript/providers/testkit/tsconfig.typecheck.json",
  ts.sys.readFile
);
if (configFile.error) {
  throw new Error("invalid providers-testkit typecheck config");
}

const config = ts.parseJsonConfigFileContent(
  configFile.config,
  ts.sys,
  path.resolve("typescript/providers/testkit")
);
const program = ts.createProgram(config.fileNames, config.options);
const checker = program.getTypeChecker();
const printer = ts.createPrinter();
const source = program.getSourceFile(path.resolve(target));

if (source === undefined) {
  throw new Error(`missing source file ${target}`);
}

const original = fs.readFileSync(target, "utf8");
const statements = [...source.statements];
const ownerBySymbol = new Map();

for (const statement of statements) {
  const visit = (node) => {
    if (ts.isIdentifier(node)) {
      const symbol = checker.getSymbolAtLocation(node);
      if (symbol !== undefined && symbol.declarations?.some((declaration) => declaration === node || declaration.name === node)) {
        ownerBySymbol.set(symbol, statement);
      }
    }
    ts.forEachChild(node, visit);
  };
  visit(statement);
}

const dependencies = new Map();
for (const statement of statements) {
  const found = new Set();
  const visit = (node) => {
    if (ts.isIdentifier(node)) {
      const owner = ownerBySymbol.get(checker.getSymbolAtLocation(node));
      if (owner !== undefined && owner !== statement) {
        found.add(owner);
      }
    }
    ts.forEachChild(node, visit);
  };
  visit(statement);
  dependencies.set(statement, [...found].sort((left, right) => statements.indexOf(left) - statements.indexOf(right)));
}

const converted = new Map();
for (const statement of statements) {
  if (!ts.isFunctionDeclaration(statement)) {
    converted.set(statement, original.slice(statement.getFullStart(), statement.end));
    continue;
  }

  if (statement.name === undefined || statement.body === undefined || statement.type === undefined || statement.typeParameters !== undefined) {
    throw new Error(`unsupported function declaration in ${target}`);
  }

  const lexical = [];
  const inspect = (node) => {
    if (
      node.kind === ts.SyntaxKind.ThisKeyword ||
      (ts.isMetaProperty(node) && node.keywordToken === ts.SyntaxKind.NewKeyword) ||
      (ts.isIdentifier(node) && node.text === "arguments") ||
      (ts.isFunctionLike(node) && node.asteriskToken !== undefined)
    ) {
      lexical.push(node.getText(source));
    }
    ts.forEachChild(node, inspect);
  };
  inspect(statement.body);
  if (lexical.length > 0) {
    throw new Error(`lexical-sensitive function ${statement.name.text}`);
  }

  const open = statement.getChildren(source).find((node) => node.kind === ts.SyntaxKind.OpenParenToken);
  if (open === undefined) {
    throw new Error(`missing parameters for ${statement.name.text}`);
  }

  const leading = original.slice(statement.getFullStart(), statement.getStart(source));
  const exported = statement.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.ExportKeyword) === true ? "export " : "";
  const asyncPrefix = statement.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword) === true ? "async " : "";
  const signature = original.slice(open.getStart(source), statement.body.getStart(source)).trimEnd();
  const assertion = ts.isTypePredicateNode(statement.type) && statement.type.assertsModifier !== undefined;
  let annotation = "";

  if (assertion) {
    const signatures = checker.getSignaturesOfType(
      checker.getTypeAtLocation(statement.name),
      ts.SignatureKind.Call
    );
    if (signatures.length !== 1) {
      throw new Error(`unexpected assertion overloads for ${statement.name.text}`);
    }
    const declaration = checker.signatureToSignatureDeclaration(
      signatures[0],
      ts.SyntaxKind.FunctionType,
      source,
      ts.NodeBuilderFlags.NoTruncation
    );
    if (declaration === undefined) {
      throw new Error(`missing callable signature for ${statement.name.text}`);
    }
    annotation = `: ${printer.printNode(ts.EmitHint.Unspecified, declaration, source)}`;
  }

  converted.set(
    statement,
    `${leading}${exported}const ${statement.name.text}${annotation} = ${asyncPrefix}${signature} => ${statement.body.getText(source)};`
  );
}

const done = new Set();
const active = new Set();
const ordered = [];
const emit = (statement) => {
  if (done.has(statement)) {
    return;
  }
  if (active.has(statement)) {
    throw new Error(`mutual top-level dependency in ${target}`);
  }
  active.add(statement);
  for (const dependency of dependencies.get(statement)) {
    emit(dependency);
  }
  active.delete(statement);
  done.add(statement);
  ordered.push(statement);
};

for (const statement of statements) {
  emit(statement);
}

const trailing = original.slice(statements.at(-1)?.end ?? 0);
const updated = `${ordered.map((statement) => converted.get(statement)).join("")}${trailing}`;
const oldLines = original.split("\n");
const newLines = updated.split("\n");

process.stdout.write("*** Begin Patch\n");
process.stdout.write(`*** Update File: ${path.resolve(target)}\n`);
process.stdout.write("@@\n");
for (const line of oldLines) {
  process.stdout.write(`-${line}\n`);
}
for (const line of newLines) {
  process.stdout.write(`+${line}\n`);
}
process.stdout.write("*** End Patch\n");
