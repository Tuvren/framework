#!/usr/bin/env zsh

set +e

evidence_dir=/tmp/epic-bz-m9-evidence
run_env=(
  direnv exec . env
  PGHOST=/run/user/1000/devenv-3ea1e50/postgres
  PGPORT=5432
)

${run_env[@]} bunx --bun oxlint --type-aware --format=json typescript/providers/testkit > $evidence_dir/oxlint-type-aware-after.json 2> $evidence_dir/oxlint-type-aware-after.stderr
print -r -- $? > $evidence_dir/oxlint-type-aware-after.exit

${run_env[@]} jq -e '([.diagnostics[] | select(.code == "eslint(func-style)" or .code == "eslint(no-use-before-define")] | length) == 0' $evidence_dir/oxlint-type-aware-after.json > $evidence_dir/ordering-rule-proof-after.log 2>&1
print -r -- $? > $evidence_dir/ordering-rule-proof-after.exit

${run_env[@]} bunx --bun oxfmt --check \
  typescript/providers/testkit/src/lib/provider-testkit.ts \
  typescript/providers/testkit/src/lib/provider-conformance-fixtures.ts \
  typescript/providers/testkit/src/lib/mock-mcp-server.ts \
  typescript/providers/testkit/test/mock-mcp-server.test.ts \
  > $evidence_dir/oxfmt-check-after.log 2>&1
print -r -- $? > $evidence_dir/oxfmt-check-after.exit

${run_env[@]} bun /tmp/epic-bz-m9-evidence/structural-proof.mjs > $evidence_dir/structural-proof-after.json 2> $evidence_dir/structural-proof-after.stderr
print -r -- $? > $evidence_dir/structural-proof-after.exit

${run_env[@]} bun -e 'const module = await import("./typescript/providers/testkit/src/index.ts"); const fixtures = module.providerTestkitFixtures; const provider = module.createStaticTuvrenProvider(); const response = await provider.generate(fixtures.prompt); console.log(JSON.stringify({ exports: Object.keys(module).sort(), fixturePrompt: fixtures.prompt, response }))' > $evidence_dir/fresh-process-after.log 2>&1
print -r -- $? > $evidence_dir/fresh-process-after.exit

cmp -s <(tail -n 1 $evidence_dir/fresh-process-before.log) <(tail -n 1 $evidence_dir/fresh-process-after.log)
print -r -- $? > $evidence_dir/fresh-process-comparison.exit

${run_env[@]} bun run nx run providers-testkit:typecheck > $evidence_dir/providers-testkit-typecheck-after.log 2>&1
print -r -- $? > $evidence_dir/providers-testkit-typecheck-after.exit

${run_env[@]} bun run nx run providers-testkit:test > $evidence_dir/providers-testkit-test-after.log 2>&1
print -r -- $? > $evidence_dir/providers-testkit-test-after.exit

${run_env[@]} VERIFY_SERIAL=1 NX_PARALLEL=1 bun run typecheck > $evidence_dir/workspace-typecheck-after.log 2>&1
print -r -- $? > $evidence_dir/workspace-typecheck-after.exit

${run_env[@]} bun run conformance > $evidence_dir/workspace-conformance-after.log 2>&1
print -r -- $? > $evidence_dir/workspace-conformance-after.exit

${run_env[@]} bun run nx run providers-testkit:conformance > $evidence_dir/providers-testkit-conformance-after.log 2>&1
print -r -- $? > $evidence_dir/providers-testkit-conformance-after.exit

${run_env[@]} bun run nx run providers-typescript-certification:conformance > $evidence_dir/providers-certification-conformance-after.log 2>&1
print -r -- $? > $evidence_dir/providers-certification-conformance-after.exit

${run_env[@]} bun run changeset:check > $evidence_dir/changeset-check-after.log 2>&1
print -r -- $? > $evidence_dir/changeset-check-after.exit

git diff --check > /tmp/epic-bz-m9-evidence/diff-check-after.log 2>&1
print -r -- $? > /tmp/epic-bz-m9-evidence/diff-check-after.exit
