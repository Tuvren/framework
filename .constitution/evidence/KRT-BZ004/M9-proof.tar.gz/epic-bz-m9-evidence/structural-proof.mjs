import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const ts = await import(path.join(root, "node_modules/typescript/lib/typescript.js"));
const printer = ts.createPrinter({ removeComments: true });
const files = [
  "typescript/providers/testkit/src/lib/provider-testkit.ts",
  "typescript/providers/testkit/src/lib/provider-conformance-fixtures.ts",
  "typescript/providers/testkit/src/lib/mock-mcp-server.ts",
  "typescript/providers/testkit/test/mock-mcp-server.test.ts",
];

const print = (node, source) => printer.printNode(ts.EmitHint.Unspecified, node, source);
const semanticBody = (body, source) => {
  if (
    ts.isBlock(body) &&
    body.statements.length === 1 &&
    ts.isReturnStatement(body.statements[0]) &&
    body.statements[0].expression !== undefined
  ) {
    return print(ts.skipParentheses(body.statements[0].expression), source);
  }
  return print(ts.skipParentheses(body), source);
};
const baselineFunctions = (source) =>
  source.statements.filter(ts.isFunctionDeclaration).map((statement) => ({
    async: statement.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword) === true,
    body: semanticBody(statement.body, source),
    exported: statement.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.ExportKeyword) === true,
    name: statement.name.text,
    parameters: statement.parameters.map((parameter) => print(parameter, source)),
    returnType: print(statement.type, source),
  }));

const convertedFunctions = (source) => {
  const found = [];
  for (const statement of source.statements) {
    if (!ts.isVariableStatement(statement) || statement.declarationList.declarations.length !== 1) {
      continue;
    }
    const [declaration] = statement.declarationList.declarations;
    if (!ts.isIdentifier(declaration.name) || !ts.isArrowFunction(declaration.initializer)) {
      continue;
    }
    const arrow = declaration.initializer;
    found.push({
      async: arrow.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword) === true,
      body: semanticBody(arrow.body, source),
      exported: statement.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.ExportKeyword) === true,
      name: declaration.name.text,
      parameters: arrow.parameters.map((parameter) => print(parameter, source)),
      returnType: print(arrow.type, source),
    });
  }
  return found;
};

const result = { files: [], totals: { converted: 0, exported: 0 } };
for (const file of files) {
  const beforeText = execFileSync("git", ["show", `HEAD:${file}`], { encoding: "utf8" });
  const afterText = fs.readFileSync(file, "utf8");
  const before = ts.createSourceFile(`${file}.before`, beforeText, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const after = ts.createSourceFile(`${file}.after`, afterText, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const expected = baselineFunctions(before).sort((left, right) => left.name.localeCompare(right.name));
  const actual = convertedFunctions(after)
    .filter((candidate) => expected.some(({ name }) => name === candidate.name))
    .sort((left, right) => left.name.localeCompare(right.name));

  assert.deepEqual(actual, expected, `${file} callable structure changed`);
  result.files.push({
    file,
    converted: expected.length,
    exported: expected.filter(({ exported }) => exported).length,
    bodiesParametersDefaultsReturnsExportsAndAsyncEqual: true,
  });
  result.totals.converted += expected.length;
  result.totals.exported += expected.filter(({ exported }) => exported).length;
}

assert.equal(result.totals.converted, 37);
assert.equal(result.totals.exported, 13);
process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
