#!/usr/bin/env zsh

set +e

direnv exec . bun /tmp/epic-bz-m9-evidence/structural-proof.mjs > /tmp/epic-bz-m9-evidence/structural-proof-after.json 2> /tmp/epic-bz-m9-evidence/structural-proof-after.stderr
print -r -- $? > /tmp/epic-bz-m9-evidence/structural-proof-after.exit

tail -n 1 /tmp/epic-bz-m9-evidence/fresh-process-before.log > /tmp/epic-bz-m9-evidence/fresh-process-before.json
tail -n 1 /tmp/epic-bz-m9-evidence/fresh-process-after.log > /tmp/epic-bz-m9-evidence/fresh-process-after.json
cmp -s /tmp/epic-bz-m9-evidence/fresh-process-before.json /tmp/epic-bz-m9-evidence/fresh-process-after.json
print -r -- $? > /tmp/epic-bz-m9-evidence/fresh-process-comparison.exit

jq -e '([.diagnostics[] | select(.code == "eslint(func-style)" or .code == "eslint(no-use-before-define")] | length) == 0' /tmp/epic-bz-m9-evidence/oxlint-type-aware-after.json > /tmp/epic-bz-m9-evidence/ordering-rule-proof-after.log 2>&1
print -r -- $? > /tmp/epic-bz-m9-evidence/ordering-rule-proof-after.exit
