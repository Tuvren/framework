#!/usr/bin/env zsh

set -e

evidence_dir=/tmp/epic-bz-m8-evidence
verification_env=(
  direnv exec . env
  PGHOST=/run/user/1000/devenv-3ea1e50/postgres
  PGPORT=5432
)

${verification_env[@]} bun run nx run providers-typescript-certification:typecheck > $evidence_dir/providers-certification-typecheck-after.log 2>&1
print -r -- 0 > $evidence_dir/providers-certification-typecheck-after.exit

${verification_env[@]} bun run nx run providers-typescript-certification:test > $evidence_dir/providers-certification-test-after.log 2>&1
print -r -- 0 > $evidence_dir/providers-certification-test-after.exit

${verification_env[@]} bun run nx run provider-api:typecheck > $evidence_dir/provider-api-typecheck-after.log 2>&1
print -r -- 0 > $evidence_dir/provider-api-typecheck-after.exit

${verification_env[@]} bun run nx run provider-api:test > $evidence_dir/provider-api-test-after.log 2>&1
print -r -- 0 > $evidence_dir/provider-api-test-after.exit

${verification_env[@]} bunx --bun oxfmt --check \
  typescript/providers/provider-api/test/provider-api.test.ts \
  typescript/providers/provider-api/test/provider-api-module-initialization.test.ts \
  typescript/providers/certification/test/providers-typescript-conformance.test.ts \
  > $evidence_dir/oxfmt-check-after.log 2>&1
print -r -- 0 > $evidence_dir/oxfmt-check-after.exit

${verification_env[@]} bun run conformance > $evidence_dir/workspace-conformance-after.log 2>&1
print -r -- 0 > $evidence_dir/workspace-conformance-after.exit

${verification_env[@]} bun run nx run providers-testkit:conformance > $evidence_dir/providers-testkit-conformance-after.log 2>&1
print -r -- 0 > $evidence_dir/providers-testkit-conformance-after.exit

${verification_env[@]} bun run nx run providers-typescript-certification:conformance > $evidence_dir/providers-certification-conformance-after.log 2>&1
print -r -- 0 > $evidence_dir/providers-certification-conformance-after.exit

set +e
${verification_env[@]} bunx --bun oxlint --type-aware --format=json \
  typescript/providers/provider-api \
  typescript/providers/certification \
  > $evidence_dir/oxlint-type-aware-after.json
oxlint_exit=$?
set -e
print -r -- $oxlint_exit > $evidence_dir/oxlint-type-aware-after.exit

jq -e '([.diagnostics[] | select(.code == "eslint(func-style)" or .code == "eslint(no-use-before-define)")] | length) == 0' \
  $evidence_dir/oxlint-type-aware-after.json \
  > $evidence_dir/ordering-rule-proof-after.log
print -r -- 0 > $evidence_dir/ordering-rule-proof-after.exit
