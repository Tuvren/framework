import { strict as assert } from "node:assert";
import { readFile } from "node:fs/promises";
import { parse } from "/home/oscar/GitHub/Tuvren/framework-bo/node_modules/yaml/dist/index.js";
const root = "/home/oscar/GitHub/Tuvren/framework-bo";
const stack = parse(await readFile(root + "/.constitution/tech-spec/stack.yaml", "utf8"));
const lock = JSON.parse(await readFile(root + "/devenv.lock", "utf8"));
const pkg = JSON.parse(await readFile(root + "/package.json", "utf8"));
async function probe(args) {
  const p = Bun.spawn(args, { cwd: root, env: { ...process.env, LC_ALL: "C" }, stdout: "pipe", stderr: "pipe" });
  const [stdout, stderr, status] = await Promise.all([new Response(p.stdout).text(), new Response(p.stderr).text(), p.exited]);
  assert.equal(status, 0, args.join(" ") + ": " + stderr);
  return (stdout + stderr).trim();
}
const probes = [
  ["buf", ["buf", "--version"], /^([\d.]+)$/],
  ["protobuf", ["protoc", "--version"], /^libprotoc ([\d.]+)$/],
  ["protoc-gen-es", ["protoc-gen-es", "--version"], /^protoc-gen-es v([\d.]+)$/],
  ["weaver", ["weaver", "--version"], /^weaver ([\d.]+)$/],
  ["go", ["go", "version"], /^go version go([\d.]+) /],
  ["python", ["python3", "--version"], /^Python ([\d.]+)$/],
  ["dart", ["dart", "--version"], /^Dart SDK version: ([\d.]+) /],
  ["postgresql", ["psql", "--version"], /^psql \(PostgreSQL\) ([\d.]+)$/],
];
for (const [name, args, re] of probes) {
  const output = await probe(args);
  const version = re.exec(output)?.[1];
  assert.ok(version, name + ": unparsed native version " + output);
  const rec = stack.bill_of_materials.find(r => r.name === name);
  assert.ok(rec, name + ": missing record");
  assert.equal(rec.ecosystem, "nix", name);
  assert.equal(rec.version, lock.nodes.nixpkgs.locked.rev, name);
  assert.equal(/SemVer: ([\d.]+)/.exec(rec.evidence.note)?.[1], version, name);
  assert.equal(rec.evidence.ref, "devenv.lock", name);
  console.log(name + ": " + version + "; revision=" + rec.version);
}
const bun = stack.bill_of_materials.find(r => r.name === "bun");
const bunVersion = await probe(["bun", "--version"]);
assert.equal(bun.version, bunVersion);
assert.equal(pkg.packageManager, "bun@" + bunVersion);
assert.equal(bun.certainty, "settled");
assert.equal(Object.hasOwn(bun, "assumption"), false);
assert.equal(bun.evidence.ref, "devenv.lock");
const oldProcess = Bun.spawn(["git", "show", "2e32938:.constitution/tech-spec/stack.yaml"], {cwd: root, stdout:"pipe"});
const oldStack = parse(await new Response(oldProcess.stdout).text());
assert.equal(await oldProcess.exited, 0);
const changed = new Set(["bun", ...probes.map(([name]) => name)]);
for (const r of oldStack.bill_of_materials) {
  if (!changed.has(r.name)) assert.deepEqual(stack.bill_of_materials.find(c => c.name === r.name), r, r.name + ": unrelated record changed");
}
assert.equal(stack.bill_of_materials.length, oldStack.bill_of_materials.length);
assert.deepEqual(stack.compatibility_policy.lockfiles, oldStack.compatibility_policy.lockfiles);
assert.equal(stack.compatibility_policy.upgrade_boundaries, oldStack.compatibility_policy.upgrade_boundaries);
const server = await probe(["psql", "-d", "tuvren_runtime", "-Atc", "SHOW server_version_num"]);
assert.equal(server, "170011");
console.log("Bun binary/packageManager/settled record agree; PostgreSQL actual server=" + server);
console.log("All untouched dependency and future tool records unchanged; pin invariant PASS");

