// M5/KRT-BO005 stack-pin checker. Read-only against the repository; runs native probes.
// Compares every stack.yaml physical pin against the observed installed tool, the
// repository lockfiles and packageManager. Exit 1 on any mismatch.
import { $ } from "bun";
import { readFileSync } from "node:fs";

const REPO = process.argv[2] ?? "/home/oscar/GitHub/Tuvren/framework-bo";
process.chdir(REPO);

const stackPath = ".constitution/tech-spec/stack.yaml";
const stack = Bun.YAML.parse(readFileSync(stackPath, "utf8")) as any;
const recs: any[] = stack.bill_of_materials;
const byName = new Map<string, any>(recs.map((r) => [r.name, r]));

const devenvLock = JSON.parse(readFileSync("devenv.lock", "utf8"));
const nixpkgsRev: string = devenvLock.nodes.nixpkgs.locked.rev;
const rustOverlayRev: string = devenvLock.nodes["rust-overlay"].locked.rev;
const pkg = JSON.parse(readFileSync("package.json", "utf8"));

const findings: string[] = [];
const lines: string[] = [];
const ok = (msg: string) => lines.push(`OK   ${msg}`);
const bad = (msg: string) => {
  findings.push(msg);
  lines.push(`FAIL ${msg}`);
};

async function probe(cmd: string): Promise<string> {
  const out = await $`bash -c ${`export LC_ALL=C; ${cmd}`}`.text();
  return out.trim();
}

// --- native tool probes -----------------------------------------------------
const measured: Record<string, string> = {
  bun: await probe("bun --version"),
  buf: await probe("buf --version"),
  protobuf: (await probe("protoc --version")).replace(/^libprotoc\s+/, ""),
  "protoc-gen-es": (await probe("protoc-gen-es --version")).replace(/^protoc-gen-es v/, ""),
  weaver: (await probe("weaver --version")).replace(/^weaver\s+/, ""),
  go: (await probe("go version")).replace(/^go version go([^\s]+).*$/, "$1"),
  python: (await probe("python3 --version")).replace(/^Python\s+/, ""),
  dart: (await probe("dart --version")).replace(/^Dart SDK version:\s*([^\s]+).*$/, "$1"),
  postgresql: (await probe("psql --version")).replace(/^psql \(PostgreSQL\)\s+/, ""),
  rust: (await probe("rustc --version")).replace(/^rustc\s+([^\s]+).*$/, "$1"),
};
lines.push(`measured: ${JSON.stringify(measured)}`);
lines.push(`devenv.lock nixpkgs=${nixpkgsRev} rust-overlay=${rustOverlayRev}`);
lines.push("");

const semverInNote = (r: any): string | undefined => {
  const m = /SemVer:\s*([^\s(]+)/.exec(r?.evidence?.note ?? "");
  return m?.[1];
};

// --- shared nix tools: revision convention + observed SemVer ---------------
const sharedNix = ["buf", "protobuf", "protoc-gen-es", "weaver", "go", "python", "dart", "postgresql"];
for (const name of sharedNix) {
  const r = byName.get(name);
  if (!r) {
    bad(`${name}: record missing`);
    continue;
  }
  if (r.ecosystem !== "nix") bad(`${name}: ecosystem ${r.ecosystem} is not nix`);
  if (r.version !== nixpkgsRev) bad(`${name}: version ${r.version} != devenv.lock nixpkgs rev ${nixpkgsRev}`);
  if (r.evidence?.ref !== "devenv.lock") bad(`${name}: evidence ref ${r.evidence?.ref} is not devenv.lock`);
  const note = semverInNote(r);
  if (note !== measured[name]) bad(`${name}: note SemVer ${note} != measured ${measured[name]}`);
  if (findings.every((f) => !f.startsWith(`${name}:`))) ok(`${name}: nix rev ${r.version}, measured ${measured[name]}`);
}

// --- bun: packageManager + binary + devenv provisioning ---------------------
{
  const r = byName.get("bun");
  const pm: string = pkg.packageManager ?? "";
  if (!r) bad("bun: record missing");
  else {
    if (r.version !== measured.bun) bad(`bun: version ${r.version} != installed ${measured.bun}`);
    if (pm !== `bun@${measured.bun}`) bad(`bun: packageManager ${pm} != bun@${measured.bun}`);
    if (r.certainty !== "settled") bad(`bun: certainty ${r.certainty} is not settled`);
    if (r.assumption) bad("bun: assumption field still present");
    if (!r.evidence?.note || !/1\.4\.2/.test(r.evidence.note)) bad("bun: evidence note does not record the observed 1.4.2");
    if (r.evidence?.kind !== "repository" || r.evidence?.ref !== "devenv.lock") bad(`bun: evidence ${r.evidence?.kind}/${r.evidence?.ref} is not repository/devenv.lock`);
    if (!/--isolate/.test(r.evidence?.note ?? "") || !/lock/.test(r.evidence?.note ?? ""))
      bad("bun: evidence note does not record isolation default and lock-format stability");
    if (findings.every((f) => !f.startsWith("bun:"))) ok(`bun: record ${r.version} == binary == packageManager (settled)`);
  }
}

// --- rust: rust-toolchain.toml + rustc --------------------------------------
{
  const r = byName.get("rust");
  const toml = readFileSync("rust-toolchain.toml", "utf8");
  const channel = /channel\s*=\s*"([^"]+)"/.exec(toml)?.[1];
  if (!r) bad("rust: record missing");
  else {
    if (r.version !== channel) bad(`rust: version ${r.version} != rust-toolchain.toml channel ${channel}`);
    if (r.version !== measured.rust) bad(`rust: version ${r.version} != rustc ${measured.rust}`);
    if (findings.every((f) => !f.startsWith("rust:"))) ok(`rust: ${r.version} == rust-toolchain.toml == rustc`);
  }
}

// --- canonical ecosystem pins unaffected ------------------------------------
{
  const names = ["typescript", "ai", "@biomejs/biome", "nx", "@copilotkit/aimock", "tonic", "serde"];
  const bunLock = readFileSync("bun.lock", "utf8");
  const cargoLock = readFileSync("Cargo.lock", "utf8");
  const bunVer = (n: string) => new RegExp(`"${n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}":\\s*\\[\\s*"${n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}@([^"]+)"`).exec(bunLock)?.[1];
  const cargoVer = (n: string) => new RegExp(`\\[\\[package\\]\\]\\s*\\nname = "${n}"\\s*\\nversion = "([^"]+)"`).exec(cargoLock)?.[1];
  for (const name of names) {
    const r = byName.get(name);
    if (!r) {
      bad(`${name}: record missing`);
      continue;
    }
    const locked = r.ecosystem === "cargo" ? cargoVer(name) : bunVer(name);
    if (locked !== r.version) bad(`${name}: pin ${r.version} != locked ${locked}`);
    else ok(`${name}: pin ${r.version} == lockfile`);
  }
}

lines.push("");
console.log(lines.join("\n"));
console.log(findings.length ? `\nMISMATCHES: ${findings.length}` : "\nMISMATCHES: 0");
process.exit(findings.length ? 1 : 0);
