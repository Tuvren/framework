#!/usr/bin/env bash
# M5/KRT-BO005 tool probe. Read-only. Records exact command, stdout/stderr and exit code.
export LC_ALL=C
set -u
OUT=${1:-/home/oscar/.cache/pi-subagent/framework/wf-bo-m5/probe-tools.log}
REPO=/home/oscar/GitHub/Tuvren/framework-bo
cd "$REPO" || exit 1
: > "$OUT"

run() {
  printf '### CMD: %s\n' "$*" >> "$OUT"
  out=$("$@" 2>&1)
  code=$?
  printf 'EXIT: %s\n' "$code" >> "$OUT"
  printf '%s\n' "$out" >> "$OUT"
  printf '\n' >> "$OUT"
}

runp() {
  # run a shell pipeline/command string, capture combined output and exit code
  printf '### SH: %s\n' "$1" >> "$OUT"
  out=$(eval "$1" 2>&1)
  code=$?
  printf 'EXIT: %s\n' "$code" >> "$OUT"
  printf '%s\n' "$out" >> "$OUT"
  printf '\n' >> "$OUT"
}

printf '== probe context ==\nPWD=%s\nDATE=%s\nDEVENV_ROOT=%s\nDEVENV_PROFILE=%s\nIN_NIX_SHELL=%s\n\n' \
  "$PWD" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "${DEVENV_ROOT:-unset}" "${DEVENV_PROFILE:-unset}" "${IN_NIX_SHELL:-unset}" >> "$OUT"

printf '== resolved binary paths ==\n' >> "$OUT"
for c in bun node weaver psql buf protoc protoc-gen-es go python3 dart rustc cargo nix; do
  printf '%s -> %s\n' "$c" "$(command -v "$c" 2>/dev/null || echo '<absent>')" >> "$OUT"
done
printf '\n' >> "$OUT"

runp 'bun --version'
runp 'bun --revision'
runp 'node --version'
runp 'weaver --version'
runp 'psql --version'
runp 'buf --version'
runp 'protoc --version'
runp 'protoc-gen-es --version'
runp 'go version'
runp 'python3 --version'
runp 'dart --version'
runp 'rustc --version'
runp 'cargo --version'

echo "log: $OUT"
